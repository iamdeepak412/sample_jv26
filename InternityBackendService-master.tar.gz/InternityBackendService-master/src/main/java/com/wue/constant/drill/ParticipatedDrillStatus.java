package com.wue.constant.drill;

public enum ParticipatedDrillStatus {
    CREATE_OR_JOIN_TEAM("Create/Join a team"),
    SUBMIT_OR_UPDATE_SOLUTION("Submit/Update your solution");

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    ParticipatedDrillStatus(String value){this.value=value;}

}