package com.wue.constant;

public enum UserProfileOtherDetailsType {
        CERTIFICATE,
        WORK_TO_HIGHLIGHT,
        PATENT,
        WHITEPAPER,
        EXTRA_CURRICULAR
}
