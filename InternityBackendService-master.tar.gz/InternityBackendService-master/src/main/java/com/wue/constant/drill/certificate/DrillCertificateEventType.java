package com.wue.constant.drill.certificate;

public enum DrillCertificateEventType {
    DRILL,
    WORKSHOP,
    CONFERENCE
}
