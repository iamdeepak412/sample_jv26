package com.wue.constant.drill;

public enum InvitationType {
	

    INVITEONLY("Invite only"),
    PUBLIC("Public");
	
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    InvitationType(String value){
    	
    	this.value=value;
    
    }

}
