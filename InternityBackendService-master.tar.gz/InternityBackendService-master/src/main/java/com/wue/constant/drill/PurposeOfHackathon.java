package com.wue.constant.drill;

public enum PurposeOfHackathon {
    HIRING("Hiring"),
    INNOVATION("Innovation");

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    PurposeOfHackathon(String value){this.value=value;}
}

