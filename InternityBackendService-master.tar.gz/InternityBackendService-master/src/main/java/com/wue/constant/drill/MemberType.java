package com.wue.constant.drill;

public enum MemberType {
    TEAMLEAD,
    TEAMMEMBER
}
