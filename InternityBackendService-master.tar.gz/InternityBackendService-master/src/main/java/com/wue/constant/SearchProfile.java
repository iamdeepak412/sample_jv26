package com.wue.constant;

public enum SearchProfile
{
    BASIC,
    DETAILED
}
