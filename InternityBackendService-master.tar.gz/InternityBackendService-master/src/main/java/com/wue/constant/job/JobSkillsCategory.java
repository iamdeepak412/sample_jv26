package com.wue.constant.job;

public enum JobSkillsCategory {
    MANDATORY("MANDATORY"),
    SECONDARY("SECONDARY"),
    ADDITIONAL("ADDITIONAL")
    ;

    private String value;

    public String getEnumValue() {
        return value;
    }

    JobSkillsCategory(String value) {
        this.value = value;
    }

}
