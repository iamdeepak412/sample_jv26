package com.wue.constant.drill;

public enum DrillChatPlatform {
    WHATSAPP,
    DISCORD,
    TELEGRAM,
    SLACK
}
