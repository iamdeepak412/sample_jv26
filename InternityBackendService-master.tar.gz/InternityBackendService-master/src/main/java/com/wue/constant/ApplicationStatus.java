package com.wue.constant;

public enum ApplicationStatus {
    APPLIED("APPLIED"),
    SCREEN_SELECT("SCREEN SELECT"),
    INTERVIEW("INTERVIEW"),
    OFFERED("OFFERED"),
    JOINED("JOINED"),
    REJECTED("REJECTED"),
    AUTO_SCREENED_SELECT("AUTO SCREENED SELECT"),
    AUTO_SCREENED_REJECT("AUTO SCREENED REJECT"),
    SHORTLISTED("SHORTLISTED"),
    APPLICATION_SENT("APPLICATION SENT"),
    INTERVIEW_SCHEDULED("INTERVIEW SCHEDULED"),
    ROUND_1("ROUND 1"),
    ROUND_2("ROUND 2"),
    ROUND_3("ROUND 3"),
    ROUND_4("ROUND 4"),
    ROUND_5("ROUND 5"),
    ROUND_6("ROUND 6"),
    ROUND_7("ROUND 7"),
    ROUND_8("ROUND 8"),
    ROUND_9("ROUND 9"),
    ROUND_10("ROUND 10"),
    ROUND_11("ROUND 11"),
    ROUND_12("ROUND 12"),
    ROUND_13("ROUND 13"),
    ROUND_14("ROUND 14"),
    ROUND_15("ROUND 15"),
    ALL_ROUNDS_SELECTED("ALL ROUNDS SELECTED"),
    HR_DISCUSSION("HR DISCUSSION"),
    OFFER_SENT("OFFER SENT"),
    OFFER_ACCEPTED("OFFER ACCEPTED"),
    OFFER_REJECTED("OFFER REJECTED"),
    ONHOLD("ON HOLD");
    ;

    private String value;

    public String getEnumValue() {
        return value;
    }

    ApplicationStatus(String value) {
        this.value = value;
    }
//
//    @Override
//    public String toString() {
//        return value;
//    }
}
