package com.wue.constant;

public enum NotificationType {
    GENERAL,
    JOBUPDATE
}
