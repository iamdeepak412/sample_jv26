package com.wue.constant.drill;

public enum DrillRequestType {

    PUBLISH,
    UNPUBLISH
}
