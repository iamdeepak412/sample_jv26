package com.wue.constant.drill;

public enum HackathonStatus {
	
    LIVE("Live"),
    COMPLETE("Completed"),
    UPCOMING("Upcoming");
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    HackathonStatus(String value){
    	
    	this.value=value;
    
    }

}
