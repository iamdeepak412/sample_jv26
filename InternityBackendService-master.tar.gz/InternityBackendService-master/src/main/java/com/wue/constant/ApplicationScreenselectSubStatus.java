package com.wue.constant;

public enum ApplicationScreenselectSubStatus {

    AUTO_SELECT("AUTO SELECT");

    private String value;

    public String getEnumValue() {
        return value;
    }

    ApplicationScreenselectSubStatus(String value) {
        this.value = value;
    }


}
