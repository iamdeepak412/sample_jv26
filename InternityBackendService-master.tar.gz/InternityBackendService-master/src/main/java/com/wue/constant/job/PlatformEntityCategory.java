package com.wue.constant.job;

public enum PlatformEntityCategory {
    JOB("JOB"),
    HACKATHON("HACKATHON")
    ;

    private String value;

    public String getEnumValue() {
        return value;
    }

    PlatformEntityCategory(String value) {
        this.value = value;
    }

}
