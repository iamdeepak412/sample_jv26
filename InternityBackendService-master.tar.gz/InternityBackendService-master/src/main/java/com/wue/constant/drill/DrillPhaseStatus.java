package com.wue.constant.drill;

public enum DrillPhaseStatus {
    TOBEGIN,
    RUNNING,
    COMPLETE
}
