package com.wue.constant.drill;

public enum DrillEligibilityType {

    STUDENT("Student"),
    EXPERIENCED("Experienced");

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    DrillEligibilityType(String value){
    	
    	this.value=value;
    
    }

}
