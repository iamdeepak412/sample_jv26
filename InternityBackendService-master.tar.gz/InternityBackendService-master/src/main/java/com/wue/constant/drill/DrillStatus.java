package com.wue.constant.drill;

public enum DrillStatus {
    LIVE,
    UPCOMING,
    ACTIVE,
    INACTIVE,
    REQUESTUNAPPROVED,
    COMPLETED
}
