package com.wue.constant.drill;

public enum CollaboratorType {
    SPONSOR("Sponsor"),
    PLATFORM_PARTNER("Platform partner"),
    MEDIA_PARTNER("Media Partner"),
    IN_KIND_SPONSOR("In-kind Sponsor"),
    PROMOTIONAL_PARTNER("Promotional partner"),
    VENUE_PARTNER("Venue partner"),
    FOOD_PARTNER("Food partner");

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    CollaboratorType(String value){this.value=value;}
    }
