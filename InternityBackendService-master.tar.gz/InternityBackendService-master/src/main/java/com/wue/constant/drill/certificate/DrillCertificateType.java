package com.wue.constant.drill.certificate;

public enum DrillCertificateType {
    PARTICIPANTS,
    WINNERS,
    OTHER
}
