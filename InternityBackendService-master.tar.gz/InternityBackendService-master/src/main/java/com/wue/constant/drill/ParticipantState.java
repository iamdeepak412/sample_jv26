package com.wue.constant.drill;

public enum ParticipantState {
    NOTPARTICIPANT("NotParticipant"),
    PARTICIPANT("Participant"),
    SHORTLISTED("Shortlisted"),
    FIGHTER("Fighter"),
    WINNER("Winner"),
    HIRED("Hired"),
    JOINEDTEAM("JoinedTeam"),
    SOLUTIONSUBMITTED("SolutionSubmitted");

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    ParticipantState(String value){this.value=value;}
    }
