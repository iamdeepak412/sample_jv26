package com.wue.constant;

public enum ApplicationRejectSubStatus {

    DUPLICATE("DUPLICATE"),
    LOCATIONISSUE("LOCATION ISSUE"),
    IRRELEVANT("IRRELEVANT"),
    HIGHNOTICEPERIOD("HIGH NOTICE PERIOD"),
    AUTO_REJECT("AUTO REJECT");

    private String value;

    public String getEnumValue() {
        return value;
    }

    ApplicationRejectSubStatus(String value) {
        this.value = value;
    }


}
