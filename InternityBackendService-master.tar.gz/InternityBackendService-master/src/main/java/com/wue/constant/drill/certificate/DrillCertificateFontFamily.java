package com.wue.constant.drill.certificate;

import lombok.Getter;

@Getter
public enum DrillCertificateFontFamily {
    ARIAL("Arial"),
    TIMES_NEW_ROMAN("Times New Roman"),
    CALIBRI("Calibri"),
    VERDANA("Verdana"),
    COURIER_NEW("Courier New"),
    GEORGIA("Georgia"),
    PALATINO("Palatino Linotype"),
    IMPACT("Impact"),
    TREBUCHET_MS("Trebuchet MS"),
    LUCIDA_CONSOLE("Lucida Console"),
    GARAMOND("Garamond"),
    CONSOLAS("Consolas"),
    BOOKMAN_OLD_STYLE("Bookman Old Style"),
    CANDARA("Candara"),
    ARIAL_NARROW("Arial Narrow"),
    COMIC_SANS_MS("Comic Sans MS");

    private final String familyName;

    DrillCertificateFontFamily(String familyName) {
        this.familyName = familyName;
    }

}
