package com.wue.constant.drill;

public enum NatureOfHackathon {
    //ONLINEINTERACTIVE("Online Interactive"),
    ONLINE("Online"),
    INPERSON("In-Person"),
    HYBRID("Hybrid");
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    NatureOfHackathon(String value){this.value=value;}
}

