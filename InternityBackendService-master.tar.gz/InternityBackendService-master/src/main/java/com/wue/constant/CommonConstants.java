package com.wue.constant;

public final class CommonConstants {

	public static final String AUTH_UID = "AUTH_UID";
	public static final String AUTHORIZATION = "Authorization";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILED = "FAILED";
	public static final String ON_HOLD = "ON_HOLD";
	public static final String NO_SUCH_APPLICATION_EXISTS = "NO_SUCH_APPLICATION_EXISTS";
	public static final String NO_SUCH_JOB_EXISTS = "NO_SUCH_JOB_EXISTS";

	// Verify User

	public static final String FORGOTPASSWORD = "FORGOTPASSWORD";
	public static final String REGISTER = "REGISTER";

	// User Profile

	public static  final String COMPLETE_PROFILE="completeprofile";

	//Message or Mail

    public static final String MSG_91_AUTH_KEY = "";
    public static final String MSG_91_SENDER_ID = "";
    public static final String MSG_91_OTP_TEMPLATE = "";
    public static final Integer PAGE_SIZE = 10;

	public static final String APP_DOWNLOAD_URL = "https://whereuelevate.com";

	public static final String APP_SUCCESS = "Successful request";
	public static final String APP_FAILED = "Failed request";

	//Application status
	public static final String ID = "id";
	public static final String SRNO = "srno";
	public static final String STEP = "step";
	public static final String STEP_STATUS = "stepStatus";
	public static final String FEEDBACK = "feedback";
	public static final String STEP_TIME = "stepTime";

	//response constants
	public static final String MSG = "msg";
	public static final String ERROR = "error";

	//Drill
	public static final String VALIDATION_KEY="VALIDATION";
	
	//OrganisationAndAcademicInstitute
	public static final String ORGANISATION = "ORGANISATION";
	public static final String ACADEMICINSTITUTE = "ACADEMICINSTITUTE";

	//Total YoE
	public static final String TOTAL_YOE = "TOTAL_YOE";

	//Answer Type
	public static final String BOOLEAN = "BOOLEAN";
	public static final String RANGE = "RANGE";
	public static final String SUBJECTIVE = "SUBJECTIVE";
	public static final String NUMERIC = "NUMERIC";

}
