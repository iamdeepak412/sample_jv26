package com.wue.constant.drill.certificate;

public enum DrillCertificateFieldType {
    PREDEFINED,
    CUSTOM
}
