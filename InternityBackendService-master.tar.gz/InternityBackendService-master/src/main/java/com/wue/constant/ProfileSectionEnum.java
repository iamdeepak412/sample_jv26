package com.wue.constant;

public enum ProfileSectionEnum {
    PERSONAL("personal"),
    EDUCATION("education"),
    SKILL("skill"),
    WORK("work"),
    PROJECT("project"),
    OTHER("other")
    ;

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    ProfileSectionEnum(String value){
        this.value = value.toLowerCase();
    }
}
