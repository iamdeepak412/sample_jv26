package com.wue.constant.application;

import lombok.Getter;

@Getter
public enum ApplicationStages {
    APPLIED("APPLIED"),
    SCREEN_SELECT("SCREEN SELECT"),
    INTERVIEW("INTERVIEW"),
    OFFERED("OFFERED"),
    JOINED("JOINED"),
    REJECTED("REJECTED");

    private final String stage;

    ApplicationStages(String stage) {
        this.stage = stage;
    }

    public static ApplicationStages fromValue(String value) {
        for (ApplicationStages stage : ApplicationStages.values()) {
            if (stage.stage.equalsIgnoreCase(value)) {
                return stage;
            }
        }
        return null; // Or throw an IllegalArgumentException if value not found
    }
}