package com.wue.constant.application;

import lombok.Getter;

@Getter
public enum ApplicationRejectedReasons {
    LOCATION_ISSUE("Location Issue"),
    HIGH_NOTICE_PERIOD("High Notice Period"),
    DUPLICATE("Duplicate"),
    IRRELEVANT("Irrelevant"),
    HIGH_SALARY_EXCEPTION("High Salary Exception"),
    OVER_QUALIFIED("Over Qualified"),
    UNDER_QUALIFIED("Under Qualified"),
    LACK_OF_EXPERIENCE("Lack of Experience"),
    POOR_INTERVIEW_PERFORMANCE("Poor Interview Performance"),
    CULTURAL_MISMATCH("Cultural Mismatch"),
    UNPROFESSIONAL_BEHAVIOR("Unprofessional Behavior"),
    LACK_OF_SOFT_SKILLS("Lack of Soft Skills"),
    WRONG_CAREER_PATH("Wrong Career Path"),
    LACK_OF_EDUCATION("Lack of Education"),
    PERSONALITY_MISMATCH("Personality Mismatch"),
    TECHNICAL_INCOMPETENCE("Technical Incompetence"),
    LACK_OF_INITIATIVE("Lack of Initiative"),
    POOR_COMMUNICATION_SKILLS("Poor Communication Skills"),
    INSUFFICIENT_LEADERSHIP_QUALITIES("Insufficient Leadership Qualities"),
    OTHER("Other");

    private final String reason;

    ApplicationRejectedReasons(String reason) {
        this.reason = reason;
    }

    public static ApplicationRejectedReasons fromValue(String value) {
        for (ApplicationRejectedReasons reason : ApplicationRejectedReasons.values()) {
            if (reason.reason.equalsIgnoreCase(value)) {
                return reason;
            }
        }
        return null; // Or throw an IllegalArgumentException if value not found
    }
}