package com.wue.constant;

public enum TestimonialCategoryType {
    CUSTOMER,
    USER
}
