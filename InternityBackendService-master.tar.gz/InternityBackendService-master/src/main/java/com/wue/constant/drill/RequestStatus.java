package com.wue.constant.drill;

public enum RequestStatus {
    ALL,
    PENDING,
    APPROVED,
    REJECTED
}
