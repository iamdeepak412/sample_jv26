package com.wue.constant;

public enum AuthenticationPlatform {
    GOOGLE,
    FACEBOOK,
    GITHUB,
    LINKEDIN,
    TWITTER
}
