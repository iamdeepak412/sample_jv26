package com.wue.constant;

public enum UserRoles {
    USER,
    ADMIN,
    SUPERADMIN,
    WUEADMIN,
    WUESUPERADMIN,
    DRILLADMIN,
    DRILLSUPERADMIN,
    WUEDRILLSUPERADMIN
}
