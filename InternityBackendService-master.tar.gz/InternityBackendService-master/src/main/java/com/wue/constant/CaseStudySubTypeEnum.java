package com.wue.constant;

public enum CaseStudySubTypeEnum {
	 HIRING,
	 INNOVATION,
     IDEATHON, 
	 MINIHACK, 
	CROWDSOURCING
}
