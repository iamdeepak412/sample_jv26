package com.wue.constant.saarthi;

public enum SaarthiRegistrationType {
    CAMPUS,
    MENTOR,
    ACADEMIC,
   COMMUNITY
}
