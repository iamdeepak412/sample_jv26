package com.wue.constant.drill.certificate;

public enum DrillCertificateFontStyles {

    PLAIN,
    BOLD,
    ITALIC,
    BOLD_ITALIC,
    PLAIN_ITALIC
}

