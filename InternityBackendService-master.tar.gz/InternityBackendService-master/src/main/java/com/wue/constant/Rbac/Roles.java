package com.wue.constant.Rbac;

public enum Roles {
    USER,
    SUPERADMIN,
    WUEADMIN,
    WUESUPERADMIN,
    WUERECRUITER,
    DRILLADMIN,
    DRILLORGANISER
}
