package com.wue.constant;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
