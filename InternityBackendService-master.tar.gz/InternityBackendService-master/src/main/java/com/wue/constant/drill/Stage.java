package com.wue.constant.drill;

public enum Stage {
    all,
    INVITED,
    REQUESTED,
    ACCEPTED,
    REJECTED,
    REMOVED
}
