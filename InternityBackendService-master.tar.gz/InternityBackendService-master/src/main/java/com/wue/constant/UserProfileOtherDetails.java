package com.wue.constant;

public enum UserProfileOtherDetails {

    CERTIFICATE("certificate"),
    WHITEPAPER("whitepaper"),
    PATENT("patent"),
    WORKTOHIGHLIGHT("worktohighlight"),
    EXTRACURRICULAR("extracurricular");

    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    UserProfileOtherDetails(String value){
        this.value = value.toLowerCase();
    }


}
