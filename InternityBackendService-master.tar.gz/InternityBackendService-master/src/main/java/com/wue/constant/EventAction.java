package com.wue.constant;

public enum EventAction {
    HIDE,
    SHOW
}
