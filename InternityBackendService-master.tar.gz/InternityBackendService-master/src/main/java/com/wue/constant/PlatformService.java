package com.wue.constant;

public enum PlatformService {
    HIRING,
    HACKATHON,
    SQUAD
}
