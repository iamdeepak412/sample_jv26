package com.wue.constant.drill;

public enum DrillSectionEnum {
    OVERVIEW("overview"),
    PRIZES("prizes"),
    THEMES("themes"),
    OPPORTUNITIES("opportunities"),
    COLLABORATORS("collaborators"),
    JUDGINGCRITERIA("judgingcriteria"),
    SCHEDULE("schedule"),
    EVENTS("events"),
    PROBLEMSTATEMENT("problemstatement"),
    SUBMISSION("submission"),
    SPONSORS("sponsors"),
    JUDGES("judges"),
    MENTORS("mentors"),
    SPEAKERS("speakers"),
    TEAMS("teams"),
    FAQ("faq"),
    RESOURCES("resources"),
    PHASES("phases"),
	CUSTOM("custom"),
    ORGANISERDETAILS("organiserdetails"),
    LEADERBOARD("leaderboard");


    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    DrillSectionEnum(String value){this.value = value.toLowerCase();}
}
