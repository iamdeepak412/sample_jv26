package com.wue.constant.drill;

public enum RequestType {

    ALL(""),

    BASIC_TEAM_DETAILS("Team Details change Request"),
    TEAM_IMAGE("Team image change Request"),
    TEAM_LEAD("Team Lead change Request"),
    NEW_TEAM_MEMBER("New Team Member join Request"),
    REMOVE_MEMBER("Remove Member Request"),
    TEAM_NAME("Team Name change Request"),
    TEAM_STATUS("Team Status change Request");

    private final String value;

    RequestType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}

