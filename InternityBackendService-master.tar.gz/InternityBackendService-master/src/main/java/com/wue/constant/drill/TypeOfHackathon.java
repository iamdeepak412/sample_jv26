package com.wue.constant.drill;

public enum TypeOfHackathon {
    PROBLEMBASED("Problem based"),
    THEMEBASED("Theme based");
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    TypeOfHackathon(String value){this.value=value;}
}

