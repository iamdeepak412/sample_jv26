package com.wue.constant.job;

public enum ElementType {
    DRILL,
    JOB,
    BLOG
}
