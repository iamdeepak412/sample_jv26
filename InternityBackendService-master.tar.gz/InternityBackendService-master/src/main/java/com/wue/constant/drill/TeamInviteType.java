package com.wue.constant.drill;

public enum TeamInviteType {
    SEARCHED,
    INVITECODE
}
