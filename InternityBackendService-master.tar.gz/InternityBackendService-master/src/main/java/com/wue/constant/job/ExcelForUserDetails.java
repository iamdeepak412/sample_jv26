package com.wue.constant.job;

public enum ExcelForUserDetails {
    NAME("Name"),
    EMAIL("Email"),
    CONTACT("Contact");

    private String value;

    public String getEnumValue() {
        return value;
    }

    ExcelForUserDetails(String value) {
        this.value = value;
    }
}
