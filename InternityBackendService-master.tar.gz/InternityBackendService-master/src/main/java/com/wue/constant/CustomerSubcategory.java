package com.wue.constant;

public enum CustomerSubcategory {
    STARTUP("Startup (1-50)", CustomerCategory.INDUSTRY.name()),
    SMALL_SIZED_COMPANY("Small-sized company (51-250)", CustomerCategory.INDUSTRY.name()),
    MID_SIZED_COMPANY("Mid-sized company (251-500)", CustomerCategory.INDUSTRY.name()),
    LARGE_SIZED_COMPANY("Large-sized company (501-1000)", CustomerCategory.INDUSTRY.name()),
    MULTI_NATIONAL_COMPANY("Multi-national company", CustomerCategory.INDUSTRY.name()),
    GOVERNMENT_INSTITUTION("Government Institution", CustomerCategory.INSTITUTION_UNIVERSITY.name()),
    PRIVATE_INSTITUTION("Private Institution", CustomerCategory.INSTITUTION_UNIVERSITY.name()),
    UNIVERSITY("University", CustomerCategory.INSTITUTION_UNIVERSITY.name()),
    DEEMED_UNIVERSITY("Deemed University", CustomerCategory.INSTITUTION_UNIVERSITY.name()),
    NOT_FOR_PROFIT("Not for Profit", CustomerCategory.NOT_FOR_PROFIT.name()),
    COMMUNITY("Community", CustomerCategory.COMMUNITY.name());

    private final String displayName;
    private final String category;

    private CustomerSubcategory(String displayName, String category) {
        this.displayName = displayName;
        this.category = category;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getCategory() {
        return category;
    }
}



