package com.wue.constant.drill.certificate;

public enum DrillCertificatePredefinedFields {
    ID,
    NAME,
    EMAIL,
    EVENT_NAME,
    ISSUED_DATE,
    DATE_TODAY,
    POSITION,
    TEAM_NAME,
    CUSTOM
}
