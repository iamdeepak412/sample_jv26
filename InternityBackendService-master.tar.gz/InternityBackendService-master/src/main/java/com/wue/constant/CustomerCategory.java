package com.wue.constant;

public enum CustomerCategory {
    INDUSTRY("Industry"),
    INSTITUTION_UNIVERSITY("Institution/University"),
    INSTITUTION("Institution"),
    COMMUNITY("Community"),
    NOT_FOR_PROFIT("Not for profit");

    private final String displayName;

    CustomerCategory(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}

