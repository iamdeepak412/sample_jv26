package com.wue.constant.application;

import lombok.Getter;

@Getter
public enum ApplicationInterviewRounds {
    ROUND_1("Round 1"),
    ROUND_2("Round 2"),
    ROUND_3("Round 3"),
    ROUND_4("Round 4"),
    ROUND_5("Round 5"),
    ROUND_6("Round 6"),
    ROUND_7("Round 7"),
    ROUND_8("Round 8"),
    HR_ROUND("HR Round"),
    OTHER("Other");

    private final String round;

    ApplicationInterviewRounds(String round) {
        this.round = round;
    }

    public static ApplicationInterviewRounds fromValue(String value) {
        for (ApplicationInterviewRounds round : ApplicationInterviewRounds.values()) {
            if (round.round.equalsIgnoreCase(value)) {
                return round;
            }
        }
        return null; // Or throw an IllegalArgumentException if value not found
    }
}
