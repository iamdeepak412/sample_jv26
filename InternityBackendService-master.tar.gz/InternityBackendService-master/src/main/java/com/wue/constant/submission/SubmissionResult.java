package com.wue.constant.submission;

public enum SubmissionResult {

    PENDING,
    SHORTLISTED,
    REJECTED
}
