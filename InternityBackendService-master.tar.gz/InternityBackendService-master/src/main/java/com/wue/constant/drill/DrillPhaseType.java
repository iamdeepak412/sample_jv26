package com.wue.constant.drill;

public enum DrillPhaseType {
    IDEA,
    HACKATHON,
    OTHER
}
