package com.wue.constant.drill;

public enum DrillWinnerType {
    GENERAL,
    SPECIAL

}
