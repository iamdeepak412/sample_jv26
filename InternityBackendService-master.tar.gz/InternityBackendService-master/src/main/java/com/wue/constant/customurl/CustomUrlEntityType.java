package com.wue.constant.customurl;

public enum CustomUrlEntityType {
    CASESTUDY
}
