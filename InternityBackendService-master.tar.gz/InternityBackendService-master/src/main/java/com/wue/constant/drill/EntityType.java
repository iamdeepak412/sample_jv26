package com.wue.constant.drill;

public enum EntityType {
    ALL,
    DRILLTEAM
}
