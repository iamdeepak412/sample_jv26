package com.wue.constant.drill;

public enum PaymentStatus {
    NA,
    PENDING,
    SUCCESS,
    FAILED,
    TIMEOUT
}
