package com.wue.constant;

public enum FeaturedElementType {
	
	JOB("Job"),
	DRILL("drill")
	
	;
	
	private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    FeaturedElementType(String value){
        this.value = value.toLowerCase();
    }

}
