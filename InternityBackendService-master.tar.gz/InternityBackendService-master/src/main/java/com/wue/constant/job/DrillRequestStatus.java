package com.wue.constant.job;

public enum DrillRequestStatus {

    PENDING,APPROVED,REJECTED
}
