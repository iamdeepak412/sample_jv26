package com.wue.constant;

public enum CaseStudyTypeEnum {
	HACKATHON,
	JOB
}
