package com.wue.constant.drill;

public enum DrillSubmissionFieldType {
    CODE_SOLUTION,
    PROJECT_NAME,
    VIDEO_SOLUTION,
    PRESENTATION
}
