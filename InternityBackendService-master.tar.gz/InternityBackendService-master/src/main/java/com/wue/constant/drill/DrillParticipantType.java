package com.wue.constant.drill;

public enum DrillParticipantType {
    ALL,
    PROFESSIONAL,
    STUDENT
}
