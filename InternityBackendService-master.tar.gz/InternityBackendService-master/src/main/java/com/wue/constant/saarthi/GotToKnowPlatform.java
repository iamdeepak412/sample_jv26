package com.wue.constant.saarthi;

import lombok.Getter;

@Getter
public enum GotToKnowPlatform {
    LINKEDIN("LinkedIn"),
    FACEBOOK("Facebook"),
    TWITTER("Twitter"),
    INSTAGRAM("Instagram"),
    TELEGRAM("Telegram"),
    DISCORD("Discord"),
    NEWSPAPER("Newspaper"),
    OTHERS("Others");

    private final String source;

    GotToKnowPlatform(String source) {
        this.source = source;
    }

}
