package com.wue.util.ResumeParser;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.iterable.S3Objects;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.wue.service.UserManagementService;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@Log4j2
public class AwsIntegration {

    public static void main(String[] args) {
        new AwsIntegration().fetchAllFilesInABucket("a");
    }

    public List<String> fetchAllFilesInABucket(String bucketName){
        try{
            UserManagementService service = new UserManagementService();
            AWSCredentials credentials = new BasicAWSCredentials("AKIAQI4P3III3EDQF4VY",
                    "/+GzIHbTTVek5qzMsg6tKDVFnnVFyVjwuKTT9/5H");
            AmazonS3 s3client = AmazonS3ClientBuilder
                    .standard()
                    .withCredentials(new AWSStaticCredentialsProvider(credentials))
                    .withRegion("ap-south-1")
                    .build();
            List<String> fileNameList = new ArrayList<>();
            S3Objects.inBucket(s3client, "wue-candidate-resume")
                    .forEach(
                            (S3ObjectSummary objectSummary) -> {
                                String fileName =
                                        "https://wue-candidate-resume.s3.ap-south-1.amazonaws.com/"
                                                + objectSummary.getKey();
                                fileNameList.add(fileName);
                            });
            System.out.println(fileNameList.size());
            return fileNameList;
        }
        catch (Exception e){
            log.error("Exception while fetching all the files in an Aws bucket {}", e);
        }
        return Collections.emptyList();
    }
}
