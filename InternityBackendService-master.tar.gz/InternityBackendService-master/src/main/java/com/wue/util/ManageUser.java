package com.wue.util;

public class ManageUser extends Thread{

}
