package com.wue.util.ResumeParser;

import com.wue.dto.assessprofile.UserDetailsInBulk;
import lombok.extern.log4j.Log4j2;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
@Log4j2
public class ResumeParser {

    @Value("${resume.parsing.url:http://127.0.0.1:5069}")
    private String resumeParsingUrl;

    public JSONObject parsedResumeObj(String resumeLink){
        try{
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            String payloadJson = "{\"resume_s3_url\": \""+resumeLink+"\"}";
            HttpEntity<String> request = new HttpEntity<String>(payloadJson,headers);
            String response =
                    restTemplate.postForObject(
                            resumeParsingUrl,
                            request,
                            String.class);
            log.info("response from parsed resume ::: {}", response);
            return new JSONObject(response);
        }
        catch (Exception e){
            log.error("Exception while parsing resume ::: {}", e);
        }
        return null;
    }

    public UserDetailsInBulk getUserDetailsObjFromParsedResume(JSONObject json, String resumeLink, String jobId){
        try{
            UserDetailsInBulk userDetailsInBulk = new UserDetailsInBulk();
            userDetailsInBulk.setEmail(json.getString("email"));
            userDetailsInBulk.setName(json.getString("name"));
            userDetailsInBulk.setContact(json.get("mobile_number")+"");
            userDetailsInBulk.setCollegeName(json.get("college_name")+"");
            userDetailsInBulk.setDesignation(json.get("designation")+"");
            userDetailsInBulk.setSkills(json.get("skills")+"");
            userDetailsInBulk.setResumeLink(resumeLink);
            userDetailsInBulk.setJobId(jobId);
            userDetailsInBulk.setYoe(json.get("total_experience")+"");

            return userDetailsInBulk;
        }
        catch (Exception e){
            log.error("Exception while getting user details object from parsed resume {}", e);
            return new UserDetailsInBulk();
        }
    }
}
