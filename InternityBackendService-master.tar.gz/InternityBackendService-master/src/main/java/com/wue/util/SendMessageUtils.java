package com.wue.util;

import com.wue.config.AWSConfig;
import com.wue.constant.CommonConstants;
import com.wue.exception.ApiException;
import com.wue.model.EmailContent;
import com.wue.util.ses.SESEmailMessage;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.validator.routines.EmailValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

@Component
@Log4j2
public class SendMessageUtils {


    public final static Logger LOGGER = LoggerFactory.getLogger(SendMessageUtils.class);

    @Autowired
    private final TemplateEngine templateEngine;

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private AWSConfig awsConfig;

    public ResponseEntity<String> sendMessage(String mobileNumber, String otp) throws ApiException {
        try {
           /* LOGGER.info("sending text message");
            String apiKey = "apikey=" + "/4mJHP2NbEs-y9wd7KFNwYgkkkm4X6ON0OzXNMvmGe";
            String message = "&message=" + "OTP for A2ZWHS : " + otp;
            String sender = "&sender=" + "TXTLCL";
            String numbers = "&numbers=" + 91 + mobileNumber;
            HttpURLConnection conn = (HttpURLConnection) new URL("https://api.textlocal.in/send/?")
                    .openConnection();
            String data = apiKey + numbers + message + sender;
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
            conn.getOutputStream().write(data.getBytes("UTF-8"));

            final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            LOGGER.info(rd.toString());
            final StringBuffer stringBuffer = new StringBuffer();

            String line;
            while ((line = rd.readLine()) != null) {
                stringBuffer.append(line);
                LOGGER.info(stringBuffer.toString());
            }
            rd.close();*/
            LOGGER.info("Message sent successfully");
            return new ResponseEntity<String>("Message sent successfully", HttpStatus.OK);
        } catch (Exception exception) {
            LOGGER.error(exception.getMessage());
            throw new ApiException(500, "Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<String> sendMessage(String mobileNumber, String message, Boolean isOtp) throws ApiException {
        String authKey = CommonConstants.MSG_91_AUTH_KEY;
        String senderId = CommonConstants.MSG_91_SENDER_ID;
        String otpTemplate = CommonConstants.MSG_91_OTP_TEMPLATE;
        //encoding message
        String encoded_message = URLEncoder.encode(message);
        //Prepare Url
        URLConnection myURLConnection = null;
        URL myURL = null;
        BufferedReader reader = null;
        String mainUrl = null;
        //Send SMS API
        if (isOtp)
            mainUrl = "https://api.msg91.com/api/v5/otp?";
        else
            mainUrl = "https://api.msg91.com/api/sendhttp.php?";

        //Prepare parameter string
        StringBuilder sbPostData = new StringBuilder(mainUrl);
        sbPostData.append("authkey=" + authKey);
        sbPostData.append("&mobiles=" + mobileNumber);
        sbPostData.append("&country=91");
        if (isOtp) {
            sbPostData.append("&otp=" + encoded_message);
            sbPostData.append("&template_id=" + otpTemplate);
            sbPostData.append("&invisible=" + 1);
        } else {
            sbPostData.append("&message=" + encoded_message);
            sbPostData.append("&route=4");
        }
        sbPostData.append("&sender=" + senderId);

        //final string
        mainUrl = sbPostData.toString();
        try {
            //prepare connection
            myURL = new URL(mainUrl);
            myURLConnection = myURL.openConnection();
            myURLConnection.connect();
            reader = new BufferedReader(new InputStreamReader(myURLConnection.getInputStream()));
            //reading response
            String response;
            while ((response = reader.readLine()) != null)
                //print response
                LOGGER.info("Send sms api response is : " + response);

            //finally close connection
            reader.close();
            LOGGER.info("Message Sent successfully");
            return new ResponseEntity<String>("Message sent successfully", HttpStatus.OK);
        } catch (IOException exception) {
            LOGGER.info("Message not Send");
            return new ResponseEntity<String>(exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Async
    public String sendMail(String to, EmailContent emailContent) throws MessagingException {
    	try {
            EmailValidator emailValidator = EmailValidator.getInstance();
            if(!emailValidator.isValid(to)){
                log.info("Email is invalid {}", to);
                return "Email is Invalid";
            }
    	log.debug("Send mail config {} ::: {}", awsConfig, emailContent.getTemplateName());
        Context context = new Context();
        context.setVariable("content", emailContent);
        String process = templateEngine.process(emailContent.getTemplateName(), context);
        String data = process.replaceAll("&lt;", "<")
                                .replaceAll("&amp;", "&")
                                .replaceAll("&gt;", ">")
                                .replaceAll("&quot;","\"");

        //SENDING EMAIL VIA SES
        SESEmailMessage sesEmailMessage = new SESEmailMessage();
        sesEmailMessage.setTo(to);
        sesEmailMessage.setBody(data);
        sesEmailMessage.setSubject(emailContent.getSubject());
        if(!StringUtils.isEmpty(emailContent.getBcc())){
            sesEmailMessage.setBcc(emailContent.getBcc());
        }
        if(!StringUtils.isEmpty(emailContent.getCc())){
            sesEmailMessage.setCc(emailContent.getCc());
        }
        awsConfig.build().sendEmail(sesEmailMessage);
        return "Sent";
    	}
    	catch (Exception e) {
    		log.error("exception {}", e);
    	}
    	return "sent";
    }

    public String sendMailForGenericUsers(String to, EmailContent emailContent) throws MessagingException {
        try {
            EmailValidator emailValidator = EmailValidator.getInstance();
            if(!emailValidator.isValid(to)){
                log.info("Email is invalid \"{}\" ", to);
                return "\""+to+"\" email is invalid";
            }
            log.debug("Send mail config {} ::: {}", awsConfig, emailContent.getTemplateName());
            Context context = new Context();
            context.setVariable("content", emailContent);
            String process = templateEngine.process(emailContent.getTemplateName(), context);
            String data = process.replaceAll("&lt;", "<").replaceAll("&amp;", "&").replaceAll("&gt;", ">");

            //SENDING EMAIL VIA SES
            SESEmailMessage sesEmailMessage = new SESEmailMessage();
            sesEmailMessage.setTo(to);
            sesEmailMessage.setBody(data);
            sesEmailMessage.setSubject(emailContent.getSubject());
            if(!StringUtils.isEmpty(emailContent.getBcc())){
                sesEmailMessage.setBcc(emailContent.getBcc());
            }
            if(!StringUtils.isEmpty(emailContent.getCc())){
                sesEmailMessage.setCc(emailContent.getCc());
            }
            awsConfig.build().sendEmail(sesEmailMessage);
            return "Sent";
        }
        catch (Exception e) {
            log.error("exception {}", e);
        }
        return "sent";
    }

    @Async
    public String sendMailWithAttachment(String to, EmailContent emailContent, InternityUser user, MultipartFile FileToAttach) throws MessagingException {
        try {

            log.debug("Send mail config {} ::: {}", awsConfig, emailContent.getTemplateName());
            Context context = new Context();
            context.setVariable("content", emailContent);
            String process = templateEngine.process(emailContent.getTemplateName(), context);
            String data = process.replaceAll("&lt;", "<").replaceAll("&amp;", "&").replaceAll("&gt;", ">");

            //SENDING EMAIL VIA SES
            SESEmailMessage sesEmailMessage = new SESEmailMessage();
            sesEmailMessage.setTo(to);
            sesEmailMessage.setBody(data);
            sesEmailMessage.setSubject(emailContent.getSubject());
            if(!StringUtils.isEmpty(emailContent.getBcc())){
                sesEmailMessage.setBcc(emailContent.getBcc());
            }
            if(!StringUtils.isEmpty(emailContent.getCc())){
                sesEmailMessage.setCc(emailContent.getCc());
            }
            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText("Mail Body");
            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.attachFile((File) FileToAttach);
            awsConfig.build().sendEmail(sesEmailMessage);
            return "Sent";
        }
        catch (Exception e) {
            log.error("exception {}", e);
        }
        return "sent";
    }

    public SendMessageUtils(TemplateEngine templateEngine, JavaMailSender javaMailSender) {
        this.templateEngine = templateEngine;
        this.javaMailSender = javaMailSender;
    }

    /**
     * This is the sendEmail method it
     * Receive email-id as a parameter and send email to that email-id.
     *
     * @return Response object as a response in json format
     */
    @Async
    public ResponseEntity<String> sendEmail(SimpleMailMessage email) {
        javaMailSender.send(email);
        return new ResponseEntity<String>("Message sent successfully", HttpStatus.OK);
    }

}
