package com.wue.util;

import org.springframework.stereotype.Component;

@Component
public class JobRecommendation {

}
