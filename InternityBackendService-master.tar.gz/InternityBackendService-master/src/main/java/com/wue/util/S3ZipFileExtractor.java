package com.wue.util;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.GetObjectRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;
import java.util.Date;

@Component
public class S3ZipFileExtractor {
    @Value("${bucket}")
    private String bucket;

    @Value("${ACCESS_KEY}")
    private String aws_access_key;

    @Value("${SECRET_KEY}")
    private String aws_secret_key;

    @Value("${region}")
    private String region;

    @Autowired
    CommonUtils commonUtils;

    public String downloadS3ZipFile(String zipFileKey) throws IOException {

        AWSCredentials credentials = new BasicAWSCredentials(aws_access_key, aws_secret_key);
        AmazonS3 s3Client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(region)
                .build();

        // Define local file path to save the downloaded zip file
        String localFilePath = "src/main/resources/extractedZipForAsync/resume_"+new Date().getTime()+".zip";

        // Download the zip file from S3
        GetObjectRequest getObjectRequest = new GetObjectRequest(bucket, zipFileKey);
        S3Object s3Object = s3Client.getObject(getObjectRequest);
        S3ObjectInputStream objectInputStream = s3Object.getObjectContent();

        // Create a local file to save the zip content
        try (FileOutputStream fos = new FileOutputStream(new File(localFilePath))) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = objectInputStream.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
            System.out.println("Zip file downloaded successfully.");
            return localFilePath;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            objectInputStream.close();
        }
        return "";
    }
}

