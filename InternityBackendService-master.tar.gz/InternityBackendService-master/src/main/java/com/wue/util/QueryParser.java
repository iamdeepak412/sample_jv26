package com.wue.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.wue.domain.Partner;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.domain.Job;
import com.wue.repository.PartnerRepository;

@Component
@Log4j2
public class QueryParser {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private PartnerRepository partnerRepository;

    public List<Job> getJobs(String query) {
        List<Map<String, Object>> jobs = jdbcTemplate
                .queryForList(getAllActiveJobQuery(query));
        ObjectMapper obj = new ObjectMapper();

        List<Job> result = new ArrayList<>();

        for (Map<String, Object> jobObj : jobs) {
            try {
                Job job = obj.convertValue(jobObj, Job.class);
                Partner partner = partnerRepository.findById(job.getPartnerId()).get();
                job.setPartner(partner);
                job.setJobImageLink(partner.getPartnerLogoPath());
                result.add(job);
            }
            catch (Exception e){
                log.error("Exception while fetching job {}", e);
            }
        }

        return result;

    }

    private String getAllActiveJobQuery(String query) {
		log.info("getAllActiveJobQuery {}", query);
        return "select j.job_title as jobTitle, j.job_location as jobLocation,"
                + "j.partner_id as partnerId, j.job_skills as jobSkills,"
                + "j.job_id as jobId, j.is_active as isActive, j.is_company_name_hidden as isCompanyNameHidden,"
                + "j.job_ctc_currency as jobCtcCurrency, j.job_esop_acceptance as jobEsopAcceptance,"
                + "j.job_industry_category as jobIndustryCategory, j.job_max_ctc_range as jobMaxCtcRange,"
                + "j.job_max_yoe as jobMaxYoe, j.job_min_ctc_range as jobMinCtcRange,"
                + "j.job_min_yoe as jobMinYoe, j.job_notice_period_acceptable as jobNoticePeriodAcceptable,"
                + "j.job_type as jobType, j.job_applicant_count as jobApplicantCount,"
                + "j.job_number_of_vacancies as jobNumberOfVacancies, "
                + "j.job_img_link as jobImageLink from jobs j where " + this.parseQuery(query);
    }

    public String parseQuery(String query) {
        query = query.replaceAll("([:][\\w.\\s[-][/]]+)", " like \'%$1%\'");
        query = query.replace(",", " AND ");
        query = query.replace(";", " OR ");
        query = query.replace(":", "");
        query = query.replace("jobTitle", "job_title");
        query = query.replace("jobLocation", "job_location");
        query = query.replace("jobSkills", "job_skills");
        query = query.replace("jobMaxYoe", "job_max_yoe");
        query = query.replace("jobMinYoe", "job_min_yoe");
        query = query.replace("jobMaxCtcRange", "job_max_ctc_range");
        query = query.replace("jobMinCtcRange", "job_min_ctc_range");
        query = query.replace("jobType", "job_type");

        System.out.println(query);
        return query;
    }

}
