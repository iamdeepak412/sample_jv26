package com.wue.config;

import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.crypto.SecretKey;

/**
 * This configuration class will be used for injecting secret key in environment variable.
 * @author Rishab
 */
@Configuration
public class JwtSecretKeyConfig {

    private final JwtConfig jwtConfig;

    // Getting jwt configuration properties
    @Autowired
    public JwtSecretKeyConfig(JwtConfig jwtConfig) {
        this.jwtConfig = jwtConfig;
    }

    // Creating bean of secretKey
    @Bean
    public SecretKey secretKey() {
        return Keys.hmacShaKeyFor(jwtConfig.getSecretKey().getBytes());
    }
}