package com.wue.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.wue.util.ses.SESClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AWSConfig {

    @Value("${SECRET_KEY}")
    private String secretKey;

    @Value("${ACCESS_KEY}")
    private String accessKey;

    @Value("${REGION}")
    private String region;

    @Value("${DISPLAY_NAME}")
    private String displayName;

    @Value("${FROM_EMAIL}")
    private String fromEmail;

    @Bean
    public SESClientBuilder build() {
        Regions region = Regions.fromName(this.region);
        SESClientBuilder clientBuilder = new SESClientBuilder(displayName, fromEmail, region, accessKey, secretKey);
        return clientBuilder;
    }

    @Bean
    public AmazonS3 getS3Client() {

        BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
       return AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(region)
                .build();

    }

}
