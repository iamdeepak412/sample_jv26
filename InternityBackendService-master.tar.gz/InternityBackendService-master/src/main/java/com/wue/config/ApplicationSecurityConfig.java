package com.wue.config;

import com.wue.jwt.JwtTokenVerifier;
import com.wue.jwt.JwtUsernameAndPasswordAuthenticationFilter;
import com.wue.repository.UserRepository;
import com.wue.service.UserAuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import javax.crypto.SecretKey;
import java.util.Arrays;

/**
 * This is security configuration where all security related configuration is present which includes
 * configuring HttpSecurity, AuthenticationManagerBuilder, and AuthenticationProvider.
 * @author Rishab
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class ApplicationSecurityConfig extends WebSecurityConfigurerAdapter {

    private final PasswordEncoder passwordEncoder;
    private final UserAuthenticationService userAuthenticationService;
    private final SecretKey secretKey;
    private final JwtConfig jwtConfig;
    private UserRepository userRepository;
    
    @Autowired
    public ApplicationSecurityConfig(PasswordEncoder passwordEncoder,
                                     UserAuthenticationService userServiceImpl,
                                     SecretKey secretKey,
                                     JwtConfig jwtConfig, UserRepository userRepository) {
        this.passwordEncoder = passwordEncoder;
        this.userAuthenticationService = userServiceImpl;
        this.secretKey = secretKey;
        this.jwtConfig = jwtConfig;
        this.userRepository = userRepository;
    }

    /**
     * Configuring endpoints and filters
      */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .addFilter(new JwtUsernameAndPasswordAuthenticationFilter(authenticationManager(),
                        jwtConfig, secretKey, userRepository))
                .addFilterAfter(new JwtTokenVerifier(secretKey, jwtConfig),
                        JwtUsernameAndPasswordAuthenticationFilter.class)
                .authorizeRequests()
                .antMatchers(HttpMethod.GET, "/v2/api-docs", "/configuration/ui", "/configuration/security",
                        "/webjars/**").permitAll()

                .antMatchers(HttpMethod.POST, "/api/v1/users/register").permitAll()
                .antMatchers(HttpMethod.POST,"/api/v1/users/login").permitAll()
                .antMatchers(HttpMethod.POST,"/api/v1/users/login/google").permitAll()
                .antMatchers(HttpMethod.GET,"/api/v1/testimonialwithcategory").permitAll()
                .antMatchers(HttpMethod.GET,"/api/v1/common/organisationandacademic").permitAll()
                .antMatchers(HttpMethod.GET,"/api/v1/stats/landingpage").permitAll()
                .antMatchers(HttpMethod.GET,"/api/v1/common/featuredelements").permitAll()
                .anyRequest()
                .permitAll();
                //.authenticated();
        http.cors();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        final CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("*"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    /**
     * Configuring authentication provider
      */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(daoAuthenticationProvider());
    }

    /**
     * Creating bean of authentication provider
     */
    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder);
        provider.setUserDetailsService(userAuthenticationService);
        return provider;
    }
}