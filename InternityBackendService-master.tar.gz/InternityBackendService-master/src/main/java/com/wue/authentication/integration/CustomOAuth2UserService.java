package com.wue.authentication.integration;

import org.springframework.stereotype.Service;

@Service
public class CustomOAuth2UserService {
//
//    @Autowired
//    private UserService userService;
//
//    @Autowired
//    private Environment env;
//
//    @Override
//    public OAuth2User loadUser(OAuth2UserRequest oAuth2UserRequest) throws OAuth2AuthenticationException {
//        OAuth2User oAuth2User = super.loadUser(oAuth2UserRequest);
//        try {
//            Map<String, Object> attributes = new HashMap<>(oAuth2User.getAttributes());
//            String provider = oAuth2UserRequest.getClientRegistration().getRegistrationId();
//            if (provider.equals(SocialProvider.LINKEDIN.getProviderType())) {
//                populateEmailAddressFromLinkedIn(oAuth2UserRequest, attributes);
//            }
//            return userService.processUserRegistration(provider, attributes, null, null);
//        } catch (AuthenticationException ex) {
//            throw ex;
//        } catch (Exception ex) {
//            ex.printStackTrace();
//            // Throwing an instance of AuthenticationException will trigger the
//            // OAuth2AuthenticationFailureHandler
//            throw new OAuth2AuthenticationProcessingException(ex.getMessage(), ex.getCause());
//        }
//    }
//
//    @SuppressWarnings({ "rawtypes", "unchecked" })
//    public void populateEmailAddressFromLinkedIn(OAuth2UserRequest oAuth2UserRequest, Map<String, Object> attributes) throws OAuth2AuthenticationException {
//        String emailEndpointUri = env.getProperty("linkedin.email-address-uri");
//        Assert.notNull(emailEndpointUri, "LinkedIn email address end point required");
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + oAuth2UserRequest.getAccessToken().getTokenValue());
//        HttpEntity<?> entity = new HttpEntity<>("", headers);
//        ResponseEntity<Map> response = restTemplate.exchange(emailEndpointUri, HttpMethod.GET, entity, Map.class);
//        List<?> list = (List<?>) response.getBody().get("elements");
//        Map map = (Map<?, ?>) ((Map<?, ?>) list.get(0)).get("handle~");
//        attributes.putAll(map);
//    }
}