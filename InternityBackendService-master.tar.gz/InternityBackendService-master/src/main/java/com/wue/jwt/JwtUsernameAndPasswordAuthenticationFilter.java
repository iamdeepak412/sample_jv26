package com.wue.jwt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.config.JwtConfig;
import com.wue.domain.User;
import com.wue.dto.AuthResponseDto;
import com.wue.dto.AuthenticationDto;
import com.wue.repository.UserRepository;

import io.jsonwebtoken.Jwts;
import lombok.extern.log4j.Log4j2;

import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.crypto.SecretKey;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;

/**
 * This is a filter which intercept request and extract username and password for authentication.
 * This will intercept request if someone hit /login url.
 * 
 */
@Log4j2
public class JwtUsernameAndPasswordAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private final AuthenticationManager authenticationManager;
    private final JwtConfig jwtConfig;
    private final SecretKey secretKey;
    private final UserRepository userRepository;
    public JwtUsernameAndPasswordAuthenticationFilter(AuthenticationManager authenticationManager, JwtConfig jwtConfig,
                                                      SecretKey secretKey, UserRepository userRepository) {
        this.authenticationManager = authenticationManager;
        this.jwtConfig = jwtConfig;
        this.secretKey = secretKey;
        this.setFilterProcessesUrl("/api/v1/users/login");
        this.userRepository = userRepository;
    }

    /**
     * This method extract object which contain authentication credential and try to authenticate it
     * @param request
     * @param response
     * @throws AuthenticationException
     */
    @Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException {
		AuthenticationDto authenticationRequest = null;
		try {
			log.debug("attempt authentication");
			// Extracting auth object from request body
			authenticationRequest = new ObjectMapper().readValue(request.getInputStream(), AuthenticationDto.class);

            Optional<User> userObj = userRepository.findByEmail(authenticationRequest.getUsername());
            if(userObj.isPresent()){
                if(!userObj.get().isActive()){
                    //service.sendForgotPasswordEmail(userObj.get());
                    throw new RuntimeException("User email is not verified. Please resend verification link");
                }
            }
            else {
                throw new RuntimeException("User is not registered yet. Please register");
            }
			// Authentication request
			Authentication authentication = new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(),
					authenticationRequest.getPassword());

			return authenticationManager.authenticate(authentication);

		} catch (Exception exception) {
			log.error("Error message while authenticating user {}", exception);
            if(exception.getMessage().equals("Bad credentials")){
                throw new RuntimeException("Username or password is incorrect. Please check or use forgot password");
            }
			throw new RuntimeException(exception.getMessage());
        }
	}

    /**
     * Over successful authentication this method will be called which will generate JWT token and prepare response.
     * @param request
     * @param response
     * @param chain
     * @param authResult
     * @throws IOException
     * @throws ServletException
     */
    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
                                            Authentication authResult) throws IOException, ServletException {
    	log.debug("logging authentication");
    	
        String token = Jwts.builder().setSubject(authResult.getName())
                .claim("authorities", authResult.getAuthorities()).setIssuedAt(new Date())
                .setExpiration(java.sql.Date.valueOf(LocalDate.now().plusDays(jwtConfig.getTokenExpirationAfterDays())))
                .signWith(secretKey).compact();

        String jwt = jwtConfig.getTokenPrefix() + " " + token;
        AuthResponseDto responseObj = new AuthResponseDto();
        responseObj.setResponseCode(HttpStatus.OK.value());
        responseObj.setToken(jwt);
        responseObj.setAuthoritiesInString(authorityListToSet(authResult.getAuthorities()).toString());
        
        Optional<User> userObj = userRepository.findByUsername(authResult.getName());
        if(userObj.isPresent()) {
        	User user = userObj.get();

        	JSONObject userJson = new JSONObject();
        	userJson.put("fullName", user.getFullName());
        	userJson.put("uemail", user.getEmail());
        	userJson.put("uid", user.getUId());
        	responseObj.setUserDetails(userJson);
        }

        response.setStatus(HttpStatus.OK.value());
        response.getWriter().write(responseObj.toString());

        response.flushBuffer();

    }

    private static Set<String> authorityListToSet(Collection<? extends GrantedAuthority> userAuthorities) {
		Set<String> set = new HashSet<>(userAuthorities.size());
		for (GrantedAuthority authority : userAuthorities) {
			set.add("\""+authority.getAuthority()+"\"");
		}
		return set;
	}
}