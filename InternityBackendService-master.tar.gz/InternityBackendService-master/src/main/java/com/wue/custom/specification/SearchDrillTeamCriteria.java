package com.wue.custom.specification;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class SearchDrillTeamCriteria {
    private String drillId;
    private String teamId;
    private String teamName;
    private boolean isLookingForTeamMate;
    private boolean isIncompleteTeam;

}
