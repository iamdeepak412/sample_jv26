package com.wue.custom.specification;

import org.springframework.data.jpa.domain.Specification;

import com.wue.domain.Application;
import com.wue.domain.UserCandidateMandatoryFields;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ApplicationFilterSpecification {

    public static Specification<Application> withJobId(String jobId) {
        return (root, query, criteriaBuilder) -> {
            if (jobId != null && !"All".equals(jobId)) {
                return criteriaBuilder.equal(root.get("jobId"), jobId);
            }
            return null;
        };
    }
    public static Specification<Application> withCurrentStatus(String currentStatus) {
        return (root, query, criteriaBuilder) -> {
            if (currentStatus != null && !"All".equals(currentStatus)) {
                return criteriaBuilder.equal(root.get("currentStatus"), currentStatus);
            }
            return null;
        };
    }
    
    public static Specification<Application> withSubStatus(String subStatus) {
        return (root, query, criteriaBuilder) -> {
            if (subStatus != null && !"All".equals(subStatus)) {
                return criteriaBuilder.equal(root.get("subStatus"), subStatus);
            }
            return null;
        };
    }
    
    public static Specification<Application> withAppliedTimestamp(String appliedTimestamp) {
        return (root, query, criteriaBuilder) -> {
            if (appliedTimestamp != null) {
            		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
                	LocalDateTime appliedTimestampDateTime = LocalDateTime.parse(appliedTimestamp, formatter);
                    return criteriaBuilder.equal(root.get("appliedTs"), appliedTimestampDateTime);
            	}
            return null;
        };
    }
    public static Specification<UserCandidateMandatoryFields> withCurrentOrg(String currentOrg) {
        return (root, query, criteriaBuilder) -> {
            if (currentOrg != null && !currentOrg.isEmpty()) {
                return criteriaBuilder.equal(root.get("currentOrg"), currentOrg);
            }
            return null;
        };
    }

    public static Specification<UserCandidateMandatoryFields> withYoeRange(Double minYoe, Double maxYoe) {
        return (root, query, criteriaBuilder) -> {
            if (minYoe != null && maxYoe != null) {
                return criteriaBuilder.between(root.get("yoe"), minYoe, maxYoe);
            } else if (minYoe != null) {
                return criteriaBuilder.greaterThanOrEqualTo(root.get("yoe"), minYoe);
            } else if (maxYoe != null) {
                return criteriaBuilder.lessThanOrEqualTo(root.get("yoe"), maxYoe);
            }
            return null;
        };
    }

    public static Specification<UserCandidateMandatoryFields> withExpectedCtcRange(Double minCtc, Double maxCtc) {
        return (root, query, criteriaBuilder) -> {
            if (minCtc != 0.0 && maxCtc != 0.0) {
                return criteriaBuilder.between(root.get("expectedCtc"), minCtc, maxCtc);
            } else if (minCtc != 0.0) {
                return criteriaBuilder.greaterThanOrEqualTo(root.get("expectedCtc"), minCtc);
            } else if (maxCtc != 0.0) {
                return criteriaBuilder.lessThanOrEqualTo(root.get("expectedCtc"), maxCtc);
            }
            return null;
        };
    }

    public static Specification<UserCandidateMandatoryFields> withSkills(String skills) {
        return (root, query, criteriaBuilder) -> {
            if (skills != null && !"All".equals(skills)) {
                return criteriaBuilder.isTrue(root.get("primarySkills").in(skills));
            }
            return null;
        };
    }

    public static Specification<UserCandidateMandatoryFields> withNoticePeriod(Integer noticePeriod) {
        return (root, query, criteriaBuilder) -> {
            if (noticePeriod != 0) {
                return criteriaBuilder.equal(root.get("noticePeriodDays"), noticePeriod);
            }
            return null;
        };
    }
    
    public static Specification<UserCandidateMandatoryFields> withCurrentLoc(String currentLoc) {
        return (root, query, criteriaBuilder) -> {
            if (currentLoc != null && !"All".equals(currentLoc)) {
                return criteriaBuilder.equal(root.get("currentLoc"), currentLoc);
            }
            return null;
        };
    }

    public static Specification<UserCandidateMandatoryFields> withPreferredLoc(String preferredLoc) {
        return (root, query, criteriaBuilder) -> {
            if (preferredLoc != null && !"All".equals(preferredLoc)) {
                return criteriaBuilder.equal(root.get("preferredLoc"), preferredLoc);
            }
            return null;
        };
    }

    public static Specification<UserCandidateMandatoryFields> withLastWorkingDay(String lastWorkingDay) {
        return (root, query, criteriaBuilder) -> {
            if (lastWorkingDay != null) {
            		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
                	LocalDateTime lastWorkingDayDateTime = LocalDateTime.parse(lastWorkingDay, formatter);
                	return criteriaBuilder.equal(root.get("lastWorkingDay"),lastWorkingDayDateTime);
            	}
            return null;
        };
    }

}





