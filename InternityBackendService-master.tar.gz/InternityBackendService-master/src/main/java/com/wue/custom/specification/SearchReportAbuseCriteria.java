package com.wue.custom.specification;

import lombok.*;

@Getter
@Setter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class SearchReportAbuseCriteria {

    private String reportId;
    private String postId;
    private String uId;
    private String commentId;
}


