package com.wue.custom.specification;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class SearchBlogPostCriteria {
    private String uId;
    private String name;
    private String categoryId;
    private String categoryName;
    private String tags;
    private String content;
    private String custUrl;
    private String blogpostId;
    private String title;
    private boolean isActive;
    private boolean isFeatured;

}
