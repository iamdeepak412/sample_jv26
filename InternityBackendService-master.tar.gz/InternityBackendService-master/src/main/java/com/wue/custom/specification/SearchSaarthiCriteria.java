package com.wue.custom.specification;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@Builder
@ToString
public class SearchSaarthiCriteria {
    private String saarthiId;
    private String registrationType;
    private String saarthiWhoAreYouType;
    private String saarthiPartOfSolutionType;
}
