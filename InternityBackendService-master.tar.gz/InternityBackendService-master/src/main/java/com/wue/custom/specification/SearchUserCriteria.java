package com.wue.custom.specification;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class SearchUserCriteria {
	private String isActive;
	private String email;
	private String fullName;
}
