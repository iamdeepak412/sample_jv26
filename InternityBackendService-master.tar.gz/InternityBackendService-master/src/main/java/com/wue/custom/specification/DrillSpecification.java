package com.wue.custom.specification;

import java.sql.Timestamp;
import java.time.LocalDate;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.wue.constant.drill.DrillStatus;
import org.springframework.data.jpa.domain.Specification;

import com.wue.domain.drill.Drill;

public class DrillSpecification implements Specification<Drill>{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    /**
     * 
     */
    private SearchCriteria criteria;
    
    public DrillSpecification(SearchCriteria searchCriteria) {
        this.criteria=searchCriteria;
    }


	@Override
	public Predicate toPredicate(Root<Drill> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
	    String operation = criteria.getOperation();
	    String key = criteria.getKey();
	    Object value = criteria.getValue();

	    if (">".equalsIgnoreCase(operation)) {
	        return builder.greaterThan(root.get(key), value.toString());
	    } else if (">=".equalsIgnoreCase(operation)) {
	        return builder.greaterThanOrEqualTo(root.get(key), value.toString());
	    } else if ("<".equalsIgnoreCase(operation)) {
	        return builder.lessThan(root.get(key), value.toString());
	    } else if ("<=".equalsIgnoreCase(operation)) {
	        return builder.lessThanOrEqualTo(root.get(key), value.toString());
	    } else if (":".equalsIgnoreCase(operation)) {
	        if (root.get(key).getJavaType() == String.class) {
	            return builder.like(root.get(key), "%" + value + "%");
	        } else {
	            return builder.equal(root.get(key), value);
	        }
	    } else if ("status".equalsIgnoreCase(operation)) {
	        return getStatusPredicate(root, builder, value.toString());
	    } else if ("type".equalsIgnoreCase(operation)) {
	        return builder.equal(root.get("drillType"), value.toString());
	    } else if ("invitationType".equalsIgnoreCase(operation)) {
	        return builder.equal(root.get("drillInvitationType"), value.toString());
	    } else if ("mode".equalsIgnoreCase(operation)) {
	        return builder.equal(root.get("drillNature"), value.toString());
	    } else if ("eligibility".equalsIgnoreCase(operation)) {
	        return builder.equal(root.get("drillHiringExp"), value.toString());
	    }else if ("purpose".equalsIgnoreCase(operation)) {
	        return builder.equal(root.get("drillPurpose"), value.toString());
	    }
		else {
	        throw new IllegalArgumentException("Unsupported operation: " + operation);
	    }
	}

	private Predicate getStatusPredicate(Root<Drill> root, CriteriaBuilder builder, String status) {
	    LocalDate currentDate = LocalDate.now();
	    LocalDate startDate = currentDate.minusDays(1);
	    LocalDate endDate = currentDate.plusDays(1);

	    if (DrillStatus.UPCOMING.name().equalsIgnoreCase(status)) {
	        return builder.greaterThan(root.get("drillStartDt"), Timestamp.valueOf(currentDate.atStartOfDay()));
	    } else if (DrillStatus.COMPLETED.name().equalsIgnoreCase(status)) {
	        return builder.lessThan(root.get("drillEndDt"), Timestamp.valueOf(currentDate.atStartOfDay()));
	    } else if (DrillStatus.LIVE.name().equalsIgnoreCase(status)) {
	        return builder.and(
	            builder.lessThanOrEqualTo(root.get("drillStartDt"), Timestamp.valueOf(currentDate.atStartOfDay())),
	            builder.greaterThanOrEqualTo(root.get("drillEndDt"), Timestamp.valueOf(currentDate.atStartOfDay()))
	        );
	    } else {
	        throw new IllegalArgumentException("Unsupported status: " + status);
	    }
	}
}

