package com.wue.custom.specification;

import com.wue.constant.drill.Stage;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class SearchTeamParticipantCriteria {

    private String drillId;
    private String teamId;
    private String participantId;
    private Stage stage;

}
