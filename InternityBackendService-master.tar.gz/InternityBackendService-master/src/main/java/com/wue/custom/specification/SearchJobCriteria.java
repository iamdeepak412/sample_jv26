package com.wue.custom.specification;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class SearchJobCriteria {
	private String jobType;
	private String jobTitle;
	private String jobLocation;
	private String jobSkills;
	private String partnerId;
	private double jobMinCtc;
	private double jobMaxCtc;
	private int jobMinYoe;
	private int jobMaxYoe;
	private String isActive;
	private String drillId;
}
