package com.wue.custom.specification;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@ToString
public class SearchCandidateCriteria {
	private String currentDesignation;
	private String currentOrg;
	private double minYoe;
	private double maxYoe;
	private double minCurrentCtc;
	private double maxCurrentCtc;
	private double minExpectedCtc;
	private double maxExpectedCtc;
	private int minNoticePeriodDays;
	private int maxNoticePeriodDays;
	private LocalDateTime minLastWorkingDay;
	private LocalDateTime maxLastWorkingDay;
	private String currentLocation;
	private String preferredLocation;
	private boolean isServingNp;
	private String email;
	private String name;
	private String isActive;
	private String jobId;
	private String skills;
}
