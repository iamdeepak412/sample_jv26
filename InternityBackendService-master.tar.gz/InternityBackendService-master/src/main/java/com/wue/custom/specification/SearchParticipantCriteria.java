package com.wue.custom.specification;

import java.time.LocalDate;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class SearchParticipantCriteria {
	private String drillId;
	private String platformUId;
	private String participantType;
	private String participantState;
	private String email;
	private String ctc;
	private String ectc;
	private String currentLoc;
	private String preferredLoc;
	private String clgName;
	private String clgSpecialization;
	private int clgPassingYear;
	private String fullname;
	private String organisation;
	private double yearsOfExperience;
	private boolean isServingNoticePeriod;
	private LocalDate lastWorkingDay;
	private String noticePeriod;
	private String registrationEndDate;
	private String registrationStartDate;
	
}
















