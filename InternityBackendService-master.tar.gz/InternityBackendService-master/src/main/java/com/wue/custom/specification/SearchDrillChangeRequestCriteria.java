package com.wue.custom.specification;

import com.wue.constant.drill.EntityType;
import com.wue.constant.drill.RequestStatus;
import com.wue.constant.drill.RequestType;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class SearchDrillChangeRequestCriteria {
    private RequestType requestType;
    private RequestStatus requestStatus;
    private EntityType entityType;
    private String entityId;
    private String sourceId;
}
