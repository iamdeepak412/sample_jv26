package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;


@Entity
@Getter
@Setter
@ToString
@Table(name="notification")
public class Notification {

	@Id
	@Column(name = "notification_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long notificationId;
	
	@Column(name = "sender_uid")
	private String senderUid;
	
	@Column(name = "receiver_uid", nullable = false)
	private String receiverUid;
	
	@Column(name = "is_read", nullable = false)
    private boolean isRead=false;

    @Column(name = "one_liner", nullable = false)
    private String oneLiner;

    @Lob
    @Column(name = "message", nullable = false)
    private String message;

    @Column(name = "notification_type")
    private String notificationType;
	
    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
