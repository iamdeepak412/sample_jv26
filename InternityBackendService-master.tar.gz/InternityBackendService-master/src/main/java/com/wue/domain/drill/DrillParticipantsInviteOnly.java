package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_participant_invite_only")
public class DrillParticipantsInviteOnly {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "invite_id", nullable = false, updatable = false)
    private String inviteId;

    @Column(name = "drill_id")
    private String drillId;

    @Column(name = "participant_email")
    private String participantEmail;

    @Column(name = "participant_name")
    private String participantName;

    @Column(name = "is_Participanted")
    private boolean isParticipated;


    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "record_createdby")
    private String createdBy;

    @Column(name = "record_updatedby")
    private String updatedBy;
}
