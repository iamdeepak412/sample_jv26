package com.wue.domain.certificategenerator;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
@ToString
@Table(name="web_checkin")
public class WebCheckin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false, updatable = false)
	private Long id;

	@Column(name = "event_id")
	private String eventId;
	
	
	@Column(name = "checkin_date")
	private Date checkinDt;


	@Column(name = "participant_id")
	private String participantId;

	@Column(name = "checkin_pass_url")
	private String checkinPassUrl;
	
	@Column(name = "is_participated")
	private boolean isParticipated;
	
	@Column(name = "pass_createdby")
	private String createdBy;
	
	@Column(name = "pass_updatedby")
	private String updatedBy;

	@Column(name = "pass_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "pass_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

}
