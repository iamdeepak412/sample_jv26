package com.wue.domain.CandidateApplication;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "job_application_screening_answer", uniqueConstraints = { @UniqueConstraint(columnNames = { "job_id", "u_id" }) })
public class JobApplicationScreeningAnswer {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "application_id")
    private Long applicationId;

    @Column(name = "job_id", nullable = false)
    private String jobId;

    @Column(name = "u_id", nullable = false)
    private String uId;

    @Column(name = "primary_skills_score")
    private Double primarySkillsScore;

    @Column(name = "total_yoe_score")
    private Double totalYoeScore;

    @Column(name = "is_deciding_question_score")
    private Double isDecidingQuestionScore;

    @Lob
    @Column(name = "all_custom_que_answer")
    private String allCustomQueAnswer;

    @Lob
    @Column(name = "skills_matching")
    private String skillsMatching;

    @Column(name = "total_yoe_matching")
    private String totalYoeMatching;

    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;
}
