package com.wue.domain;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.*;

import com.wue.dto.ApplicationSource;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
@ToString
@Table(name="application", uniqueConstraints = { @UniqueConstraint(columnNames = { "job_id", "u_id" }) })
public class Application {

	@Id
	@Column(name = "application_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long applicationId;
	
	@Column(name = "u_id", nullable = false)
	private String uId;
	
	@Column(name = "job_id", nullable = false)
	private String jobId;
	
	@Column(name = "appliedts", nullable = false)
    private LocalDateTime appliedTs;

    @Column(name = "current_status", nullable = false)
    private String currentStatus;

    @Column(name = "sub_status")
    private String subStatus;

    @Lob
    @Column(name = "skills_matched_details")
    private String skillsMatchedDetails;

    @Lob
    @Column(name = "custom_question_answered")
    private String customQuestionAnswered;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;

}
