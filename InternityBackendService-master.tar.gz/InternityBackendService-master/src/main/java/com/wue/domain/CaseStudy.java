package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="case_study")
public class CaseStudy {
	
	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "customer_id")
	private String customerId;

	@Column(name = "is_active")
	private boolean isActive;

	@Column(name = "title")
	private String title;

	@Column(name = "one_liner")
	private String oneLiner;

	@Lob
	@Column(name = "logo_url")
	private String logoUrl;

	@Lob
	@Column(name = "overview")
	private String overview;

	@Lob
	@Column(name = "outcome")
	private String outcome;

	@Lob
	@Column(name = "special_mention")
	private String specialMention;

	@Lob
	@Column(name = "gallery_urls")
	private String galleryUrls;

	@Lob
	@Column(name = "video_urls")
	private String videoUrls;

	@Column(name = "featured")
	private boolean isFeatured;
	
	@Column(name = "type")
	private String type;
	
	@Column(name = "sub_type")
	private String subType;

	@Column(name = "cust_url")
	private String custUrl;

	@Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;

}
