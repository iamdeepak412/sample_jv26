package com.wue.domain.idclass;

import java.io.Serializable;

public class SkillsLookupId implements Serializable{

	private static final long serialVersionUID = 3L;
	
	private String skillName;

	/**
	 * @param skillName the skillName to set
	 */
	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}
	
	

}
