package com.wue.domain.common;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name="industry_master", uniqueConstraints = { @UniqueConstraint(columnNames = { "industry" }) })
public class IndustryMaster {
    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="industry")
    private String industry;

    @Column(name="tags")
    private String tags;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;

    @Column(name="createdby")
    private String createdby;

    @Column(name="updatedby")
    private String updatedby;

}
