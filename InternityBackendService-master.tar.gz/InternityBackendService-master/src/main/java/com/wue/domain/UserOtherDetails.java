package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user_other_details")
public class UserOtherDetails{
	
	@Id
	@Column(name = "other_details_count", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long otherDetailsCount;
		
	@Column(name = "u_id")
	private String uId;
	
    @Column(name = "extra_curricular")
    @Lob
	private String extraCurricular;

    @Column(name = "certification")
    @Lob
	private String certification;
    
    @Column(name = "work_to_highlight")
    @Lob
	private String workToHighlight;

    @Column(name = "white_paper")
    @Lob
	private String whitePaper;
    
    @Column(name = "patent")
    @Lob
	private String patent;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
