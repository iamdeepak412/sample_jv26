package com.wue.domain.drill.submission;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_submission_evaluation",uniqueConstraints = { @UniqueConstraint(columnNames = { "submission_id", "judge_id" }) })
public class DrillSubmissionEvaluation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false, updatable = false)
	private Long id;

	@Column(name = "drill_id")
	private String drillId;

	@Column(name = "phase_id")
	private String phaseId;

	@Column(name = "panel_id")
	private String panelId;

	@Column(name = "submission_id")
	private String submissionId;

	@Column(name = "judge_id")
	private String judgeId;

	@Column(name = "submission_position")
	private Long submissionPosition;

	@Column(name = "status")
	private String status;

	@Lob
	@Column(name = "criteria_marks")
	private String criteriaMarks;

	@Column(name = "calculated_marks")
	private String calculatedMarks;

	@Column(name = "total_marks")
	private String totalMarks;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "is_nominated")
	private Boolean isNominated=false;

	@Column(name = "is_ignored")
	private Boolean isIgnored=false;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
