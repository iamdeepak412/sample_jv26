package com.wue.domain;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
@Table(name = "skills_lookup", uniqueConstraints = { @UniqueConstraint(columnNames = { "skill_name" }) })
@Data
public class SkillsLookup {

	@Id
	@Column(name = "skill_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long skillId;
	
	@Column(name = "skill_name", length = 200, unique = true)
	private String skillName;
	
	@Column(name = "skill_tags", columnDefinition = "TEXT")
	private String skillTags;

	@Column(name = "createdby", length = 100)
	private String createdby;

	@Column(name = "createdts")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdts;

	@Column(name = "updatedby", length = 100)
	private String updatedby;

	@Column(name = "updatedts")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedts;
}
