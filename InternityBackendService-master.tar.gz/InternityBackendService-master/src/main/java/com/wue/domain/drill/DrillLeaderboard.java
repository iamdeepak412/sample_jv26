package com.wue.domain.drill;


import com.wue.constant.drill.DrillWinnerType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "drill_leaderboard")
public class DrillLeaderboard {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "leaderboard_id", unique = true, nullable = false, updatable = false)
    private String leaderboardId;

    @Column(name = "drill_id", nullable = false, updatable = false)
    private String drillId;

    @Column(name = "team_id", updatable = false)
    private String teamId;

    @Column(name="participant_id", updatable = false)
    private String participantId;

    @Column(name = "position")
    private String position;

    @Column(name = "is_project_show")
    private boolean isProjectShow;

    @Column(name = "phase_id")
    private String phaseId;

    @Column(name = "submission_id")
    private String submissionId;

    @Enumerated(EnumType.STRING)
    private DrillWinnerType winnerType;

    @Column(name = "average_marks")
    private String averageMarks;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedTs;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordUpdatedTs;

    @Column(name = "record_createdby")
    private String recordCreatedBy;

    @Column(name = "record_updatedby")
    private String recordUpdatedBy;
}
