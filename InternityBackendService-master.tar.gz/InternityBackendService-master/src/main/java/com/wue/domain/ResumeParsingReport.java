package com.wue.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
@ToString
@Table(name="resume_parsing_report")
public class ResumeParsingReport {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "id", unique = true, nullable = false, updatable = false)
    private String Id;

    @Column(name = "document_type")
    private String documentType;

    @Column(name = "document_owner_id")
    private String documentOwnerId;

    @Column(name = "email")
    private String email;

    @Column(name = "is_parsed")
    private boolean isParsed;


}