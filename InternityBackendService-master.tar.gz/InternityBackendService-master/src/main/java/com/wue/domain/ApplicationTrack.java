package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "application_track")

public class ApplicationTrack {

	@Id
	@Column(name = "application_track_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long applicationTrackId;

	@Column(name = "status", nullable = false)
	private String status;

	@Column(name = "subStatus", nullable = false)
	private String subStatus;

	@JoinColumn(name = "application_id")
	private Long applicationId;

	@Column(name = "feedback")
	private String feedback;

	@Column(name = "updatedby", length = 100)
	private String updatedby;

	@Column(name = "updatedts")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedts;

}
