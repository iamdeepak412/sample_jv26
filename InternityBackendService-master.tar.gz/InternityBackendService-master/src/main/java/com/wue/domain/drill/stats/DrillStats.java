package com.wue.domain.drill.stats;

import lombok.Data;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "drill_stats")
@Data
public class DrillStats {

	@Id
	@Column(name = "drill_stats_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long drillStatsId;

	@Column(name = "numb_participants")
	private Long numberOfParticipants;

	@Column(name = "numb_teams")
	private Long numberOfTeams;

	@Column(name = "numb_idea_submissions")
	private Long numberOfIdeaSubmissions;

	@Column(name = "numb_page_visits")
	private Long numberOfPageVisits;

	@Column(name = "numb_partners")
	private Long numberOfPartners;

	@Column(name = "numb_joinings")
	private Long joiningsDone;

	@Column(name = "numb_users_in_one_day")
	private Long numberOfUsersInOneDay;

	@Column(name = "numb_active_users_in_one_day")
	private Long numberOfActiveUsersInOneDay;

	@Column(name = "numb_inactive_users_in_one_day")
	private Long numberOfInactiveUsersInOneDay;

	@Column(name = "numb_jobs_in_one_day")
	private Long numberOfJobPostedInOneDay;

	@Column(name = "numb_platform_views_in_one_day")
	private Long numberOfPlatformViewsInOneDay;

	@Column(name = "numb_job_views_in_one_day")
	private Long numberOfJobViewsInOneDay;

	@Column(name = "numb_drill_views_in_one_day")
	private Long numberOfDrillViewsInOneDay;

	@Column(name = "numb_landing_views_in_one_day")
	private Long numberOfLandingViewsInOneDay;

	@Column(name = "numb_profile_views_in_one_day")
	private Long numberOfProfileViewsInOneDay;

	@Column(name = "numb_drill_participants_in_one_day")
	private Long numberOfDrillParticipantsInOneDay;

	@Column(name = "numb_jobs_applied_in_one_day")
	private Long numberOfJobsAppliedInOneDay;

	@Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "record_insertedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordInsertedts;
	
    @Column(name = "numb_squad")
	private int numberOfSquadPrograms;

    @Column(name = "numb_hackathons")
	private int numberOfHackathons;

	@Transient
	private int numberOfProfessionalsUsers;

	@Transient
	private int numberOfFreshersUsers;

	@Transient
	private int numberOfFresherHired;
	
	@Transient
	private int numberOfInternsHired;
	
	@Transient
	private int numberOfmeetups;
	
	@Transient
	private int numberOfColleges;
	
	@Transient
	private int numberOfFresherDrives;
	
	@Transient
	private int numberOfStudentsInSquad;
	
}
