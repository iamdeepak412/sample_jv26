package com.wue.domain.blog;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "comment")
public class Comment {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "comment_id", nullable = false, unique = true)
    private String commentId;

    @Column(name = "blog_post_id", nullable = false)
    private String blogpostId;

    @Column(name = "u_id", nullable = false)
    private String uId;
    
    @Lob
    @Column(name = "content", nullable = false)
    private String content;

    @Column(name = "parent_comment_id")
    private String parentCommentId;

    @Column(name = "commenter_name")
    private String commenterName;

    @Column(name = "comment_reaction_count",columnDefinition = "bigint default 0")
    private long commentReactionCount;

    @Column(name = "report_abuse_count",columnDefinition = "bigint default 0")
    private long reportAbuseCount;


    @Column(name = "record_createdby")
    private String recordCreatedBy;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedTs;

    @Column(name = "record_updatedby")
    private String recordUpdatedBy;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordUpdatedTs;

}

