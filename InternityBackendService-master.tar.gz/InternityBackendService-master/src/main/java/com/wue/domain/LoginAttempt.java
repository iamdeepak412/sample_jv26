package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Table(name = "login_attempt")
public class LoginAttempt {

    @Id
    @Column(name = "login_attempt_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long loginAttemptId;

    @Column(name = "attempt_email")
	private String attemptEmail;
    
    @Column(name = "attempt_status", nullable = false)
	private String attemptStatus;

    @Column(name = "attempt_time")
	private LocalDateTime attemptTime;
    
    @Column(name = "location")
	private String location;
    
    @Column(name = "device")
    private String device;

}
