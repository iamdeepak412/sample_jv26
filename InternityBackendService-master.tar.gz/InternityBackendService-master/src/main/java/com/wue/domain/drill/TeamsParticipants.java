package com.wue.domain.drill;

import com.wue.constant.drill.Stage;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "drill_teams_participants")
public class TeamsParticipants {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "drill_id")
    private String drillId;

    @Column(name = "team_id")
    private String teamId;

    @Column(name = "participant_id")
    private String participantId;
    @Lob
    @Column(name = "participant_value")
    private String participantValue;

    @Column(name = "is_request_accepted")
    private boolean isRequestAccepted;

    @Column(name = "stage")
    @Enumerated(EnumType.STRING)
    private Stage stage;
    @Lob
    @Column(name = "participant_skills")
    private String participantSkills;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "record_createdby")
    private String createdBy;

    @Column(name = "record_updatedby")
    private String updatedBy;

}
