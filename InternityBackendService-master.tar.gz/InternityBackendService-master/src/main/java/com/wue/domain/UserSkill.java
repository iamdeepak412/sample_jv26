package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user_skill")
public class UserSkill {
	
	@Id
	@Column(name = "user_skill_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long userSkillId;

    @Column(name = "u_id")   
	private String uId;

    @Column(name = "skill_name", length = 200)   
	private String skillName;
    
    @Column(name = "skill_level_name", length = 999)   
	private String skillLevelName;

    @Column(name = "relevant_experience")   
	private Double relevantExperience;
    
    @Column(name = "is_active")   
	private boolean isActive;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "skill_last_used")
    @DateTimeFormat(pattern = "MM-yyyy")
    private Date skillLastUsed;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
