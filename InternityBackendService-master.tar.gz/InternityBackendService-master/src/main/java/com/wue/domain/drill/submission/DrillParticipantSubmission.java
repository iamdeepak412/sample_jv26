package com.wue.domain.drill.submission;

import com.wue.constant.submission.SubmissionResult;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_participant_submission")
public class DrillParticipantSubmission {
	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "submission_id", nullable = false, updatable = false)
	private String submissionId;

	@Column(name = "participant_id")
	private String participantId;

	@Column(name = "drill_id")
	private String drillId;

	@Column(name = "phase_id")
	private String phaseId;

	@Column(name = "team_id")
	private String teamId;

	@Column(name = "theme")
	private String theme;

	@Column(name = "panel_id")
	private String panelId;

	@Column(name = "project_name")
	private String projectName;

	@Column(name = "is_active_submission")
	private boolean isActiveSubmission;

	@Lob
	@Column(name = "source_code")
	private String sourceCode;

	@Lob
	@Column(name = "video")
	private String video;

	@Lob
	@Column(name = "presentation")
	private String presentation;

	@Lob
	@Column(name = "snapshots")
	private String snapshots;

	@Lob
	@Column(name = "other_submission")
	private String otherSubmission;

	@Lob
	@Column(name = "submission_desc")
	private String submissionDescription;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

	@Transient
	private String sendMail;

	@Column(name = "submission_result")
	@Enumerated(EnumType.STRING)
	private SubmissionResult submissionResult;
}
