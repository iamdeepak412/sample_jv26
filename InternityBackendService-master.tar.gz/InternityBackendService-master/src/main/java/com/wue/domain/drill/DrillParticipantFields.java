package com.wue.domain.drill;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "drill_participant_fields")
public class DrillParticipantFields {

    @Id
    @Column(name = "drill_id", nullable = false,unique = true)
    private String drillId;

    @Column(name = "participant_fields")
    private String participantFields;

    @Column(name = "created_ts")
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdTs;

    @Column(name = "updated_ts")
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTs;

}
