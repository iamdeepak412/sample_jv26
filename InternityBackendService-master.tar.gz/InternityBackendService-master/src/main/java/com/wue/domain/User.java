package com.wue.domain;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user")
public class User  {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "u_id", unique = true, nullable = false, updatable = false)
	private String uId;

    @Column(name = "user_name", unique = true, nullable = false, updatable = false)    
	private String username;
    
    @Column(name = "full_name", nullable = false)    
	private String fullName;
    
    @Column(name = "email", unique = true, nullable = false, updatable = false)    
	private String email;
    
    @Column(name = "u_contact", unique = true, nullable = false)
	private String uContact;
    
    @Column(name = "password", nullable = false)    
	private String password;
    
    @Column(name = "u_group", nullable = false)    
	private String uGroup;

    @Column(name = "u_role")
    private String uRole;

    //verification after first time login or after Admin inactivate the profile
    @Column(name = "is_active", columnDefinition="boolean default false")
    private boolean isActive;
    
    @Column(name = "u_type")
    private String uType;

    @Column(name = "referral_code")
    private String referralCode;

    @Column(name = "source")
    private String source;

    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Column(name = "is_condition_accepted", columnDefinition="boolean default true")
    private boolean isConditionAccepted;

    @Column(name = "mentor", columnDefinition="boolean default false")
    private boolean mentor;

    @Column(name = "jobfeed", columnDefinition="boolean default false")
    private boolean jobfeed;

    @Transient
    private String resumeLink;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;
}
