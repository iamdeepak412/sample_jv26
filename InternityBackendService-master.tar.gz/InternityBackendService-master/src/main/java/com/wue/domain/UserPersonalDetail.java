package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user_profile", uniqueConstraints = {@UniqueConstraint(columnNames = {"u_id"})})
public class UserPersonalDetail implements Serializable {

    private static final long serialVersionUID = 2L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "personal_details_count")
    private Long personalDetailsCount;

    @Column(name = "u_id")
    private String uId;

    @Column(name = "gender", length = 30)
    private String gender;

    @Lob
    @Column(name = "current_city", length = 100)
    private String currentCity;

    @Lob
    @Column(name = "current_state", length = 100)
    private String currentState;

    @Column(name = "zipcode", length = 10)
    private String zipcode;

    @Column(name = "current_address", length = 999)
    private String currentAddress;

    @Column(name = "marital_status")
    private String maritalStatus;

    @Column(name = "is_serving_np")
    private boolean isServingNoticePeriod = false;

    @Column(name = "lwd")
    private LocalDateTime lastWorkingDay;

    @Column(name = "dob")
    @DateTimeFormat(pattern = "dd-MM-yyyy")
    private Date dateOfBirth;

    @Lob
    @Column(name = "other_details")
    private String otherDetails;

    @Column(name = "cover_letter", length = 999)
    private String coverLetter;

    @Column(name = "resume_link", length = 999)
    private String resumeLink;

    @Column(name = "govt_id_link", length = 999)
    private String govtIdLink;

    @Column(name = "profilePicLink", length = 999)
    private String profilePicLink;

    @Column(name = "coverPicLink", length = 999)
    private String coverPicLink;

    @Lob
    @Column(name = "social_links")
    private String socialLinks;

    @Column(name = "languages_known", length = 999)
    private String languagesKnown;

    @Column(name = "profile_completion")
    private int profileCompletion;

    @Column(name = "profile_createdby", length = 100)
    private String profileCreatedby;

    @Column(name = "profile_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date profileCreatedts;

    @Column(name = "profile_updatedby", length = 100)
    private String profileUpdatedby;

    @Column(name = "profile_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date profileUpdatedts;
}
