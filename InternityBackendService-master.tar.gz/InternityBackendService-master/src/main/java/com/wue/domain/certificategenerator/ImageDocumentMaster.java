package com.wue.domain.certificategenerator;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name="image_document_master")
public class ImageDocumentMaster {
	
	@Id
	@Column(name = "event_id")
	private String eventId;
	
	@Column(name = "event_type")
	private String eventType;
	
	@Column(name = "image_state")
	private String imageState;
	
	@Column(name = "image_url")
	private String imageUrl;
	 
	@Column(name = "image_title_axis")
	@Lob
	private String imageTitleAxis;


	@Column(name = "pass_createdby")
	private String createdBy;
	
	@Column(name = "pass_updatedby")
	private String updatedBy;

	@Column(name = "pass_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "pass_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

}
