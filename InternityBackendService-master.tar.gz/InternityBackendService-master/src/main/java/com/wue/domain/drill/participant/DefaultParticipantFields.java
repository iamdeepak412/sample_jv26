package com.wue.domain.drill.participant;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="default_participant_fields")
public class DefaultParticipantFields {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "field_id")
    private Long fieldId;

    @Column(name = "field_name")
    private String fieldName;

    @Column(name = "field_desc")
    private String fieldDescription;

    @Column(name = "field_type")
    private String fieldType;

    @Column(name = "is_required")
    private boolean isRequired;

    @Column(name = "is_hidden")
    private boolean isHidden;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "record_createdby")
    private String createdBy;

    @Column(name = "record_updatedby")
    private String updatedBy;

    @Override
    public String toString() {
        return "{"
                + "\"fieldId\":\""
                + fieldId
                + '\"'
                + ", \"fieldName\":\""
                + fieldName
                + '\"'
                + ", \"fieldDescription\":\""
                + fieldDescription
                + '\"'
                + ", \"fieldType\":\""
                + fieldType
                + '\"'
                + ", \"required\":"
                + isRequired
                + ", \"hidden\":"
                + isHidden
                + ", \"createdTs\":\""
                + createdTs
                + '\"'
                + ", \"updatedTs\":\""
                + updatedTs
                + '\"'
                + ", \"createdBy\":\""
                + createdBy
                + '\"'
                + ", \"updatedBy\":\""
                + updatedBy
                + '\"'
                + '}';
    }
}
