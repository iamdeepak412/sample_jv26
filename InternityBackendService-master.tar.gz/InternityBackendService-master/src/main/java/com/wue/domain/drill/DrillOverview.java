package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_overview")
public class DrillOverview {

	@Id
	@Column(name = "drill_id", unique = true, nullable = false, updatable = false)
	private String drillId;

	@Lob
	@Column(name = "eligibility")
	private String eligibility;

	@Lob
	@Column(name = "guidelines")
	private String guidelines;

	@Column(name = "domain")
	private String domain;

	@Column(name = "industry")
	private String industry;

	@Column(name = "total_prize_value")
	private String totalPrizeValue;

	@Column(name = "overview_section_complete")
	private String OverviewSectionComplete;

	@Lob
	@Column(name = "drill_description")
	private String DrillDescription;

	@Column(name = "record_createdts")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdTs;

	@Column(name = "record_updatedts")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedTs;

	@Column(name = "record_createdby")
	private String createdBy;

	@Column(name = "record_updatedby")
	private String updatedBy;

}
