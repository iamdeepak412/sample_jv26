package com.wue.domain.drill;

import com.wue.constant.drill.DrillStatus;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drills", uniqueConstraints = { @UniqueConstraint(columnNames = { "drill_name", "drill_partner_id"}) })
public class Drill {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "drill_id", unique = true, nullable = false, updatable = false)
	private String drillId;

	@Column(name = "drill_name")
	private String drillName;

	@Column(name = "drill_timezone")
	private String drillTimezone;

	@Column(name = "drill_start_dt")
	private LocalDateTime drillStartDt;

	@Column(name = "drill_end_dt")
	private LocalDateTime drillEndDt;

	@Column(name = "drill_reg_start_dt")
	private LocalDateTime drillRegistrationStartDt;

	@Column(name = "drill_reg_end_dt")
	private LocalDateTime drillRegistrationEndDt;

	@Column(name = "drill_schedule_if_not_date_known")
	private String drillScheduleIfNotDateKnown;

	@Column(name = "drill_nature")
	private String drillNature;

	@Column(name = "drill_cust_url")
	private String drillCustUrl;

	@Column(name = "drill_purpose")
	private String drillPurpose;

	@Column(name = "drill_type")
	private String drillType;

	@Column(name = "drill_team_size")
	private String drillTeamSize="{\"min\":\"1\",\"max\":\"4\"}";

	@Column(name = "drill_section_complete")
	private String drillSectionComplete="[\"overview\"]";

	@Column(name = "drill_partner_id")
	private String drillPartnerId;

	@Column(name = "drill_partner_name")
	private String drillPartnerName;

	@Column(name = "drill_logo_url")
	private String drillLogoUrl;
	
	@Lob
	@Column(name = "drill_custom")
	private String drillCustom;

	@Lob
	@Column(name = "drill_social_links")
	private String drillSocialLinks;

	@Column(name = "drill_cover_img_url")
	private String drillCoverImgUrl="https://wuelev8-common.s3.ap-south-1.amazonaws.com/common/sampledrill.png";

	@Column(name = "drill_mobile_cover_img_settings")
	private String drillMobileCoverImgSettings;

	@Column(name = "drill_hiring_skill")
	private String drillHiringSkill;

	@Column(name = "drill_hiring_exp")
	private String drillHiringExp;

	@Column(name = "is_active")
	private boolean isActive;

	@Column(name="drill_applicant_count")
	private Long drillApplicantCount=0L;

	@Column(name="drill_page_settings")
	private String drillPageSettings="{\"bannerTextShow\":false,\"numbRegisteredIconColor\":\"black\"}";

	//{"type":"Multiple","hasIdeaPhase":true,"isSelfPaced":true,"schedule":[{"phaseStartDt":"20/03/2023T00:00:00.000Z","phaseEndDt":"28/03/2023T00:00:00.000Z","phaseSubmissionDt":"27/03/2023T00:00:00.000Z","mode":"Online","location":"Online","phaseName":"Idea Phase","phaseType":"IDEA"}]}
    @Lob
	@Column(name = "drill_phase")
    private String drillPhase;

	@Column(name = "drill_phase_type")
	private String drillPhaseType;

	@Column(name = "is_self_paced")
	private boolean isSelfPaced;

	@Column(name = "drill_chat_platform")
	private String drillChatPlatform="{\"platform\":\"Discord\", \"link\":\"\"}";

	@Column(name = "drill_location")
	private String drillLocation;

	@Column(name = "drill_latest_status")
	private String drillLatestStatus=DrillStatus.INACTIVE.name();

	@Column(name = "drill_invitation_type")
	private String drillInvitationType;

	@Column(name = "drill_key_highlights", length = 500)
	private String drillKeyHighlights;

	@Column(name = "is_drill_paid")
	private Boolean isDrillPaid;

	@Column(name = "total_prize_value")
	private String totalPrizeValue;

	@Column(name = "drill_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "drill_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "drill_createdby")
	private String createdBy;
	
	@Column(name = "drill_updatedby")
	private String updatedBy;

    @Transient
    private String partnerWebsiteLink;
}
