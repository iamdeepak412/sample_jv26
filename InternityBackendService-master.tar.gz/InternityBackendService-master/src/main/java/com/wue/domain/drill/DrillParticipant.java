package com.wue.domain.drill;

import com.wue.constant.drill.MemberType;
import com.wue.constant.drill.PaymentStatus;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_participant", uniqueConstraints = { @UniqueConstraint(columnNames = { "drill_id", "email" }) })
public class DrillParticipant {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "participant_id", nullable = false, updatable = false)
	private String participantId;

	@Column(name = "drill_id")
	private String drillId;

	@Column(name = "platform_uid")
	private String platformUId;

	@Column(name = "aadhar_id")
	private String aadharId;

	@Column(name = "pancard_id")
	private String pancardId;

	@Column(name = "full_name")
	private String fullName;

	@Column(name = "participant_type")
	private String participantType;

	@Column(name = "participant_state")
	private String participantState = "REGISTERED";

	@Column(name = "email")
	private String email;

	@Column(name = "contact")
	private String contact;

	@Column(name = "current_loc")
	private String currentLoc;

	@Column(name = "preferred_loc")
	private String preferredLoc;

	@Column(name = "ctc")
	private String ctc;

	@Column(name = "ectc")
	private String ectc;

	@Column(name = "clg_name")
	private String clgName;

	@Column(name = "clg_specialization")
	private String clgSpecialization;

	@Column(name = "clg_passing_year")
	private int clgPassingYear;

	@Column(name = "clg_passing_semester")
	private int clgPassingSemester;

	@Column(name = "job_title")
	private String jobTitle;

	@Column(name = "organisation")
	private String organisation;

	@Column(name = "yoe")
	private double yearsOfExperience;

	@Column(name = "is_serving_np")
	private boolean isServingNoticePeriod;

	@Column(name = "lwd")
	private LocalDate lastWorkingDay;

	@Column(name = "notice_period")
	private String noticePeriod;

	@Column(name = "willing_for_job")
	private boolean willingForJob;

	@Column(name = "affiliate_platform")
	private String affiliatePlatform;

	@Column(name = "skills")
	private String skills;

	@Column(name = "resume_link")
	private String resumeLink;

	@Column(name = "notification_response")
	private boolean notificationResponse;

	@Column(name = "member_type")
	@Enumerated(EnumType.STRING)
	private MemberType memberType;

	@Column(name = "payment_status")
	@Enumerated(EnumType.STRING)
	private PaymentStatus paymentStatus;
	@Column(name = "last_name")
	private String lastName;
	@Column(name = "country")
	private String country;
	@Column(name = "state")
	private String state;
	@Column(name = "registered_date")
	private Date registeredDate;
	@Column(name = "degree_type")
	private String degreeType;
	@Column(name = "degree")
	private String degree;
	@Column(name = "roll_number")
	private String rollNumber;
	@Column(name = "candidate_id")
	private String candidateId;
	@Column(name = "employee_id")
	private String employeeId;
	@Column(name = "cgpa")
	private double cgpa;

	@Column(name = "industry")
	private String industry;


	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

	@Transient
	private String drillName;

	@Transient
	private String teamId;

	@Transient
	private String teamName;

	@Transient
	private String candidateType;

	@Transient
	private String theme;

	@Transient
	private String teamParticipationMessage;

	@Transient
	private DrillTeams teamsDetails;
}
