package com.wue.domain.drill.mails;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_mail_template")
public class DrillMailTemplate {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "mail_template_id", unique = true, nullable = false, updatable = false)
	private String mailTemplateId;

	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;

	@Column(name = "template_name")
	private String templateName;

	@Column(name = "template_desc")
	private String templateDesc;

	@Column(name = "mail_subject")
	private String mailSubject;

	@Lob
	@Column(name = "mail_body")
	private String mailBody;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
