package com.wue.domain;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Entity
@Getter
@Setter
@ToString
@Table(name="customer_user")
public class CustomerUser {
	@Id
	@Column(name = "u_id",unique = true, nullable = false, updatable = false)
	private String uId;
	
	@Column(name = "designation")
	private String designation;
	
	@Column(name = "company_id")
	private String companyId;
	
	@Column(name = "created_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "updated_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "updated_by")
	private String updatedBy;

}
