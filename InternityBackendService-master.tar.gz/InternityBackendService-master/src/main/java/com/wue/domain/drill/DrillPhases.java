package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_phases")
public class DrillPhases {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "phase_id", unique = true, nullable = false, updatable = false)
	private String phaseId;

	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;

	@Column(name = "phase_name")
	private String phaseName;

	@Column(name = "phase_type")
	private String phaseType;

	@Lob
	@Column(name = "phase_desc")
	private String phaseDesc;

	@Column(name = "phase_timezone")
	private String phaseTimezone;

	@Column(name = "phase_start_dt")
	private LocalDateTime phaseStartDt;

	@Column(name = "phase_end_dt")
	private LocalDateTime phaseEndDt;

	@Column(name = "is_date_confirmed")
	private boolean isDateConfirmed=true;

	@Column(name = "start_month")
	private String startMonth;

	@Column(name = "end_month")
	private String endMonth;

	@Column(name = "phase_submission_end_dt")
	private LocalDateTime phaseSubmissionEndDt;

	@Column(name = "phase_mode")
	private String phaseMode;

	@Column(name = "phase_loc")
	private String phaseLoc;

	@Column(name = "phase_status")
	private String phaseStatus;

	@Column(name = "is_hidden")
	private boolean isHidden=false;

	@Column(name = "is_submission_allowed")
	private boolean isSubmissionAllowed;

	@Column(name = "record_createdts")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdTs;

	@Column(name = "record_updatedts")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedTs;

	@Column(name = "record_createdby")
	private String createdBy;

	@Column(name = "record_updatedby")
	private String updatedBy;

	@Column(name = "phase_position")
	private int phasePosition;

}
