package com.wue.domain.Rbac;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "access_type")
public class AccessType {

    @Id
    @Column(name = "access_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long accessId;

    @Column(name = "access_name", nullable = false)
    private String accessName;

    //to be used while fetching the accesses for creating or configuring roles
    @Column(name = "is_active", columnDefinition="boolean default true")
    private boolean isActive;

    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;
}
