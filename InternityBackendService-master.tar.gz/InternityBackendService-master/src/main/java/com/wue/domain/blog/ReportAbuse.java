package com.wue.domain.blog;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "report_abuse")
public class ReportAbuse {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "report_id", nullable = false, unique = true)
    private String reportId;

    @Column(name = "post_id", nullable = false)
    private String postId;
    
    @Lob
    @Column(name = "report", nullable = false)
    private String report;

    @Column(name = "u_id", nullable = false)
    private String uId;

    @Column(name = "comment_id")
    private String commentId;


    @Column(name = "record_createdby")
    private String recordCreatedBy;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedTs;

}

