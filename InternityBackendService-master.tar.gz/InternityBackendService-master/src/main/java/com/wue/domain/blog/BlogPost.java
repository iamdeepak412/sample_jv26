package com.wue.domain.blog;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;


@Getter
@Setter
@Entity
@Table(name = "blog_post")
public class BlogPost {

	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "blog_post_id", nullable = false, unique = true)
    private String blogpostId;

    @Column(name = "u_id", nullable = false)
    private String uId;

    @Column(name = "title", nullable = false)
    private String title;

    @Column(name = "category_id", nullable = false)
    private String categoryId;
    
    @Column(name = "cust_url")
	private String custUrl;
    
    @Lob
    @Column(name = "content", nullable = false)
    private String content;

    @Column(name = "summary")
    private String summary;
    
    @Lob
    @Column(name = "cover_img_url")
    private String coverImgUrl;
    
    @Lob
    @Column(name = "tags")
    private String tags;

    @Column(name = "reaction_count", nullable = false)
    private int reactionCount;

    @Column(name = "comment_count", nullable = false)
    private int commentCount;

    @Column(name = "min_to_read", nullable = false)
    private int minToRead;

    @Column(name = "is_active", nullable = false)
    private boolean isActive;

    @Column(name = "is_featured", nullable = false)
    private boolean isFeatured;
    @Column(name ="name", columnDefinition ="VARCHAR(255) COMMENT 'Column to store the name of the content influencer'")
    private String name;

    @Column(name = "share_count",columnDefinition = "bigint default 0")
    private long shareCount;

    @Column(name = "report_abuse_count",columnDefinition = "bigint default 0")
    private long reportAbuseCount;


    @Column(name = "record_createdby")
    private String recordCreatedBy;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedTs;

    @Column(name = "record_updatedby")
    private String recordUpdatedBy;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordUpdatedTs;

}

