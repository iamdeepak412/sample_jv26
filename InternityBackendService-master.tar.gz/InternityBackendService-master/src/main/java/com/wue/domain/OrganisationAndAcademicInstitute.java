package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "organisation_academic_institute")
public class OrganisationAndAcademicInstitute {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Long id;
	    
	    @Column(name = "type")
	    private String type;
	    
	    @Column(name = "name")
	    private String name;
	    
	    @Column(name = "image_url")
	    private String imageUrl;
	    
	    @Column(name = "position_order")
	    private int positionOrder;
	    
	    @Column(name = "is_active")
	    private boolean isActive;
	    
	    @Column(name = "created_ts", updatable = false)
	    @CreationTimestamp
	    private Date createdTs;
	    
	    @Column(name = "updated_ts")
	    @UpdateTimestamp
	    private Date updatedTs;
	    
	    @Column(name = "created_by", updatable = false)
	    private String createdBy;
	    
	    @Column(name = "updated_by")
	    private String updatedBy;
}
