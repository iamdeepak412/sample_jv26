package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "edu_info")
public class EducationInformation {
	
	@Id
	@Column(name = "edu_info_count", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long eduInfoCount;
	
	@Column(name = "u_id")
	private String uId;

    @Column(name = "qualification", length = 50)   
	private String qualification;
    
    @Column(name = "institute_name", length = 999)   
	private String instituteName;
    
    @Column(name = "school_name", length = 999)   
	private String schoolName;
    
    @Column(name = "university_name", length = 999)   
	private String universityName;
    
    @Column(name = "board_name", length = 999)   
	private String boardName;
    
    @Column(name = "school_medium", length = 100)   
	private String schoolMedium;

    @Column(name = "degree", length = 100)   
	private String degree;
    
    @Column(name = "studyField", length = 100)   
	private String specialization;
    
    @Column(name = "is_pursuing")   
	private boolean isPursuing;

    @Column(name = "cgpa_percentage")   
	private Double cgpaPercentage;
    
    @Column(name = "grading_system", length = 10)   
	private String gradingSystem;
    
    @Column(name = "passing_out_year")
	private int passingOutYear;
    
    @Column(name = "course_type", length = 50)
	private String courseType;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
