package com.wue.domain.drill.publish;

import com.wue.constant.drill.DrillRequestType;
import com.wue.constant.job.DrillRequestStatus;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_publish_requests")
public class DrillPublishRequests {

	@Id
	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;

	@Column(name = "request_type")
	@Enumerated(EnumType.STRING)
	private DrillRequestType requestType;  //(PUBLISH/UNPUBLISH)


	@Column(name = "request_status")
	@Enumerated(EnumType.STRING)
	private DrillRequestStatus requestStatus; //(PENDING,APPROVED,REJECTED)

    @Column(name = "request_by_u_id")
	private String requestByUId;


	@Column(name = "approver_uid")
	private String approverUid;


	@Lob
	@Column(name = "remarks")
	private String remarks;


	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
