package com.wue.domain.drill;

import com.wue.constant.drill.EntityType;
import com.wue.constant.drill.RequestStatus;
import com.wue.constant.drill.RequestType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "drill_change_request")
public class DrillChangeRequest {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "request_id", unique = true, nullable = false, updatable = false)
    private String requestId;
    @Column(name = "request_type")
    @Enumerated(EnumType.STRING)
    private RequestType requestType;
    @Lob
    @Column(name = "request_reason")
    private String requestReason;
    @Lob
    @Column(name = "request_data")
    private String requestData;
    @Column(name = "request_status")
    @Enumerated(EnumType.STRING)
    private RequestStatus requestStatus;
    @Column(name = "requested_by")
    private String requestedBy;
    @Column(name = "approved_by")
    private String approvedBy;
    @Column(name = "source_id")
    private String sourceId;
    @Column(name = "entity_id")
    private String entityId;
    @Column(name = "entity_type")
    @Enumerated(EnumType.STRING)
    private EntityType entityType;
    @Column(name = "drill_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

    @Column(name = "drill_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "drill_createdby")
    private String createdBy;

    @Column(name = "drill_updatedby")
    private String updatedBy;


}
