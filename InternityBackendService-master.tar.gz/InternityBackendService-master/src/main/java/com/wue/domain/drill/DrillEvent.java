package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_event")
public class DrillEvent {
	@Id
	@Column(name = "drill_event_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long drillEventId;
	
	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;

	@Column(name = "event_start_dt")
	private LocalDateTime eventStartDt;

	@Column(name = "event_end_dt")
	private LocalDateTime eventEndDt;

	@Column(name = "event_title")
	private String eventTitle;

	@Lob
	@Column(name = "event_img")
	private String eventImg;

	@Lob
	@Column(name = "event_all_link")
	private String eventAllLink;

	@Lob
	@Column(name = "event_speaker")
	private String eventSpeaker;

	@Lob
	@Column(name = "event_host")
	private String eventHost;

	@Lob
	@Column(name = "event_other_details")
	private String eventOtherDetails;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
