package com.wue.domain.certificategenerator;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_participant_result", uniqueConstraints = { @UniqueConstraint(columnNames = { "event_id", "participant_id" }) })
public class ParticipantCertificate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false, updatable = false)
	private Long id;

	@Column(name = "event_id")
	private String eventId;

	@Column(name = "event_type")
	private String eventType;

	@Column(name = "u_id")
	private String uId;

	@Column(name = "participant_id")
	private String participantId;

	@Column(name = "certificate_id")
	private String certificateId;

	@Column(name = "certificate_url")
	private String certificateUrl;

	@Column(name = "certificate_mail_status")
	private boolean certificateMailStatus = false;

	@Column(name = "position_type")
	private String positionType;

	@Lob
	@Column(name = "remarks")
	private String remarks;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
