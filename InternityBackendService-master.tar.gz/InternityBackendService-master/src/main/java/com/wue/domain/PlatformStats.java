package com.wue.domain;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
@Table(name = "platform_stats")
@Data
public class PlatformStats {

	@Id
	@Column(name = "stats_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long statsId;

	@Column(name = "numb_users")
	private Long numberOfUsersOnPlatform;

	@Column(name = "numb_active_users")
	private Long numberOfActiveUsersOnPlatform;

	@Column(name = "numb_inactive_users")
	private Long numberOfInactiveUsersOnPlatform;

	@Column(name = "numb_jobs")
	private Long numberOfJobPosted;

	@Column(name = "numb_partners")
	private Long numberOfPartners;

	@Column(name = "numb_joinings")
	private Long joiningsDone;

	@Column(name = "numb_users_in_one_day")
	private Long numberOfUsersInOneDay;

	@Column(name = "numb_active_users_in_one_day")
	private Long numberOfActiveUsersInOneDay;

	@Column(name = "numb_inactive_users_in_one_day")
	private Long numberOfInactiveUsersInOneDay;

	@Column(name = "numb_jobs_in_one_day")
	private Long numberOfJobPostedInOneDay;

	@Column(name = "numb_platform_views_in_one_day")
	private Long numberOfPlatformViewsInOneDay;

	@Column(name = "numb_job_views_in_one_day")
	private Long numberOfJobViewsInOneDay;

	@Column(name = "numb_drill_views_in_one_day")
	private Long numberOfDrillViewsInOneDay;

	@Column(name = "numb_landing_views_in_one_day")
	private Long numberOfLandingViewsInOneDay;

	@Column(name = "numb_profile_views_in_one_day")
	private Long numberOfProfileViewsInOneDay;

	@Column(name = "numb_drill_participants_in_one_day")
	private Long numberOfDrillParticipantsInOneDay;

	@Column(name = "numb_jobs_applied_in_one_day")
	private Long numberOfJobsAppliedInOneDay;

	@Lob
	@Column(name = "all_pages_stats")
	private String allPagesStats;

	@Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "record_insertedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordInsertedts;
	
    @Column(name = "numb_squad")
	private int numberOfSquadPrograms;

    @Column(name = "numb_hackathons")
	private int numberOfHackathons;

	@Transient
	private int numberOfProfessionalsUsers;

	@Transient
	private int numberOfFreshersUsers;

	@Transient
	private int numberOfFresherHired;
	
	@Transient
	private int numberOfInternsHired;
	
	@Transient
	private int numberOfmeetups;
	
	@Transient
	private int numberOfColleges;
	
	@Transient
	private int numberOfFresherDrives;
	
	@Transient
	private int numberOfStudentsInSquad;
	
}
