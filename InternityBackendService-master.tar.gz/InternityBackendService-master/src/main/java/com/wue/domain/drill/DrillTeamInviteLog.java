package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_team_invite_log")
public class DrillTeamInviteLog {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "drill_team_invite_log_id", nullable = false, updatable = false)
    private String drillTeamInviteLogId;

    @Column(name = "drill_id")
    private String drillId;

    @Column(name = "team_id")
    private String teamId;

    @Column(name = "participant_id")
    private String participantId;

    @Column(name ="invite_member")
    private String inviteMember;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "record_createdby")
    private String createdBy;

    @Column(name = "record_updatedby")
    private String updatedBy;
}
