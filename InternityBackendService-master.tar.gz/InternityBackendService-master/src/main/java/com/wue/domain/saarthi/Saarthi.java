package com.wue.domain.saarthi;

import com.wue.constant.saarthi.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "saarthi")
public class Saarthi {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "saarthi_id", unique = true, nullable = false, updatable = false)
    private String saarthiId;

    @Column(name = "name",nullable = false)
    private String name;

    @Column(name = "email_id",nullable = false)
    private String emailId;

    @Column(name = "contact_no",nullable = false)
    private String contactNo;

    @Column(name = "gender", length = 30)
    private String gender;

    @Column(name = "level_of_study")
    private String levelOfStudy;

    @Column(name = "location")
    private String location;

    @Column(name = "state")
    private String state;

    @Column(name = "why_join")
    private String whyJoin;

    @Column(name = "anything_else_text")
    private String anythingElseText;

    @Column(name = "referral_code")
    private String referralCode;

    @Column(name = "got_to_know_platform") // change to enum
    @Enumerated(EnumType.STRING)
    private GotToKnowPlatform gotToKnowPlatform;

    @Column(name = "curr_company_name")
    private String currCompanyName;

    @Column(name = "curr_role")
    private String currRole;

    @Column(name = "primary_skills")
    private String primarySkills;

    @Column(name = "total_experience")
    private Integer totalExperience;

    @Column(name = "year_of_study")
    private String yearOfStudy;

    @Column(name = "passing_year")
    private double passingYear;

    @Column(name = "no_of_societies_club_institute")
    private Integer noOfSocietiesClubInstitute;

    @Column(name = "part_of_solution")
    private String partOfSolution;

    @Column(name = "who_are_you")
    private String whoAreYou;

    @Column(name = "community_name")
    private String communityName;

    @Column(name = "organization_name")
    private String organizationName;

    @Column(name = "expectations_from_us")
    private String expectationsFromUs;

    @Column(name = "profile_links")
    private String profileLinks;

    @Column(name = "registration_type") // change to enum
    @Enumerated(EnumType.STRING)
    private SaarthiRegistrationType registrationType;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "record_createdby")
    private String createdBy;

    @Column(name = "record_updatedby")
    private String updatedBy;
}
