package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.json.JSONObject;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user_candidate_mandatory_fields",uniqueConstraints = { @UniqueConstraint(columnNames = { "u_id" }) })
public class UserCandidateMandatoryFields {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "u_id")
	private String uId;

    @Column(name = "current_designation")
	private String currentDesignation;

    @Column(name = "current_org")
    private String currentOrg;

    @Column(name = "yoe")
	private double yoe;
    
    @Column(name = "current_ctc")
	private double currentCtc;
    
    @Column(name = "expected_ctc")
	private double expectedCtc;

    @Column(name = "notice_period_days")
    private int noticePeriodDays;

    @Column(name = "last_working_day")
    private LocalDateTime lastWorkingDay;

    @Column(name = "current_loc")
	private String currentLoc;

    @Column(name = "preferred_loc")
    private String preferredLoc;

    @Lob
    @Column(name = "primary_skills")
    private String primarySkills;

    @Column(name = "is_actively_searching")
    private boolean isActivelySearching;

    @Column(name = "is_serving_np")
    private boolean isServingNp;

    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Transient
    private String resumeLink;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;

    @Override
    public String toString() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("currentDesignation",currentDesignation);
        jsonObject.put("currentOrg",currentOrg);
        jsonObject.put("yoe",yoe);
        jsonObject.put("currentCtc",currentCtc);
        jsonObject.put("expectedCtc",expectedCtc);
        jsonObject.put("noticePeriodDays",noticePeriodDays);
        jsonObject.put("lastWorkingDay",lastWorkingDay);
        jsonObject.put("currentLoc",currentLoc);
        jsonObject.put("preferredLoc",preferredLoc);
        jsonObject.put("isActivelySearching",isActivelySearching);
        jsonObject.put("isServingNp", isServingNp);
        jsonObject.put("userCreatedts",userCreatedts);
        jsonObject.put("userUpdatedts",userUpdatedts);
        return jsonObject.toString();
    }
}
