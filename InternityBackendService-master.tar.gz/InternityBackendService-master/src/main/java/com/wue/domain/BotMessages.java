package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Table(name ="bot_messages")
public class BotMessages {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "message_id")
    private Long messageId;

    @Column(name = "channel_id", nullable = false)
    private String channelId;

    @Column(name = "platform", nullable = false)
    private String platform;

    @Column(name = "entityId", nullable = false)
    private String entityId;

    @Column(name = "message", columnDefinition = "LONGTEXT", nullable = false)
    private String message;

    @Column(name = "record_created_ts")
    private LocalDateTime recordCreatedTs;

    @Column(name = "record_created_by")
    private String recordCreatedBy;

    @Column(name = "record_updated_ts")
    private LocalDateTime recordUpdatedTs;

    @Column(name = "record_updated_by")
    private String recordUpdatedBy;


}
