package com.wue.domain;

import com.wue.constant.job.PlatformEntityCategory;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "wishlist", uniqueConstraints = { @UniqueConstraint(columnNames = { "u_id", "entity_id" }) })
public class Wishlist {
    @Id
    @Column(name = "wishlist_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long wishlistId;

    @Column(name = "u_id")
    private String uId;

    @Column(name = "entity_id")
    private String entityId;

    @Column(name = "entity_name")
    private PlatformEntityCategory entityName;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedts;
}
