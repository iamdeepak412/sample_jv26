package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_opportunities")
public class DrillOpportunities {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "opportunity_id", unique = true, nullable = false, updatable = false)
	private String opportunityId;

	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;

	@Column(name = "opportunity_designation")
	private String opportunityDesignation;

	@Column(name = "opportunity_exp")
	private String opportunityExp;

	@Column(name = "opportunity_ectc")
	private String opportunityEctc;

	@Lob
	@Column(name = "opportunity_desc")
	private String opportunityDesc;

	@Column(name = "opportunity_location")
	private String opportunityLocation;

	@Column(name = "numb_of_opportunity")
	private int numberOfOpportunity;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
