package com.wue.domain.blog;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "reaction_type")
public class ReactionType {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "reaction_type_id", nullable = false, unique = true)
    private String reactionTypeId;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "img_url",nullable = false)
    private String imgUrl;

    @Column(name = "description")
    private String description;

    @Column(name = "record_createdby")
    private String recordCreatedBy;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedTs;

    @Column(name = "record_updatedby")
    private String recordUpdatedBy;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordUpdatedTs;
}
