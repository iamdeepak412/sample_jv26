package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "career_path")
public class CareerPath {
	
	@Id
	@Column(name = "career_query_count", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long careerQueryCount;
	
	@Column(name = "u_id")
	private String uId;
	
    @Column(name = "target_org_list")
    @Lob
	private String listOfTargetOrganisation;
	
    @Column(name = "target_skill_list")
    @Lob
	private String listOfTargetSkill;

    @Column(name = "target_package")
	private String targetPackage;

    @Column(name = "target_country")
	private String targetCountry;

    @Column(name = "target_job_nature")
	private String targetJobNature;
    
    @Column(name = "target_location_India")
	private String targetLocationIndia;

    @Column(name = "target_certification")
	private String targetCertification;

    @Column(name = "otherTarget")
	private String otherTarget;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
