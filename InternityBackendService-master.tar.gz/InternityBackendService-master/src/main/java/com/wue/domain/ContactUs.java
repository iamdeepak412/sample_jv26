package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;


@Entity
@Getter
@Setter
@ToString
@Table(name="contactus")
public class ContactUs {

	@Id
	@Column(name = "query_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long queryId;
	
	@Column(name = "sender_fullname", nullable = false)
	private String senderFullName;
	
	@Column(name = "email", nullable = false)
	private String email;
	
	@Column(name = "contact", nullable = false)
    private String contact;

    @Column(name = "purpose_to_connect", nullable = false)
    private String purposeToConnect;

    @Column(name = "message", nullable = false)
    private String message;

    @Column(name = "is_visible")
    private boolean isVisible = true;
	
    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;
}
