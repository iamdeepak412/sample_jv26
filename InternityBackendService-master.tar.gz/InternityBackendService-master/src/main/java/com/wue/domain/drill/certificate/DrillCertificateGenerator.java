package com.wue.domain.drill.certificate;

import com.wue.constant.drill.certificate.DrillCertificateEventType;
import com.wue.constant.drill.certificate.DrillCertificateType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "drill_Certificate_generator")
public class DrillCertificateGenerator {

    @Id
    @Column(name = "certificate_id", unique = true, nullable = false, updatable = false)
    private String certificateId;

    @Lob
    @Column(name = "certificate_url_in_s3")
    private String certificateUrlInS3;

    @Column(name = "event_name")
    private String eventName;

    @Column(name = "event_id")
    private String eventId;

    @Column(name = "event_phase_id")
    private String eventPhaseId;

    @Column(name = "participant_platform_u_id")
    private String participantPlatformUId;

    @Column(name = "certificate_creator_platform_u_id")
    private String certificateCreatorPlatformUId;

    @Column(name = "certificate_type")
    @Enumerated(EnumType.STRING)
    private DrillCertificateType certificateType;

    @Column(name = "certificate_event_type")
    @Enumerated(EnumType.STRING)
    private DrillCertificateEventType drillCertificateEventType;

    @Column(name = "template_id")
    private String templateId;

    @Column(name = "certificate_created_ts")
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdTs;

    @Column(name = "certificate_updated_ts")
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTs;

    @Column(name = "certificate_created_by")
    private String createdBy;

    @Column(name = "certificate_updated_by")
    private String updatedBy;

}
