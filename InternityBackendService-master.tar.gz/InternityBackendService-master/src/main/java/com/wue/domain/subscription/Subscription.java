package com.wue.domain.subscription;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;


@Entity
@Getter
@Setter
@ToString
@Table(name="subscription")
public class Subscription {

	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "subscription_id", unique = true, nullable = false, updatable = false)
	private String subscriptionId;
	
	@Column(name = "u_id", nullable = false)
	private String uId;
	
	@Column(name = "component", nullable = false)
	private String component;
	
	@Column(name = "component_id", nullable = false)
    private String componentId;

    @Column(name = "subscription_start_dt")
    private LocalDateTime subscriptionStartDt;

    @Column(name = "subscription_end_dt")
    private LocalDateTime subscriptionEndDt;

    @Column(name = "expiry_dt")
    private LocalDateTime expiryDt;

    @Column(name = "flavour_id")
    private String flavourId;

    @Column(name = "is_active")
    private boolean isActive = true;
	
    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "job_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "job_updatedby")
    private String updatedBy;
}
