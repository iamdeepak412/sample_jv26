package com.wue.domain.idclass;

import java.io.Serializable;

import com.wue.domain.User;

public class UserOtherDetailsId implements Serializable{

	private static final long serialVersionUID = 112L;

	@SuppressWarnings("unused")
	private User uId;
	
	public UserOtherDetailsId(User uId) {
		this.uId = uId;
	}
}
