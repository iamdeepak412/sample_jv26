package com.wue.domain.Rbac;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "role_management", uniqueConstraints = { @UniqueConstraint(columnNames = { "role_name" }) })
public class RoleManagement {

    @Id
    @Column(name = "role_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roleId;

    @Column(name = "role_name", nullable = false)
	private String roleName;

    @Column(name = "entity_name", nullable = false)
	private String entityName;

    @Column(name = "accesses_list")
	private String accessesList;

    //to be used while fetching the accesses for mapping user to role
    @Column(name = "is_active", columnDefinition="boolean default true")
    private boolean isActive;

    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;
}
