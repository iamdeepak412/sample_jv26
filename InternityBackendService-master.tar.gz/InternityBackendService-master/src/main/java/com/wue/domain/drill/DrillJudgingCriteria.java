package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_judging_criteria")
public class DrillJudgingCriteria {
	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "criteria_id", unique = true, nullable = false, updatable = false)
	private String criteriaId;

	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;

	@Column(name = "phase_id", nullable = false, updatable = false)
	private String phaseId;

	@Column(name = "criteria_name")
	private String criteriaName;

	@Column(name = "criteria_max_marks")
	private int criteriaMaxMarks;

	@Lob
	@Column(name = "criteria_desc")
	private String criteriaDesc;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
