package com.wue.domain.ConfigureJob;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "job_screening_question")
public class JobScreeningQuestion {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "question_id", unique = true, nullable = false, updatable = false)
    private String questionId;

    @Column(name = "job_id", nullable = false)
    private String jobId;

    @Lob
    @Column(name = "question", nullable = false)
    private String question;

    @Column(name = "question_category", nullable = false)
    private String questionCategory;

    @Column(name = "question_type")
    private String questionType;

    @Column(name = "expected_answer", nullable = false)
    private String expectedAnswer;

    @Column(name = "answer_type")
    private String answerType;

    @Column(name = "is_deciding_question", columnDefinition="boolean default true")
    private boolean isDecidingQuestion;

    @Column(name = "weightage")
    private String weightage;

    @Column(name = "is_hidden", columnDefinition="boolean default false")
    private boolean isHidden;

    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;
}
