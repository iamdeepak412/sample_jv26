package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user_platform_integration")
public class UserPlatformIntegration  {

    @Id
    @Column(name = "platform_integration_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long platformIntegrationId;

    @Column(name = "u_id")
	private String uId;

    @Column(name = "platform_name")
	private String platformName;
    
    @Column(name = "profile_link")
	private String profileLink;

    @Column(name = "profile_verified")
	private boolean profileVerified;
    
    @Column(name = "is_profile_integrated")
	private boolean isProfileIntegrated;
    
    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;
}
