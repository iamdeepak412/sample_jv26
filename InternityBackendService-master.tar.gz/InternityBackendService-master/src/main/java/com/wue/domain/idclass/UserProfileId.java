package com.wue.domain.idclass;

import java.io.Serializable;

public class UserProfileId implements Serializable{

	private static final long serialVersionUID = 2L;

	@SuppressWarnings("unused")
	private String uId;
	
	public UserProfileId(String uId) {
		this.uId = uId;
	}
}
