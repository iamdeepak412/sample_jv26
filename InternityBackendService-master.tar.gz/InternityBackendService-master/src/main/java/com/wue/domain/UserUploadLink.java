package com.wue.domain;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class UserUploadLink {
    private String linkType;
    private String link;
}
