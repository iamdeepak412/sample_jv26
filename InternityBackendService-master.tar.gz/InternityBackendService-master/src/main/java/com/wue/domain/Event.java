package com.wue.domain;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "event")
public class Event {
	
	@Id
    @Column(name = "event_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int eventId;

    @Column(name = "type", nullable = false, updatable = false)
	private String type;

    @Column(name = "mode", nullable = false, updatable = false)
	private String mode;

    @Column(name = "topic", nullable = false, updatable = false)
	private String topic;

    @Column(name = "agenda", nullable = false, updatable = false)
	private String agenda;

    @Column(name = "owner", nullable = false, updatable = false)
	private String owner;

    @Column(name = "start_dt")
	private String startDateTime;

    @Column(name = "end_dt")
	private String endDateTime;

    @Column(name = "status", nullable = false, updatable = false)
    private String status;

    @Column(name = "location", nullable = false, updatable = false)
	private String location;

    @Column(name = "address", nullable = false, updatable = false)
	private String address;

    @Lob
    @Column(name = "speaker", nullable = false, updatable = false)
	private String speaker;
    
    @Column(name = "event_createdby", length = 100)
    private String eventCreatedby;

    @Column(name = "event_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date eventCreatedts;

    @Column(name = "event_updatedby", length = 100)
    private String eventUpdatedby;

    @Column(name = "event_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date eventUpdatedts;

}
