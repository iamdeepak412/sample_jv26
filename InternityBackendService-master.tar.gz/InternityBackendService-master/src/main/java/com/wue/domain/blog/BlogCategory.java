package com.wue.domain.blog;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "blog_category")
public class BlogCategory {

	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "category_id", nullable = false, unique = true)
    private String categoryId;

    @Column(name = "name", nullable = false, unique = true)
    private String name;
    
    @Lob
    @Column(name = "background_img", nullable = false)
    private String backgroundImg;

    @Column(name = "record_createdby")
    private String recordCreatedBy;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedTs;

    @Column(name = "record_updatedby")
    private String recordUpdatedBy;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordUpdatedTs;
}

