package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user_project")
public class UserProject {
	
	@Id
	@Column(name = "project_count", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long projectCount;
	
    @Column(name = "u_id")
	private String uId;
	
    @Column(name = "org_or_clg_id")
	private long orgOrClgId;

    @Column(name = "project_title", length = 999)   
	private String projectTitle;

    @Column(name = "designation", length = 100)   
	private String designation;
    
    @Column(name = "client", length = 999)   
	private String client;
    
    @Column(name = "start_date")   
	private Date startDate;

    @Column(name = "end_date")   
	private Date endDate;
    
    @Column(name = "is_currently_working")   
	private boolean isCurrentlyWorking;

    @Column(name = "project_desc")
    @Lob
	private String projectDescription;

    @Column(name = "project_site")
	private String projectSite;
    
    @Column(name = "project_link")
	private String projectLink;

    @Column(name = "team_size")
	private String teamSize;

    @Column(name = "role_in_proj")
	private String roleinProject;

    @Column(name = "skills_used")
	private String skillsUsed;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
