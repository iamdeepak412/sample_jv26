package com.wue.domain.drill.submission;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_configure_submission_fields")
public class ConfigureSubmissionFields {

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "phase_id")
    private String phaseId;

    @Column(name = "drill_id")
    private String drillId;

    @Lob
    @Column(name = "fields")
    private String fields;

    @Lob
    @Column(name = "guidelines")
    private String guidelines;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "record_createdby")
    private String createdBy;

    @Column(name = "record_updatedby")
    private String updatedBy;
}
