package com.wue.domain.mail;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "mail_sender_lookup")
public class MailSenderLookup {
	
	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "sender_name")
	private String senderName;

	@Column(name = "sender_email")
	private String senderEmail;

	@Column(name = "record_created_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date recordCreatedDt;

	@Column(name = "record_updated_dt")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date recordUpdatedDt;
}
