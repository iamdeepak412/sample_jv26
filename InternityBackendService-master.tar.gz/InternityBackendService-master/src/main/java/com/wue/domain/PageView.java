package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="page_view")
public class PageView {
	@Id
	@Column(name = "page_view_count", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long pageViewCount;

	@Column(name = "page_name")
	private String page_name;

	@Column(name = "u_id")
	private String uId;

	@Column(name = "entity_id")
	private String entityId;

	@Column(name = "day_of_week")
	private String dayOfWeek;

	@Column(name = "month_of_year")
	private String monthOfYear;

	@Column(name = "year")
	private int Year;

	@Column(name = "location")
	private String Location;

	@Column(name = "longitude")
	private String Longitude;

	@Column(name = "latitude")
	private String Latitude;

	@Column(name = "deviceInfo")
	private String deviceInfo;

	@Column(name = "utm_source")
	private String utmSource;

	@Column(name = "utm_medium")
	private String utmMedium;

	@Column(name = "utm_campaign")
	private String utmCampaign;

	@Column(name = "utm_id")
	private String utmId;

	@Column(name = "utm_term")
	private String utmTerm;

	@Column(name = "utm_content")
	private String utmContent;

	@Column(name = "client_ipaddress")
	private String clientIpaddress;

	@Column(name = "createdts", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

}
