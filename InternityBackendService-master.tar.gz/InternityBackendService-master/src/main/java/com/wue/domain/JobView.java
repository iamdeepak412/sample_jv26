package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="job_view")
public class JobView {
	@Id
	@Column(name = "job_view_count", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long jobViewCount;

	@Column(name = "job_id")
	private String jobId;

	@Column(name = "job_name")
	private String jobName;

	@Column(name = "u_id")
	private String uId;

	@Column(name = "day_of_week")
	private String dayOfWeek;

	@Column(name = "month_of_year")
	private String monthOfYear;

	@Column(name = "year")
	private int Year;

	@Column(name = "location")
	private String Location;

	@Column(name = "longitude")
	private String Longitude;

	@Column(name = "latitude")
	private String Latitude;

	@Column(name = "deviceInfo")
	private String deviceInfo;

	@Column(name = "createdts", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;

	@Column(name = "job_createdby")
	private String createdBy;
}
