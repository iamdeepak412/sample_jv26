package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
@Data
@Table(name = "testimonial_posts")
public class TestimonialPost {
	@Id
	@Column(name = "testimonial_post_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long testimonialPostId;

	@Column(name = "posted_date")
	private Date postedDate;

	@Column(name = "testimonial_category")
	private String testimonialCategory;

	@Column(name = "service")
	private String service;

	@Column(name = "posted_username")
	private String postedByUsername;

	@Column(name = "postedby_userimgurl")
	private String postedByUserImgurl;

	@Column(name = "posted_user_designation")
	private String postedByUserDesignation;

	@Column(name = "position_order")
	private int positionOrder;

	@Column(name = "is_active")
	private boolean isActive;

	@Lob
	@Column(name = "posted_content")
	private String postedContent;

	@Column(name = "user_updatedby", length = 100)
	private String userUpdatedby;

	@Column(name = "record_insertedts")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date recordInsertedts;
}
