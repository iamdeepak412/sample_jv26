package com.wue.domain.drill;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_custom")
public class DrillCustom {
	
	@Id
	@Column(name = "drill_custom_id", nullable = false)
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	private String drillCustomId;
	
	@Column(name = "title")
	private String title;
	
	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;
	
	@Lob
	@Column(name = "description")
	private String description;
	
	@JsonProperty("isHidden")
    @Column(name = "is_hidden")
    private boolean isHidden = false;
	
	
	@Column(name = "record_createdts")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdTs;

	@Column(name = "record_updatedts")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedTs;

	@Column(name = "record_createdby")
	private String createdBy;

	@Column(name = "record_updatedby")
	private String updatedBy;

}
