package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_prizes")
public class DrillPrizes {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "prize_id", unique = true, nullable = false, updatable = false)
	private String prizeId;

	@Column(name = "drill_id", nullable = false, updatable = false)
	private String drillId;

	@Column(name = "prize_title")
	private String prizeTitle;

	@Column(name = "prize_type")
	private String prizeType;

	@Lob
	@Column(name = "prize_desc")
	private String prizeDesc;

	@Column(name = "position_order")
	private int positionOrder;

	@Column(name = "prize_value")
	private String prizeValue;

	@Column(name = "prize_img_url")
	private String prizeImgUrl;

	@Column(name = "prize_quantity")
	private String prize_quantity;

	@Column(name = "record_createdts")
	@Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdTs;

	@Column(name = "record_updatedts")
	@Temporal(TemporalType.TIMESTAMP)
	@UpdateTimestamp
	private Date updatedTs;

	@Column(name = "record_createdby")
	private String createdBy;

	@Column(name = "record_updatedby")
	private String updatedBy;

}
