package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "work_profile")
public class UserWorkProfile {
	
	@Id
	@Column(name = "exp_count", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long expCount;
	
    @Column(name = "u_id")
	private String uId;
	
    @Column(name = "organisation_name")
	private String organisationName;

    @Column(name = "job_designation", length = 999)
    private String jobDesignation;

    @Column(name = "current_salary", length = 30)
    private String currentSalary;

    @Column(name = "notice_period", length = 30)
    private String noticePeriod;

    @Column(name = "job_type", length = 100)   
	private String jobType;
    
    @Column(name = "is_currently_working")   
	private boolean isCurrentlyWorking;

    @Column(name = "start_date")
    @DateTimeFormat(pattern = "MM-yyyy")
	private Date startDate;

    @Column(name = "end_date")
    @DateTimeFormat(pattern = "MM-yyyy") 
	private Date endDate;

    @Column(name = "work_location")
	private String workLocation;

    @Column(name = "work_skills", length = 999)
	private String workSkillsToHighlight;
    
    @Lob
    @Column(name = "work_description")
	private String workDescription;

    @Column(name = "lwd")
	private Date lastWorkingDay;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
