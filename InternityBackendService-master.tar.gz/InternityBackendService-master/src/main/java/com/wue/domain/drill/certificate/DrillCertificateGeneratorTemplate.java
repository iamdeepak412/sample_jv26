package com.wue.domain.drill.certificate;

import com.wue.dto.drill.certificate.DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@ToString
public class DrillCertificateGeneratorTemplate {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "template_id", unique = true, nullable = false, updatable = false)
    private String templateId;

    @Column(name = "template_name")
    private String templateName;

    @Column(name = "template_data")
    @Lob
    private String templateData;

    @Column(name = "event_id")
    private String eventId;

    @Column(name = "template_url_in_s3")
    private String certificateImageUrlInS3;

    @Column(name = "template_creator_u_id")
    private String  templateCreatorUId;

    @Column(name = "template_created_ts")
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdTs;

    @Column(name = "template_updated_ts")
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTs;

    @Column(name = "template_created_by")
    private String createdBy;

    @Column(name = "template_updated_by")
    private String updatedBy;



}
