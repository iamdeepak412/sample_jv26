package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name="jobs")
public class Job {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "job_id", unique = true, nullable = false, updatable = false)
	private String jobId;

	@Column(name = "job_requisition_id")
	private String jobRequisitionId;

	@JoinColumn(name = "partner_id")
	private String partnerId;

	@Column(name = "partner_name")
	private String partnerName;
	
	@Transient
	private Partner partner;
	
	@Column(name = "job_type", nullable = false)
	private String jobType;
	
	@Column(name = "job_title", nullable = false)
	private String jobTitle;
	
	@Column(name = "job_location", nullable = false)
	private String jobLocation;
	
	@Column(name = "job_industry_category")
	private String jobIndustryCategory;

	@Column(name = "job_skills", nullable = false)
	@Lob
	private String jobSkills;

	@Column(name = "job_musthave")
	@Lob
	private String jobMusthave;

	@Column(name = "job_other_skills")
	@Lob
	private String jobOtherSkills;
	
	@Column(name = "job_domain", nullable = true)
	private String jobDomain;

	@Column(name = "job_min_ctc_range", nullable = true)
	private Double jobMinCtcRange=0.0;

	@Column(name = "job_max_ctc_range", nullable = true)
	private Double jobMaxCtcRange=0.0;

	@Column(name = "job_ctc_category")
	private String jobCtcCategory;

	@Column(name = "job_ctc_currency", nullable = true)
	private String jobCtcCurrency = "INR";
	
	@Column(name = "job_esop_acceptance", nullable = false)
	private Boolean jobEsopAcceptance = false;

	@Column(name = "job_min_yoe", nullable = false)
	private Double jobMinYoe=0.0;

	@Column(name = "job_max_yoe", nullable = false)
	private Double jobMaxYoe=0.0;
	
	@Lob
	@Column(name = "job_description")
	private String jobDescription;
	
	@Column(name = "job_number_of_vacancies")
	private Integer jobNumberOfVacancies;
	
	@Column(name = "job_notice_period_acceptable")
	private String jobNoticePeriodAcceptable;

	@Lob
	@Column(name = "job_screening_questions")
	private String jobScreeningQuestions;
	
	@Column(name = "othertags", nullable = true)
	private String otherTags;
	
	@Column(name = "job_priority", nullable = true)
	private String jobPriority;
	
	@Column(name = "duration")
	private String duration;

	@Column(name = "job_mode")
	private String jobMode;

	@Column(name = "past_internship_experience",nullable = false)
	private boolean pastInternshipExperience;
	
	@Column(name = "is_active", nullable = false)
	private Boolean isActive = true;

	@Column(name = "is_company_name_hidden", nullable = false)
	private Boolean isCompanyNameHidden = false;

	@Column(name = "is_salary_hidden")
	private Boolean isSalaryHidden = false;

	@Column(name = "job_posted_by")
	private String jobPostedBy;

	@Column(name = "job_img_link", nullable = true)
	private String jobImageLink;

	@Column(name = "jd_link", nullable = true)
	private String jdLink;

	@Column(name = "cust_url")
	private String custUrl;

	@Lob
	@Column(name = "job_rounds")
	private String jobRounds;

	@Lob
	@Column(name = "job_keywords")
	private String jobKeywords;

	@Column(name = "job_yoe_txt_for_zero")
	private String jobYoeTextForZero;

	@Column(name = "job_position_order")
	private String jobPositionOrder;

	@Column(name = "job_category_weightage")
	private String jobCategoryWeightage = "{\"overAllWeightage\":\"70\", \"skillsWeightage\":\"40\", \"totalYoeWeightage\":\"40\"}";

	@Column(name="job_applicant_count")
	private Long jobApplicantCount=0L;
	
    @Column(name = "job_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "job_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "job_createdby")
	private String createdBy;
	
	@Column(name = "job_updatedby")
	private String updatedBy;
	
	@Column(name = "is_referral")
	private boolean isReferral;
	
	@Column(name = "reward_days")
	private int rewardDays;
	
	@Column(name = "referral_condition")
	private String referralCondition;

	@Transient
	private boolean isFeatured;

	@Column(name = "drill_id")
	private String drillId;


}
