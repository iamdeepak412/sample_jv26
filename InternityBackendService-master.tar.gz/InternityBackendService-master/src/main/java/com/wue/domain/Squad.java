package com.wue.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;


@Entity
@Getter
@Setter
@ToString
@Table(name="squad")
public class Squad {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "squad_id", unique = true, nullable = false, updatable = false)
    private String squadId;

    @Column(name = "squad_name", nullable = false)
    private String squadName;

    @Column(name = "number_of_days", nullable = false)
    private int numberOfDays;

    @DateTimeFormat(pattern = "dd-MM-yyyy hh:mm:ss")
    @Column(name = "start_date", nullable = false)
    private LocalDateTime startDate;

    @DateTimeFormat(pattern = "dd-MM-yyyy hh:mm:ss")
    @Column(name = "end_date", nullable = false)
    private LocalDateTime endDate;

    @Column(name = "technology", nullable = false)
    private String technology;

    @Column(name = "domain")
    private String domain;

    @Lob
    @Column(name = "tags")
    private String tags;

    @Column(name = "managers", columnDefinition = "MEDIUMTEXT")
    private String managers;

    @Column(name = "one_liner", length = 500, nullable = false)
    private String oneLiner;

    @Column(name = "mode_of_delivery", nullable = false)
    private String modeOfDelivery;

    @Column(name = "registration_link", nullable = false)
    private String registrationLink;

    @Column(name = "logo_path")
    private String logoPath;

    @Column(name = "price", nullable = false)
    private String price;

    @Lob
    @Column(name = "description")
    private String description;

    @Lob
    @Column(name = "content", columnDefinition = "MEDIUMTEXT")
    private String content;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
