package com.wue.domain;

import com.wue.constant.UserProfileOtherDetailsType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "user_profile_other_details")
public class UserProfileOtherDetailsv2 {
	
	@Id
	@Column(name = "other_details_id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long otherDetailsId;
		
	@Column(name = "u_id")
	private String uId;
	
    @Column(name = "content")
    @Lob
	private String content;

    @Column(name = "other_details_type")
	private UserProfileOtherDetailsType otherDetailsType;

    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "updatedby", length = 100)
    private String updatedby;

    @Column(name = "updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedts;
}
