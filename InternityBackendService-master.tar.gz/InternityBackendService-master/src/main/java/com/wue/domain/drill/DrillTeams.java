package com.wue.domain.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name="drill_teams", uniqueConstraints = { @UniqueConstraint(columnNames = { "drill_id", "team_lead_id" }) })
public class DrillTeams {

	@Id
	@GeneratedValue(generator = "uuid")
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "team_id", nullable = false, updatable = false)
	private String teamId;

	@Column(name = "drill_id")
	private String drillId;

	@Column(name = "team_name")
	private String teamName;

	@Column(name = "team_img_url")
	private String teamImgUrl;

	@Column(name = "selected_theme")
	private String selectedTheme;

	@Column(name = "team_lead_id")
	private String teamLeadParticipantId;

	@Column(name = "team_current_size")
	private int teamCurrentSize;

	@Column(name = "is_active", columnDefinition="boolean default true")
	private boolean isActive=true;

	@Column(name = "declared_team_size")
	private int declaredTeamSize;

	@Column(name = "team_invite_code",length = 8)
	private String teamInviteCode;

	@Column(name = "looking_for_team_mate")
	private boolean lookingForTeamMate;
	@Lob
	@Column(name = "team_description")
	private String teamDescription;

	@Transient
	private String participantValue;

	@Transient
	private String participantId;

	@Transient
	private String participantSkills;

	@Transient
	private String participantImageUrl;

	@Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdTs;
	
    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
