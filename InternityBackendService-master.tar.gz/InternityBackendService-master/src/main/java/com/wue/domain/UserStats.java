package com.wue.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "user_stats")
@Data
public class UserStats {

	@Id
	@Column(name = "u_id")
	private String uId;
	
	@Column(name = "completion_percentage")
	private double profileCompletionPercentage;
	
}
