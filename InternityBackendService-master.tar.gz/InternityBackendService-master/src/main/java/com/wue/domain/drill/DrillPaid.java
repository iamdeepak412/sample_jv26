package com.wue.domain.drill;

import com.wue.constant.drill.DrillParticipantType;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name="drill_paid" )
public class DrillPaid {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "drill_paid_id", unique = true, nullable = false, updatable = false)
    private String drillPaidId;

    @Column(name = "drill_id",nullable = false)
    private String drillId;

    @Column(name = "drill_participant_type")
    @Enumerated(EnumType.STRING)
    private DrillParticipantType drillParticipantType;

    @Column(name = "amount",nullable = false)
    private Long amount;

    public DrillPaid(String drillId, DrillParticipantType participantType, Long amount) {
        this.setDrillId(drillId);
        this.setAmount(amount);
        this.setDrillParticipantType(participantType);
    }


}
