package com.wue.domain.mail;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "mail_status")
public class SentMailStatus {
	
	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "sender_id")
	private String senderId;

	@Column(name = "receiver_email")
	private String receiverEmail;

	@Column(name = "delivery_status")
	private String deliveryStatus;

	@Column(name = "status_update_dt")
	private String statusUpdateDt;

	@Column(name = "message_id")
	private String messageId;

    @Column(name = "mailsent_dt")
    @Temporal(TemporalType.TIMESTAMP)
	@CreationTimestamp
    private Date mailSentDt;
}
