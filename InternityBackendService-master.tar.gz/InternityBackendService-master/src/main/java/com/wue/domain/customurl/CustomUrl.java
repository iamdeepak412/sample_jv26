package com.wue.domain.customurl;

import com.wue.constant.customurl.CustomUrlEntityType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@ToString
@Table(name="cust_url_master", uniqueConstraints = { @UniqueConstraint(columnNames = { "entity_id", "short_url" }) })
public class CustomUrl {
	
	@Id
	@Column(name = "id", nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;

	@Column(name = "entity_id")
	private String entityId;

	@Column(name = "entity_type")
	private CustomUrlEntityType entityType;
	
	@Column(name = "original_url", nullable = false, unique = true)
	private String originalUrl;
	
	@Column(name = "short_url", nullable = false, unique = true)
	private String shortUrl;
	
	@Column(name = "record_createdts")
    @CreationTimestamp
    private LocalDateTime createdTs;
	
    @Column(name = "record_updatedts")
    @UpdateTimestamp
    private LocalDateTime updatedTs;
    
	@Column(name = "record_createdby")
	private String createdBy;
	
	@Column(name = "record_updatedby")
	private String updatedBy;

}
