package com.wue.domain.Rbac;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@ToString
@Table(name = "platform_entity_type")
public class PlatformEntityType {

    @Id
    @Column(name = "entity_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long entityId;

    @Column(name = "entity_name", nullable = false)
    private String entityName;

    @Column(name = "service", nullable = false)
    private String service;

    //to be fetched while creating or configuring the roles
    @Column(name = "is_active", columnDefinition="boolean default true")
    private boolean isActive;

    @Column(name = "user_createdby", length = 100)
    private String userCreatedby;

    @Column(name = "user_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date userCreatedts;

    @Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "user_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date userUpdatedts;
}
