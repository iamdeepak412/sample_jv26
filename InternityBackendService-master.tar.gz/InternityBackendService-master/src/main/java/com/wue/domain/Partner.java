package com.wue.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "partner")
public class Partner {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "partner_id", unique = true, nullable = false, updatable = false)
    private String partnerId;

    @Column(name = "partner_name", nullable = false)
    private String partnerName;

    @Column(name = "partner_display_name")
    private String partnerDisplayName;

    @Lob
    @Column(name = "partner_desc", nullable = false)
    private String partnerDescription;

    @Lob
    @Column(name = "partner_sociallinks", nullable = false)
    private String partnerSocialLinks;

    @Column(name = "partner_type", nullable = false)
    private String partnerType;

    @Column(name = "partner_industry", nullable = false)
    private String partnerIndustry;

    @Column(name = "partner_estab_date", nullable = false)
    private String partnerEstablishmentDate;

    @Column(name = "partner_logo_path")
    private String partnerLogoPath;

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(name = "headquarter")
    private String headquarter;

    @Lob
    @Column(name = "location")
    private String location;

    @Column(name = "gstin")
    private String gstin;

    @Column(name = "pan")
    private String pan;

    @Lob
    @Column(name = "address")
    private String address;

    @Column(name = "sub_category")
    private String subCategory;

    @Column(name = "representative_uid")
    private String representativeUid;

    @Column(name = "mail_email")
    private String mailEmail="";

    @Column(name = "mail_display_name")
    private String mailDisplayName;

    @Transient
    private String representativeUserDetails;
    
    @Column(name = "record_createdts")
    private Date createdTs;

    @Column(name = "record_updatedts")
    private Date updatedTs;

    @Column(name = "record_createdby")
    private String createdBy;

    @Column(name = "record_updatedby")
    private String updatedBy;
}

