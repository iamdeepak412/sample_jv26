package com.wue.domain.blog;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "reaction")
public class Reaction {

    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "reaction_id", nullable = false, unique = true)
    private String reactionId;

    @Column(name = "post_id", nullable = false)
    private String postId;

    @Column(name = "u_id")
    private String uId;

    @Column(name = "type", nullable = false)
    private String type;

    @Column(name = "record_createdby")
    private String recordCreatedBy;

    @Column(name = "record_createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date recordCreatedTs;

    @Column(name = "record_updatedby")
    private String recordUpdatedBy;

    @Column(name = "record_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordUpdatedTs;

}

