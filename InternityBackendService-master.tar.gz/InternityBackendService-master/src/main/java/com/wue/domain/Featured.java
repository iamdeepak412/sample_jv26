package com.wue.domain;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "featured")
public class Featured {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    
    @Column(name = "element_id")
    private String elementId;
    
    @Column(name = "element_type")
    private String elementType;
    
    @Column(name = "is_active")
    private boolean isActive;
    
    @Column(name = "position_order")
    private int positionOrder;

    @Column(name = "msg")
    private String msg;

    @Column(name = "single_img_url")
    private String singleImgUrl;

    @Column(name = "created_ts", updatable = false)
    @CreationTimestamp
    private Date createdTs;
    
    @Column(name = "updated_ts")
    @UpdateTimestamp
    private Date updatedTs;
    
    @Column(name = "created_by", updatable = false)
    private String createdBy;
    
    @Column(name = "updated_by")
    private String updatedBy;
    
    
}

