package com.wue.domain.subscription;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Date;


@Entity
@Getter
@Setter
@ToString
@Table(name="flavour")
public class Flavour {

	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "flavour_id", unique = true, nullable = false, updatable = false)
	private String flavourId;

    @Column(name = "flavour_name", nullable = false)
    private String flavourName;

    @Column(name = "component", nullable = false)
    private String component;

    @Lob
    @Column(name = "component_feature_list")
    private LocalDateTime componentFeatureList;

    @Column(name = "price", nullable = false)
    private String price;

    @Column(name = "flavour_sales_contact")
    private LocalDateTime flavourSalesContact;

    @Column(name = "is_active")
    private boolean isActive = true;
	
    @Column(name = "createdby", length = 100)
    private String createdby;

    @Column(name = "createdts")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    private Date createdts;

    @Column(name = "job_updatedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedTs;

    @Column(name = "job_updatedby")
    private String updatedBy;
}
