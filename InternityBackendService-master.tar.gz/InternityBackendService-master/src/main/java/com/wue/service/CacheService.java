package com.wue.service;

import com.wue.domain.Job;
import com.wue.domain.User;
import com.wue.domain.drill.DrillParticipant;
import com.wue.repository.JobsRepository;
import com.wue.repository.UserRepository;
import com.wue.repository.drill.DrillParticipantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CacheService {
	@Autowired
	JobsRepository jobsRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	DrillParticipantRepository drillRepository;

	@Cacheable("jobs")
	public List<Job> getPageFromDb() throws InterruptedException {

		Thread.sleep(1000);

		return jobsRepository.findAll();
	}

	@Cacheable("jobsresult")
	public List<Job> getAnything() throws InterruptedException {
		Thread.sleep(1000);
		return jobsRepository.findAll();
	}
	
	@Cacheable("users")
	public List<User> getPageFromDatabase() throws InterruptedException {

		Thread.sleep(1000);

		return userRepository.findAll();
	}

	@Cacheable("usersresult")
	public List<User> getAnythingFromUser() throws InterruptedException {
		Thread.sleep(1000);
		return userRepository.findAll();
	}
	@Cacheable("participants")
	public List<DrillParticipant> getPageFromDrillDb() throws InterruptedException {

		Thread.sleep(1000);

		return drillRepository.findAll();
	}

	@Cacheable("participantresult")
	public List<DrillParticipant> getAnythingFromDrill() throws InterruptedException {
		Thread.sleep(1000);
		return drillRepository.findAll();
	}
}
