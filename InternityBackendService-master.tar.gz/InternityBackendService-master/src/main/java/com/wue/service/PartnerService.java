package com.wue.service;

import java.util.*;

import com.wue.constant.CommonConstants;
import com.wue.constant.CustomerCategory;
import com.wue.domain.OrganisationAndAcademicInstitute;
import com.wue.dto.response.Response;
import com.wue.repository.OrganisationAndAcademicRepository;
import com.wue.util.CommonUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.util.drill.ResponseUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.wue.domain.ImagePositionOrder;
import com.wue.domain.Partner;
import com.wue.domain.User;
import com.wue.dto.CustomerRepresentativeDto;
import com.wue.dto.PartnerDto;
import com.wue.repository.ImagePositionOrderRepository;
import com.wue.repository.PartnerRepository;
import com.wue.repository.UserRepository;
import com.wue.util.InternityUser;

@Service
@Log4j2
public class PartnerService {

	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	PartnerRepository partnerRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ImagePositionOrderRepository imagePositionOrderRepository;

	@Autowired
	CommonUtils commonUtils;

	@Autowired
	OrganisationAndAcademicRepository organisationAndAcademicRepository;

	@Autowired
	ResponseUtil responseUtil;

	public Object saveOrUpdate(PartnerDto partnerDto, InternityUser user) {
	    Optional<Partner> partnerObj = partnerRepository.findByPartnerName(partnerDto.getPartnerName());
	    if (!partnerObj.isPresent()) {
	        try {
	            partnerDto.setCreatedTs(new Date());
				partnerDto.setActive(true);
	            Partner partner = modelMapper.map(partnerDto, Partner.class);
				Partner savedPartner = partnerRepository.save(partner);
				addCustomerInLandingpageCarousel(savedPartner);
	            return savedPartner;
	        } catch (Exception e) {
	            log.error("Failed to save partner.", e);
	            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save partner. " +
	                    "An error occurred during partner creation.");
	        }
	    } else {
	        log.info("Failed to add partner as a partner with the same name exists. " +
	                "Please ensure not to save the same partner multiple times.");
	        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to add partner as a partner with the same name exists. " +
	                "Please ensure not to save the same partner multiple times");
	    }
	}

	private void addCustomerInLandingpageCarousel(Partner savedPartner) {
		try{
			OrganisationAndAcademicInstitute orgAndAcademicObj = new OrganisationAndAcademicInstitute();
			orgAndAcademicObj.setActive(true);
			orgAndAcademicObj.setName(savedPartner.getPartnerName());
			orgAndAcademicObj.setImageUrl(savedPartner.getPartnerLogoPath());
			if(savedPartner.getPartnerType().equalsIgnoreCase(CustomerCategory.INDUSTRY.name())){
				orgAndAcademicObj.setType(CommonConstants.ORGANISATION);
			}
			else if(savedPartner.getPartnerType().startsWith(CustomerCategory.INSTITUTION.name())){
				orgAndAcademicObj.setType(CommonConstants.ACADEMICINSTITUTE);
			}
			organisationAndAcademicRepository.save(orgAndAcademicObj);
		}
		catch (Exception e){
			log.error("Exception while adding customer in landing page carousel ::: {}", e);
		}
	}

	public Object saveOrUpdateRepresentativeDetails(CustomerRepresentativeDto customerRepresentativeDto, InternityUser user) {
	    Optional<Partner> partnerObj = partnerRepository.findById(customerRepresentativeDto.getPartnerId());
	    if (partnerObj.isPresent()) {
	        Optional<User> userObj = userRepository.findByEmail(customerRepresentativeDto.getEmail());
	        if (!userObj.isPresent()) {
	            try {
	                User insertedObj = saveRepresentativeBasicDetails(customerRepresentativeDto);
	                Partner partnerDetails = partnerObj.get();
	                partnerDetails.setRepresentativeUid(insertedObj.getUId());
	                partnerRepository.save(partnerDetails);
	                return commonUtils.message(HttpStatus.OK, "Representative details saved successfully");
	            } catch (Exception e) {
	                log.error("Failed to save or update representative details.", e);
	                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save or update representative details. An error occurred.");
	            }
	        } else {
	            try {
	                    User userDetailsObj = userObj.get();
	                    userDetailsObj.setFullName(customerRepresentativeDto.getName());
                    	if (!userDetailsObj
                            .getUContact()
                            .contains(customerRepresentativeDto.getContact())) {
                        	userDetailsObj.setUContact(
                                userDetailsObj.getUContact()
                                        + ", "
                                        + customerRepresentativeDto.getContact());
	                    }
						userRepository.save(userDetailsObj);
						Partner partnerDetails = partnerObj.get();
						partnerDetails.setRepresentativeUid(userDetailsObj.getUId());
						partnerRepository.save(partnerDetails);
	                    return commonUtils.message(HttpStatus.OK, "Representative details updated successfully");
	            } catch (Exception e) {
	                log.error("Failed to update representative details.", e);
	                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to update representative details. An error occurred.");
	            }
	        }
	    } else {
	        log.error("Failed to update partner details. Partner with ID {} not found.", customerRepresentativeDto.getPartnerId());
	        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to update partner details. Partner not found.");
	    }
	}
	
	private User saveRepresentativeBasicDetails(CustomerRepresentativeDto customerRepresentativeDto) {
		try{
			String email = customerRepresentativeDto.getEmail();

                User user = new User();
                user.setUsername(email);
                user.setEmail(email);
                user.setPassword("User@123");
                user.setActive(true);
				user.setUContact(customerRepresentativeDto.getContact());
                user.setUType("USER");
                user.setFullName(customerRepresentativeDto.getName());
                user.setUGroup("NEWCUSTOMER");
                user.setURole("CUSTOMERADMIN");

				User insertedObj = userRepository.save(user);

				return insertedObj;

		}
		catch (Exception e){
			log.error("Exception while saving the basic details of the partner representative ::: {}", e);
			return null;
		}
	}

	public Object updatePartner(String partnerId,PartnerDto partnerDto, InternityUser user) {
		Optional<Partner> optionalPartner = partnerRepository.findById(partnerId);
		if (optionalPartner.isPresent()){
			Partner partner = optionalPartner.get();
			partnerDto.setUpdatedTs(new Date());
			modelMapper.map(partnerDto,partner);
			return partnerRepository.save(partner);
		}
		return null;
	}

	public List<Partner> fetch(String partnerId, boolean active, InternityUser user) {
	    List<Partner> partnerList = new ArrayList<>();
	    if (partnerId != null) {
	        Optional<Partner> partnerObj = partnerRepository.findById(partnerId);
	        if (partnerObj.isPresent()) {
	            Partner partner = partnerObj.get();
				partnerList.add(partner);

	        } else {
	            log.error("Partner not found for ID ::: {}", partnerId);
	        }
	    } else {
	        partnerList = partnerRepository.findByIsActiveOrderByCreatedTsDesc(active);
	    }
		return setRepresentativeDetails(partnerList);
	}

	/**
	 * Setting representative details in the list of
	 * partner object
	 * @param partner
	 * list of partner object
	 *
	 * @return
	 * list of updated partner object
	 *
	 */
	private List<Partner> setRepresentativeDetails(List<Partner> partnerList){
        try {
			List<Partner> result = new ArrayList<>();
            for (Partner partner : partnerList) {
                String uId = partner.getRepresentativeUid();
                if (!StringUtils.isBlank(uId)) {
                    Optional<User> userObj = userRepository.findById(uId);
                    if (userObj.isPresent()) {
                        CustomerRepresentativeDto representativeDto =
                                new CustomerRepresentativeDto();
                        representativeDto.setName(userObj.get().getFullName());
                        representativeDto.setContact(userObj.get().getUContact());
                        representativeDto.setEmail(userObj.get().getEmail());
                        representativeDto.setPartnerId(partner.getPartnerId());

                        ObjectMapper objectMapper = new ObjectMapper();
                        try {
                            String representativeJson =
                                    objectMapper.writeValueAsString(representativeDto);
                            partner.setRepresentativeUserDetails(representativeJson);
                        } catch (JsonProcessingException e) {
                            log.error("Error processing JSON ::: {}", e.getMessage());
                        }

                    } else {
                        log.error("User not found for ID ::: {}", uId);
                    }
                } else {
                    partner.setRepresentativeUserDetails(null);
				}
				result.add(partner);
            }
			return result;
		}
		catch (Exception e){
			log.error("Exception while setting representative details in the Partner object ::: {}", e);
		}
		return partnerList;
	}

    public Object saveImagePositionOrder(
            String imageUrl, String positionOrder, InternityUser user) {
        try {
            ImagePositionOrder imagePositionOrder = new ImagePositionOrder();
            imagePositionOrder.setImageUrl(imageUrl);
            imagePositionOrder.setPositionOrder(positionOrder);
            imagePositionOrderRepository.save(imagePositionOrder);
            return "Image position saved successfully";
        } catch (Exception e) {
            log.error("Exception while saving image with position Order {}", e);
            return new ResponseEntity<>(
                    commonUtils.message(
                            HttpStatus.INTERNAL_SERVER_ERROR,
                            "Failed to save image with position order " + e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

	public Object fetchImagePosition(InternityUser user) {
		try {
		 List<ImagePositionOrder> imagePositionOrders = imagePositionOrderRepository.findAll();
		 Collections.sort(imagePositionOrders, Comparator.comparingInt(imagePositionOrder -> Integer.parseInt(imagePositionOrder.getPositionOrder())));

		    List<Map<String, Object>> result = new ArrayList<>();
		    for (ImagePositionOrder imagePositionOrder : imagePositionOrders) {
		        Map<String, Object> map = new HashMap<>();
		        map.put("imageUrl", imagePositionOrder.getImageUrl());
		        map.put("positionOrder", imagePositionOrder.getPositionOrder());
		        result.add(map);
		    }
		    return result;
		}
		  catch (Exception e) {
	            log.error("Exception while getting image with position Order {}", e);
	            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
	                    "Failed in fetching image with position order " + e.getMessage())
	                    , HttpStatus.INTERNAL_SERVER_ERROR);
		  }
	}

	public Map<String, String> activatePartner(String partnerId, boolean action, InternityUser user) {
		try{
			Optional<Partner> partnerObj = partnerRepository.findById(partnerId);
			if(partnerObj.isPresent()){
				Partner partner = partnerObj.get();
				partner.setActive(action);
				partnerRepository.save(partner);
				return commonUtils.message(HttpStatus.OK, "Customer is "+(action?"activated":"deactivated"));
			}
			else {
				return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "No Customer is present" +
						"with this id");
			}
		}
		catch (Exception e){
			log.error("Exception while activating the partner object {}", e);
			return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Error while activatin/deactivating" +
					"partner object");
		}
	}

	public Response getRepresentativeDetails(String partnerId, InternityUser user) {
		try {
			log.info("Getting representative details");
			if (partnerId==null || partnerId.equals("NA") || Objects.equals(partnerId, "all")) {
				log.info("Getting all customer admins");
				// Return all records with u_role as CUSTOMERADMIN
				List<User> customerAdmins = userRepository.findByURole("CUSTOMERADMIN");
				// Remove password from each user object
				customerAdmins.forEach(userNew -> userNew.setPassword(null));
				return responseUtil.successResponse(customerAdmins);
			} else {
				if (StringUtils.isBlank(partnerId)) {
					log.error("partner ID cannot be blank or undefined");
					return responseUtil.badRequestResponse("partner ID cannot be blank or undefined");
				}
				Optional<Partner> partner= partnerRepository.findById(partnerId);
				if (!partner.isPresent()){
					log.error("Partner not found with the specified ID");
					return responseUtil.badRequestResponse("Partner not found with the specified ID");
				}
				if (StringUtils.isBlank(partner.get().getRepresentativeUid())){
					return responseUtil.notFoundResponse("No representative found with this customer id");
				}
				// Search by ID
				log.info("Searching by ID");
				Optional<User> representativeOptional = userRepository.findById(partner.get().getRepresentativeUid());
				if (representativeOptional.isPresent()) {
					log.info("Representative details found by id");
					User representative = representativeOptional.get();
					// Remove password before returning
					representative.setPassword(null);
					return responseUtil.successResponse(representative);
				} else {
					// If user ID is not found, return an error message
					log.error("Representative not found with the specified UId in Partner details");
					return responseUtil.badRequestResponse("Representative not found with the specified UId in Partner details");
				}
			}
		} catch (Exception e) {
			log.error("Exception while getting representative details {}", e.getMessage());
			return responseUtil.internalServerErrorResponse("Exception while getting representative details");
		}
	}
}
