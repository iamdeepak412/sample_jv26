package com.wue.service;

import com.wue.domain.Squad;
import com.wue.repository.SquadRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
@Log4j2
public class SquadService {
	@Autowired
	private CommonUtils commonUtils;

	@Autowired
	SquadRepository repository;

	public ResponseEntity<?> saveOrUpdate(Squad squad, InternityUser internityUser) {
		try{
			repository.save(squad);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.OK,
					"Registered successfully. Welcome to Squad."), HttpStatus.OK);
		}
		catch (Exception e){
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
					"Exception while saving user"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<?> fetchSquadList(String query, String squadId,
														  InternityUser internityUser) {
		return new ResponseEntity<>(repository.findAll(), HttpStatus.OK);
	}
}
