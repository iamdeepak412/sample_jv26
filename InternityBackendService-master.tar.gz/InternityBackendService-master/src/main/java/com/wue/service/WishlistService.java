package com.wue.service;

import com.wue.constant.job.PlatformEntityCategory;
import com.wue.domain.Job;
import com.wue.domain.User;
import com.wue.domain.Wishlist;
import com.wue.domain.drill.Drill;
import com.wue.dto.response.Response;
import com.wue.dto.response.ResponseError;
import com.wue.repository.ApplicationRepository;
import com.wue.repository.JobsRepository;
import com.wue.repository.UserRepository;
import com.wue.repository.WishlistRepository;
import com.wue.repository.drill.DrillRepository;
import lombok.extern.log4j.Log4j2;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Log4j2
public class WishlistService {
	
	private static final Logger logger = LoggerFactory.getLogger(WishlistService.class);

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    ApplicationRepository applicationRepository;

    @Autowired
    WishlistRepository wishlistRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    JobsRepository jobsRepository;

    @Autowired
    DrillRepository drillRepository;

    public Response saveWishlist(String uId, Wishlist wishlist){
        try{
            Optional<User> userObj = userRepository.findById(uId);
            if(userObj.isPresent()){
                if(wishlist.getEntityName() instanceof PlatformEntityCategory){
                    if(!checkIfEntitynameExistsInDb(wishlist)){
                        return new Response(500, false, null,
                                new ResponseError("500", "No record found for the given entity id. Please contact technical support"));
                    }
                    wishlist.setUId(uId);
                    Wishlist savedWishList = wishlistRepository.save(wishlist);
                    return new Response(200, true, savedWishList, null);
                }
            }
        }
        catch (Exception e){
            log.error("Exception while saving wishlist for an user ::: {}", e);
            ResponseError responseError = new ResponseError();
            responseError.setCode("500");
            if(e instanceof DataIntegrityViolationException){
                responseError.setMessage(
                        "Exception while saving wishlist in Db. Kindly check if there is an entry of the entity already exists for the user");
            } else {
                responseError.setMessage(
                        "Exception while saving wishlist with error " + e.getMessage());
            }
            return new Response(500, false, null, responseError);
        }
        return new Response(500, false, null, new ResponseError("500", "Failed to save wishlist"));
    }

    public Response fetchWishlistForAnUser(String uId, Long wishlistId, String entityName){
        try{
            if(wishlistId>0.0){
                Optional<Wishlist> wishlistObj = wishlistRepository.findById(wishlistId);
                if(wishlistObj.isPresent()){
                    return new Response(200, true, wishlistObj.get(), null);
                }
                else {
                    return new Response(500, false, null, new ResponseError("500",
                            "Given wishlist id is invalid or not available. Please revalidate and provide valid id."));
                }
            }
            if(!"all".equals(uId) && "all".equals(entityName)){
                Optional<User> userObj = userRepository.findById(uId);
                if(userObj.isPresent()){
                    return new Response(200, true, wishlistRepository.findByuId(uId), null);
                }else {
                    return new Response(500, false, null, new ResponseError("500",
                            "User is not present"));
                }
            }
            if("all".equals(uId) && !"all".equals(entityName)){
                PlatformEntityCategory category = entityExistsInPlatformEntityCategoryEnum(entityName);
                if(category!=null){
                    List<Wishlist> wishlistList = wishlistRepository.findByEntityName(category);
                    return new Response(200, true, wishlistList, null);
                }
                else {
                    return new Response(500, false,
                            "Entity name is invalid. Please provide valid entity name", null);
                }
            }
            if(!"all".equals(uId) && !"all".equals(entityName)){
                Optional<User> userObj = userRepository.findById(uId);
                if(userObj.isPresent()){
                    PlatformEntityCategory category = entityExistsInPlatformEntityCategoryEnum(entityName);
                    if(category!=null){
                        List<Wishlist> wishlistList = wishlistRepository.findByuIdAndEntityName(uId, category);
                        return new Response(200, true, wishlistList, null);
                    }
                    else {
                        return new Response(500, false,
                                "Entity name is invalid. Please provide valid entity name", null);
                    }
                }
            }
            else {
                return new Response(200, true, wishlistRepository.findAll(), null);
            }
        }
        catch (Exception e){
            log.error("Exception while fetching wishlist for an user ::: uId {} ::: error {}", uId, e);
            ResponseError responseError = new ResponseError();
            responseError.setCode("500");
            responseError.setMessage("Exception while fetching wishlist with error " + responseError.getMessage());
            return new Response(500, false, null, responseError);
        }
        return new Response(500, false, null, new ResponseError("500",
                "Failed to fetch wishlist"));
    }

    private PlatformEntityCategory entityExistsInPlatformEntityCategoryEnum(String entityName) {
        for(PlatformEntityCategory val : PlatformEntityCategory.values()){
            if(val.name().equals(entityName))
                return val;
        }
        return null;
    }

    private boolean checkIfEntitynameExistsInDb(Wishlist wishlist){
        if(wishlist.getEntityName() == PlatformEntityCategory.JOB){
            Optional<Job> jobObj = jobsRepository.findById(wishlist.getEntityId());
            return jobObj.isPresent();
        }
        if(wishlist.getEntityName() == PlatformEntityCategory.HACKATHON){
            Optional<Drill> drillObj = drillRepository.findById(wishlist.getEntityId());
            return drillObj.isPresent();
        }
        return true;
    }
}




	
