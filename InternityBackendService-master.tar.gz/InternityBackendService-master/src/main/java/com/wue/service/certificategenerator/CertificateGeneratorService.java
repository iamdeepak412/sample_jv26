package com.wue.service.certificategenerator;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.domain.certificategenerator.ImageDocumentMaster;
import com.wue.domain.certificategenerator.ParticipantCertificate;
import com.wue.domain.drill.DrillParticipant;
import com.wue.domain.drill.DrillTeams;
import com.wue.domain.drill.TeamsParticipants;
import com.wue.dto.certificategenerator.CertificateGenerator;
import com.wue.model.EmailContent;
import com.wue.repository.certificategenerator.CertificateGeneratorRepository;
import com.wue.repository.certificategenerator.ImageDocumentMasterRepository;
import com.wue.repository.certificategenerator.WebCheckinRepository;
import com.wue.repository.drill.DrillParticipantRepository;
import com.wue.repository.drill.DrillRepository;
import com.wue.repository.drill.DrillTeamsRepository;
import com.wue.repository.drill.TeamsParticipantsRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.SendMessageUtils;
import lombok.extern.log4j.Log4j2;

import org.apache.commons.lang3.RandomStringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import javax.mail.MessagingException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Log4j2
public class CertificateGeneratorService {
	
	 @Value("${bucket}")
	 private String bucket;
	 
	 @Value("${ACCESS_KEY}")
	 private String aws_access_key;

	 @Value("${SECRET_KEY}")
	 private String aws_secret_key;
	 
	 @Value("${region}")
	 private String region;
	 
	 private AmazonS3 s3client;
	 
	 private String imageTitleAxis;
	 
	 private String imageUrl;

	@Autowired
	CertificateGeneratorRepository certificateGeneratorRepository;
	
	@Autowired
	WebCheckinRepository webCheckinRepository;
	
	@Autowired
	ImageDocumentMasterRepository imageDocumentMasterRepository;

	@Autowired
	DrillParticipantRepository drillParticipantRepository;

	@Autowired
	CommonUtils commonUtils;

	@Autowired
	SendMessageUtils messageUtils;

	@Autowired
	DrillRepository drillRepository;
	
	@Autowired
	TeamsParticipantsRepository TeamsParticipantsRepository;
	
	@Autowired
	DrillTeamsRepository drillTeamsRepository;

	@Autowired
	private ModelMapper modelMapper;

	@Value("${certificate.generator.url:http://13.200.62.58:5000/api/v1/certificates/imageGenerator}")
	private String certificateGeneratorUrl;

	public ResponseEntity<?> saveCertificateUrl(CertificateGenerator payload, InternityUser internityUser) {
		try {
			Long maxId = certificateGeneratorRepository.count();
			String eventId = payload.getEventId();
			String email = payload.getEmail();
			ParticipantCertificate participantCertificate = new ParticipantCertificate();

			participantCertificate.setCertificateId("WUE-"
					+ RandomStringUtils.randomAlphabetic(1)
					+ RandomStringUtils.randomNumeric(4)
					+ "-"
					+ (maxId+1));
			participantCertificate.setCertificateUrl(payload.getCertificateUrl());
			participantCertificate.setEventId(eventId);
			participantCertificate.setEventType(payload.getEventType());
			participantCertificate.setPositionType(
					StringUtils.isEmpty(payload.getPositionType())
						? "Participant"
						: payload.getPositionType()
			);
			

			switch (payload.getEventType()){
				case "Drill":
					Optional<DrillParticipant> drillParticipantObj =
							drillParticipantRepository.findByDrillIdAndEmail(eventId, email);
					if(drillParticipantObj.isPresent()){
						participantCertificate.setParticipantId(drillParticipantObj.get().getParticipantId());
						participantCertificate.setUId(drillParticipantObj.get().getPlatformUId());
					}else{
						log.error("No participant present in drill {} with email {}", eventId, email);
						participantCertificate.setEventId("NOTPRESENT");
					}
					break;
				default:
					break;
			}
			certificateGeneratorRepository.save(participantCertificate);

			return new ResponseEntity<>(commonUtils.message(HttpStatus.OK
					, "Certificate details saved successfully"), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while saving certificate details {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					, "Failed to save certificate details"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	public Object saveCertificateToDB(String eventId, String eventType, String positionOrder, InternityUser user) {
	    StringBuilder report = new StringBuilder();

	    if ("NA".equals(positionOrder)) {
	        positionOrder = "PARTICIPANT";
	    }

	    List<DrillParticipant> drillParticipantObj = drillParticipantRepository.findByDrillIdAndParticipantState(eventId, positionOrder);
	    positionOrder = "PARTICIPANT".equals(positionOrder) ? "participants" : positionOrder;
	    RestTemplate restTemplate = new RestTemplate();

	    Long maxId = certificateGeneratorRepository.count();

	    for (DrillParticipant participant : drillParticipantObj) {
	        try {
	            String name = participant.getFullName();
	            String participantId = participant.getParticipantId();

	            maxId++;
	            String certificateId =
	                "WUE-"
	                    + RandomStringUtils.randomAlphabetic(1)
	                    + RandomStringUtils.randomNumeric(4)
	                    + "-"
	                    + maxId;

	            Optional<ImageDocumentMaster> imageDetailsObj = imageDocumentMasterRepository.findByEventId(eventId);
	            ImageDocumentMaster imageDetails = imageDetailsObj.orElseThrow(() -> new Exception("Image details not found for eventId: " + eventId));
	            String imageUrl = imageDetails.getImageUrl();
	            String imageTitleAxis = imageDetails.getImageTitleAxis();
	            String teamName = "";

	            // Fetch the actual name, team, and certificateId values
	            String actualName = name;
	            List<TeamsParticipants> teamList = TeamsParticipantsRepository.findByParticipantId(participantId);

	            if (!teamList.isEmpty()) {
	                // Assuming you want the first team's ID, you can adjust as needed
	                String teamId = teamList.get(0).getTeamId();

	                // Fetch the teamName using teamId from drillTeamsRepository
	                Optional<DrillTeams> teamObj = drillTeamsRepository.findById(teamId);

	                if (teamObj.isPresent()) {
	                    teamName = teamObj.get().getTeamName();
	                }
	            }

	            // Parse the imageTitleAxis JSON
	            JSONArray titleAxisArray = new JSONArray(imageTitleAxis);

	            // Construct the JSON for the certificate text list
	            JSONArray certificateTextList = new JSONArray();
	            for (int i = 0; i < titleAxisArray.length(); i++) {
	                JSONObject titleAxisItem = titleAxisArray.getJSONObject(i);
	                String text = titleAxisItem.getString("Text");
	                double xAxis = titleAxisItem.getDouble("X-axis");
	                double yAxis = titleAxisItem.getDouble("Y-axis");
	                int fontSize = titleAxisItem.getInt("font_size");

	                JSONObject certificateTextItem = new JSONObject();
	                certificateTextItem.put("Text", text);
	                certificateTextItem.put("X-axis", xAxis);
	                certificateTextItem.put("Y-axis", yAxis);
	                certificateTextItem.put("font_size", fontSize);

	                if ("FullName".equalsIgnoreCase(text)) {
	                    certificateTextItem.put("Text", actualName);
	                } else if ("Team".equalsIgnoreCase(text)) {
	                    certificateTextItem.put("Text", teamName);
	                } else if ("CertificateId".equalsIgnoreCase(text)) {
	                    certificateTextItem.put("Text", certificateId);
	                }

	                certificateTextList.put(certificateTextItem);
	            }

	            // Create the JSON request body
	            JSONObject requestBody = new JSONObject();
	            requestBody.put("certificateTextList", certificateTextList);

	            HttpHeaders headers = new HttpHeaders();
	            headers.setContentType(MediaType.APPLICATION_JSON);
	            HttpEntity<String> request = new HttpEntity<>(requestBody.toString(), headers);

	            String apiUrlWithParam = certificateGeneratorUrl+"?imageUrl=" + imageUrl;

	            // Send the POST request to the Python API
	            ResponseEntity<String> responseEntity = restTemplate.exchange(
	                apiUrlWithParam,
	                HttpMethod.POST,
	                request,
	                String.class);

	            if (responseEntity.getStatusCode() == HttpStatus.OK) {
	                String responseData = responseEntity.getBody();
	                
	             // Parse the JSON response from the Python API
	                JSONObject responseJson = new JSONObject(responseData);

	                // Get the S3 image URL from the response
	                String s3ImageUrl = responseJson.getString("s3_image_url");
	                
	                ParticipantCertificate participantCertificate = new ParticipantCertificate();

	                participantCertificate.setCertificateId(certificateId);
	                participantCertificate.setParticipantId(participant.getParticipantId());
	                participantCertificate.setCertificateUrl(s3ImageUrl);
	                participantCertificate.setEventId(eventId);
	                participantCertificate.setPositionType(positionOrder);
	                participantCertificate.setEventType(eventType);
	                
	                certificateGeneratorRepository.save(participantCertificate);
	                     
	            } else {
	           
	                report.append(
	                    "[NOT GENERATED] Certificate did not generate for "
	                    + participant.getFullName()
	                    + " with id "
	                    + participant.getParticipantId()
	                    + ". HTTP Status Code: "
	                    + responseEntity.getStatusCodeValue());
	            }
	        } catch (Exception e) {
	            log.error("Exception while saving participant certificate ::: {}", e);
	            report.append(
	                "[NOT GENERATED] Certificate did not generate for "
	                + participant.getFullName()
	                + " with id "
	                + participant.getParticipantId()
	                + " due to "
	                + e.getMessage());
	        }
	    }
	    return report.toString();
	}



	public Object fetchCertificateUrl(String participantId, InternityUser user) {
		try{
			Optional<ParticipantCertificate> participantCertificateObj = certificateGeneratorRepository.findByParticipantId(participantId);
			if(participantCertificateObj.isPresent()){
				return "{\"url\":\""+participantCertificateObj.get().getCertificateUrl()+"\"}";
			}
		}
		catch (Exception e){
			log.error("Exception while fetching certificate url {}", e);
			return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch certificate url "+e.getMessage());
		}
		return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch certificate url");
	}

  /**
   * Send mail to the participants whose certificates has been generated
   *
   * @param eventId
   * @param eventType
   * @param positionType
   * @param user
   * @return
   */
  public Object sendMailToParticipants(
      String eventId, String eventType, String positionType, String email, InternityUser user) {
    try {
      StringBuilder report = new StringBuilder();
	  String eventName = "";
	  if(eventType.equalsIgnoreCase("drill")){
		  eventName =  drillRepository.findById(eventId).get().getDrillName();
	  }

	  //for single email
      if (!email.equals("NA") && eventType.equalsIgnoreCase("drill")) {
        Optional<DrillParticipant> drillParticipantSingleObj =
            drillParticipantRepository.findByDrillIdAndEmail(eventId, email);
        if (drillParticipantSingleObj.isPresent()) {
          DrillParticipant drillParticipant = drillParticipantSingleObj.get();
          Optional<ParticipantCertificate> participantCertificate =
              certificateGeneratorRepository.findByParticipantId(
                  drillParticipant.getParticipantId());
          if (participantCertificate.isPresent()) {
            return (sendCertificateMail(
                drillParticipant.getEmail(),
                participantCertificate.get().getCertificateUrl(),
                drillParticipant.getFullName(),
                positionType,
                drillParticipant.getDrillId(),
                eventName));
          }
        }
      }

	  //for all participants of that event
      List<ParticipantCertificate> participantCertificateList =
          certificateGeneratorRepository.findByEventIdAndEventTypeAndPositionType(
              eventId, eventType, positionType);

      for (ParticipantCertificate participantCertificate : participantCertificateList) {
        Optional<DrillParticipant> drillParticipantObj =
            drillParticipantRepository.findById(participantCertificate.getParticipantId());
        if (drillParticipantObj.isPresent()) {
          DrillParticipant drillParticipant = drillParticipantObj.get();
          report.append(
              sendCertificateMail(
                  drillParticipant.getEmail(),
                  participantCertificate.getCertificateUrl(),
                  drillParticipant.getFullName(),
                  positionType,
                  drillParticipant.getDrillId(),
                  eventName));
        }
        report.append(
            "[NOT PRESENT] Certificate mail not sent as participant is not present with participant id "
                + participantCertificate.getParticipantId());
      }

	  return report.toString();

    } catch (Exception e) {
      log.error(
          "Failed while sending mail of certificate to the user of event {} with error ::: {}",
          eventId,
          e);
      return "Failed while sending mail of certificate to the user of event " + eventId;
    }
  }

	private String sendCertificateMail(String email, String certificateUrl, String fullName,
									 String positionType, String drillId, String drillName){
		try{
			EmailContent emailContent = new EmailContent();
			emailContent.setSubject(drillName + " | Participation certificate");
			emailContent.setTemplateName("GenericMailForAllUsers");
			//emailContent.setLink();
			emailContent.setMessage("<h2>Thanks for participating in "+drillName+"</h2>" +
				"<h3>You can download your participation certificate from this " +
				"<a href=\""+certificateUrl+"\">link</a></h3><br/><h3>We have more and bigger hackathons" +
				"listed on our platform, please <a href=\"https://wuelev8.tech/drill\">visit here</a> " +
				"and participate</h3>"
			);
			emailContent.setUserName("Dear "+fullName);
			messageUtils.sendMail(email, emailContent);
			return "Certificate mail sent to participant "+ fullName + " with email " + email;
		}
		catch (MessagingException me){
			log.error("Exception while sending mail of certificate "+ me);
			return "[MAIL NOT SENT] Failed to send mail to user "+ fullName + " with email "+ email;
		}
	}

	public Object saveImageUrlToDB(String eventId, String eventType, String positionType, MultipartFile multipartFile,String imageTitleAxis, InternityUser user) {
		
		StringBuilder report = new StringBuilder();
	    RestTemplate restTemplate = new RestTemplate();
	    try {
	        HttpHeaders headers = new HttpHeaders();
	        HttpEntity<String> request = new HttpEntity<String>(headers);
	        String response = uploadFileToS3(eventId,eventType,positionType,multipartFile, user);

	        ImageDocumentMaster participantCheckinPass = new ImageDocumentMaster();

	        participantCheckinPass.setImageTitleAxis(imageTitleAxis);
	        participantCheckinPass.setEventId(eventId);
	        participantCheckinPass.setImageState(positionType);
	        participantCheckinPass.setEventType(eventType);
	        participantCheckinPass.setImageUrl(response);
	        imageDocumentMasterRepository.save(participantCheckinPass);
	        report.append(
	            "Image Url Saved For Participant Type "
	                + positionType);
	      } catch (Exception e) {
	        log.error("Exception while saving image url ::: {}", e);
	        report.append(
	            "[NOT SAVED] Image url did not save for  "
	                + positionType
	                + "type due to "
	                + e.getMessage());
	      }
	    return report.toString();
	}

//	public Object generateBoardingPass(String eventId, String participantId, InternityUser user) {
//		
//		 StringBuilder report = new StringBuilder();
//		  List<ImageDocumentMaster>list = imageDocumentMasterRepository.FirstfindByEventId(eventId);
//		  for(ImageDocumentMaster imageDetails:list) {
//			  imageTitleAxis = imageDetails.getImageTitleAxis();
//			  imageUrl = imageDetails.getImageUrl();
//			  String TitleAxis =  imageTitleAxis;
//			  String image_url =  imageUrl;
//		    RestTemplate restTemplate = new RestTemplate();
//		    try {
//		        HttpHeaders headers = new HttpHeaders();
//		        headers.setContentType(MediaType.APPLICATION_JSON);
//		        HttpEntity<String> request = new HttpEntity<String>(TitleAxis,headers);
//		        String response =
//		            restTemplate.postForObject(
//		                "http://127.0.0.1:5000"
//		                    + "/imageGenerator"
//		                    + "?image_url="
//                            + image_url,
//		                request,
//		                String.class);
//
//		        WebCheckin participantCheckinPass = new WebCheckin();
//		        participantCheckinPass.setEventId(eventId);
//		        participantCheckinPass.setParticipantId(participantId);
//		        participantCheckinPass.setCheckinPassUrl(response);
//		        webCheckinRepository.save(participantCheckinPass);
//		        report.append(
//		            "Checkin Pass Url Saved For Participant Type "
//		                + participantId);
//		      } catch (Exception e) {
//		        log.error("Exception while saving image url ::: {}", e);
//		        report.append(
//		            "[NOT SAVED] Checkin pass url did not generate for  "
//		                + participantId
//		                + "type due to "
//		                + e.getMessage());
//		      }
//		  }
//		    return report.toString();
//		}
	
	@PostConstruct
    private void initializeAmazon() {
       AWSCredentials credentials = new BasicAWSCredentials(this.aws_access_key, this.aws_secret_key);
       this.s3client = new AmazonS3Client(credentials);
}
	
	private File convertMultiPartToFile(MultipartFile file) throws IOException {
	    File convFile = new File(file.getOriginalFilename());
	    FileOutputStream fos = new FileOutputStream(convFile);
	    fos.write(file.getBytes());
	    fos.close();
	    return convFile;
	}
	
	private String generateFileName(MultipartFile multiPart) {
	    return new Date().getTime() + "-" + multiPart.getOriginalFilename().replace(" ", "_");
	}
	private void uploadFileTos3bucket(String fileName, File file,String eventId,String eventType,String positionType) {
	    s3client.putObject(new PutObjectRequest(bucket,"certificates/"+eventId+'/'+eventType+'/'+positionType+'/'+ fileName, file)
	            .withCannedAcl(CannedAccessControlList.PublicRead));
	}

	public String uploadFileToS3(String eventId, String eventType, String positionType, MultipartFile multipartFile,
			InternityUser user) {
		String fileUrl = "";
	    try {
	        File file = convertMultiPartToFile(multipartFile);
	        String fileName = generateFileName(multipartFile);
	        fileUrl = "https://wuelev8-user-bucket.s3.ap-south-1.amazonaws.com/certificates/"+eventId+'/'+eventType+'/'+positionType+'/' + fileName;
	        uploadFileTos3bucket(fileName, file,eventId,eventType,positionType);
	        file.delete();
	        }
	    catch (Exception e)
	    {
	    	 log.error("Failed to upload",e);
	    }
	    return fileUrl;
	}
//	private String sendCertificateMailToParticipant(String email, String certificateUrl, String fullName,
//			 String positionType, String drillId, String drillName) {
//		try{
//			EmailContent emailContent = new EmailContent();
//			emailContent.setSubject(drillName + " | Boarding Pass");
//			emailContent.setTemplateName("GenericMailForAllUsers");
//			emailContent.setMessage("<h2>Thanks for participating in "+drillName+"</h2>" +
//			"<h3>You can download your Boarding Pass from this " +
//			"<a href=\""+certificateUrl+"\">link</a></h3><br/><h3>We have more and bigger hackathons" +
//			"listed on our platform, please <a href=\"https://wuelev8.tech/drill\">visit here</a> " +
//			"and participate</h3>"
//			);
//			emailContent.setUserName("Dear "+fullName);
//			messageUtils.sendMail(email, emailContent);
//			return "Boarding Pass mail sent to participant "+ fullName + " with email " + email;
//			}
//			catch (MessagingException me){
//			log.error("Exception while sending mail of certificate "+ me);
//			return "[MAIL NOT SENT] Failed to send mail to user "+ fullName + " with email "+ email;
//			}
//	}

	public byte[] generateCertificate(String imageUrl, List<String> details) throws IOException {
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    RestTemplate restTemplate = new RestTemplate();
	    ObjectMapper objectMapper = new ObjectMapper();

	    // Construct the request body
	    Map<String, Object> requestBody = new HashMap<>();
	    requestBody.put("imageUrl", imageUrl);
	    requestBody.put("certificateTextList", details);

	    String jsonRequest = objectMapper.writeValueAsString(requestBody);

	    HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);

	    ResponseEntity<byte[]> responseEntity = restTemplate
				.exchange(certificateGeneratorUrl + "/imageGenerator",
						HttpMethod.POST, requestEntity, byte[].class);

	    if (responseEntity.getStatusCode() == HttpStatus.OK) {
	        return responseEntity.getBody();
	    } else {
	        throw new IOException("Failed to generate certificate image");
	    }
	}


	
	
}
