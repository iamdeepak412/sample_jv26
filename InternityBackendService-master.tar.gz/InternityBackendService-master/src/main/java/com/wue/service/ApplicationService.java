package com.wue.service;

import com.wue.constant.ApplicationRejectSubStatus;
import com.wue.constant.ApplicationStatus;
import com.wue.constant.CommonConstants;
import com.wue.constant.NotificationType;
import com.wue.constant.application.ApplicationInterviewRounds;
import com.wue.constant.application.ApplicationRejectedReasons;
import com.wue.constant.application.ApplicationStages;
import com.wue.custom.specification.ApplicationFilterSpecification;
import com.wue.custom.specification.ApplicationTrackSpecification;
import com.wue.custom.specification.SearchCriteria;
import com.wue.domain.*;
import com.wue.domain.CandidateApplication.JobApplicationScreeningAnswer;
import com.wue.domain.ConfigureJob.JobScreeningQuestion;
import com.wue.dto.ApplicationDto;
import com.wue.dto.CompleteApplicationDto;
import com.wue.dto.application.ApplicationStageResponseDto;
import com.wue.dto.application.ApplicationUpdateStagesDto;
import com.wue.dto.assessprofile.FinalAssessedProfileDetails;
import com.wue.dto.response.Response;
import com.wue.dto.search.ApplicationSearchResultDto;
import com.wue.model.EmailContent;
import com.wue.repository.*;
import com.wue.repository.CandidateApplication.JobApplicationScreeningAnswerRepository;
import com.wue.repository.ConfigureJob.JobScreeningQuestionRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.SendMessageUtils;
import com.wue.util.application.ApplicationStatusRuleEngine;
import com.wue.util.drill.ResponseUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Log4j2
public class ApplicationService {

	private static final Logger logger = LoggerFactory.getLogger(ApplicationService.class);

    @PersistenceContext
	private EntityManager entityManager;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    ApplicationRepository applicationRepository;

    @Autowired
    ApplicationTrackRepository applicationTrackRepository;

    @Autowired
    JobsRepository jobsRepository;

    @Autowired
    PartnerService partnerService;

    @Autowired
    PartnerRepository partnerRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    NotificationRepository notificationRepository;

    @Autowired
    NotificationService notificationService;

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    UserProfileRepository userProfileRepository;

    @Autowired
	SendMessageUtils messageUtils;

    @Autowired
    UserCandidateMandatoryFieldsRepository userCandidateMandatoryFieldsRepository;

    @Value("${domain.url:https://www.whereuelevate.com/}")
    String domainUrl;

    @Value("${talentacquisition.emailid:talentacquisition@wuelev8.tech}")
    String talentAcquisitionEmailid;

    @Value("${certificate.generator.url:http://127.0.0.1:5069}")
  	private String certificateGeneratorUrl;

    @Autowired
    JobsService jobsService;

    @Autowired
    JobScreeningQuestionRepository jobScreeningQuestionRepository;

    @Autowired
    JobApplicationScreeningAnswerRepository screeningAnswerRepository;

    @Autowired
    ApplicationStatusRuleEngine applicationStatusRuleEngine;

    @Autowired
    AssessApplicationService assessApplicationService;

    @Autowired
    ResponseUtil responseUtil;

	private Specification<Application> Specifications;

    public ResponseEntity<?> addApplication(ApplicationDto applicationDto, InternityUser user) {
        try {
            applicationDto.setAppliedTs(LocalDateTime.now());

            if (checkIfAlreadyApplied(applicationDto)) {
               return new ResponseEntity<>(responseUtil.badRequestResponse("Already Applied to the application."),HttpStatus.BAD_REQUEST);
            }

            Optional<Job> jobObj = jobsRepository.findById(applicationDto.getJobId());

            if (jobObj.isPresent()) {
                Job job = jobObj.get();

                Application applicationObj = modelMapper.map(applicationDto, Application.class);

                Map<String, String> payload = setStatusAndFeedbackForApplied();

                Application application = this.addApplicationRecordInDb(applicationObj, payload);
                if (application==null) {
                    return new ResponseEntity<>(responseUtil.internalServerErrorResponse("Something went wrong. We request you to re-apply"),HttpStatus.INTERNAL_SERVER_ERROR);
                }
                if (application.getApplicationId() >= 0) {

                    increaseApplicant(job);

                    if (applicationIsInsertedIntoDb(job.getJobId(), applicationDto.getUId())) {
                        if(!StringUtils.isBlank(applicationDto.getCustomQuestionAnswered())){
                            JobApplicationScreeningAnswer answerObj = saveCandidateAnswers(application.getApplicationId(), job, applicationDto);
                            if (answerObj == null) {
                                return new ResponseEntity<>(responseUtil.internalServerErrorResponse("Something went wrong. while saving the custom questions"),HttpStatus.INTERNAL_SERVER_ERROR);
                            }
                        }

                       Response response = assessApplicationService.assessApplications(application, job,
                                applicationDto.getUId(), applicationDto.getCustomQuestionAnswered());
                        if (response.getSuccess()) {
                            jobApplicationMailToTATeam(job, applicationDto.getUId());
                            jobMailToUserApplying(job, applicationDto.getUId());
                            return new ResponseEntity<>(responseUtil.successResponse("Application added and assessed successfully."), HttpStatus.OK);
                        }
                        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
                    }
                }
                else {
                    responseUtil.internalServerErrorResponse("We request you to re-apply. Failure occurred due to network issue.");
                }
            } else {
                return new ResponseEntity<>(responseUtil.badRequestResponse("Failed to add the application as the job is not present in our database."),HttpStatus.BAD_REQUEST);
            }
        } catch (Exception e) {
            log.error("Failed to add the application for user {} with error {}", applicationDto.getUId(), e);
           return new ResponseEntity<>(responseUtil.internalServerErrorResponse("Exception occurred while adding the application"),HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(responseUtil.internalServerErrorResponse("We request you to re-apply. Failure occurred due to network issue."),HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private JobApplicationScreeningAnswer saveCandidateAnswers(Long applicationId, Job job, ApplicationDto applicationDto) {
        try{
            JobApplicationScreeningAnswer answerObj = new JobApplicationScreeningAnswer();
            answerObj.setUId(applicationDto.getUId());
            answerObj.setApplicationId(applicationId);
            answerObj.setAllCustomQueAnswer(applicationDto.getCustomQuestionAnswered());
            answerObj.setJobId(job.getJobId());
            return screeningAnswerRepository.save(answerObj);
        }
        catch (Exception e){
            log.error("Exception while saving the screening answers given by the user with " +
                    "job id {} ::: and user id {} ::: {}", job.getJobId(), applicationDto.getUId(), e);
            return null;
        }
    }

    private Map<String, Object> parseAndFetchCustomQuestionAnswers(String customQuestionAnswered) {
        try{
            Map<String, Object> result = new HashMap<>();
            JSONObject answerArr = new JSONObject(customQuestionAnswered);
            System.out.println(answerArr);
            List<Map<String, String>> listOfAssessedQuestions = new ArrayList<>();
            int countOfIsDecidingQuestionsIncorrect = 0;
            int countOfIsDecidingQuestions = 0;
            for (String key : answerArr.keySet()) {
                Map<String, String> questionAssessment = new HashMap<>();
                JSONObject customAnswerJson = new JSONObject(answerArr.get(key));
                Optional<JobScreeningQuestion> questionObj = jobScreeningQuestionRepository.findById(key);
                if(questionObj.isPresent()){
                    JobScreeningQuestion question = questionObj.get();

                    boolean isAnsweredAsExpected = customAnswerJson.getString(answerArr.getString(key))
                            .equalsIgnoreCase(question.getExpectedAnswer());

                    questionAssessment.put("question", question.getQuestion());
                    questionAssessment.put("score", isAnsweredAsExpected?"100%":"0%");
                    questionAssessment.put("actualAnswer", customAnswerJson.getString("answer"));
                    questionAssessment.put("expectedAnswer", question.getExpectedAnswer());

                    if(question.isDecidingQuestion()){
                        countOfIsDecidingQuestions++;
                        if(!isAnsweredAsExpected){
                            countOfIsDecidingQuestionsIncorrect++;
                        }
                    }
                    listOfAssessedQuestions.add(questionAssessment);
                }
            }
            if(countOfIsDecidingQuestions>0){
                double percentageMatch = ((double) countOfIsDecidingQuestionsIncorrect / (countOfIsDecidingQuestions)) * 100;
                result.put("isDecidingQuestionScore", percentageMatch+"");
            }else {
                result.put("isDecidingQuestionScore", "NA");
            }
            result.put("details", listOfAssessedQuestions);
        }
        catch (Exception e){
            log.error("Exception while parsing and fetching the custom question answers ::: {}", e);
        }
        return Collections.emptyMap();
    }

    private Map<String, String> setStatusAndFeedbackForApplied() {
        Map<String, String> payload = new HashMap<>();
        payload.put("status", ApplicationStatus.APPLIED.getEnumValue());
        payload.put("feedback", "Applied Successfully");
        return  payload;
    }

    private boolean applicationIsInsertedIntoDb(String jobId, String uId) {
        return applicationRepository.findByuIdAndJobId(uId,jobId).isPresent();
    }

    private void increaseApplicant(Job job) {
        job.setJobApplicantCount(job.getJobApplicantCount() + 1);
        jobsRepository.save(job);
    }

    private boolean checkIfAlreadyApplied(ApplicationDto applicationDto) {
        Optional<Application> applicationObj = applicationRepository.findByuIdAndJobId(applicationDto.getUId(), applicationDto.getJobId());
        return applicationObj.isPresent();
    }

    public ResponseEntity<Map<String, String>> updateApplicationStatusInBulk(Map<String, String> payload, InternityUser user) {
        try{
            String listOfApplicationId = payload.get("listOfApplicationId");
            StringBuilder report = new StringBuilder();
            for(String applicationId : listOfApplicationId.split(",")){
               ResponseEntity<String> res = updateApplicationStatus(Long.parseLong(applicationId), payload, user);
               if(res.getStatusCode()!=HttpStatus.OK){
                   report.append("Failed to update the status for application with id ::: "+applicationId);
                   report.append("\n");
               }
            }
            return new ResponseEntity(StringUtils.isBlank(report.toString())
                    ? commonUtils.message(HttpStatus.OK, "Updated successfully")
                    : commonUtils.message(HttpStatus.OK, report.toString()), HttpStatus.OK);
        }
        catch (Exception e){
            log.error("Exception while updating the application status in bulk {}", e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,"Failed to updated application status"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private Application addApplicationRecordInDb(Application application, Map<String, String> payload){
        try{
            application.setCurrentStatus(payload.get("status"));
            application.setUpdatedts(new Date());
            application.setSubStatus(payload.get("subStatus"));

            Application savedApplication = applicationRepository.saveAndFlush(application);

            ApplicationTrack appTrack = new ApplicationTrack();
            appTrack.setApplicationId(savedApplication.getApplicationId());
            appTrack.setFeedback(payload.get("feedback"));
            appTrack.setStatus(payload.get("status"));
            appTrack.setSubStatus(payload.get("subStatus"));
            appTrack.setUpdatedts(new Date());

            //Save new Application track entry
            applicationTrackRepository.saveAndFlush(appTrack);

            return savedApplication;
        }
        catch (Exception e){
            log.error("Exception while adding application record in Db ::: {}", e);
        }
        return null;
    }

    public ResponseEntity<String> updateApplicationStatus(Long applicationId, Map<String, String> payload, InternityUser user) {
        try {
            Optional<Application> applicationObj = applicationRepository.findById(applicationId);
            if (applicationObj.isPresent()) {
                Application application = applicationObj.get();
                if(!applicationStatusRuleEngine.isStatusUpdatePossible(application, payload)){
                    return new ResponseEntity<>("Update is not possible while changing the status ::: {}"
                        , HttpStatus.OK);
                }
                application.setCurrentStatus(payload.get("status"));
                application.setUpdatedts(new Date());
                application.setSubStatus(payload.get("subStatus"));

                ApplicationTrack appTrack = new ApplicationTrack();
                Optional<ApplicationTrack> appTrackWithStatus = applicationTrackRepository
                        .findByApplicationIdAndStatus(applicationId, payload.get("status"));
                if(appTrackWithStatus.isPresent()){
                    appTrack.setApplicationTrackId(
                            appTrackWithStatus.get().getApplicationTrackId());
                }

                appTrack.setApplicationId(applicationId);
                appTrack.setFeedback(payload.get("feedback"));
                appTrack.setStatus(payload.get("status"));
                appTrack.setUpdatedts(new Date());

                //Save new Application track entry
                applicationTrackRepository.saveAndFlush(appTrack);

                //Update Application entry
                applicationRepository.saveAndFlush(application);

                //Save Notification for application update
                Optional<Job> jobObj = jobsRepository.findById(application.getJobId());
                Job job = jobObj.get();

                Notification notification = notificationService.setNotificationObj(false, application.getUId(),NotificationType.JOBUPDATE.name(), new Date(), "NA", "Status updated to "+payload.get("status")+" for "+job.getJobTitle());
                notificationRepository.save(notification);
                jobMailToUserWithApplicationUpdate(job, payload.get("status"), payload.get("feedback"), application.getUId());
                return new ResponseEntity<>("{\"msg\":\"" + CommonConstants.SUCCESS + "\"}", HttpStatus.OK);

            } else {
                return new ResponseEntity<>("{\"msg\":\"" + CommonConstants.NO_SUCH_APPLICATION_EXISTS + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
            }

        } catch (Exception e) {
            log.error("Exception while updating application status and feedback {}", e);
            return new ResponseEntity<>("{\"msg\":\"" + CommonConstants.FAILED + " with exception " + e.getMessage() + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public List<Application> fetchAllApplications(String jobId, String uId, String applicationStatus, InternityUser user) {
        try {
            List<Application> applicationList = new ArrayList<>();
            if(!applicationStatus.equalsIgnoreCase("NA")){
                if (jobId.equalsIgnoreCase("NA")) {
                    return applicationRepository.findByuIdAndCurrentStatusOrderByUpdatedtsDesc(uId, applicationStatus);
                } else {
                    applicationList.addAll(
                            applicationRepository.findByJobIdAndCurrentStatusOrderByUpdatedtsDesc(jobId, applicationStatus));
                    return applicationList;
                }
            } else {
                if (jobId.equalsIgnoreCase("NA")) {
                    return applicationRepository.findByuIdOrderByUpdatedtsDesc(uId);
                } else {
                    applicationList.addAll(
                            applicationRepository.findByJobIdOrderByUpdatedtsDesc(jobId));
                    return applicationList;
                }
            }

        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch the events");
        }
    }

    /*
        Called as the user lands on the Track Application page and expects all the statuses
     */
    public List<CompleteApplicationDto> fetchListOfCompleteApplication(String uId, String jobId, InternityUser user) {

        List<CompleteApplicationDto> responseList = new ArrayList<>();
        try {
        //get all applications for a job or for a user
        List<Application> applicationList = this.fetchAllApplications(jobId, uId, "NA", user);
//        if(uId !=null||jobId!=null) {
//        	resumeScreeningAsPerJobDescription(uId,jobId,"NA",user);
//        }
        //iterate and get the complete information of an application
        for (Application app : applicationList) {

            CompleteApplicationDto completeApplication = new CompleteApplicationDto();

            // Function call
            setCompleteApplicationFromApplicationObj(app, completeApplication);

            Optional<Job> jobObj = jobsRepository.findById(app.getJobId());

            if (jobObj.isPresent()) {
                Job job = jobObj.get();

                //Function call
                setCompleteApplicationFromJobObj(job, completeApplication);

                Optional<Partner> partnerObj = partnerRepository.findById(job.getPartnerId());

                if (partnerObj.isPresent()) {
                    Partner partner = partnerObj.get();
                    setCompleteApplicationFromPartnerObj(partner, completeApplication);
                } else {
                    log.error("Company is not registered with us for this job completeApplication. " +
                            "Please connect with support team");
                }
                Optional<User> userObj = userRepository.findById(app.getUId());
                if (userObj.isPresent()) {
                    User user1 = userObj.get();
                    user1.setPassword(null);
                    completeApplication.setUserId(app.getUId());
                    completeApplication.setUserFullName(userObj.get().getFullName());

                    completeApplication.setAllUserDetails(user1);
                    if(!jobId.equals("NA")){
                        Optional<UserPersonalDetail> userPersonalDetail = userProfileRepository
                                .findByuId(app.getUId());
                        if(userPersonalDetail.isPresent()){
                            UserPersonalDetail userPersonalDetail1 = userPersonalDetail.get();
                            completeApplication.setResumeLink(userPersonalDetail1.getResumeLink());
                            completeApplication.setUserProfileImgUrl(userPersonalDetail1.getProfilePicLink());
                        }
                        else {
                            completeApplication.setResumeLink("NA");
                        }
                    }
                    Optional<UserCandidateMandatoryFields> mandatoryFieldsObj = userCandidateMandatoryFieldsRepository
                            .findByuId(app.getUId());
                    if(mandatoryFieldsObj.isPresent()){
                            completeApplication.setUserCandidateMandatoryFields(
                                    mandatoryFieldsObj.get());
                    }else {
                        completeApplication.setUserCandidateMandatoryFields(new UserCandidateMandatoryFields());
                    }
                } else {
                    log.error("User is not registered with us. Please connect with support team");
                }
            } else {
                throw new RuntimeException("No Job is present with this Application. Please connect with support team");
            }
            Optional<UserCandidateMandatoryFields> userCandidateMandatoryFields = userCandidateMandatoryFieldsRepository.findByuId(uId);

            if (userCandidateMandatoryFields.isPresent()) {
                    completeApplication.setUserCandidateMandatoryFields(userCandidateMandatoryFields.get());
            }
            responseList.add(completeApplication);
        }
    }
    catch (Exception e){
        log.error("Exception while fetching the list of applications for job or user {} {} ::: {}", uId, jobId, e);
        return Collections.emptyList();
    }
        return responseList;
    }

    public List<CompleteApplicationDto> fetchListOfFinalAssessedProfiles(String uId, String jobId, InternityUser user) {

        List<CompleteApplicationDto> responseList = new ArrayList<>();
        try {
            //get all applications for a job or for a user
            List<Application> applicationList = this.fetchAllApplications(jobId, uId, "NA", user);
//        if(uId !=null||jobId!=null) {
//        	resumeScreeningAsPerJobDescription(uId,jobId,"NA",user);
//        }
            //iterate and get the complete information of an application
            for (Application app : applicationList) {

                CompleteApplicationDto completeApplication = new CompleteApplicationDto();

                // Function call
                setCompleteApplicationFromApplicationObj(app, completeApplication);

                Optional<Job> jobObj = jobsRepository.findById(app.getJobId());

                if (jobObj.isPresent()) {
                    Job job = jobObj.get();

                    //Function call
                    setCompleteApplicationFromJobObj(job, completeApplication);

                    Optional<Partner> partnerObj = partnerRepository.findById(job.getPartnerId());

                    if (partnerObj.isPresent()) {
                        Partner partner = partnerObj.get();
                        setCompleteApplicationFromPartnerObj(partner, completeApplication);
                    } else {
                        log.error("Company is not registered with us for this job completeApplication. " +
                                "Please connect with support team");
                    }
                    Optional<User> userObj = userRepository.findById(app.getUId());
                    if (userObj.isPresent()) {
                        User user1 = userObj.get();
                        user1.setPassword(null);
                        completeApplication.setUserId(app.getUId());
                        completeApplication.setUserFullName(userObj.get().getFullName());

                        completeApplication.setAllUserDetails(user1);
                        if(!jobId.equals("NA")){
                            Optional<UserPersonalDetail> userPersonalDetail = userProfileRepository
                                    .findByuId(app.getUId());
                            if(userPersonalDetail.isPresent()){
                                UserPersonalDetail userPersonalDetail1 = userPersonalDetail.get();
                                completeApplication.setResumeLink(userPersonalDetail1.getResumeLink());
                                completeApplication.setUserProfileImgUrl(userPersonalDetail1.getProfilePicLink());
                            }
                            else {
                                completeApplication.setResumeLink("NA");
                            }
                        }
                        Optional<UserCandidateMandatoryFields> mandatoryFieldsObj = userCandidateMandatoryFieldsRepository
                                .findByuId(app.getUId());
                        if(mandatoryFieldsObj.isPresent()){
                            completeApplication.setUserCandidateMandatoryFields(
                                    mandatoryFieldsObj.get());
                        }else {
                            completeApplication.setUserCandidateMandatoryFields(new UserCandidateMandatoryFields());
                        }
                    } else {
                        log.error("User is not registered with us. Please connect with support team");
                    }
                } else {
                    throw new RuntimeException("No Job is present with this Application. Please connect with support team");
                }
                Optional<UserCandidateMandatoryFields> userCandidateMandatoryFields = userCandidateMandatoryFieldsRepository.findByuId(uId);

                if (userCandidateMandatoryFields.isPresent()) {
                    completeApplication.setUserCandidateMandatoryFields(userCandidateMandatoryFields.get());
                }
                responseList.add(completeApplication);
            }
        }
        catch (Exception e){
            log.error("Exception while fetching the list of applications for job or user {} {} ::: {}", uId, jobId, e);
            return Collections.emptyList();
        }
        return responseList;
    }


    public List<CompleteApplicationDto> searchListOfCompleteApplication(String uId, String jobId, String applicationStatus,
           int minYoe, int maxYoe, int minExpectedCtc, int maxExpectedCtc, LocalDateTime minLwd, LocalDateTime maxLwd,
           boolean isServingNoticePeriod, String currentLoc, String noticePeriodDays, int limit, int offset, InternityUser user) {

        List<CompleteApplicationDto> responseList = new ArrayList<>();
        try {
            //get all applications for a job or for a user
            List<Application> applicationList = this.fetchAllApplications(jobId, uId, applicationStatus, user);
//        if(uId !=null||jobId!=null) {
//        	resumeScreeningAsPerJobDescription(uId,jobId,"NA",user);
//        }
            //iterate and get the complete information of an application
            for (Application app : applicationList) {

                CompleteApplicationDto completeApplication = new CompleteApplicationDto();

                // Function call
                setCompleteApplicationFromApplicationObj(app, completeApplication);

                Optional<Job> jobObj = jobsRepository.findById(app.getJobId());

                if (jobObj.isPresent()) {
                    Job job = jobObj.get();

                    //Function call
                    setCompleteApplicationFromJobObj(job, completeApplication);

                    Optional<Partner> partnerObj = partnerRepository.findById(job.getPartnerId());

                    if (partnerObj.isPresent()) {
                        Partner partner = partnerObj.get();
                        setCompleteApplicationFromPartnerObj(partner, completeApplication);
                    } else {
                        log.error("Company is not registered with us for this job completeApplication. " +
                                "Please connect with support team");
                    }
                    Optional<User> userObj = userRepository.findById(app.getUId());
                    if (userObj.isPresent()) {
                        User user1 = userObj.get();
                        user1.setPassword(null);
                        completeApplication.setUserId(app.getUId());
                        completeApplication.setUserFullName(userObj.get().getFullName());

                        completeApplication.setAllUserDetails(user1);
                        if(!jobId.equals("NA")){
                            Optional<UserPersonalDetail> userPersonalDetail = userProfileRepository
                                    .findByuId(app.getUId());
                            if(userPersonalDetail.isPresent()){
                                UserPersonalDetail userPersonalDetail1 = userPersonalDetail.get();
                                completeApplication.setResumeLink(userPersonalDetail1.getResumeLink());
                                completeApplication.setUserProfileImgUrl(userPersonalDetail1.getProfilePicLink());
                            }
                            else {
                                completeApplication.setResumeLink("NA");
                            }
                        }
                        Optional<UserCandidateMandatoryFields> mandatoryFieldsObj = userCandidateMandatoryFieldsRepository
                                .findByuId(app.getUId());
                        if(mandatoryFieldsObj.isPresent()){
                            completeApplication.setUserCandidateMandatoryFields(
                                    mandatoryFieldsObj.get());
                        }else {
                            completeApplication.setUserCandidateMandatoryFields(new UserCandidateMandatoryFields());
                        }
                    } else {
                        log.error("User is not registered with us. Please connect with support team");
                    }
                } else {
                    throw new RuntimeException("No Job is present with this Application. Please connect with support team");
                }
                Optional<UserCandidateMandatoryFields> userCandidateMandatoryFields = userCandidateMandatoryFieldsRepository.findByuId(uId);

                if (userCandidateMandatoryFields.isPresent()) {
                    completeApplication.setUserCandidateMandatoryFields(userCandidateMandatoryFields.get());
                }
                responseList.add(completeApplication);
            }
        }
        catch (Exception e){
            log.error("Exception while fetching the list of applications for job or user {} {} ::: {}", uId, jobId, e);
            return Collections.emptyList();
        }
        return responseList;
    }

    private void setCompleteApplicationFromPartnerObj(Partner partner, CompleteApplicationDto completeApplication) {
        completeApplication.setPartnerName(partner.getPartnerName());
        completeApplication.setJobImg(partner.getPartnerLogoPath());
    }

    private void setCompleteApplicationFromJobObj(Job job, CompleteApplicationDto completeApplication) {
        completeApplication.setJobTitle(job.getJobTitle());
        completeApplication.setJobId(job.getJobId());
        completeApplication.setJobObj(job);
    }

    private void setCompleteApplicationFromApplicationObj(Application app, CompleteApplicationDto completeApplication) {
        completeApplication.setApplicationId(app.getApplicationId());
        completeApplication.setAppliedTs(app.getAppliedTs());
        completeApplication.setUpdatedTs(app.getUpdatedts());
        completeApplication.setCurrentStatus(app.getCurrentStatus());
        completeApplication.setSkillsMatchedDetails(app.getSkillsMatchedDetails());
        if(app.getCurrentStatus().equalsIgnoreCase("Rejected")){
            completeApplication.setSubStatus(app.getSubStatus());
        }
    }

    public List<ApplicationTrack> applicationFilter(String search) {
        try {
            Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)(\\w+?),");
            Matcher matcher = pattern.matcher(search + ",");
            List<ApplicationTrackSpecification> productSpecs = new ArrayList<ApplicationTrackSpecification>();
            while (matcher.find()) {
                productSpecs.add(new ApplicationTrackSpecification(
                        new SearchCriteria(matcher.group(1), matcher.group(2), matcher.group(3))));
            }
            Specification<ApplicationTrack> spec = productSpecs.get(0);
            for (int i = 1; i < productSpecs.size(); i++) {
                spec = Specification.where(spec).and(productSpecs.get(i));
            }
            return applicationTrackRepository.findAll(spec);
        } catch (Exception e) {
            e.printStackTrace();
            return Collections.emptyList();
        }

    }

    public Map<String, Object> fetchApplicationStats(String uId, InternityUser user) {
        try {
            List<Application> userApplicationList = applicationRepository.findByuId(uId);

            int applicationPending = 0;
            int offersClosed = 0;
            int interviewsPending = 0;

            for (Application application : userApplicationList) {
                if (isApplicationJoined(application.getCurrentStatus())) {
                    offersClosed++;
                }
                if (isApplicationPending(application.getCurrentStatus())) {
                    applicationPending++;
                }
                if (isApplicationInterviewPending(application.getCurrentStatus().toLowerCase())) {
                    interviewsPending++;
                }
            }

            Map<String, Object> stats = new HashMap<>();

            stats.put("jobApplied", userApplicationList.size());
            stats.put("applicationPending", applicationPending);
            stats.put("offersClosed", offersClosed);
            stats.put("interviewsPending", interviewsPending);

            return stats;
        } catch (Exception e) {
            log.error("Exception in getting map of applications stats {}", e);
            return Collections.emptyMap();
        }
    }

    private boolean isApplicationPending(String status) {
        return !(status.equalsIgnoreCase(ApplicationStatus.OFFERED.name())
                || status.equalsIgnoreCase(ApplicationStatus.JOINED.name())
                || status.equalsIgnoreCase(ApplicationStatus.REJECTED.name()));
    }

    private boolean isApplicationJoined(String status) {
        return (status.equalsIgnoreCase(ApplicationStatus.OFFERED.name())
                || status.equalsIgnoreCase(ApplicationStatus.JOINED.name()));
    }

    private boolean isApplicationInterviewPending(String status) {
        return status.contains("interview") || status.contains("round");
    }

    /**
     * ToDo
     *
     * @param applicationId
     * @param user
     * @return
     */
    public List<Map<String, Object>> fetchCompleteListApplicationTrack(Long applicationId, String jobId, InternityUser user) {
        List<ApplicationTrack> listOfApplicationStatus = applicationTrackRepository.findByApplicationIdOrderByUpdatedtsAsc(applicationId);
        List<Map<String, Object>> listOfStatuses = new ArrayList<>();
        boolean isHrDiscussionInStatus = false;
        boolean isJoinedInStatus = false;
        String latestStatus = "";

        int countOfStatusUpdates = listOfApplicationStatus.size();

        for (int i = 0; i < countOfStatusUpdates; i++) {
            ApplicationTrack trackObj = listOfApplicationStatus.get(i);

            log.info("seq {} with obj {}", i, trackObj);

            latestStatus = trackObj.getStatus();

//            listOfStatuses.add(setCommonStatuses(trackObj.getApplicationTrackId(),i + "",
//                    trackObj.getStatus().contains("REJECTED")?ApplicationStatus.REJECTED.name():trackObj.getStatus()
//                    , "Completed", trackObj.getFeedback(), trackObj.getUpdatedts() + ""));

            listOfStatuses.add(setCommonStatuses(trackObj.getApplicationTrackId(),i + "", trackObj.getStatus()
                    , "Completed", trackObj.getFeedback(), trackObj.getUpdatedts() + ""));

        }

        log.info("latest status {}", latestStatus);

        int biggestOrderOfStatus = this.mapOfStatusAndOrder(user).get(latestStatus.toUpperCase());

        log.info("biggest order of status {}", biggestOrderOfStatus);

        setListOfStatus(biggestOrderOfStatus, countOfStatusUpdates, listOfStatuses);

        log.info("list {}", listOfStatuses);

        if(!isHrDiscussionInStatus){
            Long counter = Long.valueOf(countOfStatusUpdates++);
            listOfStatuses.add(setCommonStatuses(counter, ""+counter, ApplicationStatus.HR_DISCUSSION.getEnumValue()
                    , "Pending", "HR Discussion pending", ""));
        }
        if(!isJoinedInStatus){
            Long counter = Long.valueOf(countOfStatusUpdates++);
            listOfStatuses.add(setCommonStatuses(counter,""+counter, ApplicationStatus.JOINED.getEnumValue()
                    , "Pending", "Joining is yet to be done", ""));
        }

        return listOfStatuses;
    }

    public List<Map<String, Object>> fetchCompleteListApplicationTrackv2(Long applicationId, String jobId, InternityUser user) {
        try{
            log.info("Fetching application track for application id ::: {}", applicationId);
            Optional<Application> applicationObj = applicationRepository.findById(applicationId);
            List<Map<String, Object>> listOfStatuses = new ArrayList<>();
            if (applicationObj.isPresent()) {
                if (applicationObj.get()
                        .getCurrentStatus()
                        .equalsIgnoreCase(ApplicationStatus.REJECTED.getEnumValue())) {
                    List<ApplicationTrack> applicationTrackObj =
                            applicationTrackRepository.findByApplicationIdOrderByUpdatedtsAsc(
                                    applicationId);

                    for (ApplicationTrack track : applicationTrackObj) {
                        listOfStatuses.add(
                                setCommonStatusesv2(
                                        track.getApplicationTrackId(),
                                        track.getStatus(),
                                        track.getStatus(),
                                        track.getFeedback(),
                                        track.getUpdatedts() + ""));
                    }
                } else {
                    List<ApplicationTrack> applicationTrackObj =
                            applicationTrackRepository.findTop1ByApplicationIdOrderByUpdatedtsDesc(
                                    applicationId);
                    ApplicationTrack trackObj = applicationTrackObj.get(0);
                    listOfStatuses.add(
                            setCommonStatusesv2(
                                    trackObj.getApplicationTrackId(),
                                    applicationObj.get().getCurrentStatus(),
                                    trackObj.getStatus(),
                                    trackObj.getFeedback(),
                                    trackObj.getUpdatedts() + ""));
                    log.debug(
                            "list of status returning for application id ::: {} ::: {}",
                            applicationId,
                            trackObj);
                }
                log.info("Application track for application id is fetched ::: {}", applicationId);
            }
            return listOfStatuses;
        }
        catch (Exception e){
            log.error("Exception while fetching the complete list of application track ::: {}", e);
        }
        return Collections.emptyList();
    }

    public Map<String, Integer> mapOfStatusAndOrder(InternityUser user) {
        Map<String, Integer> statusEnum = new HashMap<>();
        statusEnum.put(ApplicationStatus.APPLIED.getEnumValue(),1);
        statusEnum.put(ApplicationStatus.SHORTLISTED.getEnumValue(), 2);
        statusEnum.put(ApplicationStatus.APPLICATION_SENT.getEnumValue(),3);
        statusEnum.put(ApplicationStatus.INTERVIEW_SCHEDULED.getEnumValue(),4);
        statusEnum.put(ApplicationStatus.ROUND_1.getEnumValue(),5);
        statusEnum.put(ApplicationStatus.ROUND_2.getEnumValue(),6);
        statusEnum.put(ApplicationStatus.ROUND_3.getEnumValue(),7);
        statusEnum.put(ApplicationStatus.ROUND_4.getEnumValue(),8);
        statusEnum.put(ApplicationStatus.ROUND_5.getEnumValue(),9);
        statusEnum.put(ApplicationStatus.ROUND_6.getEnumValue(),10);
        statusEnum.put(ApplicationStatus.ROUND_7.getEnumValue(),11);
        statusEnum.put(ApplicationStatus.ROUND_8.getEnumValue(),12);
        statusEnum.put(ApplicationStatus.ROUND_9.getEnumValue(),13);
        statusEnum.put(ApplicationStatus.ROUND_10.getEnumValue(),14);
        statusEnum.put(ApplicationStatus.ROUND_11.getEnumValue(),15);
        statusEnum.put(ApplicationStatus.ROUND_12.getEnumValue(),16);
        statusEnum.put(ApplicationStatus.ROUND_13.getEnumValue(),17);
        statusEnum.put(ApplicationStatus.ROUND_14.getEnumValue(),18);
        statusEnum.put(ApplicationStatus.ROUND_15.getEnumValue(),19);
        statusEnum.put(ApplicationStatus.ALL_ROUNDS_SELECTED.getEnumValue(),20);
        statusEnum.put(ApplicationStatus.HR_DISCUSSION.getEnumValue(),21);
        statusEnum.put(ApplicationStatus.OFFER_SENT.getEnumValue(),22);
        statusEnum.put(ApplicationStatus.OFFER_ACCEPTED.getEnumValue(),23);
        statusEnum.put(ApplicationStatus.JOINED.getEnumValue(),24);
        statusEnum.put(ApplicationStatus.REJECTED.getEnumValue(),25);
        statusEnum.put(ApplicationStatus.ONHOLD.getEnumValue(),26);

        return statusEnum;
    }


    private void setListOfStatus(int biggestOrderOfStatus, int counter, List<Map<String, Object>> listOfStatuses) {
        if(biggestOrderOfStatus < 2){
            listOfStatuses.add(setCommonStatuses(2L,"2", ApplicationStatus.SHORTLISTED.getEnumValue()
                    , "Pending", "Pending to be Shortlisted", ""));
            counter++;
        }
        if(biggestOrderOfStatus < 3){
            listOfStatuses.add(setCommonStatuses(3L,"3", ApplicationStatus.APPLICATION_SENT.getEnumValue()
                    , "Pending", "Application is not sent yet", ""));
            counter++;
        }
        if(biggestOrderOfStatus < 4){
            listOfStatuses.add(setCommonStatuses(4L,"4", ApplicationStatus.INTERVIEW_SCHEDULED.getEnumValue()
                    , "Pending", "Interview scheduling is pending", ""));
            counter++;
        }
    }

    private Map<String, Object> setCommonStatusesv2(Long applicationTrackId, String step, String stepStatus, String feedback, String stepTime) {
        Map<String, Object> innerStatusMap = new HashMap<>();
        innerStatusMap.put("applicationTrackId", applicationTrackId);
        innerStatusMap.put(CommonConstants.STEP, step);
        innerStatusMap.put(CommonConstants.STEP_STATUS, stepStatus);
        innerStatusMap.put(CommonConstants.FEEDBACK, feedback);
        innerStatusMap.put(CommonConstants.STEP_TIME, stepTime);
        return innerStatusMap;
    }
    private Map<String, Object> setCommonStatuses(Long applicationTrackId, String seq, String step, String stepStatus, String feedback, String stepTime) {
        Map<String, Object> innerStatusMap = new HashMap<>();
        innerStatusMap.put("applicationTrackId", applicationTrackId);
        innerStatusMap.put(CommonConstants.SRNO, seq);
        innerStatusMap.put(CommonConstants.STEP, step);
        innerStatusMap.put(CommonConstants.STEP_STATUS, stepStatus);
        innerStatusMap.put(CommonConstants.FEEDBACK, feedback);
        innerStatusMap.put(CommonConstants.STEP_TIME, stepTime);
        return innerStatusMap;
    }

    public List<Map<String, String>> fetchApplicationEnum(InternityUser user) {
        List<Map<String, String>> listOfMap = new ArrayList<>();
        Map<Integer, String> statusEnum = new HashMap<>();
        statusEnum.put(1, ApplicationStatus.APPLIED.getEnumValue());
        statusEnum.put(2, ApplicationStatus.SHORTLISTED.getEnumValue());
        statusEnum.put(3, ApplicationStatus.APPLICATION_SENT.getEnumValue());
        statusEnum.put(4, ApplicationStatus.INTERVIEW_SCHEDULED.getEnumValue());
        statusEnum.put(5, ApplicationStatus.ROUND_1.getEnumValue());
        statusEnum.put(6, ApplicationStatus.ROUND_2.getEnumValue());
        statusEnum.put(7, ApplicationStatus.ROUND_3.getEnumValue());
        statusEnum.put(8, ApplicationStatus.ROUND_4.getEnumValue());
        statusEnum.put(9, ApplicationStatus.ROUND_5.getEnumValue());
        statusEnum.put(10, ApplicationStatus.ROUND_6.getEnumValue());
        statusEnum.put(11, ApplicationStatus.ROUND_7.getEnumValue());
        statusEnum.put(12, ApplicationStatus.ROUND_8.getEnumValue());
        statusEnum.put(13, ApplicationStatus.ROUND_9.getEnumValue());
        statusEnum.put(14, ApplicationStatus.ROUND_10.getEnumValue());
        statusEnum.put(15, ApplicationStatus.ROUND_11.getEnumValue());
        statusEnum.put(16, ApplicationStatus.ROUND_12.getEnumValue());
        statusEnum.put(17, ApplicationStatus.ROUND_13.getEnumValue());
        statusEnum.put(18, ApplicationStatus.ROUND_14.getEnumValue());
        statusEnum.put(19, ApplicationStatus.ROUND_15.getEnumValue());
        statusEnum.put(20, ApplicationStatus.ALL_ROUNDS_SELECTED.getEnumValue());
        statusEnum.put(21, ApplicationStatus.HR_DISCUSSION.getEnumValue());
        statusEnum.put(22, ApplicationStatus.OFFER_SENT.getEnumValue());
        statusEnum.put(23, ApplicationStatus.OFFER_ACCEPTED.getEnumValue());
        statusEnum.put(24, ApplicationStatus.JOINED.getEnumValue());
        statusEnum.put(25, ApplicationStatus.REJECTED.getEnumValue());
        statusEnum.put(26, ApplicationStatus.ONHOLD.getEnumValue());

        for (Map.Entry<Integer, String> entry : statusEnum.entrySet()) {
            Map<String, String> mapOfStatus = new HashMap<>();
            mapOfStatus.put("order", entry.getKey() + "");
            mapOfStatus.put("status", entry.getValue());
            listOfMap.add(mapOfStatus);
        }
        return listOfMap;
    }

    public List<Map<String, String>> fetchApplicationSubstatusEnum(String subStatus, InternityUser user) {
        List<Map<String, String>> listOfMap = new ArrayList<>();
        Map<Integer, String> statusEnum = new HashMap<>();
        if (subStatus.equalsIgnoreCase(ApplicationStatus.REJECTED.name())) {
            statusEnum.put(30, ApplicationRejectSubStatus.DUPLICATE.getEnumValue());
            statusEnum.put(31, ApplicationRejectSubStatus.IRRELEVANT.getEnumValue());
            statusEnum.put(32, ApplicationRejectSubStatus.LOCATIONISSUE.getEnumValue());
            statusEnum.put(33, ApplicationRejectSubStatus.HIGHNOTICEPERIOD.getEnumValue());
        }
        for (Map.Entry<Integer, String> entry : statusEnum.entrySet()) {
            Map<String, String> mapOfStatus = new HashMap<>();
            mapOfStatus.put("order", entry.getKey() + "");
            mapOfStatus.put("status", entry.getValue());
            listOfMap.add(mapOfStatus);
        }
        return listOfMap;
    }

    public void jobApplicationMailToTATeam(Job job, String uId) {
		try {
        Optional<User> userObj = userRepository.findById(uId);
        if(userObj.isPresent()) {
            User user = userObj.get();
            UserPersonalDetail personalDetails = userProfileRepository.findByuId(uId).get();
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject("A candidate "+ user.getFullName() + " has applied for " + job.getJobTitle() + ", " + job.getPartnerName());
            emailContent.setTemplateName("JobApplicationMailToTATeam");
            emailContent.setLink(domainUrl);
            emailContent.setJobId(job.getJobId());
            emailContent.setMessage("<h2>Here you go</h2><h3>Candidate details:</h3><table><tr>" +
                            "<td><b>Name</b>:</td><td>&nbsp;  "+user.getFullName()+"</td></tr><tr>"+
                            "<td><b>Email id</b>:</td><td>&nbsp;  "+user.getEmail()+"</td></tr><tr>"+
                            "<td><b>Contact</b>:</td><td>&nbsp;  "+user.getUContact()+"</td></tr><tr>"+
                            "<td><b>Resume</b>:</td><td>&nbsp;  <a href=\""+personalDetails.getResumeLink()+"\">" +
                            "View/Download resume</a></td></tr></table>"
                    );
            emailContent.setResumeLink(userObj.get().getResumeLink());
            emailContent.setUserName("Dear TA team,");
            emailContent.setLink(domainUrl + "/desc/" + job.getJobId());
		    messageUtils.sendMail(talentAcquisitionEmailid, emailContent);
        }
	} catch (Exception exception) {
		log.info(exception.getMessage());
	}

		}

	public void jobMailToUserApplying(Job job, String uId) {
		try {
            Optional<User> userObj = userRepository.findById(uId);
            if(userObj.isPresent()) {
                UserPersonalDetail personalDetails = userProfileRepository.findByuId(uId).get();
                EmailContent emailContent = new EmailContent();
                emailContent.setSubject("Congratulations. You have successfully applied to the job " +
                        "for " + job.getJobTitle() + ", "+job.getPartnerName());
                emailContent.setTemplateName("JobMailToUserApplying");
                emailContent.setJobId(job.getJobId());
                emailContent.setMessage("<h3>Details of the job applied:</h3><table><tr>" +
                        "<td><b>Job Title</b>:</td><td>&nbsp; "+job.getJobTitle()+"</td></tr><tr>"+
                        "<td><b>Company</b>:</td><td>&nbsp; "+job.getPartnerName()+"</td></tr><tr>"+
                        "<td><b>Job Type</b>:</td><td>&nbsp; "+job.getJobType()+"</td></tr><tr>"+
                        "<td><b>Job Skills</b>:</td><td>&nbsp; "+job.getJobSkills()+"</td></tr><tr>"+
                        "<td><b>Your resume for this job</b>:</td><td>&nbsp; <a href=\""+personalDetails.getResumeLink()+"\">" +
                        "View/Download resume</a></td></tr></table>");
                emailContent.setUserName(userObj.get().getFullName());
                emailContent.setLink(domainUrl + "/track");
                messageUtils.sendMail(userObj.get().getEmail(), emailContent);
            }
		} catch (Exception exception) {
			log.info(exception.getMessage());
		}
	}

    public void jobMailToUserWithApplicationUpdate(Job job, String currentStatus, String feedback, String uId) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                UserPersonalDetail personalDetails = userProfileRepository.findByuId(uId).get();
                EmailContent emailContent = new EmailContent();
                emailContent.setSubject("Status on your job application is updated " +
                        "for " + job.getJobTitle() + ", " + job.getPartnerName());
                emailContent.setTemplateName("JobMailToUserApplying");
                emailContent.setJobId(job.getJobId());
                emailContent.setMessage("<h3>" + job.getJobTitle() + "</h3><table><tr>" +
                        "<td><b>Company</b>:</td><td>&nbsp; " + job.getPartnerName() + "</td></tr><tr>" +
                        "<td><b>Current Status</b>:</td><td>&nbsp; " + currentStatus + "</td></tr>" +
                        (StringUtils.isNoneBlank(feedback) ?
                                "<tr><td><b>Feedback</b>:</td><td>&nbsp; " + feedback + "</td></tr>"
                                : "") +
                        "</table>");
                emailContent.setUserName(userObj.get().getFullName());
                StringBuilder messageBuilder = new StringBuilder("<h3>" + job.getJobTitle() + "</h3><table style=\"width: 100%;\">" +
                        "<tr><td style=\"width: 138px;\"><b>Company</b>:</td><td>" + job.getPartnerName() + "</td></tr>" +
                        "<tr><td style=\"width: 138px;\"><b>Current Status</b>:</td><td>" + currentStatus + "</td></tr>");

                if (!StringUtils.isBlank(feedback)) {
                    // If feedback is not null or empty, include it in the email message with text alignment
                    messageBuilder.append("<tr><td style=\"width: 138px;\"><b>Feedback</b>:</td><td>" + feedback + "</td></tr>");
                }

                messageBuilder.append("</table>");

                emailContent.setMessage(messageBuilder.toString());
                emailContent.setLink(domainUrl + "/my-jobs");
                messageUtils.sendMail(userObj.get().getEmail(), emailContent);
            }
        } catch (Exception exception) {
            log.info("Exception while sending email to candidate who applied on job {}",exception.getMessage());
        }

    }

    public ApplicationSearchResultDto filterApplications(
            String skills,
            Double minCtc,
            Double maxCtc,
            Double minYoe,
            Double maxYoe,
            Integer noticePeriod,
            String preferredLocation,
            String currentLocation,
            String currentOrganization,
            String currentStatus,
            String subStatus,
            String appliedTimestamp,
            String lastWorkingDay,
            int limit,
            int offset,
            String order,
            String jobId,
            InternityUser user) {
        ApplicationSearchResultDto applicationSearchResultDto = null;

        try {
            Sort sort =
                    Sort.by(
                            order.equals("DESC") ? Sort.Direction.DESC : Sort.Direction.ASC,
                            "createdts");
            Pageable pageable = PageRequest.of(offset, limit, sort);
            Sort userSort =
                    Sort.by(
                            order.equals("DESC") ? Sort.Direction.DESC : Sort.Direction.ASC,
                            "userCreatedts");
            Pageable userPageable = PageRequest.of(offset, limit, userSort);

            Specification<Application> applicationSpecification = Specification.where(null);
            if (currentStatus != null) {
                applicationSpecification =
                        applicationSpecification.and(
                                ApplicationFilterSpecification.withCurrentStatus(currentStatus));
            }

            if (subStatus != null) {
                applicationSpecification =
                        applicationSpecification.and(
                                ApplicationFilterSpecification.withSubStatus(subStatus));
            }

            if (appliedTimestamp != null) {
                applicationSpecification =
                        applicationSpecification.and(
                                ApplicationFilterSpecification.withAppliedTimestamp(
                                        appliedTimestamp));
            }

            if (jobId != null) {
                applicationSpecification =
                        applicationSpecification.and(
                                ApplicationFilterSpecification.withJobId(jobId));
            }

            Page<Application> filteredApplications =
                    applicationRepository.findAll(applicationSpecification, pageable);

            List<String> filteredApplicationUIds =
                    filteredApplications.stream()
                            .map(Application::getUId)
                            .collect(Collectors.toList());
            List<Long> applicationIds =
                    filteredApplications.stream()
                            .map(Application::getApplicationId)
                            .collect(Collectors.toList());

            Specification<UserCandidateMandatoryFields> userCandidateSpecification =
                    Specification.where(null);
            userCandidateSpecification =
                    userCandidateSpecification
                            .and(ApplicationFilterSpecification.withSkills(skills))
                            .and(ApplicationFilterSpecification.withCurrentOrg(currentOrganization))
                            .and(ApplicationFilterSpecification.withNoticePeriod(noticePeriod))
                            .and(ApplicationFilterSpecification.withCurrentLoc(currentLocation))
                            .and(ApplicationFilterSpecification.withPreferredLoc(preferredLocation))
                            .and(ApplicationFilterSpecification.withLastWorkingDay(lastWorkingDay))
                            .and(ApplicationFilterSpecification.withYoeRange(minYoe, maxYoe))
                            .and(
                                    ApplicationFilterSpecification.withExpectedCtcRange(
                                            minCtc, maxCtc));

            Page<JobApplicationScreeningAnswer> filteredAssessedApplications =
                    screeningAnswerRepository.findByApplicationIdIn(applicationIds, userPageable);
            Map<Long, JobApplicationScreeningAnswer> applications = new HashMap<>();
            // set map of {applicationId, object of JobApplicationScreeningAnswer}
            for (JobApplicationScreeningAnswer answer : filteredAssessedApplications.toList()) {
                applications.put(answer.getApplicationId(), answer);
            }

            Page<UserCandidateMandatoryFields> filteredUserCandidates =
                    userCandidateMandatoryFieldsRepository.findByuIdIn(
                            filteredApplicationUIds, userPageable);
            // set map of {uId, object of UserCandidateMandatoryFields}
            Map<String, UserCandidateMandatoryFields> filteredUsers =
                    filteredUserCandidates.stream()
                            .collect(
                                    Collectors.toMap(
                                            UserCandidateMandatoryFields::getUId, item -> item));

            List<UserPersonalDetail> getResumeLink =
                    userProfileRepository.findByuIdIn(filteredApplicationUIds);
            // set map of {uId, object of UserCandidateMandatoryFields}

            Map<String, String> userWithResume = new HashMap<>();

            for(UserPersonalDetail personalDetail : getResumeLink){
                userWithResume.put(personalDetail.getUId(), personalDetail.getResumeLink());
            }

            Page<User> userBasicDetails =
                    userRepository.findByuIdIn(filteredApplicationUIds, userPageable);
            // set map of {uId, object of UserCandidateMandatoryFields}
            Map<String, User> filteredUserBasicDetail =
                    userBasicDetails.stream().collect(Collectors.toMap(User::getUId, item -> item));

            Optional<Job> jobObj = jobsRepository.findById(jobId);
            Job job = new Job();
            if (jobObj.isPresent()) {
                job = jobObj.get();
            }

            List<FinalAssessedProfileDetails> finalAssessedProfileDetails = new ArrayList<>();
            for (Application applicationObj : filteredApplications.toList()) {
                String uId = applicationObj.getUId();
                FinalAssessedProfileDetails assessedProfileDetails =
                        new FinalAssessedProfileDetails();
                UserCandidateMandatoryFields userMandatoryObj = filteredUsers.get(uId);
                if (userMandatoryObj == null) {
                    userMandatoryObj = new UserCandidateMandatoryFields();
                }
                JobApplicationScreeningAnswer assessedApplication =
                        applications.get(applicationObj.getApplicationId());
                if (assessedApplication == null) {
                    assessedApplication = new JobApplicationScreeningAnswer();
                }
                User userObj = filteredUserBasicDetail.get(uId);
                if (userObj == null) {
                    continue;
                }
                assessedProfileDetails.setUId(uId);
                assessedProfileDetails.setJobId(applicationObj.getJobId());
                assessedProfileDetails.setApplicationId(applicationObj.getApplicationId());
                assessedProfileDetails.setName(userObj.getFullName());
                assessedProfileDetails.setEmail(userObj.getEmail());
                assessedProfileDetails.setContact(userObj.getUContact());
                assessedProfileDetails.setActualYoe(userMandatoryObj.getYoe());
                assessedProfileDetails.setUserCandidateMandatoryFields(userMandatoryObj);
                assessedProfileDetails.setExpectedYoe(
                        ((StringUtils.isBlank(job.getJobMinYoe() + ""))
                                        ? ""
                                        : job.getJobMinYoe() + "")
                                + "-"
                                + ((StringUtils.isBlank(job.getJobMaxYoe() + ""))
                                        ? ""
                                        : job.getJobMaxYoe() + ""));
                assessedProfileDetails.setActualSkills(userMandatoryObj.getPrimarySkills());
                assessedProfileDetails.setExpectedSkills(job.getJobSkills());
                assessedProfileDetails.setResumeLink(userWithResume.get(uId));
                assessedProfileDetails.setStatus(applicationObj.getCurrentStatus());
                assessedProfileDetails.setSubStatus(applicationObj.getSubStatus());
                if (assessedApplication != null) {
                    assessedProfileDetails.setYoeScore(
                            assessedApplication.getTotalYoeScore() == null
                                    ? -1.0
                                    : assessedApplication.getTotalYoeScore());
                    assessedProfileDetails.setSkillScore(
                            assessedApplication.getPrimarySkillsScore() == null
                                    ? -1.0
                                    : assessedApplication.getPrimarySkillsScore());
                    assessedProfileDetails.setIsDecidingQuestionScore(
                            assessedApplication.getIsDecidingQuestionScore() == null
                                    ? -1.0
                                    : assessedApplication.getIsDecidingQuestionScore());
                    assessedProfileDetails.setCustomQuestionMap(
                            StringUtils.isBlank(assessedApplication.getAllCustomQueAnswer())
                                    ? "NA"
                                    : assessedApplication.getAllCustomQueAnswer());
                }
                assessedProfileDetails.setLastUpdated(applicationObj.getUpdatedts());

                finalAssessedProfileDetails.add(assessedProfileDetails);
            }

            //	    List<String> filteredUserCandidateUIds = filteredUserCandidates
            //	            .stream()
            //	            .map(UserCandidateMandatoryFields::getUId)
            //	            .collect(Collectors.toList());
            //
            //	    List<CompleteApplicationDto> completeApplications = new ArrayList<>();
            //	    for (String uId : filteredUserCandidateUIds) {
            //	        if (jobId != null) {
            //	            completeApplications.addAll(fetchListOfFinalAssessedProfiles(uId, jobId,
            // user));
            //	        } else {
            //	            completeApplications.addAll(fetchListOfCompleteApplication(uId, "All",
            // user));
            //	        }
            //	    }
            applicationSearchResultDto =
                    ApplicationSearchResultDto.builder()
                            .Details(finalAssessedProfileDetails)
                            .totalRecordCount(filteredApplications.getTotalElements())
                            .build();
        } catch (Exception e) {
            log.error("Exception while filtering the API for fetching Applications {}", e);
        }
        return applicationSearchResultDto;
    }

	public List<FinalAssessedProfileDetails> downloadFilterApplications(String skills, Double minCtc, Double maxCtc, Double minYoe, Double maxYoe,
	        Integer noticePeriod, String preferredLocation, String currentLocation, String currentOrganization,
	        String currentStatus, String subStatus, String appliedTimestamp, String lastWorkingDay,
	        int limit, int offset, String order, String jobId, InternityUser user) {
		 try {
			 List<FinalAssessedProfileDetails> completeApplicationDto =
	                    this.filterApplications(skills, minCtc, maxCtc, minYoe, maxYoe,
                                noticePeriod, preferredLocation, currentLocation, currentOrganization,
                                currentStatus, subStatus, appliedTimestamp, lastWorkingDay, limit,
                                offset, order, jobId, user).getDetails();
	            return completeApplicationDto;
	        } catch (Exception e) {
	            log.error(
	                    "Exception while downloading filter applications into an Excel file "
	                            + e.getMessage());
	            return null;
	        }
	    }

	public ByteArrayInputStream getCSVLoad(List<FinalAssessedProfileDetails> completeApplicationDtos) {
		   final CSVFormat format =
	                CSVFormat.DEFAULT
	                        .withQuoteMode(QuoteMode.MINIMAL)
	                        .withHeader(
	                                "Application Id",
                                    "jobId",
                                    "uId",
                                    "name",
                                    "email",
                                    "contact",
                                    "resumeLink",
                                    "status",
                                    "lastUpdated",
                                    "expectedSkills",
                                    "actualSkills",
                                    "skillScore",
                                    "expectedYoe",
                                    "actualYoe",
                                    "yoeScore",
                                    "isDecidingQuestionScore",
                                    "customQuestionMap"
	                        );

		    try (ByteArrayOutputStream out = new ByteArrayOutputStream();
	                CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format); ) {
		    	for (FinalAssessedProfileDetails completeApplication : completeApplicationDtos) {
		    	    List<String> data =
		    	            Arrays.asList(
		    	                    completeApplication.getApplicationId() + "",
		    	                    completeApplication.getJobId() + "",
		    	                    completeApplication.getUId() + "",
		    	                    completeApplication.getName() + "",
		    	                    completeApplication.getEmail() + "",
		    	                    completeApplication.getContact() + "",
		    	                    completeApplication.getResumeLink() + "",
		    	                    completeApplication.getStatus() + "",
		    	                    completeApplication.getLastUpdated().toString() + "",
                                    completeApplication.getExpectedSkills() + "",
                                    completeApplication.getActualSkills() + "",
                                    completeApplication.getSkillScore() + "",
                                    completeApplication.getExpectedYoe() + "",
                                    completeApplication.getActualYoe() + "",
                                    completeApplication.getYoeScore() + "",
                                    completeApplication.getIsDecidingQuestionScore() + "",
                                    completeApplication.getCustomQuestionMap()
		    	            );
		    	    csvPrinter.printRecord(data);
			}
            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
        }

	}

    public Response getApplicationStages(Long applicationId, InternityUser user) {
        try {
            if (applicationId == null) {
                log.warn("Application Id is null or undefined.");
                return responseUtil.badRequestResponse("Application Id cannot be null or undefined");
            }

            Application application = applicationRepository.findById(applicationId).orElse(null);
            if (application == null) {
                log.warn("Application not found with ID: {}", applicationId);
                return responseUtil.badRequestResponse("Application not found");
            }

            ApplicationStages stage = ApplicationStages.fromValue(application.getCurrentStatus());
            if (stage == null) {
                log.warn("Application stage not found for ID: {}", applicationId);
                return responseUtil.badRequestResponse("Application stage not found");
            }

            log.info("Generating application stages for application ID: {}", applicationId);
            return generateStages(stage);

        } catch (Exception e) {
            log.error("Exception while getting application stages for application ID {}: {}", applicationId, e.getMessage());
            return responseUtil.internalServerErrorResponse("Exception while getting application stages");
        }
    }


    public Response updateApplicationStages(Long applicationId, ApplicationUpdateStagesDto payload, InternityUser user) {
        try {
            if (applicationId == null) {
                log.warn("Application Id is null or undefined.");
                return responseUtil.badRequestResponse("Application Id cannot be null or undefined");
            }

            Application application = applicationRepository.findById(applicationId).orElse(null);
            if (application == null) {
                log.warn("Application not found with ID: {}", applicationId);
                return responseUtil.badRequestResponse("Application not found");
            }

            // Validate payload
            Response validationResponse = validatePayload(payload);
            if (validationResponse != null) {
                return validationResponse;
            }

            log.info("Updating application status...");

            application.setCurrentStatus(payload.getNewStatus());
            application.setSubStatus(payload.getNewSubStatus());

            ApplicationTrack appTrack = new ApplicationTrack();
            Optional<ApplicationTrack> appTrackWithStatus = applicationTrackRepository.findByApplicationIdAndStatus(applicationId, payload.getNewStatus());

            appTrackWithStatus.ifPresent(applicationTrack -> appTrack.setApplicationTrackId(applicationTrack.getApplicationTrackId()));

            appTrack.setApplicationId(applicationId);
            appTrack.setFeedback(payload.getFeedback());
            appTrack.setStatus(payload.getNewStatus());

            log.info("Saving new application track entry...");
            applicationTrackRepository.saveAndFlush(appTrack);

            // Update Application entry
            log.info("Saving updated application...");
            Application savedApplication = applicationRepository.saveAndFlush(application);

            // Save Notification for application update
            Optional<Job> jobObj = jobsRepository.findById(application.getJobId());
            Job job = jobObj.get();

            Notification notification = notificationService.setNotificationObj(false, application.getUId(), NotificationType.JOBUPDATE.name(), new Date(), "NA", "Status updated to " + payload.getNewStatus() + " for " + job.getJobTitle());
            notificationRepository.save(notification);

            log.info("Sending mail to user with application update...");
            jobMailToUserWithApplicationUpdate(job, payload.getNewStatus(), payload.getNewSubStatus(), application.getUId());

            log.info("Application status updated successfully.");
            return responseUtil.successResponse(savedApplication);

        } catch (Exception e) {
            log.error("Exception while adding application record in Db: {}", e.getMessage());
            return responseUtil.internalServerErrorResponse("Exception while adding application record in Db");
        }
    }

    public Response updateApplicationStagesInBulk(String applicationIds, ApplicationUpdateStagesDto payload, InternityUser user) {
        try {
            if (StringUtils.isBlank(applicationIds)) {
                log.warn("Application Id is null or undefined.");
                return responseUtil.badRequestResponse("Application Id cannot be null or undefined");
            }

            // Validate payload
            Response validationResponse = validatePayload(payload);
            if (validationResponse != null) {
                return validationResponse;
            }

            StringBuilder successIds = new StringBuilder();
            StringBuilder failedIds = new StringBuilder();
            boolean hasFailed = false;

            for (String appId : applicationIds.split(",")) {
                Response response = updateApplicationStages(Long.parseLong(appId), payload, user);
                if (response.getSuccess()) {
                    successIds.append(appId).append(",");
                } else {
                    failedIds.append(appId).append(",");
                    hasFailed = true;
                }
            }
            // Trim any trailing commas
            if (successIds.length() > 0) {
                successIds.setLength(successIds.length() - 1);
            }
            if (failedIds.length() > 0) {
                failedIds.setLength(failedIds.length() - 1);
            }
            StringBuilder message = new StringBuilder();
            message.append("Ids with status update success: ").append(successIds).append(".");
            if (hasFailed) {
                message.append("\nIds with status update failed: ").append(failedIds).append(".");
            }
            return responseUtil.successResponse(message.toString());
        } catch (Exception e) {
            log.error("Exception while updating applications stages in bulk: {}", e.getMessage());
            return responseUtil.internalServerErrorResponse("Exception while updating applications stages in bulk");
        }
    }

    private Response validatePayload(ApplicationUpdateStagesDto payload) {
        if (StringUtils.isBlank(payload.getNewStatus())) {
            log.warn("Stage is null or undefined.");
            return responseUtil.badRequestResponse("Stage cannot be null or undefined");
        }
        if (ApplicationStages.fromValue(payload.getNewStatus()) == null) {
            log.warn("Undefined value found. please choose Predefined Options for Status");
            return responseUtil.badRequestResponse("Undefined value found. please choose Predefined Options for Status");
        }
        if (payload.getNewStatus().equals("REJECTED") || payload.getNewStatus().equals("INTERVIEW")) {
            if (StringUtils.isBlank(payload.getNewSubStatus())) {
                log.warn("Sub stage is null or undefined.");
                return responseUtil.badRequestResponse("Sub stage cannot be Empty or undefined");
            }
        }
        if (payload.getNewStatus().equals("INTERVIEW")) {
            if (ApplicationInterviewRounds.fromValue(payload.getNewSubStatus()) == null) {
                log.warn("Undefined value found. please choose 'Other' option for Undefined Text");
                return responseUtil.badRequestResponse("Undefined value found. please choose 'Other' option for Undefined Text");
            }
        }
        if (payload.getNewStatus().equals("REJECTED")) {
            if (ApplicationRejectedReasons.fromValue(payload.getNewSubStatus()) == null) {
                log.warn("Undefined value found. please choose 'Other' option for Undefined Text");
                return responseUtil.badRequestResponse("Undefined value found. please choose 'Other' option for Undefined Text");
            }
        }
        if (Objects.equals(payload.getNewSubStatus(), "Other")) {
            if (StringUtils.isBlank(payload.getOtherText())) {
                log.warn("Other text is empty or undefined.");
                return responseUtil.badRequestResponse("Sub stage choose 'Other', Other text cannot be Empty");
            } else {
                payload.setNewSubStatus(payload.getOtherText());
            }
        }
        return null; // No validation error
    }


    public Response getBulkApplicationStages(String stage1, InternityUser user) {
        try {
            if (StringUtils.isBlank(stage1)) {
                log.warn("Stage is null or undefined.");
                return responseUtil.badRequestResponse("Stage cannot be null or undefined");
            }

            ApplicationStages stage = ApplicationStages.fromValue(stage1);
            if (stage == null) {
                log.warn("Application stage not found");
                return responseUtil.badRequestResponse("Application stage not found");
            }

            log.info("Generating application stages");
            return generateStages(stage);

        } catch (Exception e) {
            log.error("Exception while getting application stages {}", e.getMessage());
            return responseUtil.internalServerErrorResponse("Exception while getting application stages");
        }

    }

    private Response generateStages(ApplicationStages currentStage) {
        List<ApplicationStageResponseDto> stagesDto = new ArrayList<>();
        switch (currentStage) {
            case APPLIED:
                log.info("Generating stages for APPLIED application");
                stagesDto.addAll(ApplicationStageResponseDto.generateStagesFromCurrentStage(ApplicationStages.APPLIED));
                break;
            case SCREEN_SELECT:
                log.info("Generating stages for SCREEN_SELECT application");
                stagesDto.addAll(ApplicationStageResponseDto.generateStagesFromCurrentStage(ApplicationStages.SCREEN_SELECT));
                break;
            case INTERVIEW:
                log.info("Generating stages for INTERVIEW application");
                stagesDto.addAll(ApplicationStageResponseDto.generateStagesFromCurrentStage(ApplicationStages.INTERVIEW));
                break;
            case OFFERED:
                log.info("Generating stages for OFFERED application");
                stagesDto.addAll(ApplicationStageResponseDto.generateStagesFromCurrentStage(ApplicationStages.OFFERED));
                break;
            case JOINED:
                log.info("Generating stages for JOINED application");
                stagesDto.addAll(ApplicationStageResponseDto.generateStagesFromCurrentStage(ApplicationStages.JOINED));
                break;
            case REJECTED:
                log.info("Generating stages for REJECTED application");
                return responseUtil.badRequestResponse("The Application is Already Rejected, Cannot Update Status.");
            default:
                log.warn("Invalid Application stage");
                responseUtil.badRequestResponse("Invalid Application stage");
        }

        log.info("Application stages generated successfully");
        return responseUtil.successResponse(stagesDto);
    }

}







