package com.wue.service.drill;


import com.wue.domain.drill.*;
import com.wue.dto.drill.DrillLeaderboardByDrillResponseDto;
import com.wue.dto.drill.DrillLeaderboardRequestDto;
import com.wue.dto.drill.DrillLeaderboardResponseDto;
import com.wue.dto.response.Response;
import com.wue.repository.UserProfileRepository;
import com.wue.repository.drill.*;
import com.wue.repository.drill.submission.DrillParticipantSubmissionRepository;
import com.wue.util.InternityUser;
import com.wue.util.drill.*;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;


import java.util.*;
import java.util.stream.Collectors;

@Service
@Log4j2
public class DrillLeaderboardService {

    @Autowired
    ResponseUtil responseUtil;

    @Autowired
    DrillLeaderboardRepository drillLeaderboardRepository;

    @Autowired
    DrillValidationUtils drillValidationUtils;

    @Autowired
    DrillPhasesRepository drillPhasesRepository;

    @Autowired
    RandomStringGeneratorUtil randomStringGeneratorUtil;

    @Autowired
    DrillTeamsRepository drillTeamsRepository;

    @Autowired
    TeamsParticipantsRepository teamsParticipantsRepository;

    @Autowired
    DrillRepository drillRepository;

    @Autowired
    DrillParticipantRepository drillParticipantRepository;

    @Autowired
    UserProfileRepository userProfileRepository;
    @Autowired
    DrillParticipantSubmissionRepository drillParticipantSubmissionRepository;


    public Response createLeaderboard(String drillId, String teamId, String participantId, DrillLeaderboardRequestDto payload, InternityUser user) {

        try {
            log.info("Creating leaderboard - Drill ID ::: {}, Team ID ::: {}, Participant ID ::: {}", drillId, teamId, participantId);
            // Check if Drill ID is blank
            if (StringUtils.isAnyBlank(drillId)) {
                log.warn("Hackathon ID is blank for creating leaderboard - Drill ID ::: {}", drillId);
                return responseUtil.badRequestResponse("Hackathon ID should not be empty or undefined");
            }
            // Check if the drill with the provided ID exists
            Optional<Drill> optionalDrill = drillValidationUtils.isDrillIdValid(drillId);
            if (!optionalDrill.isPresent()) {
                log.warn("Hackathon not found with the specified ID ::: {}", drillId);
                return responseUtil.notFoundResponse("Hackathon not found with the specified ID");
            }

            // Check if Team ID  and Participant ID both are blank
            if (StringUtils.isAnyBlank(teamId) && StringUtils.isAnyBlank(participantId)) {
                log.warn("Team ID and participant ID both both are blank we need any one for creating leaderboard - Team ID ::: {} , participant ID ::: {}", teamId, participantId);
                return responseUtil.badRequestResponse("Team ID and participant ID both should not be empty or undefined");
            }
            // Check if Team ID  and Participant ID both are present
            if (!StringUtils.isAnyBlank(teamId) && !StringUtils.isAnyBlank(participantId)) {
                log.warn("Team ID and participant ID both are not present we need any one for creating leaderboard - Team ID ::: {} , participant ID ::: {}", teamId, participantId);
                return responseUtil.badRequestResponse("Team ID and participant ID both should not be present or defined");
            }

            // Check if the participant with the provided ID exists
            if (!StringUtils.isAnyBlank((participantId))) {
                Optional<DrillParticipant> optionalDrillParticipant = drillValidationUtils.isParticipantIdValid(participantId);
                if (!optionalDrillParticipant.isPresent()) {
                    log.warn("Participant not found with the specified ID ::: {}", participantId);
                    return responseUtil.notFoundResponse("Participant not found with the specified ID");
                }
            }

            // Check if the team with the provided ID exists
            if (!StringUtils.isAnyBlank((teamId))) {
                Optional<DrillTeams> optionalDrillTeams = drillValidationUtils.isTeamIdValid(teamId);
                if (!optionalDrillTeams.isPresent()) {
                    log.warn("Team not found with the specified ID ::: {}", teamId);
                    return responseUtil.notFoundResponse("Team not found with the specified ID");
                }
            }
//           create leaderboard setting values
            DrillLeaderboard newLeaderboard = new DrillLeaderboard();

            newLeaderboard.setDrillId(drillId);
            newLeaderboard.setTeamId(teamId);
            newLeaderboard.setParticipantId(participantId);
            newLeaderboard.setPosition(payload.getPosition());
            newLeaderboard.setProjectShow(payload.isProjectShow());
            newLeaderboard.setPhaseId(payload.getPhaseId());
            newLeaderboard.setWinnerType(payload.getWinnerType());

//           save leaderboard
            newLeaderboard = drillLeaderboardRepository.save(newLeaderboard);
            log.info("Leaderboard created successfully - leaderboard ID ::: {}", newLeaderboard.getLeaderboardId());
            return new Response(HttpStatus.CREATED.value(), Boolean.TRUE, newLeaderboard, null);

        } catch (Exception e) {
            log.error("Exception while saving Leaderboard ::: {}", e);
            return responseUtil.internalServerErrorResponse("Error Creating Leaderboard +"
                    + "Apologies for inconvenience, please try after sometime.");

        }
    }

    public Response updateLeaderboardDetails(String leaderboardId, DrillLeaderboardRequestDto payload, InternityUser user) {
        try {
            log.info("Updating leaderboard - leaderboard ID ::: {}", leaderboardId);

            // Check if leaderboard ID is blank
            if (StringUtils.isAnyBlank(leaderboardId)) {
                log.warn("Leaderboard ID is blank for updating leaderboard - leaderboard ID ::: {}", leaderboardId);
                return responseUtil.badRequestResponse("Leaderboard ID should not be empty or undefined");
            }

            // Check if the leaderboard with the provided ID exists
            Optional<DrillLeaderboard> optionalDrillLeaderboard = drillLeaderboardRepository.findById(leaderboardId);
            if (!optionalDrillLeaderboard.isPresent()) {
                log.warn("Leaderboard not found with the specified ID ::: {}", leaderboardId);
                return responseUtil.notFoundResponse("Leaderboard not found with the specified ID");
            }

            // Update the leaderboard
            DrillLeaderboard leaderboard = optionalDrillLeaderboard.get();

            if (payload.getPosition() != null && StringUtils.isAnyBlank(payload.getPosition())) {
                leaderboard.setPosition(payload.getPosition());
            }
            if (payload.getWinnerType() != null) {
                leaderboard.setWinnerType(payload.getWinnerType());
            }
            leaderboard.setProjectShow(payload.isProjectShow());

//            saving updated leaderboard
            leaderboard = drillLeaderboardRepository.saveAndFlush(leaderboard);
            log.info("Leaderboard updated successfully - leaderboard ID ::: {}", leaderboard.getLeaderboardId());
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, leaderboard, null);

        } catch (Exception e) {
            log.error("Exception while updating leaderboard ::: {}", e);
            return responseUtil.internalServerErrorResponse("Error Updating Leaderboard "
                    + "Apologies for inconvenience, please try after sometime.");
        }
    }

    public Response updateLeaderboardPositions(Map<String, String> leaderboardIdsAndPositions, InternityUser user) {

        try {
            log.info("Updating leaderboard positions - leaderboard IDs ::: {}", leaderboardIdsAndPositions);
            if (leaderboardIdsAndPositions.isEmpty()) {
                log.warn("Leaderboard IDs and positions are empty");
                return responseUtil.badRequestResponse("Leaderboard IDs and positions should not be empty or undefined");
            }

            List<DrillLeaderboard> responseList = new ArrayList<>();
            // set position of all the leaderboards Ids
            for (Map.Entry<String, String> entry : leaderboardIdsAndPositions.entrySet()) {
                String leaderboardId = entry.getKey();
                String position = entry.getValue();

                // checking leaderboard id if present update leaderboard position
                if (drillLeaderboardRepository.existsById(leaderboardId)) {
                    if (!StringUtils.isAnyBlank(position)) {
                        DrillLeaderboard leaderboard = drillLeaderboardRepository.findById(leaderboardId).get();
                        leaderboard.setPosition(position);
                        leaderboard = drillLeaderboardRepository.saveAndFlush(leaderboard);
                        responseList.add(leaderboard);
                        log.info("Position updated for leaderboard ID {} - New position: {}", leaderboardId, position);
                    } else {
                        log.warn("Position is blank for leaderboard ID {} ", leaderboardId);
                    }

                } else {
                    log.warn("Leaderboard not found with the specified ID ::: {}", leaderboardId);
                }

            }
            if (responseList.isEmpty()) {
                log.warn("Leaderboard not found with the specified IDs ::: {}", leaderboardIdsAndPositions);
                return responseUtil.notFoundResponse("Leaderboard not found with the any of the specified IDs");
            }
            // get updated leaderboard positions
            log.info("Leaderboard positions updated successfully - leaderboards ::: {}", responseList);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, responseList, null);

        } catch (Exception e) {
            log.error("Exception while updating leaderboard positions ::: {}", e);
            return responseUtil.internalServerErrorResponse("Error Updating Leaderboard positions "
                    + "Apologies for inconvenience, please try after sometime.");
        }
    }

    public Response getAllLeaderboardDetails(InternityUser user, String drillId, String phaseId) {

        // leaderboardId is present fetch that data otherwise fetch all data
        try {
            if (StringUtils.isAnyBlank(drillId)) {
                return responseUtil.badRequestResponse("Drill ID should not be empty or undefined");
            }
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (!drillObj.isPresent()) {
                return responseUtil.notFoundResponse("Drill not found with the specified ID");
            }

            if (StringUtils.isAnyBlank(phaseId)) {
                return responseUtil.badRequestResponse("Phase ID should not be empty or undefined");
            }

            Optional<DrillPhases> phaseObj = drillPhasesRepository.findById(phaseId);
            if (!phaseObj.isPresent()) {
                return responseUtil.notFoundResponse("Phase not found with the specified ID");
            }
            List<DrillLeaderboardResponseDto> responseList = new ArrayList<>();

            List<DrillLeaderboard> leaderboardList = drillLeaderboardRepository.findAllByDrillIdAndPhaseId(drillId, phaseId);
            for (DrillLeaderboard leaderboard : leaderboardList) {
                DrillLeaderboardResponseDto leaderboardResponseDto = drillLeaderboardResponseHelper(leaderboard);
                responseList.add(leaderboardResponseDto);
            }
            if (responseList.isEmpty()) {
                log.warn("Leaderboard details not found for this drill/phases");
                return responseUtil.notFoundResponse("Leaderboard details not found for this drill/phases");
            }
            // Sort the list based on the position field
            responseList.sort((o1, o2) -> {
                // Parse the position strings into appropriate types for comparison
                // Here, we assume the position strings represent integers
                double position1 = Double.parseDouble(o1.getPosition());
                double position2 = Double.parseDouble(o2.getPosition());

                // Compare the parsed position values
                return Double.compare(position1, position2);
            });

            log.info("All Leaderboard details fetched successfully - leaderboards ::: {}", responseList);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, responseList, null);

        } catch (Exception e) {
            log.error("Exception while fetching leaderboard details ::: {}", e);
            return responseUtil.internalServerErrorResponse("Error fetching leaderboard details "
                    + "Apologies for inconvenience, please try after sometime.");
        }
    }

    public Response getLeaderboardDetailsById(String leaderboardId, InternityUser user) {

        if (StringUtils.isAnyBlank(leaderboardId)) {
            return responseUtil.badRequestResponse("Leaderboard ID should not be empty or undefined");
        }
        Optional<DrillLeaderboard> leaderboardObj = drillLeaderboardRepository.findById(leaderboardId);
        return leaderboardObj.map(drillLeaderboard -> new Response(HttpStatus.OK.value(), Boolean.TRUE, drillLeaderboardResponseHelper(drillLeaderboard), null)).orElseGet(() -> responseUtil.notFoundResponse("Leaderboard not found with the specified ID"));

    }

    // helper methods for setting the output of the leaderboard
    private DrillLeaderboardResponseDto drillLeaderboardResponseHelper(DrillLeaderboard leaderboard) {

        // setting the output of the leaderboard
        DrillLeaderboardResponseDto drillLeaderboardResponseDto = new DrillLeaderboardResponseDto();

        drillLeaderboardResponseDto.setLeaderboardId(leaderboard.getLeaderboardId());
        drillLeaderboardResponseDto.setDrillId(leaderboard.getDrillId());
        drillLeaderboardResponseDto.setPhaseId(leaderboard.getPhaseId());
        List<DrillParticipant> drillParticipants = new ArrayList<>();
        if (leaderboard.getTeamId() != null) {
            drillLeaderboardResponseDto.setTeamInfoDetails(drillTeamsRepository.findById(leaderboard.getTeamId()).get());
            List<TeamsParticipants> teamsParticipantsList = teamsParticipantsRepository.findByDrillIdAndTeamId(leaderboard.getDrillId(), leaderboard.getTeamId());

            if (!teamsParticipantsList.isEmpty()) {
                for (TeamsParticipants teamsParticipants : teamsParticipantsList) {
                    Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(teamsParticipants.getParticipantId());
                    drillParticipantOptional.ifPresent(drillParticipants::add);
                }
            }
        } else if (leaderboard.getParticipantId() != null) {
            Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(leaderboard.getParticipantId());
            drillParticipantOptional.ifPresent(drillParticipants::add);
        }

        drillLeaderboardResponseDto.setParticipantInfoDetails(drillParticipants);
        drillLeaderboardResponseDto.setPosition(leaderboard.getPosition());
        drillLeaderboardResponseDto.setProjectShow(leaderboard.isProjectShow());
        drillLeaderboardResponseDto.setWinnerType(leaderboard.getWinnerType());
        drillLeaderboardResponseDto.setAverageMarks(leaderboard.getAverageMarks());
        drillLeaderboardResponseDto.setSubmissionInfoDetails(drillParticipantSubmissionRepository.findById(leaderboard.getSubmissionId()).get());
        return drillLeaderboardResponseDto;

    }


    public Response getLeaderboardByDrill(String drillId, InternityUser user) {

        if (StringUtils.isAnyBlank(drillId)) {
            return responseUtil.badRequestResponse("Drill ID should not be empty or undefined");
        }
        Optional<Drill> drill = drillRepository.findById(drillId);
        if (!drill.isPresent()) {
            return responseUtil.notFoundResponse("Drill not found with the specified ID");
        }

        List<DrillLeaderboard> leaderboardList = drillLeaderboardRepository.findAllByDrillId(drillId);
        if (leaderboardList.isEmpty()) {
            log.warn("Leaderboard details not found for this drill");
            return responseUtil.notFoundResponse("Leaderboard details not found for this drill");
        }

        Map<String, DrillLeaderboardByDrillResponseDto> dataMap = new HashMap<>();

        // Iterate through the leaderboardList to combine data for each team
        for (DrillLeaderboard leaderboard : leaderboardList) {
            String id = leaderboard.getTeamId();

            // If the team ID is null, use the participant ID
            if (id == null) {
                id = leaderboard.getParticipantId();
            }

            // If the team/participant is not in the map, create a new entry
            if (!dataMap.containsKey(id)) {
                DrillLeaderboardByDrillResponseDto combinedList = new DrillLeaderboardByDrillResponseDto();
                List<DrillParticipant> drillParticipants = new ArrayList<>();
                if (leaderboard.getTeamId() != null) {
                    Optional<DrillTeams> team = drillTeamsRepository.findById(leaderboard.getTeamId());
                    if(team.isPresent()) {
                        combinedList.setTeamDetails(team.get());
                        List<TeamsParticipants> teamsParticipantsList = teamsParticipantsRepository.findByDrillIdAndTeamId(leaderboard.getDrillId(), leaderboard.getTeamId());
                        if (!teamsParticipantsList.isEmpty()) {
                            for (TeamsParticipants teamsParticipants : teamsParticipantsList) {
                                Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(teamsParticipants.getParticipantId());
                                drillParticipantOptional.ifPresent(drillParticipants::add);
                            }
                        }
                    }
                } else if (leaderboard.getParticipantId() != null) {
                    Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(leaderboard.getParticipantId());
                    drillParticipantOptional.ifPresent(drillParticipants::add);
                }
                combinedList.setParticipantDetailsList(drillParticipants);
                dataMap.put(id, combinedList);
            }
            // Add total marks to the combined data for the team
            dataMap.get(id).setTotalAverageMarks(
                    dataMap.get(id).getTotalAverageMarks() + Double.parseDouble(leaderboard.getAverageMarks())
            );
        }
        if (dataMap.isEmpty()) {
            log.warn("Leaderboard details not found for this drill");
            return responseUtil.notFoundResponse("Leaderboard details not found for this drill");
        }
        // Sort the list based on total marks (average marks)
        List<DrillLeaderboardByDrillResponseDto> sortedLeaderboardList = dataMap.values().stream()
                .sorted(Comparator.comparing(DrillLeaderboardByDrillResponseDto::getTotalAverageMarks).reversed())
                .collect(Collectors.toList());

        // Set positions according to the sorted order
        for (int i = 0; i < sortedLeaderboardList.size(); i++) {
            sortedLeaderboardList.get(i).setPosition(i + 1);
        }

        log.info("All Leaderboard details fetched successfully - leaderboards ::: {}", leaderboardList);
        return new Response(HttpStatus.OK.value(), Boolean.TRUE, sortedLeaderboardList, null);

    }
}
