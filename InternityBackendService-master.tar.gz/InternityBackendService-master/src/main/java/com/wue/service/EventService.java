package com.wue.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wue.constant.CommonConstants;
import com.wue.constant.EventAction;
import com.wue.domain.Event;
import com.wue.dto.EventDto;
import com.wue.repository.EventRepository;
import com.wue.util.InternityUser;

@Service
public class EventService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    EventRepository eventRepository;

    public int addEvent(EventDto eventDto, InternityUser user){
        try {
            Event event = eventRepository.save(modelMapper.map(eventDto, Event.class));
            return event.getEventId();
        }
        catch (Exception e){
            System.out.println(e);
            throw new RuntimeException("Failed to add the event");
        }
    }

    public String addOrUpdateEvent(List<EventDto> eventDto, InternityUser user){
        try {
            List<Event> eventList = new ArrayList<>();
            for (EventDto event : eventDto) {
                eventList.add(modelMapper.map(event, Event.class));
            }
            eventRepository.saveAll(eventList);
            return CommonConstants.SUCCESS;
        }
        catch (Exception e){
            return CommonConstants.FAILED;
        }
    }
    public String actionOnEvent(List<EventDto> eventDto, EventAction action, InternityUser user){
        try {
            List<Event> eventList = new ArrayList<>();
            for (EventDto event : eventDto) {
                Event eventObj = modelMapper.map(event, Event.class);
                eventObj.setStatus(action.toString());
                eventList.add(eventObj);
            }
            eventRepository.saveAll(eventList);
            return CommonConstants.SUCCESS;
        }
        catch (Exception e){
            return CommonConstants.FAILED;
        }
    }
    public String deleteEvent(List<EventDto> eventDto, InternityUser user){
        try {
            List<Event> eventList = new ArrayList<>();
            for (EventDto event : eventDto) {
                eventList.add(modelMapper.map(event, Event.class));
            }
            eventRepository.deleteAll(eventList);
            return CommonConstants.SUCCESS;
        }
        catch (Exception e){
            return CommonConstants.FAILED;
        }
    }
    public List<Event> fetchAllEvent(int eventId, InternityUser user){
        try {
            if(eventId < 0) {
                return eventRepository.findAll();
            }
            else{
                List<Event> eventList = new ArrayList<>();
                eventList.add(eventRepository.findById(eventId).get());
                return eventList;
            }
        }
        catch (Exception e){
            throw new RuntimeException("Failed to fetch the events");
        }
    }
}
