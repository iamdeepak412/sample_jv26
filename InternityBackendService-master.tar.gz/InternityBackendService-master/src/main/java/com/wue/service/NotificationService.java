package com.wue.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.domain.*;
import com.wue.dto.*;
import com.wue.model.EmailContent;
import com.wue.repository.*;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Log4j2
public class NotificationService {

    @Autowired
    CommonUtils utils;

    @Autowired
    NotificationRepository notificationRepository;
    
    @Autowired
    BotMessagesRepository botMessagesRepository;
    
    @Value("${chatbot.message.url:http://127.0.0.1:5069}")
    private String chatbotUrl;

    @Autowired
    UserManagementService userManagementService;

    @Value("${bulk.mail.url:https://mail.whereuelevate.coms}")
    private String bulkMailUrl;

    @Autowired
    PartnerRepository partnerRepository;

    public ResponseEntity<String> save(Notification obj, InternityUser user) {
        try {
            notificationRepository.save(obj);
            return new ResponseEntity<>("{\"msg\":\""+utils.message(HttpStatus.OK, "")+"\"}", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("{\"Error\":\""+utils.message(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage())+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public Notification setNotificationObj(boolean isRead, String receiverUid, String notificationType
            , Date notificationCreatedTs, String message, String oneLiner) {
        Notification notification = new Notification();
        notification.setRead(isRead);
        notification.setReceiverUid(receiverUid);
        notification.setNotificationType(notificationType);
        notification.setCreatedts(notificationCreatedTs);
        notification.setMessage(message);
        notification.setOneLiner(oneLiner);
        return notification;
    }

    public ResponseEntity<?> getNotificationList(String receiverUid, InternityUser user) {
        try {
            ObjectMapper obj = new ObjectMapper();
            int unreadMsg = 0;
            List<Notification> notificationList = notificationRepository.findByReceiverUid(receiverUid);
            List<NotificationDto> notificationDtos = new ArrayList<>();
            for (int i = 0; i < notificationList.size(); i++) {
                Notification notification = notificationList.get(i);

                if(!notification.isRead()){
                    unreadMsg++;
                }

                NotificationDto dtoObj = new NotificationDto();
                dtoObj.setOneLiner(notification.getOneLiner());
                dtoObj.setReceiverUid(notification.getReceiverUid());
                dtoObj.setRead(notification.isRead());
                dtoObj.setUpdatedBy(notification.getUpdatedby());
                dtoObj.setUpdatedTs(notification.getUpdatedts());
                dtoObj.setMessage(notification.getMessage());
                dtoObj.setNotificationType(notification.getNotificationType());
                notificationDtos.add(dtoObj);
            }

            Map<String, Object> response = new HashMap<>();
            response.put("count", unreadMsg);
            response.put("data",notificationDtos);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("{\"msg\":\""+utils.message(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage())+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> updateNotificationBody(String action, Notification notificationObj, InternityUser user) {
        try {
            if (action.equals("READALL")) {
                if (!StringUtils.isEmpty(notificationObj.getReceiverUid())) {
                    List<Notification> notificationList = notificationRepository
                            .findByReceiverUidAndUnread(notificationObj.getReceiverUid());
                    List<Notification> newNotificationList = new ArrayList<>();
                    if (!notificationList.isEmpty()) {
                        for (Notification notification : notificationList) {
                            notification.setRead(true);
                            newNotificationList.add(notification);
                        }
                    }
                    notificationRepository.saveAll(newNotificationList);
                }
            } else if (action.equals("READONE")) {
                if (!StringUtils.isEmpty(notificationObj.getNotificationId())) {
                    Optional<Notification> notification = notificationRepository.findById(notificationObj.getNotificationId());
                    if (notification.isPresent()) {
						Notification newNotification = notification.get();
                        newNotification.setRead(true);
                        notificationRepository.save(newNotification);
                    }
                }
            }
            return new ResponseEntity<>(utils.message(HttpStatus.OK, "All notifications read successfully"), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while updating notification read status {} ::: {}", notificationObj, e);
            return new ResponseEntity<>(utils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to mark notification as read"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> getNotificationWithFilter(String messageType, InternityUser user) {
        List<Notification> notificationList = notificationRepository.findBynotificationType(messageType);
        return new ResponseEntity<>(notificationList, HttpStatus.OK);
    }
    public ResponseEntity<String> saveBotMessages(BotMessages payload, InternityUser user) {
        try {
            botMessagesRepository.save(payload);
            return new ResponseEntity<>("{\"msg\":\"" + utils.message(HttpStatus.OK, "") + "\"}", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error occurred while saving bot messages: {}", e.getMessage());
            return new ResponseEntity<>("{\"Error\":\"" + utils.message(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage()) + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    public Map<String, List<Map<String, String>>> fetchSavedBotMessages(String startDate, String endDate,
            String platform, InternityUser user) {
        Map<String, List<Map<String, String>>> responseMap = new HashMap<>();

        try {
            List<BotMessages> botMessages;

            LocalDateTime startDt = startDate.equalsIgnoreCase("NA") ? null : parseLocalDateTime(startDate + "T00:00:00");
            LocalDateTime endDt = endDate.equalsIgnoreCase("NA") ? null : parseLocalDateTime(endDate + "T23:59:59");

            if (platform != null && startDt == null && endDt == null) {
                if (platform.equalsIgnoreCase("NA")) {
                    botMessages = botMessagesRepository.findAll();
                    platform = "All platforms";
                } else {
                    botMessages = botMessagesRepository.findByPlatform(platform);
                }
            } else if (startDt != null && endDt != null) {
                if (platform.equalsIgnoreCase("NA")) {
                    botMessages = botMessagesRepository.findAll().stream()
                            .filter(botMessage -> botMessage.getRecordCreatedTs().toLocalDate().isEqual(startDt.toLocalDate())
                                    || botMessage.getRecordCreatedTs().toLocalDate().isEqual(endDt.toLocalDate())
                                    || (botMessage.getRecordCreatedTs().toLocalDate().isAfter(startDt.toLocalDate())
                                            && botMessage.getRecordCreatedTs().toLocalDate().isBefore(endDt.toLocalDate())))
                            .collect(Collectors.toList());
                    platform = "All platforms";
                } else {
                    botMessages = botMessagesRepository.findByPlatform(platform).stream()
                            .filter(botMessage -> botMessage.getRecordCreatedTs().toLocalDate().isEqual(startDt.toLocalDate())
                                    || botMessage.getRecordCreatedTs().toLocalDate().isEqual(endDt.toLocalDate())
                                    || (botMessage.getRecordCreatedTs().toLocalDate().isAfter(startDt.toLocalDate())
                                            && botMessage.getRecordCreatedTs().toLocalDate().isBefore(endDt.toLocalDate())))
                            .collect(Collectors.toList());
                }
            } else {
                log.error("Both startDt and endDt must be provided");
                return responseMap;
            }

            List<Map<String, String>> botMessageList = botMessages.stream()
                    .map(this::convertToBotMessageMap)
                    .collect(Collectors.toList());

            responseMap.put(platform, botMessageList);
        } catch (Exception e) {
            log.error("Error occurred while fetching bot messages: {}", e.getMessage());
        }

        return responseMap;
    }


    private LocalDateTime parseLocalDateTime(String dateTimeStr) {
        if (dateTimeStr == null || dateTimeStr.isEmpty()) {
            return null;
        }

        LocalDateTime dateTime = null;
        DateTimeFormatter[] formatters = {
                DateTimeFormatter.ISO_LOCAL_DATE_TIME,
                DateTimeFormatter.ISO_OFFSET_DATE_TIME,
                DateTimeFormatter.ISO_DATE_TIME,
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
                DateTimeFormatter.ofPattern("yyyy-MM-dd"),
                DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"),
                DateTimeFormatter.ofPattern("dd-MM-yyyy"),
                DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss"),
                DateTimeFormatter.ofPattern("MM/dd/yyyy")
        };

        for (DateTimeFormatter formatter : formatters) {
            try {
                dateTime = LocalDateTime.parse(dateTimeStr, formatter);
                break;
            } catch (Exception e) {
                // Continue to the next formatter
            }
        }

        return dateTime;
    }


    private Map<String, String> convertToBotMessageMap(BotMessages botMessage) {
        Map<String, String> messageMap = new HashMap<>();
        messageMap.put("channelId", botMessage.getChannelId());
        messageMap.put("message", botMessage.getMessage());
        messageMap.put("messageDt", botMessage.getRecordCreatedTs().toString());
        return messageMap;
    }

    public ResponseEntity<?> sendNotificationMessage(Map<String, Object> requestBody, String platform) {
        Optional<BotMessagesRepository> botMessageObj = botMessagesRepository.findByPlatformAndEntityId(platform, "WUE");
        String apiUrl = chatbotUrl+"/api/v1/notifications/" + platform;

        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(requestBody, headers);

        try {
        	ResponseEntity<String> response = restTemplate.exchange(apiUrl, HttpMethod.POST, httpEntity, String.class);
            return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to send message: {}", e.getMessage());
            return new ResponseEntity<>(utils.message(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    @Autowired
    CommonUtils commonUtils;

    public ResponseEntity<?> sendBulkMailToAll(String partnerId, String type, EmailContent emailContent, InternityUser user) {
        try {
            if(emailContent.getTo().split(",").length>5000){
                return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                        "Please send a maximum of 5000 emails in one go"), HttpStatus.INTERNAL_SERVER_ERROR);
            }

            if(!partnerId.equals("NA")){
                Optional<Partner> partnerObj = partnerRepository.findById(partnerId);
                if(partnerObj.isPresent()){
                    Partner partner = partnerObj.get();
                    Map<String, String> partnerObjMap = new HashMap<>();
                    partnerObjMap.put("from", partner.getMailEmail());
                    partnerObjMap.put("displayName", partner.getMailDisplayName());
                    partnerObjMap.put("customerName", partner.getPartnerName());
                    partnerObjMap.put("customerLogo", partner.getPartnerLogoPath());
                    partnerObjMap.put("socialLinks", partner.getPartnerSocialLinks());
                    partnerObjMap.put("partnerId", partner.getPartnerId());
                    emailContent.setCustomerDetails(partnerObjMap);
                }
            }
            String apiUrl = bulkMailUrl + "/wuelev8/api/v1/mails/bulk?uId=NA";
            List<String> emailsList = userManagementService.getEmailAndPhoneOfUsers(type);
            RestTemplate restTemplate = new RestTemplate();

            if (type.equalsIgnoreCase("NA")) {
                try{
                    ResponseEntity<?> response = restTemplate.postForEntity(apiUrl, emailContent, Boolean.class);
                    return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
                }
                catch (Exception e){
                    log.error("Exception while connecting Mail server ::: {}", e);
                    return new ResponseEntity<>(utils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                            "Issue connecting mail server. Please connect Administrator."), HttpStatus.INTERNAL_SERVER_ERROR);
                }
            } else {
                if (emailsList.isEmpty()) {
                    ResponseEntity<?> response = restTemplate.postForEntity(apiUrl, emailContent, Boolean.class);
                    return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
                } else {
                    String emailsAsString = String.join(",", emailsList);
                    emailContent.setTo(emailsAsString);
                    ResponseEntity<?> response = restTemplate.postForEntity(apiUrl, emailContent, Boolean.class);
                    return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
                }
            }
        } catch (Exception e) {
            log.error("Error occurred while sending bulk mail to all: {}", e.getMessage());
            return new ResponseEntity<>(utils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Error occurred while sending bulk mail to all"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
