package com.wue.service;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.wue.dto.ApplicationDto;
import com.wue.dto.response.Response;
import com.wue.util.S3ZipFileExtractor;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.*;

@Service
@Log4j2
public class BulkApplicationService {

    @Autowired
    S3ZipFileExtractor s3ZipFileExtractor;

    @Autowired
    ApplicationService applicationService;

    @Autowired
    JobsService jobsService;

    @Autowired
    UserManagementService userManagementService;

    @Value("${bucket}")
    private String bucket;

    @Value("${ACCESS_KEY}")
    private String aws_access_key;

    @Value("${SECRET_KEY}")
    private String aws_secret_key;

    @Value("${region}")
    private String region;


    public Map<String, String> runExtractorAndApplyOnJob(String zipFileKey, String jobId) throws IOException {
        List<File> listOfResumeFiles = extractZipFileAndReadFiles(zipFileKey);
        List<String> uploadedFileNameList = uploadExtractedFilesToS3(listOfResumeFiles);
        List<ApplicationDto> applicationDtoList = createProfileAfterResumeExtraction(uploadedFileNameList, jobId);

        for (ApplicationDto applicationDto : applicationDtoList) {
            log.info("Adding application for ::: {}", applicationDto);
            applicationService.addApplication(applicationDto, null);
        }

        return Collections.EMPTY_MAP;
    }

    public List<ApplicationDto> createProfileAfterResumeExtraction(List<String> uploadedFileNameList, String jobId) {
        try {
            List<ApplicationDto> applicationDtoList = new ArrayList<>();
            for (String resumeOnS3 : uploadedFileNameList) {
                Map<String, String> resumeMap = new HashMap<>();
                resumeMap.put("jobId", jobId);
                resumeMap.put("resumeLink", resumeOnS3);
                Response response = (Response) userManagementService.parseResumeAndCreateProfile(resumeMap).getBody();
                assert response != null;
                if (response.getSuccess()) {
                    ApplicationDto applicationDto = new ApplicationDto();
                    applicationDto.setJobId(jobId);
                    applicationDto.setUId(response.getResult().toString());
                    applicationDtoList.add(applicationDto);
                }
            }
            return applicationDtoList;
        } catch (Exception e) {
            log.error("Exception while creating profile after resume extraction ::: {}", e);
        }
        return Collections.EMPTY_LIST;
    }

    public List<String> uploadExtractedFilesToS3(List<File> extractedFiles) {
//        String aws_access_key="AKIATBYQQ5LVFFJRE7BH";
//        String aws_secret_key="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";
//        String region="ap-south-1";

        List<String> uploadedFileName = new ArrayList<>();

        AWSCredentials credentials = new BasicAWSCredentials(aws_access_key, aws_secret_key);
        AmazonS3 s3Client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(region)
                .build();

        if (extractedFiles != null) {
            for (File file : extractedFiles) {
                try {
                    // Construct the S3 object key (path within the bucket)
                    String objectKey = "asyncExtractedFiles/" + file.getName(); // Change "your-prefix" as needed

                    // Upload the file to S3
                    //PutObjectResult res = s3Client.putObject(new PutObjectRequest(targetBucketName, objectKey, file));
                    //String s3ObjectUrl = getS3ObjectUrl(targetBucketName, objectKey);
                    PutObjectRequest request = new PutObjectRequest(bucket, objectKey, file).withCannedAcl(CannedAccessControlList.PublicRead);
                    s3Client.putObject(request);
                    URL s3Url = s3Client.getUrl(bucket, objectKey);

                    //System.out.println("Uploaded file: " + res.getMetadata());
                    System.out.println("S3 Object URL: " + s3Url.toExternalForm());
                    uploadedFileName.add(s3Url.toExternalForm());
                } catch (Exception e) {
                    System.out.println("Exception while uploading resume file to s3 ::: {}" + e);
                    continue;
                }
            }
        } else {
            System.err.println("No files found to upload.");
        }

        return uploadedFileName;
    }

    public List<File> extractZipFileAndReadFiles(String zipFileKey)
            throws IOException {
        String localDownloadedFilePath = s3ZipFileExtractor.downloadS3ZipFile(zipFileKey);
        List<File> listOfExtractedFiles = new ArrayList<>();

        File folderToStorePdf = new File(localDownloadedFilePath);
        if (!folderToStorePdf.isDirectory()) {
            folderToStorePdf.mkdir();
        }
        String extractionDirectory = "src/main/resources/files";

        try (ZipFile zipFile = new ZipFile(localDownloadedFilePath)) {
            Enumeration<ZipArchiveEntry> entries = zipFile.getEntries();
            while (entries.hasMoreElements()) {
                ZipArchiveEntry entry = entries.nextElement();
                File entryFile = new File(extractionDirectory, entry.getName());
                if (entry.isDirectory()) {
                    entryFile.mkdirs();
                } else {
                    if (entryFile.getPath().contains("MACOS")) {
                        continue;
                    }
                    try (FileOutputStream fos = new FileOutputStream(entryFile)) {
                        byte[] buffer = new byte[1024];
                        int bytesRead;
                        try (InputStream entryInputStream = zipFile.getInputStream(entry)) {
                            while ((bytesRead = entryInputStream.read(buffer)) != -1) {
                                fos.write(buffer, 0, bytesRead);
                            }
                            listOfExtractedFiles.add(entryFile);
                        }
                    }
                }
            }
            System.out.println(listOfExtractedFiles);
            System.out.println("Files extracted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return listOfExtractedFiles;
    }
}
