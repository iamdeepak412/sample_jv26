package com.wue.service;

import com.wue.constant.*;
import com.wue.constant.job.JobSkillsCategory;
import com.wue.domain.*;
import com.wue.domain.CandidateApplication.JobApplicationScreeningAnswer;
import com.wue.domain.ConfigureJob.JobScreeningQuestion;
import com.wue.dto.response.Response;
import com.wue.repository.*;
import com.wue.repository.CandidateApplication.JobApplicationScreeningAnswerRepository;
import com.wue.repository.ConfigureJob.JobScreeningQuestionRepository;
import com.wue.util.CommonUtils;
import com.wue.util.drill.ResponseUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@Log4j2
public class AssessApplicationService {

    @Autowired
    JobScreeningQuestionRepository jobScreeningQuestionRepository;

    @Autowired
    JobApplicationScreeningAnswerRepository screeningAnswerRepository;

    @Autowired
    UserCandidateMandatoryFieldsRepository mandatoryFieldsRepository;

    @Autowired
    JobsService jobsService;

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    ApplicationRepository applicationRepository;

    @Autowired
    ApplicationTrackRepository applicationTrackRepository;
    @Autowired
    ResponseUtil responseUtil;

    public Response assessApplications(Application application, Job job, String uId, String candidateAnswers){
        try{
            Long applicationId = application.getApplicationId();
            log.info("Start to assess the application ::: {}", applicationId);

            log.info("Get the skills and YoE score for the application ::: {}", applicationId);

            Map<String, Object> matchedSkillsWithPercentage =
                jobsService.getSkillsMatchedPercentageForASingleUser(uId, job);
            if (matchedSkillsWithPercentage == null) {
                return responseUtil.internalServerErrorResponse( "Something went wrong. while getting the skills and YoE score");
            }

            JobApplicationScreeningAnswer answer = saveSkillsAndYoeScore
                    (matchedSkillsWithPercentage, application, job);
            if(answer==null){
                return responseUtil.internalServerErrorResponse( "Something went wrong. while saving the skills and YoE score");
            }
            try{
                if (!StringUtils.isBlank(answer.getAllCustomQueAnswer())) {
                    JobApplicationScreeningAnswer answerObj = setCandidateApplicationAnswers(
                            answer, answer.getAllCustomQueAnswer(), application, job);
                    if (answerObj == null) {
                        return responseUtil.internalServerErrorResponse("Something went wrong. while saving the custom questions");
                    }
                }
                log.info("Assess the screening answers for the job ::: {}", job.getJobId());
                screeningAnswerRepository.save(answer);
            }
            catch (Exception e){
                log.error("Exception while assessing the screening answers for the job ::: {}", e.getMessage());
            }
           String result= assessProfileOnParametersAndSave(
                    job,
                    application,
                    answer.getIsDecidingQuestionScore(),
                    answer.getPrimarySkillsScore(),
                    answer.getTotalYoeScore());
            if (result == null) {
                return responseUtil.internalServerErrorResponse("Something went wrong. while assessing the application");
            }
           return responseUtil.successResponse("Application assessed successfully.");
        }
        catch (Exception e){
            log.error("Exception while assessing the application ::: {}", e.getMessage());
            return responseUtil.internalServerErrorResponse( "Exception while assessing the application");
        }
    }

    private JobApplicationScreeningAnswer saveSkillsAndYoeScore(
            Map<String, Object> matchedSkillsAndTotalYoeWithPercentage,
            Application application,
            Job job) {
        try {
            log.info("Save skills and YoE score ::: {} ::: {}", application.getApplicationId(), matchedSkillsAndTotalYoeWithPercentage);
            JobApplicationScreeningAnswer answerObj;
            Optional<JobApplicationScreeningAnswer> obj = screeningAnswerRepository.findByuIdAndJobId(
                            application.getUId(), job.getJobId());
            answerObj = obj.orElseGet(JobApplicationScreeningAnswer::new);
            Map<String, Object> allAnswers = null;

            Map<String, Object> primarySkillsObj =
                    (Map<String, Object>)
                            matchedSkillsAndTotalYoeWithPercentage.get(
                                    JobSkillsCategory.MANDATORY.name());
            Map<String, Object> totalYoeObj =
                    (Map<String, Object>)
                            matchedSkillsAndTotalYoeWithPercentage.get(CommonConstants.TOTAL_YOE);

            answerObj.setApplicationId(application.getApplicationId());
            answerObj.setSkillsMatching(primarySkillsObj.toString());
            answerObj.setPrimarySkillsScore(
                    primarySkillsObj.get("skillsMatchedFromResume") != null
                            ? Double.parseDouble(
                                    primarySkillsObj.get("skillsMatchedFromResume") + "")
                            : 0.0);
            answerObj.setTotalYoeMatching(totalYoeObj.toString());
            answerObj.setTotalYoeScore(
                    totalYoeObj.get("totalYoeScore") != null
                            ? Double.parseDouble(totalYoeObj.get("totalYoeScore") + "")
                            : 0.0);
            answerObj.setJobId(job.getJobId());
            answerObj.setUId(application.getUId());
            return answerObj;
        } catch (Exception e) {
            log.error("Exception while saving Skills and YoE score, expected and actual ::: {}", e);
            return null;
        }
    }

    private JobApplicationScreeningAnswer setCandidateApplicationAnswers(JobApplicationScreeningAnswer answerObj,
                                                               String customQuestionAnswered,
                                                               Application application, Job job) {
        try{
            log.info("Set candidate application screening answers for application id ::: {} ::: {}",
                    application.getApplicationId(), customQuestionAnswered);
            ;
            Map<String, Object> allAnswers = new HashMap<>(parseAndFetchCustomQuestionAnswers(customQuestionAnswered));
            if (!allAnswers.isEmpty()) {
                answerObj.setAllCustomQueAnswer(allAnswers.get("details").toString());
                answerObj.setIsDecidingQuestionScore(
                        StringUtils.isBlank(allAnswers.get("isDecidingQuestionScore")+"")
                                    ? Double.parseDouble(allAnswers.get("isDecidingQuestionScore") + "")
                                    : 0.0);
            }
            return answerObj;
        }
        catch (Exception e){
            log.error("Exception while saving the job application screening questions answers ::: {}", e);
            return null;
        }
    }

    private String assessProfileOnParametersAndSave(Job job, Application application, Double isDecidingQuestionScore,
                                             Double skillsScore, Double totalYoeScore) {
        try{
            log.info("Assess profile on parameters and save scores ::: {}", application.getApplicationId());
            Double overAllWeightage = 70.0;
            Double skillsWeightage = 20.0;
            Double totalYoeWeightage = 80.0;
            Double customQuestionsWeightage = 0.0;

            List<JobScreeningQuestion> screeningQuestionList = jobScreeningQuestionRepository.findByJobId(job.getJobId());

            if(!screeningQuestionList.isEmpty()){
                skillsWeightage = 20.0;
                totalYoeWeightage = 60.0;
                customQuestionsWeightage = 20.0;
            }

            if(!StringUtils.isBlank(job.getJobCategoryWeightage())){
                JSONObject weightageJson = new JSONObject(job.getJobCategoryWeightage());
                overAllWeightage = Double.parseDouble(weightageJson.get("overAllWeightage")+"");
                skillsWeightage = Double.parseDouble(weightageJson.get("skillsWeightage")+"");
                totalYoeWeightage = Double.parseDouble(weightageJson.get("totalYoeWeightage")+"");
            }

            log.info("Calculating score with ::: skills {} ::: total Yoe score {} ::: is deciding score {}"
                    , skillsScore, totalYoeScore, isDecidingQuestionScore);

            Double finalSkillsWeightage = skillsScore*(skillsWeightage/100);
            Double finalTotalYoeWeightage = totalYoeScore*(totalYoeWeightage/100);
            Double finalCustomQuestionWeightage = 0.0;
            try{
                finalCustomQuestionWeightage = isDecidingQuestionScore*(customQuestionsWeightage/100);
            }
            catch (Exception e){
                finalCustomQuestionWeightage = 0.0;
            }

            Double finalScore = finalSkillsWeightage + finalTotalYoeWeightage + finalCustomQuestionWeightage;
                if (finalScore < overAllWeightage) {
                    log.info("Application is rejected. Final score ::: {} ::: OverAllWeightage {}", finalScore, overAllWeightage);
                    application.setCurrentStatus(ApplicationStatus.APPLIED.getEnumValue());
                    application.setSubStatus(ApplicationRejectSubStatus.AUTO_REJECT.getEnumValue());
                    applicationRepository.saveAndFlush(application);
                    saveApplicationTrack(application);
                } else {
                    log.info("Application is screen select. Final score ::: {} ::: OverAllWeightage {}", finalScore, overAllWeightage);
                    application.setCurrentStatus(ApplicationStatus.APPLIED.getEnumValue());
                    application.setSubStatus(ApplicationScreenselectSubStatus.AUTO_SELECT.getEnumValue());
                    applicationRepository.saveAndFlush(application);
                    saveApplicationTrack(application);
                }
        }
        catch (Exception e){
            log.error("Exception while calculating the final assessment on the application ::: {}", e);
            return null;
        }
        return ApplicationStatus.APPLIED.getEnumValue();
    }

    private Map<String, String> saveApplicationTrack(Application application){
        try{
            ApplicationTrack appTrack = new ApplicationTrack();
            appTrack.setApplicationId(application.getApplicationId());
            appTrack.setFeedback(application.getSubStatus());
            appTrack.setStatus(application.getCurrentStatus());
            appTrack.setSubStatus(application.getSubStatus());
            appTrack.setUpdatedts(new Date());
            applicationTrackRepository.saveAndFlush(appTrack);
            return commonUtils.message(HttpStatus.OK, "Application track saved successfully");
        }
        catch (Exception e){
            log.error("Exception while saving application track ::: {}", e);
        }
        return Collections.emptyMap();
    }

    private Map<String, Object> parseAndFetchCustomQuestionAnswers(String customQuestionAnswered) {
        try{
            log.info("Parse and fetch custom question answers ::: {} ", customQuestionAnswered);
            Map<String, Object> result = new HashMap<>();
            JSONObject answerArr = new JSONObject(customQuestionAnswered);
            System.out.println(answerArr);
            List<Map<String, String>> listOfAssessedQuestions = new ArrayList<>();
            int countOfIsDecidingQuestionsIncorrect = 0;
            int countOfIsDecidingQuestions = 0;
            for (String key : answerArr.keySet()) {
                Map<String, String> questionAssessment = new HashMap<>();
                JSONObject customAnswerJson = new JSONObject(answerArr.get(key).toString());
                Optional<JobScreeningQuestion> questionObj = jobScreeningQuestionRepository.findById(key);
                log.info("key ::: {} ::: {}", key, customAnswerJson.getString("answer"));
                if(questionObj.isPresent()){
                    JobScreeningQuestion question = questionObj.get();
                    String answerType = question.getAnswerType();
                    boolean isAnsweredAsExpected = false;
                    if(answerType.equalsIgnoreCase(CommonConstants.BOOLEAN)){
                        log.info("type {} ::: key ::: {}", answerType, customAnswerJson.getString("answer"));
                        isAnsweredAsExpected = customAnswerJson.getString("answer")
                                .equalsIgnoreCase(question.getExpectedAnswer());
                    }else if(answerType.equalsIgnoreCase(CommonConstants.RANGE)){
                        log.info("type {} ::: key ::: {}", answerType, customAnswerJson.getString("answer"));
                        String[] jobAnswer = question.getExpectedAnswer().split(",");
                        int expectedAnswer = Integer.parseInt(customAnswerJson.getString("answer"));
                        int minAnswer = jobAnswer[0].contains("min")
                                        ? Integer.parseInt((jobAnswer[0].split(":")[1]).trim())
                                        : Integer.parseInt((jobAnswer[1].split(":")[1]).trim());
                        int maxAnswer = jobAnswer[1].contains("max")
                                ? Integer.parseInt((jobAnswer[1].split(":")[1]).trim())
                                : Integer.parseInt((jobAnswer[0].split(":")[1]).trim());
                        isAnsweredAsExpected = (expectedAnswer >= minAnswer) && (expectedAnswer <= maxAnswer);
                    }else if(answerType.equalsIgnoreCase(CommonConstants.NUMERIC)){
                        log.info("type {} ::: key ::: {}", answerType, customAnswerJson.getString("answer"));
                        isAnsweredAsExpected = customAnswerJson.getString("answer")
                                .equalsIgnoreCase(question.getExpectedAnswer());
                    }else if(answerType.equalsIgnoreCase(CommonConstants.SUBJECTIVE)){
                        log.info("type {} ::: key ::: {}", answerType, customAnswerJson.getString("answer"));
                        isAnsweredAsExpected = customAnswerJson.getString("answer")
                                .equalsIgnoreCase(question.getExpectedAnswer());
                    }

                    questionAssessment.put("questionId", question.getQuestionId());
                    questionAssessment.put("question", question.getQuestion());
                    questionAssessment.put("score", isAnsweredAsExpected?"100":"0");
                    questionAssessment.put("answer", customAnswerJson.getString("answer"));
                    questionAssessment.put("expectedAnswer", question.getExpectedAnswer());

                    if(question.isDecidingQuestion()){
                        countOfIsDecidingQuestions++;
                        if(!isAnsweredAsExpected){
                            countOfIsDecidingQuestionsIncorrect++;
                        }
                    }
                    answerArr.put(key, questionAssessment);
                }
            }
            if(countOfIsDecidingQuestions>0){
                double percentageMatch = ((double) (countOfIsDecidingQuestions-countOfIsDecidingQuestionsIncorrect) / (countOfIsDecidingQuestions)) * 100;
                result.put("isDecidingQuestionScore", percentageMatch+"");
            }else {
                result.put("isDecidingQuestionScore", "NA");
            }
            result.put("details", answerArr);
            return result;
        }
        catch (Exception e){
            log.error("Exception while parsing and fetching the custom question answers ::: {}", e);
        }
        return Collections.emptyMap();
    }

}




	
