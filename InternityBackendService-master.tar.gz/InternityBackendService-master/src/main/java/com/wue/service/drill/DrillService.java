package com.wue.service.drill;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.wue.constant.CommonConstants;
import com.wue.constant.UserRoles;
import com.wue.constant.drill.*;
import com.wue.constant.job.DrillRequestStatus;
import com.wue.custom.specification.SearchParticipantCriteria;
import com.wue.domain.CustomerUser;
import com.wue.domain.Partner;
import com.wue.domain.User;
import com.wue.domain.drill.*;
import com.wue.domain.drill.participant.ConfigureParticipantFields;
import com.wue.domain.drill.participant.DefaultParticipantFields;
import com.wue.domain.drill.problemstatement.DrillProblemstatement;
import com.wue.domain.drill.publish.DrillPublishRequests;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.dto.SearchProfiles;
import com.wue.dto.UserDto;
import com.wue.dto.drill.*;
import com.wue.dto.response.Response;
import com.wue.dto.response.ResponseError;
import com.wue.dto.search.DrillParticipantSpecification;
import com.wue.model.EmailContent;
import com.wue.repository.PartnerRepository;
import com.wue.repository.UserRepository;
import com.wue.repository.drill.*;
import com.wue.repository.drill.participant.ConfigureParticipantFieldsRepository;
import com.wue.repository.drill.participant.DefaultParticipantFieldsRepository;
import com.wue.repository.drill.problemstatement.DrillProblemStatementRepository;
import com.wue.repository.drill.publish.DrillPublishRequestsRepository;
import com.wue.repository.drill.submission.DrillParticipantSubmissionRepository;
import com.wue.service.UserManagementService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.OffsetBasedPageRequest;
import com.wue.util.SendMessageUtils;
import com.wue.util.drill.ResponseUtil;
import com.wue.util.drill.SendCustomMailUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


@Service
@Log4j2
public class DrillService {
    private static final ModelMapper modelMapper = new ModelMapper();

    @Autowired
    DrillRepository drillRepository;

    @Autowired
    DrillOverviewRepository drillOverviewRepository;

    @Autowired
    DrillPrizesRepository drillPrizesRepository;

    @Autowired
    DrillThemesRepository drillThemesRepository;

    @Autowired
    DrillCollaboratorsRepository drillCollaboratorsRepository;

    @Autowired
    DrillOpportunitiesRepository drillOpportunitiesRepository;

    @Autowired
    DrillNewFaqRepository drillNewFaqRepository;

    @Autowired
    DrillParticipationFormRepository drillParticipationFormRepository;

    @Autowired
    DrillParticipantRepository drillParticipantRepository;

    @Autowired
    DrillTeamsRepository drillTeamsRepository;

    @Autowired
    DrillJudgingCriteriaRepository drillJudgingCriteriaRepository;

    @Autowired
    DrillEventRepository drillEventRepository;

    @Autowired
    TeamsParticipantsRepository teamsParticipantsRepository;

    @Autowired
    DrillProblemStatementRepository drillProblemStatementRepository;

    @Autowired
    DrillParticipantStateMasterRepository drillParticipantStateMasterRepository;

    @Autowired
    DrillResourcesRepository drillResourcesRepository;

    @Autowired
    DrillPhasesRepository drillPhasesRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    SendMessageUtils messageUtils;

    @Autowired
    SendCustomMailUtils sendCustomMailUtils;

    @Autowired
    PartnerRepository partnerRepository;

    @Autowired
    DrillParticipantSubmissionRepository drillParticipantSubmissionRepository;

    @Autowired
    ConfigureParticipantFieldsRepository configureParticipantFieldsRepository;

    @Autowired
    DefaultParticipantFieldsRepository defaultParticipantFieldsRepository;

    @Autowired
    DrillCustomRepository drillCustomRepository;

    @Value("${domain.url:http://api-dev.whereuelevate.com:8080}")
    String domainUrl;

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    CustomerUserRepository customerUserRepository;

    @Autowired
    DrillPublishRequestsRepository drillPublishRequestsRepository;

    @Autowired
    UserManagementService userManagementService;

    @Autowired
    DrillPaidRepository drillPaidRepository;

    @Autowired
    DrillOrganiserDetailsRepository drillOrganiserDetailsRepository;

    @Autowired
    ResponseUtil responseUtil;

    @Autowired
    DrillParticipantsInviteOnlyRepository drillParticipantsInviteOnlyRepository;
    @Autowired
    DrillParticipantFieldsRepository drillParticipantFieldsRepository;

    @Value("${support.mail.id:techsupport@wuelev8.tech}")
    private String techSupportEmail;

    @Value(
            "#{'${drill.skills:Java,reactJs,Python,NodeJs,Docker,DevOps,Kubernetes,Others}'.trim().split(',')}")
    private List<String> drillCommonSkills;

    @Value(
            "#{'${drill.affiliate.platforms:Facebook, LinkedIn, Where U Elevate, Twitter}'.trim().split(',')}")
    private String drillAffiliatePlatforms;

    public List<Drill> fetchDrills(
            String drillId,
            String runningStatus,
            String type,
            boolean isActive,
            InternityUser user) {
        try {
            List<Drill> listOfDrill = new ArrayList<>();
            if (drillId.equalsIgnoreCase("NA")) {
                listOfDrill.addAll(drillRepository.findByIsActiveTrueOrderByCreatedTsAsc());
            } else if (drillId.equalsIgnoreCase("ALL")) {
                listOfDrill.addAll(drillRepository.findAllByOrderByCreatedTsAsc());
            } else {
                Optional<Drill> drillObj = drillRepository.findById(drillId);
                if (drillObj.isPresent()) {
                    listOfDrill.add(drillObj.get());
                } else return Collections.emptyList();
            }

            return setPartnerWebsiteLink(listOfDrill);
        } catch (Exception e) {
            log.error("Exception while fetching drills {}", e);
            return Collections.emptyList();
        }
    }

    private List<Drill> setPartnerWebsiteLink(List<Drill> listOfDrill) {
        try {
            if (listOfDrill.size() == 1) {
                Optional<Partner> partnerObj = partnerRepository.findById(listOfDrill.get(0).getDrillPartnerId());
                if (partnerObj.isPresent()) {
                    Drill drill = listOfDrill.get(0);
                    Partner partner = partnerObj.get();
                    drill.setDrillPartnerName(StringUtils.isBlank(partner.getPartnerDisplayName())
                            ? partner.getPartnerName() : partner.getPartnerDisplayName());
                    drill.setPartnerWebsiteLink(
                            !StringUtils.isBlank(partner.getPartnerSocialLinks())
                                    ?
                                    getOrganisationWebsiteUrl(partner.getPartnerSocialLinks())
                                    :
                                    "");
                    List<Drill> resultantList = new ArrayList<>();
                    resultantList.add(drill);
                    return resultantList;
                }
            }
            List<Partner> partners = partnerRepository.findAll();
            Map<String, String> mapOfPartnerIdAndWebsiteLink = new HashMap<>();
            Map<String, String> mapOfPartnerIdAndPartnerName = new HashMap<>();

            for (Partner partner : partners) {
                try {
                    if (!StringUtils.isBlank(partner.getPartnerSocialLinks())) {
                        JSONObject partnerSocialLinkJson = new JSONObject(partner.getPartnerSocialLinks());
                        mapOfPartnerIdAndWebsiteLink.put(
                                partner.getPartnerId(),
                                !StringUtils.isBlank(partner.getPartnerSocialLinks())
                                        ?
                                        !partnerSocialLinkJson.isNull("websiteurl")
                                                ?
                                                partnerSocialLinkJson.get("websiteurl")
                                                        + ""
                                                :
                                                ""
                                        : "");
                        mapOfPartnerIdAndPartnerName.put(partner.getPartnerId(),
                                StringUtils.isBlank(partner.getPartnerDisplayName()) ? partner.getPartnerName() : partner.getPartnerDisplayName());
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching website url ::: {}", e.getMessage());
                }
            }

            List<Drill> resultantList = new ArrayList<>();

            for (Drill drill : listOfDrill) {
                drill.setDrillPartnerName(mapOfPartnerIdAndPartnerName.get(drill.getDrillPartnerId()));
                drill.setPartnerWebsiteLink(mapOfPartnerIdAndWebsiteLink.get(drill.getDrillPartnerId()));
                resultantList.add(drill);
            }
            return resultantList;
        } catch (Exception e) {
            log.error("Exception while setting partner website link in list of drill ::: {} ::: error {}", listOfDrill, e);
            return listOfDrill;
        }
    }

    private String getOrganisationWebsiteUrl(String partnerSocialLinks) {
        try {
            if (!StringUtils.isBlank(partnerSocialLinks)) {
                return new JSONObject(partnerSocialLinks).get("websiteurl") + "";
            }
        } catch (Exception e) {
            log.error("Exception while getting organisation website url ::: {}", e);
        }
        return "";
    }

    public List<DrillPhases> validateAndUpdateDrillPhases(String drillId, String phaseStatus) {
        try {
            List<DrillPhases> updatedDrillPhases = new ArrayList<>();
            boolean anyUpdate = false;
            List<DrillPhases> drillPhasesList = new ArrayList<>();
            if ("NA".equals(phaseStatus)) {
                drillPhasesList.addAll(drillPhasesRepository.findByDrillIdOrderByPhaseStartDtAsc(drillId));
            } else {
                drillPhasesList.addAll(
                        drillPhasesRepository.findByDrillIdAndPhaseStatusOrderByPhaseStartDtAsc(
                                drillId, phaseStatus.toUpperCase()));
            }
            for (DrillPhases drillPhase : drillPhasesList) {
                if (drillPhase.getPhaseEndDt().isEqual(LocalDateTime.now())
                        || drillPhase.getPhaseEndDt().isBefore(LocalDateTime.now())) {
                    drillPhase.setPhaseStatus(DrillPhaseStatus.COMPLETE.name());
                    anyUpdate = true;
                }
                if (drillPhase.getPhaseStartDt().isEqual(LocalDateTime.now())
                        || (drillPhase.getPhaseStartDt().isBefore(LocalDateTime.now())
                        && drillPhase.getPhaseEndDt().isAfter(LocalDateTime.now()))) {
                    drillPhase.setPhaseStatus(DrillPhaseStatus.RUNNING.name());
                    anyUpdate = true;
                }
                if (drillPhase.getPhaseStartDt().isAfter(LocalDateTime.now())
                        && drillPhase.getPhaseEndDt().isAfter(LocalDateTime.now())) {
                    drillPhase.setPhaseStatus(DrillPhaseStatus.TOBEGIN.name());
                    anyUpdate = true;
                }
                updatedDrillPhases.add(drillPhase);
            }
            if (anyUpdate) {
                return drillPhasesRepository.saveAll(updatedDrillPhases);
            } else {
                return updatedDrillPhases;
            }
        } catch (Exception e) {
            log.error("Exception while validating and updating drill phases {}", e);
        }
        return Collections.EMPTY_LIST;
    }

    public Object fetchDrillSection(
            String drillId, DrillSectionEnum section, String participantId, InternityUser user, String phaseId) {
        List result = new ArrayList();
        switch (section.getValue()) {
            case "overview":
                result.add(drillOverviewRepository.findById(drillId).get());
                break;
            case "prizes":
                result.addAll(drillPrizesRepository.findByDrillIdOrderByPositionOrder(drillId));
                break;
            case "themes":
                result.addAll(drillThemesRepository.findByDrillId(drillId));
                break;
            case "opportunities":
                result.addAll(drillOpportunitiesRepository.findByDrillId(drillId));
                break;
            case "collaborators":
                result.addAll(
                        drillCollaboratorsRepository.findByDrillIdOrderByPositionOrder(drillId));
                break;
            case "faq":
                result.add(fetchFaqOfDrill(drillId));
                break;
            case "judgingcriteria":
                if (phaseId == null || StringUtils.isAnyBlank(phaseId)) {
                    result.add(drillJudgingCriteriaRepository.findByDrillId(drillId));
                } else {
                    result.add(drillJudgingCriteriaRepository.findByDrillIdAndPhaseId(drillId, phaseId));
                }
                break;
            case "events":
                result.add(drillEventRepository.findByDrillId(drillId));
                break;
            case "problemstatement":
                result.add(getProblemStatement(drillId, participantId));
                break;
            case "resources":
                result.add(drillResourcesRepository.findByDrillId(drillId));
                break;
            case "phases":
                result.addAll(drillPhasesRepository.findByDrillIdOrderByPhaseStartDtDesc(drillId));
                break;
            case "organiserdetails":
                result.addAll(drillOrganiserDetailsRepository.findByDrillId(drillId));
                break;
            case "custom":
                result.addAll(drillCustomRepository.findByDrillId(drillId));
                break;
        }
        return result;
    }

    private Object fetchFaqOfDrill(String drillId) {
        try {
            List<DrillNewFaq> drillNewFaqList = drillNewFaqRepository.findByDrillId(drillId);
            if (drillNewFaqList.isEmpty()) {
                return createDefaultFaq(drillId);
            }
            return drillNewFaqList;
        } catch (Exception e) {
            log.error("Exception while fetching the FAQs ::: {}", e);
        }
        return Collections.EMPTY_LIST;
    }

    private List<DrillNewFaq> createDefaultFaq(String drillId) {
        try {
            List<DrillNewFaq> drillNewFaqList = new ArrayList<>();
            DrillNewFaq drillNewFaq = new DrillNewFaq();
            drillNewFaq.setQuestion("How do participants register for the hackathon?");
            drillNewFaq.setAnswer("Participants must register on the Where U Elevate platform " +
                    "and participate to join the hackathon.");
            drillNewFaqRepository.save(drillNewFaq);
            drillNewFaqList.add(drillNewFaq);
            return drillNewFaqList;
        } catch (Exception e) {
            log.error("Exception while creating default FAQs ::: {}", e);
        }
        return Collections.EMPTY_LIST;
    }

    private Object getProblemStatement(String drillId, String participantId) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {
                if (drillObj.get()
                        .getDrillStartDt()
                        .minus(390, ChronoUnit.MINUTES)
                        .isAfter(LocalDateTime.now())) {
                    return commonUtils.message(
                            HttpStatus.INTERNAL_SERVER_ERROR,
                            "This page will be live as the hackathon starts");
                }
            }
            Optional<DrillProblemstatement> problemstatementObj =
                    drillProblemStatementRepository.findByDrillId(drillId);
            if (problemstatementObj.isPresent()) {
                DrillProblemstatement problemstatement = problemstatementObj.get();
                if (problemstatement.isPublic()) {
                    return problemstatementObj.get();
                } else {
                    Optional<DrillParticipant> drillParticipant =
                            drillParticipantRepository.findById(participantId);
                    if (!drillParticipant.isPresent()) {
                        return commonUtils.message(
                                HttpStatus.INTERNAL_SERVER_ERROR,
                                "Failed to get problem statement as you"
                                        + "have not participated in the hackathon");
                    } else {
                        return problemstatementObj.get();
                    }
                }
            } else {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Problem statement is not present."
                                + "Please contact the hackathon execution team");
            }
        } catch (Exception e) {
            log.error("Exception while fetching the problem statement with error {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to get the problem statement. Please contact the support team at " + techSupportEmail);
        }
    }

    public Object saveDrill(Drill payload, InternityUser user) {
        try {
            String drillName = payload.getDrillName();

            log.info("Started to save the Drill with name ::: {}", drillName);

            Map<String, String> validationMessage = allDrillValidation(payload);

            if (validationMessage != null) {
                return validationMessage;
            }

            log.info("Creating the custom url for the drill for ::: {}", drillName);
            // Create the custom URL for the Drill
            String custUrl = getCustomUrlForDrill(payload.getDrillCustUrl(), payload.getDrillName(), payload.getDrillId());
            if (custUrl == null) {
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Custom URL already exists");
            }

            payload.setDrillCustUrl(custUrl);

            if (payload.getDrillRegistrationEndDt() == null) {
                payload.setDrillRegistrationEndDt(payload.getDrillEndDt());
            }

            if (payload.getDrillRegistrationStartDt() == null) {
                payload.setDrillRegistrationStartDt(payload.getDrillStartDt());
            }

            if (payload.getDrillRegistrationEndDt().isBefore(payload.getDrillRegistrationStartDt())) {
                return commonUtils.message(HttpStatus.BAD_REQUEST, "Registration Start date should be smaller than Registration End date");
            }

            String drillPhaseInfoFromUser = payload.getDrillPhase();

            //Validating the dates of the phases
            if (!StringUtils.isBlank(payload.getDrillPhase())) {
                log.info("Validating the phases of drill ::: {}", drillName);
                Map<String, String> phaseValidationMessage =
                        drillPhaseValidationWhileCreating(drillPhaseInfoFromUser);
                if (!phaseValidationMessage.isEmpty()) {
                    return phaseValidationMessage;
                }
            } else {
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Phases cannot be empty");
            }

            //remove extra schedule key from JSON
            removeScheduleInfoFromDrillObject(payload);

            if (payload.getIsDrillPaid() == null) {
                log.info("isDrillPaid info ::: {}", payload.getIsDrillPaid());
                payload.setIsDrillPaid(false);
            }

            log.info("Saving the drill in DB ::: {}", drillName);
            //save Drill object in DB
            Drill savedDrill = drillRepository.save(payload);

            log.info("Saving the drill phases in DB ::: {}", drillName);
            //save drill phases in DB
            saveDrillPhases(drillPhaseInfoFromUser, savedDrill.getDrillId());
            // call method to update phases positions
            updatePhasesPositions(savedDrill);
            log.info("Saving the overview object for Drill in DB ::: {}", drillName);
            //save Overview if not present
            Optional<DrillOverview> overviewObj =
                    drillOverviewRepository.findById(savedDrill.getDrillId());
            if (!overviewObj.isPresent()) {
                DrillOverview overview = new DrillOverview();
                overview.setDrillId(savedDrill.getDrillId());
                drillOverviewRepository.save(overview);
            }

            updateStartAndEndDateOfDrill(savedDrill);
            // check if the participant field presents no change else create new
            Optional<DrillParticipantFields> savedFields = drillParticipantFieldsRepository.findById(savedDrill.getDrillId());
            if (!savedFields.isPresent()) {
                log.info("creating default participant fields");
                DrillParticipantFields participantFields = new DrillParticipantFields();
                participantFields.setDrillId(savedDrill.getDrillId());
                participantFields.setParticipantFields("[\"First Name\",\"Last Name\", \"University/College\", \"Graduation Year\", \"Job Title\", \"Company Name\", \"Years Of Experience\"]");
                log.info("default participant fields saved successfully");
                drillParticipantFieldsRepository.save(participantFields);
            }
            return savedDrill;
        } catch (Exception e) {
            log.error("Exception while saving or updating Drill {}", e);
        }
        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while saving the drill." +
                "Please connect with admin at " + techSupportEmail);
    }

    private void updatePhasesPositions(Drill drill) {
        // phases list
        List<DrillPhases> phasesList = drillPhasesRepository.findByDrillId(drill.getDrillId());
        if (!drill.isSelfPaced()) {
            // Sort phasesList based on phaseStartDt using a custom comparator
            phasesList.sort(Comparator.comparing(
                    DrillPhases::getPhaseStartDt,
                    Comparator.nullsFirst(Comparator.naturalOrder())
            ));

            // Set phasePositions according to the sorted order
            for (int i = 0; i < phasesList.size(); i++) {
                phasesList.get(i).setPhasePosition(i + 1);
            }
            // Save the updated phasesList
            drillPhasesRepository.saveAll(phasesList);

        } else {
            // check for non 0 value
            boolean allPhasesHaveNonZeroPositions = phasesList.stream()
                    .allMatch(phase -> phase.getPhasePosition() != 0);

            if (!allPhasesHaveNonZeroPositions) {
                // Sort phasesList based on phaseStartDt using a custom comparator
                phasesList.sort(Comparator.comparing(
                        DrillPhases::getPhaseStartDt,
                        Comparator.nullsFirst(Comparator.naturalOrder())
                ));

                // Set phasePositions according to the sorted order
                for (int i = 0; i < phasesList.size(); i++) {
                    phasesList.get(i).setPhasePosition(i + 1);
                }

                // Save the updated phasesList
                drillPhasesRepository.saveAll(phasesList);
            }
        }
    }

    /**
     * Removing the schedule key and its value from the JSON as the value will be saved in the drill
     * phase table
     *
     * @param payload {"type":"Multiple","hasIdeaPhase":true,"isSelfPaced":true,
     *                "schedule":[{"phaseStartDt":"20/03/2023T00:00:00.000Z","phaseEndDt":"28/03/2023T00:00:00.000Z",
     *                "phaseSubmissionDt":"27/03/2023T00:00:00.000Z","mode":"Online","location":"Online","phaseName":"Idea
     *                Phase","phaseType":"IDEA"}]}
     */
    private void removeScheduleInfoFromDrillObject(Drill payload) {
        JSONObject fullJsonObj = new JSONObject(payload.getDrillPhase());

        if (!fullJsonObj.isNull("schedule")) {
            fullJsonObj.remove("schedule");
            payload.setSelfPaced((Boolean) fullJsonObj.get("isSelfPaced"));
            payload.setDrillPhaseType(fullJsonObj.getString("type"));
            payload.setDrillPhase(fullJsonObj.toString());
        }
    }

    private Map<String, String> drillPhaseValidationWhileCreating(String drillPhase)
            throws ParseException {
        JSONObject fullJsonObj = new JSONObject(drillPhase);
        if (fullJsonObj.isNull("schedule")) {
            return Collections.EMPTY_MAP;
        }
        JSONArray phaseArray = new JSONArray(fullJsonObj.get("schedule").toString());

        List<DrillPhases> listOfPhases = new ArrayList<>();

        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

        for (int i = 0; i < phaseArray.length(); i++) {
            JSONObject jsonObject = phaseArray.getJSONObject(i);
            DrillPhases drillPhases = new DrillPhases();
            drillPhases.setPhaseName(jsonObject.getString("phaseName"));
            drillPhases.setPhaseMode(jsonObject.getString("phaseMode"));
            drillPhases.setPhaseType(jsonObject.getString("phaseType"));
            drillPhases.setPhaseLoc((!jsonObject.isNull("phaseLoc") && jsonObject.get("phaseLoc") == null)
                    ? jsonObject.getString("phaseLoc")
                    : "");
            drillPhases.setPhaseTimezone(
                    (!jsonObject.isNull("phaseTimezone") && jsonObject.get("phaseTimezone") == null)
                            ? jsonObject.getString("phaseTimezone")
                            : "");
            drillPhases.setPhaseStartDt(
                    (!jsonObject.isNull("phaseStartDt") && jsonObject.get("phaseStartDt") == null)
                            ? LocalDateTime.parse(jsonObject.getString("phaseStartDt"), format)
                            : null);
            drillPhases.setPhaseEndDt(
                    (!jsonObject.isNull("phaseEndDt") && jsonObject.get("phaseEndDt") == null)
                            ? LocalDateTime.parse(jsonObject.getString("phaseEndDt"), format)
                            : null);
            drillPhases.setDateConfirmed((Boolean) jsonObject.get("dateConfirmed"));
            drillPhases.setStartMonth(
                    !jsonObject.isNull("phaseStartMonth")
                            ? jsonObject.getString("phaseStartMonth")
                            : null);
            drillPhases.setEndMonth(
                    !jsonObject.isNull("phaseEndMonth")
                            ? jsonObject.getString("phaseEndMonth")
                            : null);
            drillPhases.setSubmissionAllowed((Boolean) jsonObject.get("isSubmissionAllowed"));
            drillPhases.setPhaseSubmissionEndDt(
                    (!jsonObject.isNull("phaseSubmissionEndDt")
                            && jsonObject.get("phaseSubmissionEndDt") == null)
                            ? LocalDateTime.parse(
                            jsonObject.getString("phaseSubmissionEndDt"), format)
                            : null);
            drillPhases.setPhasePosition(jsonObject.getInt("phasePosition"));
            listOfPhases.add(drillPhases);
        }

        // Multiple Phase
        if (fullJsonObj.getString("type").equalsIgnoreCase("multiple")) {
            if ((Boolean) fullJsonObj.get("isSelfPaced")) {
                for (DrillPhases phase : listOfPhases) {
                    Map<String, String> validPhaseMsg = validateDatesSequenceOfPhases(phase);
                    if (!validPhaseMsg.isEmpty()) {
                        return validPhaseMsg;
                    }
                }
                Map<String, String> sequenceOfDatesMsg =
                        checkDatesOfPhasesForNonSelfpaced(listOfPhases);
                if (!sequenceOfDatesMsg.isEmpty()) {
                    return sequenceOfDatesMsg;
                }
            }
        } else {
            // Single Phase
            Map<String, String> validPhaseMsg = validateDatesSequenceOfPhases(listOfPhases.get(0));
            if (!validPhaseMsg.isEmpty()) {
                return validPhaseMsg;
            }
        }
        return Collections.EMPTY_MAP;
    }

    private Map<String, String> drillPhaseValidationWhileManaging(String drillPhase, String drillId)
            throws ParseException {

        Optional<Drill> drillObj = drillRepository.findById(drillId);
        if (drillObj.isPresent()) {
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while validating drill phase" + "with managing Drill");
        }

        Drill drill = drillObj.get();

        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

        JSONObject jsonObject = new JSONObject(drillPhase);
        DrillPhases drillPhases = new DrillPhases();
        drillPhases.setDrillId(drillId);
        drillPhases.setPhaseName(jsonObject.getString("phaseName"));
        drillPhases.setPhaseMode(jsonObject.getString("phaseMode"));
        drillPhases.setPhaseType(jsonObject.getString("phaseType"));
        drillPhases.setPhaseLoc(jsonObject.getString("phaseLoc"));
        drillPhases.setPhaseTimezone(
                (!jsonObject.isNull("phaseTimezone") && jsonObject.get("phaseTimezone") == null)
                        ? jsonObject.getString("phaseTimezone")
                        : "");
        drillPhases.setPhaseStartDt(
                (!jsonObject.isNull("phaseStartDt") && jsonObject.get("phaseStartDt") == null)
                        ? LocalDateTime.parse(jsonObject.getString("phaseStartDt"), format)
                        : null);
        drillPhases.setPhaseEndDt(
                (!jsonObject.isNull("phaseEndDt") && jsonObject.get("phaseEndDt") == null)
                        ? LocalDateTime.parse(jsonObject.getString("phaseEndDt"), format)
                        : null);
        drillPhases.setDateConfirmed((Boolean) jsonObject.get("dateConfirmed"));
        drillPhases.setStartMonth(
                !jsonObject.isNull("phaseStartMonth")
                        ? jsonObject.getString("phaseStartMonth")
                        : null);
        drillPhases.setEndMonth(
                !jsonObject.isNull("phaseEndMonth") ? jsonObject.getString("phaseEndMonth") : null);
        drillPhases.setSubmissionAllowed((Boolean) jsonObject.get("isSubmissionAllowed"));
        drillPhases.setPhaseSubmissionEndDt(
                (!jsonObject.isNull("phaseSubmissionEndDt")
                        && jsonObject.get("phaseSubmissionEndDt") == null)
                        ? LocalDateTime.parse(jsonObject.getString("phaseSubmissionEndDt"), format)
                        : null);
        JSONObject fullJsonObj = new JSONObject(drill.getDrillPhase());

        // Multiple Phase
        //        if(fullJsonObj.getString("type").equalsIgnoreCase("multiple")){
        //            if ((Boolean) fullJsonObj.get("isSelfPaced")) {
        //                    Map<String, String> validPhaseMsg =
        // validateDatesSequenceOfPhases(drillPhases);
        //                    if(!validPhaseMsg.isEmpty()){
        //                        return validPhaseMsg;
        //                    }
        //                    Map<String, String> sequenceOfDatesMsg =
        // checkDatesOfPhasesForNonSelfpaced(listOfPhases);
        //                    if (sequenceOfDatesMsg.isEmpty()) {
        //                        return sequenceOfDatesMsg;
        //                    }
        //            }
        //        }
        //        else {
        //            //Single Phase
        //            Map<String, String> validPhaseMsg =
        // validateDatesSequenceOfPhases(listOfPhases.get(0));
        //            if(!validPhaseMsg.isEmpty()){
        //                return validPhaseMsg;
        //            }
        //        }
        return Collections.EMPTY_MAP;
    }

    private Map<String, String> checkDatesOfPhasesForNonSelfpaced(List<DrillPhases> listOfPhases) {
        try {
            for (DrillPhases phaseToBeChecked : listOfPhases) {
                for (DrillPhases allPhases : listOfPhases) {

                    if ((phaseToBeChecked.getPhaseName().equals(allPhases.getPhaseName())
                            && phaseToBeChecked
                            .getPhaseStartDt()
                            .equals(allPhases.getPhaseStartDt())
                            && phaseToBeChecked.getPhaseEndDt().equals(allPhases.getPhaseEndDt())
                    )
                            || (phaseToBeChecked.getPhaseId().equals(allPhases.getPhaseId()))) {
                        continue;
                    }
                    Map<String, String> msg = validateSelfPacedPhases(phaseToBeChecked, allPhases);
                    if (!msg.isEmpty()) {
                        return msg;
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception while checking the dates for the non Self paced hackathons ::: {}", e);
        }
        return Collections.EMPTY_MAP;
    }

    private Map<String, String> validateSelfPacedPhases(
            DrillPhases phaseToBeChecked, DrillPhases allPhases) {
        try {
            log.info("phasetobechecked {} ;;; allphases {}", phaseToBeChecked, allPhases);

            if (phaseToBeChecked.getPhaseId().equals(allPhases.getPhaseId())) {
                return Collections.EMPTY_MAP;
            }
            if ((phaseToBeChecked.getPhaseStartDt().isAfter(allPhases.getPhaseStartDt())
                    && phaseToBeChecked
                    .getPhaseStartDt()
                    .isBefore(allPhases.getPhaseEndDt()))
                    || phaseToBeChecked.getPhaseEndDt().isAfter(allPhases.getPhaseStartDt())
                    && phaseToBeChecked.getPhaseEndDt().isBefore(allPhases.getPhaseEndDt())
                    || phaseToBeChecked.getPhaseStartDt().isBefore(allPhases.getPhaseStartDt())
                    && phaseToBeChecked
                    .getPhaseEndDt()
                    .isAfter(allPhases.getPhaseEndDt())) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Phase date is collapsing with dates of Phase " + allPhases.getPhaseName());
            }
        } catch (Exception e) {
            log.error("Exception while validating phases for self paced hackathon ::: {}", e);
        }
        return Collections.EMPTY_MAP;
    }

    private Map<String, String> validateDatesSequenceOfPhases(DrillPhases phase) {
        try {
            Map<String, String> resultMsg;
            if (phase.isDateConfirmed() == true) {
                resultMsg = checkIfStartdtIsBeforeEnddt(phase.getPhaseStartDt(), phase.getPhaseEndDt());
            } else {
                resultMsg = checkIfStartMonthIsBeforeEndMonth(
                        phase.getStartMonth(), phase.getEndMonth());
            }
            if (!resultMsg.isEmpty()) {
                return resultMsg;
            }
        } catch (Exception e) {
            log.error("Exception while validating the dates of the phase {}", e);
        }
        return Collections.EMPTY_MAP;
    }

    public Map<String, String> checkIfStartMonthIsBeforeEndMonth(String startMonth, String endMonth) {
//        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        LocalDateTime startMonthDt = LocalDateTime.parse(startMonth);
        LocalDateTime endMonthDt = LocalDateTime.parse(endMonth);

        if (startMonthDt.isAfter(endMonthDt)) {
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "End month cannot be set before the Start month");
        }
        return Collections.emptyMap();
    }

    private Map<String, String> checkIfStartdtIsBeforeEnddt(
            LocalDateTime phaseStartDt, LocalDateTime phaseEndDt) {
        if (phaseStartDt.isAfter(phaseEndDt)) {
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "End date cannot be set before the Start date");
        }
        return Collections.EMPTY_MAP;
    }

    private String getCustomUrlForDrill(String drillCustUrl, String drillName, String drillId) {
        try {
            if (StringUtils.isAnyBlank(drillCustUrl)) {
                String custUrl = drillName.toLowerCase().replaceAll(" ", "-")
                        .replaceAll("/", "-");

                int count = drillRepository.countByDrillName(drillName);
                if (count > 0) {
                    custUrl = custUrl + "-" + (count + 1);
                    return custUrl;
                }
                return custUrl;
            } else if (!StringUtils.isAnyBlank(drillCustUrl)) {
                Optional<Drill> drill = drillRepository.findByDrillCustUrl(drillCustUrl.toLowerCase().replaceAll(" ", "-").replaceAll("/", "-"));
                if (drill.isPresent() && Objects.equals(drill.get().getDrillId(), drillId)) {
                    return drill.get().getDrillCustUrl();
                } else if (drill.isPresent()) {
                    return null;
                }
            }
        } catch (Exception e) {
            log.error("Exception while fetching the custom URL for the Drill ::: {}", e);
        }
        return drillCustUrl.toLowerCase().replaceAll(" ", "-").replaceAll("/", "-");
    }

    private Map<String, String> saveDrillPhases(String drillPhase, String drillId) {
        try {
            JSONObject fullJsonObj = new JSONObject(drillPhase);
            JSONArray phaseArray = new JSONArray(fullJsonObj.get("schedule").toString());

            List<DrillPhases> listOfPhases = new ArrayList<>();

            DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

            for (int i = 0; i < phaseArray.length(); i++) {
                JSONObject jsonObject = phaseArray.getJSONObject(i);
                DrillPhases drillPhases = new DrillPhases();
                drillPhases.setDrillId(drillId);
                drillPhases.setPhaseName(jsonObject.getString("phaseName"));
                drillPhases.setPhaseMode(jsonObject.getString("phaseMode"));
                drillPhases.setPhaseType(jsonObject.getString("phaseType"));
                drillPhases.setPhaseLoc(!jsonObject.isNull("phaseLoc")
                        ? jsonObject.getString("phaseLoc")
                        : null);
                drillPhases.setDateConfirmed((Boolean) jsonObject.get("dateConfirmed"));
                if ((Boolean) jsonObject.get("dateConfirmed")) {
                    drillPhases.setPhaseTimezone(jsonObject.getString("phaseTimezone"));
                    drillPhases.setPhaseStartDt(
                            LocalDateTime.parse(jsonObject.getString("phaseStartDt"), format));
                    drillPhases.setPhaseEndDt(
                            LocalDateTime.parse(jsonObject.getString("phaseEndDt"), format));
                } else {
                    drillPhases.setStartMonth(
                            !jsonObject.isNull("startMonth")
                                    ? jsonObject.getString("startMonth")
                                    : null);
                    drillPhases.setEndMonth(
                            !jsonObject.isNull("endMonth")
                                    ? jsonObject.getString("endMonth")
                                    : null);
                    if (drillPhases.getStartMonth() != null && drillPhases.getEndMonth() != null) {

                        LocalDateTime startMonth = LocalDateTime.parse(drillPhases.getStartMonth().replace("Z", ""));
                        LocalDateTime endMonth = LocalDateTime.parse(drillPhases.getEndMonth().replace("Z", ""));

                        // Get the current month
                        Month currentMonth = LocalDateTime.now().getMonth();

                        // Extract the months from the input LocalDateTime objects
                        Month startInputMonth = startMonth.getMonth();
                        Month endInputMonth = endMonth.getMonth();

                        // Initialize variables for start and end DateTime
                        LocalDateTime startDateTime;
                        LocalDateTime endDateTime;

                        // Check if the start month is the same as the current month
                        if (startInputMonth == currentMonth) {
                            // Set startDateTime to the current LocalDateTime
                            startDateTime = LocalDateTime.now();
                        } else {
                            // Set startDateTime to the start of the input start month
                            startDateTime = startMonth.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
                        }

                        // Set endDateTime to the end of the input end month
                        endDateTime = endMonth.withDayOfMonth(endMonth.getMonth().length(endMonth.toLocalDate().isLeapYear())).withHour(23).withMinute(59).withSecond(59);
                        drillPhases.setStartMonth(startDateTime.toString());
                        drillPhases.setEndMonth(endDateTime.toString());
                        drillPhases.setPhaseStartDt(startDateTime);
                        drillPhases.setPhaseEndDt(endDateTime);
                    }
                }
                drillPhases.setSubmissionAllowed((Boolean) jsonObject.get("isSubmissionAllowed"));
                drillPhases.setPhaseStatus(DrillPhaseStatus.TOBEGIN.name());
                drillPhases.setPhasePosition(jsonObject.getInt("phasePosition"));
                if ((Boolean) jsonObject.get("isSubmissionAllowed")) {
                    drillPhases.setPhaseSubmissionEndDt(
                            LocalDateTime.parse(jsonObject.getString("phaseSubmissionEndDt"), format));
                }
                listOfPhases.add(drillPhases);
            }
            drillPhasesRepository.saveAll(listOfPhases);
            return null;
        } catch (Exception e) {
            log.error("Exception while saving all drill phases ::: {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR, "Exception while saving all drill phases");
        }
    }

    private Map<String, String> checkEverythingIsCreated(Drill savedDrill) {
        if (StringUtils.isBlank(savedDrill.getDrillId())) {
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Drill id cannot be blank after creating the Drill");
        } else {
            Optional<DrillOverview> overviewObj =
                    drillOverviewRepository.findById(savedDrill.getDrillId());
            if (!overviewObj.isPresent()) {
                DrillOverview overview = new DrillOverview();
                overview.setDrillId(savedDrill.getDrillId());
                drillOverviewRepository.save(overview);
            }
            //            List<DrillPhases> phasesObj =
            // drillPhasesRepository.findByDrillIdOrderByPhaseStartDtDesc(savedDrill.getDrillId());
            //            if(phasesObj.isEmpty()){
            //                savePhase(savedDrill);
            //            }
        }
        return Collections.EMPTY_MAP;
    }

    private DrillPhases saveHackathonPhase(Drill savedDrill, DrillPhases ideaPhase) {
        try {
            DrillPhases drillPhases = new DrillPhases();
            drillPhases.setDrillId(savedDrill.getDrillId());
            drillPhases.setPhaseType(DrillPhaseType.HACKATHON.name());
            drillPhases.setPhaseStatus(DrillPhaseStatus.TOBEGIN.name());
            drillPhases.setPhaseName("Hackathon Phase");
            drillPhases.setPhaseDesc("Hackathon Phase");
            drillPhases.setPhaseStartDt(ideaPhase.getPhaseEndDt());
            drillPhases.setPhaseEndDt(savedDrill.getDrillEndDt());
            drillPhases.setPhaseMode(savedDrill.getDrillNature());
            drillPhases.setPhaseLoc(
                    savedDrill.getDrillLocation() == null ? "" : savedDrill.getDrillLocation());
            return drillPhasesRepository.save(drillPhases);
        } catch (Exception e) {
            log.error("Exception while saving hackathon phase for a Drill {}", e);
            return null;
        }
    }

    public Object saveDrillOverview(DrillOverview payload, InternityUser user) {
        payload.getDrillDescription().replaceAll("&lt;", "<").replaceAll("&gt;", ">");
        return drillOverviewRepository.save(payload);
    }

    public Object saveDrillPrizes(DrillPrizes payload, InternityUser user) {
        return drillPrizesRepository.save(payload);
    }

    private Map<String, String> allDrillValidation(Drill drill) {
        try {
            log.info("Validating the drill object while saving ::: {}", drill.getDrillName());
            Drill drillFromDb = null;

            if (!StringUtils.isBlank(drill.getDrillId())) {
                Optional<Drill> drillObjectFromDb = drillRepository.findById(drill.getDrillId());

                if (drillObjectFromDb.isPresent()) {
                    drillFromDb = drillObjectFromDb.get();
                }
            }

            if (StringUtils.isBlank(drill.getDrillName())) {
                if (drillFromDb != null) {
                    if (StringUtils.isBlank(drillFromDb.getDrillName())) {
                        return commonUtils.setupMessage(
                                new HashMap<>(),
                                CommonConstants.VALIDATION_KEY,
                                "Drill Name cannot be empty");
                    }
                } else {
                    return commonUtils.setupMessage(
                            new HashMap<>(),
                            CommonConstants.VALIDATION_KEY,
                            "Drill Name cannot be empty");
                }
            }
            if (StringUtils.isBlank(drill.getDrillPurpose())) {
                if (drillFromDb != null) {
                    if (StringUtils.isBlank(drillFromDb.getDrillPurpose())) {
                        return commonUtils.setupMessage(
                                new HashMap<>(),
                                CommonConstants.VALIDATION_KEY,
                                "Purpose of the Drill cannot be empty");
                    }
                } else {
                    return commonUtils.setupMessage(
                            new HashMap<>(),
                            CommonConstants.VALIDATION_KEY,
                            "Purpose of the Drill cannot be empty");
                }
            }
            if (StringUtils.isBlank(drill.getDrillPartnerId())) {
                if (drillFromDb != null) {
                    if (StringUtils.isBlank(drillFromDb.getDrillPartnerId())) {
                        return commonUtils.setupMessage(
                                new HashMap<>(),
                                CommonConstants.VALIDATION_KEY,
                                "Organisation Id of the Drill cannot be empty");
                    }
                } else {
                    return commonUtils.setupMessage(
                            new HashMap<>(),
                            CommonConstants.VALIDATION_KEY,
                            "Organisation Id of the Drill cannot be empty");
                }
            }
            if (StringUtils.isBlank(drill.getDrillType())) {
                if (drillFromDb != null) {
                    if (StringUtils.isBlank(drillFromDb.getDrillType())) {
                        return commonUtils.setupMessage(
                                new HashMap<>(),
                                CommonConstants.VALIDATION_KEY,
                                "Type of the Drill cannot be empty");
                    }
                } else {
                    return commonUtils.setupMessage(
                            new HashMap<>(),
                            CommonConstants.VALIDATION_KEY,
                            "Type of the Drill cannot be empty");
                }
            }
        } catch (Exception e) {
            log.error("Exception while validating the drill object ::: {}", e);
        }
        return null;
    }

    public ResponseEntity<?> saveDrillSection(
            DrillSectionEnum section, Map<String, Object> payload, InternityUser user) {
        ObjectMapper obj = new ObjectMapper();
        try {
            switch (section.getValue()) {
                case "overview":
                    DrillOverview drillOverview = obj.convertValue(payload, DrillOverview.class);
                    if (!StringUtils.isBlank(drillOverview.getDrillDescription())) {
                        drillOverview
                                .getDrillDescription()
                                .replaceAll("&lt;", "<")
                                .replaceAll("&gt;", ">");
                    }
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillOverviewRepository.save(drillOverview), HttpStatus.OK);
                case "prizes":
                    DrillPrizes drillPrizes = obj.convertValue(payload, DrillPrizes.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillPrizesRepository.save(drillPrizes), HttpStatus.OK);
                case "themes":
                    DrillThemes drillTheme = obj.convertValue(payload, DrillThemes.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillThemesRepository.save(drillTheme), HttpStatus.OK);
                case "opportunities":
                    DrillOpportunities drillOpportunities =
                            obj.convertValue(payload, DrillOpportunities.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillOpportunitiesRepository.save(drillOpportunities), HttpStatus.OK);
                case "collaborators":
                    DrillCollaborators drillCollaborators =
                            obj.convertValue(payload, DrillCollaborators.class);
                    if (drillCollaborators.getCollaboratorType().equalsIgnoreCase("judge")
                            && StringUtils.isBlank(drillCollaborators.getKey())) {
                        String randomAlphabets = RandomStringUtils.randomAlphabetic(2);
                        String randomNumbers = RandomStringUtils.randomNumeric(4);
                        String key = randomAlphabets + randomNumbers;
                        drillCollaborators.setKey(key);
                        section = DrillSectionEnum.JUDGES;
                    } else if (drillCollaborators
                            .getCollaboratorType()
                            .equalsIgnoreCase("mentor")) {
                        section = DrillSectionEnum.MENTORS;
                    } else if (drillCollaborators
                            .getCollaboratorType()
                            .equalsIgnoreCase("sponsor")) {
                        section = DrillSectionEnum.SPONSORS;
                    } else if (drillCollaborators
                            .getCollaboratorType()
                            .equalsIgnoreCase("collaborator")) {
                        section = DrillSectionEnum.COLLABORATORS;
                    }
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillCollaboratorsRepository.save(drillCollaborators), HttpStatus.OK);
                case "faq":
                    DrillNewFaq drillNewFaq = obj.convertValue(payload, DrillNewFaq.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(drillNewFaqRepository.save(drillNewFaq), HttpStatus.OK);
                case "judgingcriteria":
                    DrillJudgingCriteria drillJudgingCriteria =
                            obj.convertValue(payload, DrillJudgingCriteria.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillJudgingCriteriaRepository.save(drillJudgingCriteria),
                            HttpStatus.OK);
                case "events":
                    obj.registerModule(new JavaTimeModule());
                    DrillEvent drillEvent = obj.convertValue(payload, DrillEvent.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillEventRepository.save(drillEvent), HttpStatus.OK);
                case "problemstatement":
                    DrillProblemstatement drillProblemstatement =
                            obj.convertValue(payload, DrillProblemstatement.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillProblemStatementRepository.save(drillProblemstatement),
                            HttpStatus.OK);
                case "resources":
                    DrillResources drillResources = obj.convertValue(payload, DrillResources.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillResourcesRepository.save(drillResources), HttpStatus.OK);
                case "custom":
                    DrillCustom drillCustom = obj.convertValue(payload, DrillCustom.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillCustomRepository.save(drillCustom), HttpStatus.OK);
                case "phases":
                    DateTimeFormatter formatter =
                            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
                    JSONObject jsonObject = new JSONObject(payload);
                    String phaseId = "";
                    String phaseType = jsonObject.getString("phaseType");
                    DrillPhases hackathonPhaseWithIdeaPhase = new DrillPhases();

                    if (!jsonObject.isNull("phaseId")) {
                        phaseId = jsonObject.getString("phaseId");
                    }

                    LocalDateTime startDt =
                            LocalDateTime.parse(
                                    jsonObject.getString("phaseStartDt").replaceAll("Z", ""));

                    LocalDateTime endDt =
                            LocalDateTime.parse(
                                    jsonObject.getString("phaseEndDt").replaceAll("Z", ""));

                    DrillPhases drillPhases = new DrillPhases();
                    if (!jsonObject.isNull("phaseId")) {
                        drillPhases.setPhaseId(phaseId);
                    }

                    if (phaseType.equalsIgnoreCase(DrillPhaseType.IDEA.name())) {
                        Map<String, String> validationMsg =
                                validateIdeaPhase(
                                        jsonObject.isNull("phaseId")
                                                ? ""
                                                : jsonObject.getString("phaseId"),
                                        payload.get("drillId").toString(),
                                        startDt,
                                        endDt);
                        if (!validationMsg.isEmpty()) {
                            return new ResponseEntity<>(
                                    validationMsg, HttpStatus.INTERNAL_SERVER_ERROR);
                        } else {
                            drillPhases.setDrillId(jsonObject.getString("drillId"));
                            drillPhases.setPhaseName(jsonObject.getString("phaseName"));
                            drillPhases.setPhaseLoc(jsonObject.getString("phaseLoc"));
                            drillPhases.setPhaseMode(jsonObject.getString("phaseMode"));
                            drillPhases.setPhaseStartDt(startDt);
                            drillPhases.setPhaseEndDt(endDt);
                            drillPhases.setPhaseStatus(jsonObject.getString("phaseStatus"));
                            drillPhases.setPhaseType(phaseType);
                            drillPhases.setPhaseDesc(jsonObject.getString("phaseDesc"));

                            if (StringUtils.isBlank(phaseId)) {
                                Drill hackathonPhaseAfterIdea =
                                        drillRepository
                                                .findById(payload.get("drillId").toString())
                                                .get();
                                saveHackathonPhase(hackathonPhaseAfterIdea, drillPhases);
                            }
                            return new ResponseEntity<>(
                                    drillPhasesRepository.save(drillPhases), HttpStatus.OK);
                        }
                    } else {
                        Map<String, String> validationMsg =
                                checkIfPhaseIsInOrder(
                                        startDt, endDt, phaseId, jsonObject.getString("drillId"));

                        if (!validationMsg.isEmpty()) {
                            return new ResponseEntity<>(
                                    validationMsg, HttpStatus.INTERNAL_SERVER_ERROR);
                        }

                        drillPhases.setDrillId(jsonObject.getString("drillId"));
                        drillPhases.setPhaseName(jsonObject.getString("phaseName"));
                        drillPhases.setPhaseLoc(
                                jsonObject.isNull("phaseLoc")
                                        ? null
                                        : jsonObject.getString("phaseLoc"));
                        drillPhases.setPhaseMode(jsonObject.getString("phaseMode"));
                        drillPhases.setPhaseStartDt(startDt);
                        drillPhases.setPhaseEndDt(endDt);
                        drillPhases.setPhaseStatus(jsonObject.getString("phaseStatus"));
                        drillPhases.setPhaseType(phaseType);
                        drillPhases.setPhaseDesc(jsonObject.getString("phaseDesc"));

                        return new ResponseEntity<>(
                                drillPhasesRepository.save(drillPhases), HttpStatus.OK);
                    }
                case "organiserdetails":
                    String drillId = (String) payload.get("drillId");
                    if (StringUtils.isBlank(drillId)) {
                        return new ResponseEntity<>("Drill Id can not be empty", HttpStatus.BAD_REQUEST);
                    }
                    Optional<Drill> drillObjectFromDb = drillRepository.findById(drillId);

                    if (!drillObjectFromDb.isPresent()) {
                        return new ResponseEntity<>("Drill not found by this Id,drill id invalid", HttpStatus.BAD_REQUEST);
                    }

                    DrillOrganiserDetails drillOrganiserDetails = obj.convertValue(payload, DrillOrganiserDetails.class);
                    showOrHideADrillSection(payload.get("drillId").toString(), section, true, user);
                    return new ResponseEntity<>(
                            drillOrganiserDetailsRepository.save(drillOrganiserDetails), HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while saving section of Drill {}", e);
        }
        return null;
    }

    private Map<String, String> validateIdeaPhase(
            String phaseId, String drillId, LocalDateTime startDt, LocalDateTime endDt) {
        try {
            if (drillPhasesRepository
                    .findByDrillIdAndPhaseType(drillId, DrillPhaseType.IDEA.name())
                    .isPresent()
                    && StringUtils.isBlank(phaseId)) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "A Drill can have only 1 Idea phase, please edit it or contact support team");
            }
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {
                Drill drill = drillObj.get();
                Map<String, String> msg = checkTheDatesWithTheHackathonDate(drill, startDt, endDt);
                if (!msg.isEmpty()) {
                    return msg;
                }
            }
            return Collections.EMPTY_MAP;
        } catch (Exception e) {
            log.error(
                    "Exception while checking if only one idea phase exists with this "
                            + "drill {} ::: error {}",
                    drillId,
                    e);
        }
        return Collections.EMPTY_MAP;
    }

    private Map<String, String> checkTheDatesWithTheHackathonDate(
            Drill drill, LocalDateTime startDt, LocalDateTime endDt) {
        try {
            if (startDt.isBefore(drill.getDrillStartDt())) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Idea phase must start after the hackathon start date. Please edit in Schedule section");
            }
            if (startDt.isAfter(drill.getDrillEndDt())) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Idea phase cannot start after the hackathon end date. Please edit in Schedule section");
            }
            if (endDt.isAfter(drill.getDrillEndDt())) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Idea phase cannot conclude after the end date of the hackathon. Please edit in Schedule section");
            }
            if (endDt.isBefore(drill.getDrillStartDt())) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Idea phase cannot conclude before the hackathon start date. Please edit in Schedule section");
            }
        } catch (Exception e) {
            log.error(
                    "Exception occurred while checking the hackathon dates order with the order of the phase dates");
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception occurred while checking the hackathon dates order with the order of the phase dates");
        }
        return Collections.EMPTY_MAP;
    }

    private Map<String, String> checkIfPhaseIsInOrder(
            LocalDateTime startDt, LocalDateTime endDt, String phaseId, String drillId) {
        try {
            if (startDt.isAfter(endDt)) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "End date cannot be set before the Start date");
            }
            List<DrillPhases> drillPhasesList =
                    drillPhasesRepository.findByDrillIdOrderByPhaseStartDtDesc(drillId);
            if (!drillPhasesList.isEmpty()) {
                DrillPhases drillPhasesObj = drillPhasesList.get(0);

                if (phaseId != "" && drillPhasesObj.getPhaseId().equals(phaseId)) {
                    return Collections.EMPTY_MAP;
                }
                if (drillPhasesObj.getPhaseEndDt().isAfter(startDt)) {
                    return commonUtils.message(
                            HttpStatus.INTERNAL_SERVER_ERROR,
                            "Start date cannot be set after the end date of previous Phase");
                }
            }
            Map<String, String> msg =
                    checkTheDatesWithTheHackathonDate(
                            drillRepository.findById(drillId).get(), startDt, endDt);
            if (!msg.isEmpty()) {
                return msg;
            }
        } catch (Exception e) {
            log.error(
                    "Exception while checking the dates of phase for drill Id {} ::: error {}",
                    drillId,
                    e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "An error occured while validating the values. Please contact " + techSupportEmail);
        }
        return Collections.emptyMap();
    }

    public Map<String, Object> getDrillSpecificCommonValues(String drillId, InternityUser user) {
        try {
            Optional<DrillParticipationForm> drillParticipationForm =
                    drillParticipationFormRepository.findByDrillId(drillId);
            Map<String, Object> mapOfCommonValues = new HashMap<>();
            if (drillParticipationForm.isPresent()) {
                DrillParticipationForm obj = drillParticipationForm.get();
                mapOfCommonValues.put("skills", Arrays.asList(obj.getDrillSkills().split(",")));
                mapOfCommonValues.put(
                        "knownPlatforms", Arrays.asList(obj.getDrillAffiliate().split(",")));
            } else {
                mapOfCommonValues.put("skills", drillCommonSkills);
                mapOfCommonValues.put("knownPlatforms", drillAffiliatePlatforms);
            }
            return mapOfCommonValues;
        } catch (Exception e) {
            log.error("Exception while fetching common values for a drill");
        }
        return Collections.emptyMap();
    }

    public Response saveDrillParticipant(DrillParticipant payload, InternityUser internityUser) {

        try {
            Drill drill = drillRepository.findById(payload.getDrillId()).orElse(null);
            if (drill == null) {
                return responseUtil.internalServerErrorResponse("Drill is not available");
            }
            Optional<User> user = userRepository.findById(payload.getPlatformUId());
            if (!user.isPresent()) {
                return responseUtil.badRequestResponse(
                        "User is not registered yet with us."
                                + "Please register or contact our tech support at " + techSupportEmail);
            }
            Optional<DrillParticipant> participantFromDb = drillParticipantRepository.findByDrillIdAndEmail(payload.getDrillId(), payload.getEmail());
            if (participantFromDb.isPresent()) {
                return responseUtil.conflictResponse("User " + payload.getFullName() +
                        " has already participated with email id " + payload.getEmail() +
                        " in this hackathon.For any assistance, please contact our tech support at " +
                        techSupportEmail);
            }

            if (drill.getDrillInvitationType().equals("INVITE_ONLY")) {
                DrillParticipantsInviteOnly drillParticipantsInviteOnly = drillParticipantsInviteOnlyRepository.findByDrillIdAndParticipantEmail(payload.getDrillId(), payload.getEmail());
                if (drillParticipantsInviteOnly != null) {
                    drillParticipantsInviteOnly.setParticipated(true);
                    drillParticipantsInviteOnlyRepository.saveAndFlush(drillParticipantsInviteOnly);
                    return saveParticipant(payload, drill);
                } else {
                    // return error says its invite only
                    return responseUtil.badRequestResponse("This Hackathon is Invite only.");
                }
            } else {
                return saveParticipant(payload, drill);

            }
        } catch (Exception e) {
            log.error("Exception while saving drill participant {}", e);
        }
        return responseUtil.internalServerErrorResponse("Participation is unsuccessful. "
                + "Apologies for inconvenience, please try after sometime.");
    }

    // helper method to save participant
    public Response saveParticipant(DrillParticipant payload, Drill drill) {
        if (drill.getIsDrillPaid()) {
            payload.setPaymentStatus(PaymentStatus.PENDING);
        } else {
            payload.setPaymentStatus(PaymentStatus.NA);
        }
        payload.setMemberType(MemberType.TEAMMEMBER);
        DrillParticipant participant = drillParticipantRepository.save(payload);
        drill.setDrillApplicantCount(drill.getDrillApplicantCount() + 1);
        drill.setUpdatedTs(drill.getUpdatedTs());
        drillRepository.saveAndFlush(drill);
        sendWelcomeDrillEmail(drill, participant);
        return new Response(HttpStatus.OK.value(), Boolean.TRUE, participant, null);

    }

    public Object saveNewDrillTeam(
            String drillId, String participantId, DrillTeams payload, InternityUser user) {
        try {
            if (isTeamnameAvailable(drillId, payload.getTeamName(), user)) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "A team with same name already exists in this hackathon. " +
                                "Please choose another name for your team");
            }
            if (memberAlreadyHasATeamInADrill(drillId, participantId)) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Failed to accept participation as you are already a member of another team."
                                + " Please contact tech support for any changes at " + techSupportEmail);
            }

            payload.setDrillId(drillId);
            payload.setTeamLeadParticipantId(participantId);

            DrillTeams team = drillTeamsRepository.save(payload);
            // team creation is successful
            // adding participant

            this.saveTeamsParticipants(
                    setTeamsParticipants(
                            drillId,
                            team.getTeamId(),
                            participantId,
                            payload.getParticipantValue(),
                            true));

            team.setTeamCurrentSize(team.getTeamCurrentSize() + 1);

            sendMailForNewDrillTeam(team.getTeamName(), participantId);

            return drillTeamsRepository.saveAndFlush(team);

        } catch (Exception e) {
            log.error("Exception while saving drill team {}", e);
        }
        return commonUtils.message(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Team creation is unsuccessful. "
                        + "Apologies for inconvenience, please try after sometime.");
    }

    public Object addDrillTeamMember(
            String drillId,
            String teamId,
            String participantId,
            String participantValue,
            boolean isRequestAccepted,
            InternityUser user) {
        try {
            if (memberAlreadyHasATeamInADrill(drillId, participantId)) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Failed to accept participation as you are already a member of another team."
                                + " Please contact our support team for any changes at " + techSupportEmail);
            }
            if (isAlreadyRequestedToJoinThisTeam(teamId, participantId)) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Failed to send request to join as you have already sent a request to join this team."
                                + "Please ask the team lead to accept the request or contact our support team for any changes at " + techSupportEmail);
            }
            if (!checkIfTeamSizeIsFull(drillId, teamId)) {

                TeamsParticipants participantsInfo =
                        this.setTeamsParticipants(
                                drillId,
                                teamId,
                                participantId,
                                participantValue,
                                isRequestAccepted);

                TeamsParticipants savedTeamParticipants =
                        this.saveTeamsParticipants(participantsInfo);

                DrillTeams team = drillTeamsRepository.findById(teamId).get();

                sendDrillMailForParticipationAcceptance(
                        drillId,
                        teamId,
                        team.getTeamName(),
                        "sendRequest",
                        "lead",
                        participantId,
                        team.getTeamLeadParticipantId());
                sendDrillMailForParticipationAcceptance(
                        drillId,
                        teamId,
                        team.getTeamName(),
                        "sendRequest",
                        "participant",
                        participantId,
                        null);

                return savedTeamParticipants;
            } else {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Team size is full. "
                                + "Please request another team or contact our support team at " + techSupportEmail);
            }
        } catch (Exception e) {
            log.error("Exception while saving drill team member {}", e);
        }
        return commonUtils.message(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Team member addition is unsuccessful. "
                        + "Apologies for inconvenience, please try after sometime.");
    }

    private boolean isAlreadyRequestedToJoinThisTeam(String teamId, String participantId) {
        return teamsParticipantsRepository
                .findByTeamIdAndParticipantId(teamId, participantId)
                .isPresent();
    }

    private TeamsParticipants setTeamsParticipants(
            String drillId,
            String teamId,
            String participantId,
            String participantValue,
            boolean isRequestAccepted) {
        TeamsParticipants participantsInfo = new TeamsParticipants();
        participantsInfo.setParticipantId(participantId);
        participantsInfo.setTeamId(teamId);
        participantsInfo.setDrillId(drillId);
        participantsInfo.setParticipantValue(participantValue);
        participantsInfo.setRequestAccepted(isRequestAccepted);
        return participantsInfo;
    }

    public Map<String, String> acceptTeamMember(
            String drillId,
            String teamId,
            String participantId,
            String leadParticipantId,
            InternityUser user) {
        try {
            if (memberAlreadyHasATeamInADrill(drillId, participantId)) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Failed to accept participation as the participant is already a member of another team."
                                + " Please contact our support team for any changes at " + techSupportEmail);
            }
            if (!checkIfTeamSizeIsFull(drillId, teamId)) {

                Optional<DrillTeams> drillTeamsObj =
                        drillTeamsRepository.findByTeamIdAndTeamLeadParticipantId(
                                teamId, leadParticipantId);
                if (drillTeamsObj.isPresent()) {
                    Optional<TeamsParticipants> teamsParticipantsObj =
                            teamsParticipantsRepository.findByTeamIdAndParticipantId(
                                    teamId, participantId);
                    if (teamsParticipantsObj.isPresent()) {
                        TeamsParticipants teamsParticipants = teamsParticipantsObj.get();
                        teamsParticipants.setRequestAccepted(true);
                        teamsParticipants.setUpdatedTs(new Date());
                        teamsParticipantsRepository.save(teamsParticipants);
                    }

                    DrillTeams drillTeams = drillTeamsObj.get();
                    drillTeams.setTeamCurrentSize(drillTeams.getTeamCurrentSize() + 1);
                    drillTeamsRepository.save(drillTeams);

                    DrillTeams team = drillTeamsRepository.findById(teamId).get();

                    sendDrillMailForParticipationAcceptance(
                            drillId,
                            teamId,
                            team.getTeamName(),
                            "acceptRequest",
                            "lead",
                            participantId,
                            leadParticipantId);
                    sendDrillMailForParticipationAcceptance(
                            drillId,
                            teamId,
                            team.getTeamName(),
                            "acceptRequest",
                            "participant",
                            participantId,
                            null);

                    return commonUtils.message(
                            HttpStatus.OK, "Great. A new member got added to your team");
                }
            } else {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Failed to accept participation as team size is full."
                                + " Please contact tech support for any changes at " + techSupportEmail);
            }
        } catch (Exception e) {
            log.error(
                    "Exception while accepting the pariticpation of {} with error ::: {}",
                    participantId,
                    e);
        }
        return commonUtils.message(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Failed to accept the participation."
                        + " Please contact tech support for any changes at " + techSupportEmail);
    }

    private boolean checkIfTeamSizeIsFull(String drillId, String teamId) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            int maxTeamSize = 0;
            int currentSize = 0;
            if (drillObj.isPresent()) {
                Drill drill = drillObj.get();
                JSONObject drillTeamSize = new JSONObject(drill.getDrillTeamSize());
                maxTeamSize = Integer.parseInt(drillTeamSize.get("max").toString());
            }

            Optional<DrillTeams> teamsObj = drillTeamsRepository.findById(teamId);
            if (teamsObj.isPresent()) {
                DrillTeams teams = teamsObj.get();
                currentSize = teams.getTeamCurrentSize();
            }
            return currentSize == maxTeamSize;
        } catch (Exception e) {
            log.error("Exception while checking if the team size is maximum {}", e);
        }
        return true;
    }

    private boolean memberAlreadyHasATeamInADrill(String drillId, String participantId) {
        try {
            List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);
            if (!drillTeamsList.isEmpty()) {
                List<String> teamIds = new ArrayList<>();
                for (DrillTeams team : drillTeamsList) {
                    teamIds.add(team.getTeamId());
                }
                List<TeamsParticipants> teamsParticipantsList =
                        teamsParticipantsRepository
                                .findByParticipantIdAndTeamIdInAndIsRequestAccepted(
                                        participantId, teamIds, true);
                if (!teamsParticipantsList.isEmpty()) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error("Exception while accepting the participation of the participant {}", e);
        }
        return false;
    }

    public TeamsParticipants saveTeamsParticipants(TeamsParticipants teamsParticipants) {
        return teamsParticipantsRepository.save(teamsParticipants);
    }

    public boolean isTeamnameAvailable(String drillId, String teamName, InternityUser user) {
        return drillTeamsRepository.findByDrillIdAndTeamName(drillId, teamName).isPresent();
    }

    public List<DrillTeams> searchDrillTeamsWithInitialLetters(
            String drillId, String initialLetters, InternityUser user) {
        try {
            if (null != initialLetters) {
                return drillTeamsRepository.findByDrillIdAndTeamNameStartsWith(
                        drillId, initialLetters);
            } else {
                return drillTeamsRepository.findByDrillId(drillId);
            }
        } catch (Exception e) {
            log.error("Exception while listing the teams {}", e);
        }
        return drillTeamsRepository.findAll();
    }

    public void sendWelcomeDrillEmail(Drill drill, DrillParticipant participant) {
        // send welcome email to drill participant
        try {
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject(
                    "Congratulations "
                            + participant.getFullName()
                            + ". We got your registration for "
                            + drill.getDrillName());
            emailContent.setTemplateName("WelcomeDrillEmail");
            emailContent.setUserName(participant.getFullName());
            if (!StringUtils.isBlank(drill.getDrillChatPlatform())) {
                try {
                    JSONObject jsonObject = new JSONObject(drill.getDrillChatPlatform());
                    if (!jsonObject.isNull("platform") && !jsonObject.isNull("link")) {
                        String platform = jsonObject.getString("platform");
                        String link = jsonObject.getString("link");
                        if (platform.toUpperCase().equals(DrillChatPlatform.DISCORD.name())) {
                            if (!StringUtils.isBlank(link)) {
                                emailContent.setMessage(
                                        "<div style=\"border-radius:10px; padding:10px;background-color:#738ADB; color:#fff;\">"
                                                + "<img src=\"https://wuelev8-common.s3.ap-south-1.amazonaws.com/common/mailtemplate/discord.png\"/>"
                                                + "<h3>Join the Hackathon Discord channel by clicking <a href=\""
                                                + link
                                                + "\">here</a> and get"
                                                + " all important notifications timely</h3>"
                                                + "</div>");
                            }
                        } else if (platform.toUpperCase().equals(DrillChatPlatform.WHATSAPP.name())) {
                            if (!StringUtils.isBlank(link)) {
                                emailContent.setMessage("<div style=\"border-radius:10px; padding:10px;background-color:#25d366; color:#fff;\">" +
                                        "<img src=\"https://wuelev8-common.s3.ap-south-1.amazonaws.com/common/mailtemplate/whatsapp.png\"/>" +
                                        "<h3>Join the Hackathon WhatsApp group by clicking <a href=\"" + link + "\">here</a> and get" +
                                        " all important notifications timely</h3>" +
                                        "</div>");
                            }
                        } else if (platform.toUpperCase().equals(DrillChatPlatform.TELEGRAM.name())) {
                            if (!StringUtils.isBlank(link)) {
                                emailContent.setMessage("<div style=\"border-radius:10px; padding:10px;background-color:#6cc1e3; color:#fff;\">" +
                                        "<img src=\"https://wuelev8-common.s3.ap-south-1.amazonaws.com/common/mailtemplate/telegram.png\"/>" +
                                        "<h3>Join the Hackathon Telegram group by clicking <a href=\"" + link + "\">here</a> and get" +
                                        " all important notifications timely</h3>" +
                                        "</div>");
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error("Exception while fetching chat platform link of the hackathons ::: {}", e);
                    emailContent.setMessage("");
                }
            }
            emailContent.setMobile(participant.getContact());
            messageUtils.sendMail(participant.getEmail(), emailContent);
        } catch (Exception exception) {
            log.error("Exception while sending email {}", exception);
        }
    }

    private void sendMailForNewDrillTeam(String teamName, String participantId) {
        // send welcome email to drill participant
        try {
            DrillParticipant drillParticipant =
                    drillParticipantRepository.findById(participantId).get();

            EmailContent emailContent = new EmailContent();
            emailContent.setSubject(
                    "Your team " + teamName + " is successfully registered with us.");
            emailContent.setTemplateName("DrillNewTeam");
            emailContent.setUserName(drillParticipant.getFullName());
            emailContent.setMobile(drillParticipant.getContact());
            emailContent.setLink(
                    domainUrl
                            + "/drills/"
                            + drillRepository
                            .findById(drillParticipant.getDrillId())
                            .get()
                            .getDrillCustUrl());
            messageUtils.sendMail(drillParticipant.getEmail(), emailContent);
        } catch (Exception exception) {
            log.error("Exception while sending email {}", exception);
        }
    }

    private void sendDrillMailForParticipationAcceptance(
            String drillId,
            String teamId,
            String teamName,
            String messageType,
            String participantType,
            String participantId,
            String leadId) {
        // send welcome email to drill participant
        try {

            String subject = "";
            String templateName = "";

            DrillParticipant drillParticipant =
                    drillParticipantRepository.findById(participantId).get();

            EmailContent emailContent = new EmailContent();

            if (participantType.equalsIgnoreCase("lead")) {
                // MAIL TO LEAD
                if (messageType.equalsIgnoreCase("sendRequest")) {
                    DrillParticipant lead = drillParticipantRepository.findById(leadId).get();

                    subject =
                            "Hey "
                                    + lead.getFullName()
                                    + ", we have a new request from a participant "
                                    + drillParticipant.getFullName()
                                    + " for your team, "
                                    + teamName;
                    templateName = "DrillLeadSendRequestTeam";
                    emailContent.setSubject(subject);
                    emailContent.setTemplateName(templateName);

                    emailContent.setLink(
                            domainUrl
                                    + "/drillsteam/participation/accept/"
                                    + drillId
                                    + "/"
                                    + participantId
                                    + "/"
                                    + leadId
                                    + "/"
                                    + teamId);

                    emailContent.setUserName(lead.getFullName());
                    emailContent.setMobile(lead.getContact());
                    messageUtils.sendMail(lead.getEmail(), emailContent);

                } else if (messageType.equalsIgnoreCase("acceptRequest")) {

                    DrillParticipant lead = drillParticipantRepository.findById(leadId).get();

                    subject =
                            "Yayy, a new member "
                                    + drillParticipant.getFullName()
                                    + " got added to the team "
                                    + teamName;
                    templateName = "DrillLeadAcceptRequestTeam";
                    emailContent.setSubject(subject);
                    emailContent.setTemplateName(templateName);

                    emailContent.setUserName(lead.getFullName());
                    emailContent.setMobile(lead.getContact());
                    messageUtils.sendMail(lead.getEmail(), emailContent);
                }

            } else {
                if (messageType.equalsIgnoreCase("sendRequest")) {
                    subject =
                            "Hey "
                                    + drillParticipant.getFullName()
                                    + ", we got your participation in team, "
                                    + teamName;
                    templateName = "DrillParticipantSendRequestTeam";
                    emailContent.setSubject(subject);
                    emailContent.setTemplateName(templateName);
                } else if (messageType.equalsIgnoreCase("acceptRequest")) {
                    subject =
                            "Congratulations "
                                    + drillParticipant.getFullName()
                                    + " Your participation just got accepted to the team "
                                    + teamName;
                    templateName = "DrillParticipantAcceptRequestTeam";
                    emailContent.setSubject(subject);
                    emailContent.setTemplateName(templateName);
                }
                emailContent.setUserName(drillParticipant.getFullName());
                emailContent.setMobile(drillParticipant.getContact());
                messageUtils.sendMail(drillParticipant.getEmail(), emailContent);
            }
        } catch (Exception exception) {
            log.error("Exception while sending email {}", exception);
        }
    }

    private String getUserIdFromParticipantId(String participantId) {
        return drillParticipantRepository.findById(participantId).get().getPlatformUId();
    }

    public Object getDrillTeams(String drillId, String teamId, InternityUser user) {
        try {
            return setAllTeamParticipantsInfo(drillId, teamId);
        } catch (Exception e) {
            log.error("Exception while fetching Drill teams {}", e);
        }
        return Collections.emptyList();
    }

    private Object setAllTeamParticipantsInfo(String drillId, String teamId) {
        try {
            Optional<DrillTeams> drillTeamInfoObj = drillTeamsRepository.findById(teamId);
            if (!drillTeamInfoObj.isPresent()) {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Failed to fetch team participants details as team is not registered with the sent id."
                                + "Please connect with tech support at " + techSupportEmail);
            }
            DrillTeams drillTeams = drillTeamInfoObj.get();

            List<DrillParticipantInfo> drillParticipantInfoList = new ArrayList<>();
            DrillTeamsDto teamsDto = new DrillTeamsDto();

            List<TeamsParticipants> teamsParticipantsList =
                    teamsParticipantsRepository.findByTeamIdAndIsRequestAccepted(teamId, true);

            for (TeamsParticipants participant : teamsParticipantsList) {
                DrillParticipant drillParticipantAllDetails =
                        drillParticipantRepository.findById(participant.getParticipantId()).get();

                DrillParticipantInfo participantInfo = new DrillParticipantInfo();
                participantInfo.setParticipantId(drillParticipantAllDetails.getParticipantId());
                participantInfo.setParticipantFullName(drillParticipantAllDetails.getFullName());
                participantInfo.setParticipantSkills(drillParticipantAllDetails.getSkills());
                participantInfo.setParticipantValue(participant.getParticipantValue());
                participantInfo.setLead(
                        drillTeams
                                .getTeamLeadParticipantId()
                                .equals(participant.getParticipantId()));
                drillParticipantInfoList.add(participantInfo);
            }

            teamsDto.setParticipantInfo(drillParticipantInfoList);
            teamsDto.setTeamId(teamId);
            teamsDto.setTeamName(drillTeams.getTeamName());
            teamsDto.setTeamImgUrl(drillTeams.getTeamImgUrl());
            teamsDto.setSelectedTheme(drillTeams.getSelectedTheme());

            return teamsDto;
        } catch (Exception e) {
            log.error("Exception while setting the information to be sent for a team {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to fetch team participants details."
                            + "Please connect with tech support at " + techSupportEmail);
        }
    }

    public Object fetchUserObjOrIfUserRegistered(
            String drillId, String uId, String action, InternityUser user) {
        try {
            Optional<DrillParticipant> participantObj =
                    drillParticipantRepository.findByDrillIdAndPlatformUId(drillId, uId);
            if (action.equals("NA")) {
                return participantObj.isPresent();
            } else {
                if (participantObj.isPresent()) {
                    return fetchParticipants(
                            drillId, participantObj.get().getParticipantId(), user);
                } else {
                    return commonUtils.messageWithStatus(HttpStatus.INTERNAL_SERVER_ERROR,
                            "Failed to fetch the participant information"
                                    + "as the user is not yet participated with this hackathon");
                }
            }
        } catch (Exception e) {
            log.error(
                    "Exception while checking if user has already participated in the Drill {}", e);
        }
        return null;
    }

    public List<DrillParticipant> fetchAllDrillParticipants(
            String drillId, InternityUser internityUser) {
        return drillParticipantRepository.findAll();
    }

    public Object fetchParticipants(String drillId, String participantId, InternityUser user) {
        try {
            // fetch the list of all teams in a drill
            List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);

            Map<String, String> drillIdAndDrillName = getDrillIdAndDrillNameMap();

            if (!participantId.equals("NA")) {

                Optional<DrillParticipant> drillParticipantObj =
                        drillParticipantRepository.findById(participantId);

                if (drillParticipantObj.isPresent()) {

                    DrillParticipant drillParticipant = drillParticipantObj.get();

                    setTeamAndThemeDetailsInDrillParticipantv2(drillParticipant, drillTeamsList);

                    return drillParticipant;
                } else {
                    return commonUtils.message(
                            HttpStatus.INTERNAL_SERVER_ERROR,
                            "Participant is not present with the provided id" + participantId);
                }
            }

            List<DrillParticipant> tempOfListOfParticipant = new ArrayList<>();
            if (!drillId.equals("NA")) {
                List<DrillParticipant> drillParticipantList =
                        drillParticipantRepository.findByDrillId(drillId);
                for (DrillParticipant drillParticipant : drillParticipantList) {
                    setTeamAndThemeDetailsInDrillParticipantv2(drillParticipant, drillTeamsList);
                }
                tempOfListOfParticipant.addAll(drillParticipantList);
            } else {
                List<Drill> drillList = drillRepository.findAll();
                for (Drill drill : drillList) {
                    List<DrillParticipant> drillParticipantList =
                            drillParticipantRepository.findByDrillId(drill.getDrillId());

                    // fetch the list of all teams in a drill
                    drillTeamsList = drillTeamsRepository.findByDrillId(drill.getDrillId());

                    //Get a map of Drill id and Drill name

                    for (DrillParticipant drillParticipant : drillParticipantList) {
                        setTeamAndThemeDetailsInDrillParticipantv2(drillParticipant, drillTeamsList);
                    }
                    tempOfListOfParticipant.addAll(drillParticipantList);
                }
            }
            List<DrillParticipant> listOfDrillParticipant = new ArrayList<>();

            for (DrillParticipant participant : tempOfListOfParticipant) {
                setDrillNameInParticipantObj(participant);
                listOfDrillParticipant.add(participant);
            }

            return listOfDrillParticipant;
        } catch (Exception e) {
            log.error("Exception while fetching participants {}", e);
        }
        return null;
    }
    private Map<String, Boolean> getTeamForTheParticipantv2(
            List<TeamsParticipants> listOfTeamsForAParticipant) {
        try {
            Map<String, Boolean> teamWithJoiningStatus = new HashMap();

            for(TeamsParticipants teamsParticipants : listOfTeamsForAParticipant){
                if(teamsParticipants.isRequestAccepted()){
                    teamWithJoiningStatus.clear();
                    teamWithJoiningStatus.put(teamsParticipants.getTeamId(), true);
                }
                else {
                    teamWithJoiningStatus.put(teamsParticipants.getTeamId(), false);
                }
            }
            return teamWithJoiningStatus;
        } catch (Exception e) {
            log.error(
                    "Exception while fetching team details for a participant of that drill {}", e);
        }
        return Collections.EMPTY_MAP;
    }

    private DrillTeams getTeamForTheParticipant(
            Set<String> listOfTeamIdsForAParticipant,
            List<DrillTeams> drillTeamsList,
            String participantId,
            String drillId) {
        try {
            Optional<TeamsParticipants> teamsParticipants =
                    teamsParticipantsRepository.findByParticipantIdAndIsRequestAccepted(
                            participantId, true);
            String teamId = "";
            if (teamsParticipants.isPresent()) {
                teamId = teamsParticipants.get().getTeamId();
            }
            DrillTeams response = new DrillTeams();
            for (DrillTeams drillTeam : drillTeamsList) {
                log.debug("team {} for participant {}", drillTeam.getTeamName(), participantId);
                if (drillTeam.getTeamId().equals(teamId)) {
                    return drillTeam;
                }
                //                if (drillTeam.getTeamLeadParticipantId().equals(participantId)) {
                //                    response = drillTeam;
                //                    break;
                //                } else if
                // (listOfTeamIdsForAParticipant.contains(drillTeam.getTeamId())) {
                //                    response = drillTeam;
                //                }
            }
            return response;
        } catch (Exception e) {
            log.error(
                    "Exception while fetching team details for a participant of that drill {}", e);
        }
        return null;
    }

    private void setDrillNameInParticipantObj(DrillParticipant participant) {
        try {
            participant.setDrillName(
                    drillRepository.findById(participant.getDrillId()).get().getDrillName());
        } catch (Exception e) {
            log.error(
                    "Exception while finding the drill name from a participant with "
                            + "id {} and name {} ::: {}",
                    participant.getParticipantId(),
                    participant.getFullName(),
                    e);
        }
    }

    public Object sendMailToDifferentUsers(
            String drillId, DrillMail drillMail, InternityUser user) {
        try {
            int c = 0;
            List<String> result = new ArrayList<>();
            List<String> listOfEmail = drillMail.getListOfReceiver();
            if (drillId.equals("Generic")) {

                for (String userEmail : listOfEmail) {

                    // String name = userEmail.substring(0,userEmail.indexOf('_')).trim();
                    // String email = userEmail.substring(userEmail.indexOf('_')+1).trim();

                    result.add(
                            sendCustomMailUtils.sendMailForGenericUser(
                                    "Dear User,",
                                    userEmail,
                                    drillMail.getMailSubject(),
                                    drillMail.getMailBody()));
                    c++;
                    if (c == 149) {
                        log.info("sleep in email datetime {} ", LocalDateTime.now());
                        c = 0;
                        Thread.sleep(500);
                        log.info("sleep in email datetime {} ", LocalDateTime.now());
                    }
                }
                return result;
            }

            for (String userEmail : listOfEmail) {
                Optional<DrillParticipant> drillParticipantObj =
                        drillParticipantRepository.findByDrillIdAndEmail(drillId, userEmail.trim());
                if (drillParticipantObj.isPresent()) {
                    DrillParticipant drillParticipant = drillParticipantObj.get();
                    String mailBody = drillMail.getMailBody();
                    if (mailBody.contains("##Receiverfullname##")) {
                        mailBody =
                                mailBody.replace(
                                        "##Receiverfullname##", drillParticipant.getFullName());
                    }
                    drillMail.setMailBody(mailBody);
                    result.add(sendCustomMailUtils.sendMailForUser(drillParticipant, drillMail));
                } else {
                    result.add(
                            "NOT PRESENT. " + userEmail + "is not registered for this hackathon");
                }
            }

            return result;
        } catch (Exception e) {
            log.error("Exception while sending emails {}", e);
        }
        return null;
    }

    public Object fetchDrillidFromCusturl(String custUrl) {
        try {
            Optional<Drill> drillObj = drillRepository.findByDrillCustUrl(custUrl);
            if (drillObj.isPresent()) {
                return drillObj.get().getDrillId();
            } else {
                return commonUtils.message(
                        HttpStatus.INTERNAL_SERVER_ERROR, "Check the custom url");
            }
        } catch (Exception e) {
            log.error("Exception while fetching id from custom URL {}", e);
        }
        return commonUtils.message(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "Failed while fetching id from custom URL. Check the custom url");
    }

    public Object updateStateOfAParticipant(
            String drillId,
            String participantId,
            ParticipantState participantState,
            InternityUser user) {
        try {
            Optional<DrillParticipant> drillParticipantObj =
                    drillParticipantRepository.findById(participantId);
            if (drillParticipantObj.isPresent()) {
                DrillParticipant drillParticipant = drillParticipantObj.get();
                drillParticipant.setParticipantState(participantState.getValue());
                return drillParticipantRepository.save(drillParticipant);
            }
        } catch (Exception e) {
            log.error("Exception while updating the state of the participant {}", e);
        }
        return commonUtils.message(
                HttpStatus.INTERNAL_SERVER_ERROR, "Failed to update the state of the participant");
    }

    public ParticipantSearchResultDto searchParticipants(
            SearchParticipantCriteria searchCriteria,
            int offset,
            int limit,
            String order,
            String profile) {
        log.info("Search criteria: {}", searchCriteria);
        ParticipantSearchResultDto participantSearchResultDTO = null;
        try {
            // log.info("Search criteria: {}", searchCriteria);
            List<DrillTeams> drillTeamsList = new ArrayList<>();
            if (!searchCriteria.getDrillId().equals("all")) {
                drillTeamsList = drillTeamsRepository.findByDrillId(searchCriteria.getDrillId());
            } else {
                drillTeamsList = drillTeamsRepository.findAll();
            }

            String[] sort = order.split("\\.");
            Sort direction =
                    Sort.by(
                            "desc".equalsIgnoreCase(sort[1])
                                    ? Sort.Direction.DESC
                                    : Sort.Direction.ASC,
                            sort[0]);

            Page<DrillParticipant> page =
                    drillParticipantRepository.findAll(
                            new DrillParticipantSpecification(searchCriteria),
                            OffsetBasedPageRequest.of(offset, limit, direction));
            Map<String, DrillTeams> drillTeamsMap = new HashMap<>();

            for(DrillTeams drillTeams : drillTeamsList){
                drillTeamsMap.put(drillTeams.getTeamId(), drillTeams);
            }

            List<DrillTeams> finalDrillTeamsList = drillTeamsList;

            //Get a map of Drill id and Drill name
            Map<String, String> drillIdAndDrillName = getDrillIdAndDrillNameMap();

            List<DrillParticipant> participantList =
                    page.getContent().stream()
                            .map(
                                    x ->
                                            setTeamAndThemeDetailsInDrillParticipant(
                                                    x, drillTeamsMap))
                            .collect(Collectors.toList());

            List<DrillParticipantDto> participants =
                    participantList.stream()
                            .map(participant -> new DrillParticipantDto(participant))
                            .collect(Collectors.toList());

            String result =
                    new ObjectMapper()
                            .writerWithView(SearchProfiles.getProfileByName(profile))
                            .writeValueAsString(participants);

            participants =
                    new ObjectMapper()
                            .readValue(result, new TypeReference<List<DrillParticipantDto>>() {
                            });

            participantSearchResultDTO =
                    ParticipantSearchResultDto.builder()
                            .Details(participants)
                            .totalRecordCount(page.getTotalElements())
                            .build();

            return participantSearchResultDTO;

        } catch (Exception e) {
            log.error("Exception while searching jobs {}", e);
        }
        return participantSearchResultDTO;
    }
    private DrillParticipant setTeamAndThemeDetailsInDrillParticipant(
            DrillParticipant drillParticipant, Map<String, DrillTeams> drillTeamsMap) {
        try {

            Map<String, String> drillIdAndDrillName = getDrillIdAndDrillNameMap();

            List<TeamsParticipants> listOfAllTeamsEitherAcceptedOrLeadingOrPending =
                    teamsParticipantsRepository.findByParticipantId(
                            drillParticipant.getParticipantId());

            Map<String, TeamsParticipants> listOfTeamsParticipants = new HashMap<>();

            for (TeamsParticipants teamsParticipant : listOfAllTeamsEitherAcceptedOrLeadingOrPending) {
                listOfTeamsParticipants.put(teamsParticipant.getTeamId(), teamsParticipant);
            }

            drillParticipant.setDrillName(drillIdAndDrillName.get(drillParticipant.getDrillId()));

            Map<String, Boolean> drillTeamJoiningStatusMap =
                    getTeamForTheParticipantv2(
                            //list of the teams either pending, accepted or leading
                            listOfAllTeamsEitherAcceptedOrLeadingOrPending);

            if (!drillTeamJoiningStatusMap.isEmpty()) {
                StringBuilder message = new StringBuilder("[PENDING REQUEST] Team Names: ");

                for(String drillTeamId : drillTeamJoiningStatusMap.keySet()){
                    if(drillTeamJoiningStatusMap.get(drillTeamId)){
                        DrillTeams drillTeam = drillTeamsMap.get(drillTeamId);
                        drillParticipant.setTeamId(drillTeam.getTeamId());
                        drillParticipant.setTeamName(drillTeam.getTeamName());
                        drillParticipant.setTeamParticipationMessage(drillTeam.getTeamName());
                        drillParticipant.setTheme(drillTeam.getSelectedTheme());
                        if(drillTeam.getTeamLeadParticipantId().equals(drillParticipant.getParticipantId())){
                            drillParticipant.setCandidateType("TEAM LEAD");
                        }
                        else {
                            drillParticipant.setCandidateType("TEAM MEMBER");
                        }
                        message=null;
                        break;
                    }
                    else {
                        message = message.append(drillTeamsMap.get(drillTeamId).getTeamName());
                        if(drillTeamJoiningStatusMap.size()>1){
                            message = message.append(",");
                        }
                    }
                }
                if (message != null) {
                    drillParticipant.setTeamParticipationMessage(message.toString());
                    drillParticipant.setTeamId("NA");
                    drillParticipant.setTeamName("NA");
                    drillParticipant.setTheme("NA");
                    drillParticipant.setCandidateType("NA");
                }
            }
            else {
                drillParticipant.setTeamParticipationMessage("NO REQUEST SENT");
                drillParticipant.setTeamId("NA");
                drillParticipant.setTeamName("NA");
                drillParticipant.setTheme("NA");
                drillParticipant.setCandidateType("NA");
            }
        } catch (Exception e) {
            log.error(
                    "Exception while setting team and theme details with the participant {} ::: error {}",
                    drillParticipant.getParticipantId(),
                    e);
        }
        return drillParticipant;
    }

    private void assignDrillNameTeamAndTheme(
            ParticipantSearchResultDto participantSearchResultDTO) {
        Map<String, String> drillIdAndDrillName = getDrillIdAndDrillNameMap();
        Map<String, String> teamIdAndTeamName = getTeamIdAndTeamName();

        List<DrillParticipantDto> resultList = new ArrayList<>();

        List<DrillParticipantDto> drillParticipantDtos = participantSearchResultDTO.getDetails();

        for (int i = 0; i < drillParticipantDtos.size(); i++) {
            drillParticipantDtos
                    .get(i)
                    .setDrillName(
                            drillIdAndDrillName.get(drillParticipantDtos.get(i).getDrillId()));

            Optional<TeamsParticipants> participantWithTeaminfo =
                    getTeamInfoForParticipant(
                            drillParticipantDtos.get(i).getParticipantId(),
                            drillParticipantDtos.get(i).getDrillId());

            if (participantWithTeaminfo.isPresent()) {
                TeamsParticipants teamsParticipant = participantWithTeaminfo.get();
                drillParticipantDtos
                        .get(i)
                        .setTeamName(teamIdAndTeamName.get(teamsParticipant.getTeamId()));
            }
        }
        participantSearchResultDTO.setDetails(drillParticipantDtos);
        log.info(
                "participant info with drill and team name {}",
                participantSearchResultDTO.getDetails());
    }

    private DrillParticipant setTeamAndThemeDetailsInDrillParticipantv2(
            DrillParticipant drillParticipant, List<DrillTeams> drillTeamsList) {
        try {

            Map<String, String> drillIdAndDrillName = getDrillIdAndDrillNameMap();

            List<TeamsParticipants> teamsParticipantsList =
                    teamsParticipantsRepository.findByParticipantId(
                            drillParticipant.getParticipantId());

            Map<String, TeamsParticipants> listOfTeamsParticipants = new HashMap<>();

            for (TeamsParticipants teamsParticipant : teamsParticipantsList) {
                listOfTeamsParticipants.put(teamsParticipant.getTeamId(), teamsParticipant);
            }

            DrillTeams drillTeam =
                    getTeamForTheParticipant(
                            listOfTeamsParticipants.keySet(),
                            drillTeamsList,
                            drillParticipant.getParticipantId(),
                            drillParticipant.getDrillId());

            drillParticipant.setDrillName(drillIdAndDrillName.get(drillParticipant.getDrillId()));

            if (null != drillTeam) {
                TeamsParticipants teamsParticipant =
                        listOfTeamsParticipants.get(drillTeam.getTeamId());
                if (teamsParticipant != null && teamsParticipant.isRequestAccepted()) {
                    drillParticipant.setTeamId(teamsParticipant.getTeamId());
                    drillParticipant.setTeamName(drillTeam.getTeamName());
                    drillParticipant.setTeamParticipationMessage(drillTeam.getTeamName());
                    drillParticipant.setTheme(drillTeam.getSelectedTheme());
                } else {
                    drillParticipant.setTeamParticipationMessage(
                            "[PENDING REQUEST] Your request to join "
                                    + "team "
                                    + drillTeam.getTeamName()
                                    + " is yet to be accepted. "
                                    + "Please connect with us at " + techSupportEmail +" if you need any changes");
                }
            } else {
                drillParticipant.setTeamParticipationMessage(
                        "[NOT A MEMBER] You are not a member on a team. "
                                + "Either create a team or join a team."
                                + "Please contact us at " + techSupportEmail + " for any assistance");
            }
        } catch (Exception e) {
            log.error(
                    "Exception while setting team and theme details with the participant {} ::: error {}",
                    drillParticipant.getParticipantId(),
                    e);
        }
        return drillParticipant;
    }


    private DrillParticipant setTeamAndThemeDetailsInDrillParticipant(
            DrillParticipant drillParticipant, List<DrillTeams> drillTeamsList,
            Map<String, String> drillIdAndDrillName) {
        try {

            //List of team participants
            List<TeamsParticipants> teamsParticipantsList =
                    teamsParticipantsRepository.findByParticipantId(
                            drillParticipant.getParticipantId());

            Map<String, TeamsParticipants> listOfTeamsParticipants = new HashMap<>();

            for (TeamsParticipants teamsParticipant : teamsParticipantsList) {
                listOfTeamsParticipants.put(teamsParticipant.getTeamId(), teamsParticipant);
            }

            DrillTeams drillTeam =
                    getTeamForTheParticipant(
                            listOfTeamsParticipants.keySet(),
                            drillTeamsList,
                            drillParticipant.getParticipantId(),
                            drillParticipant.getDrillId());

            drillParticipant.setDrillName(drillIdAndDrillName.get(drillParticipant.getDrillId()));

            if (null != drillTeam) {
                TeamsParticipants teamsParticipant =
                        listOfTeamsParticipants.get(drillTeam.getTeamId());
                if (teamsParticipant != null && teamsParticipant.isRequestAccepted()) {
                    drillParticipant.setTeamId(teamsParticipant.getTeamId());
                    drillParticipant.setTeamName(drillTeam.getTeamName());
                    drillParticipant.setTeamParticipationMessage(drillTeam.getTeamName());
                    drillParticipant.setTheme(drillTeam.getSelectedTheme());
                } else {
                    drillParticipant.setTeamParticipationMessage(
                            "[PENDING REQUEST] Your request to join "
                                    + "team "
                                    + drillTeam.getTeamName()
                                    + " is yet to be accepted. "
                                    + "Please connect with us at " + techSupportEmail + " if you need any changes");
                }
            } else {
                drillParticipant.setTeamParticipationMessage(
                        "[NOT A MEMBER] You are not a member on a team. "
                                + "Either create a team or join a team."
                                + "Please contact us at " + techSupportEmail + " for any assistance");
            }
        } catch (Exception e) {
            log.error(
                    "Exception while setting team and theme details with the participant {} ::: error {}",
                    drillParticipant.getParticipantId(),
                    e);
        }
        return drillParticipant;
    }

    private Map<String, String> getTeamIdAndTeamName() {
        List<DrillTeams> drillTeamsList = drillTeamsRepository.findAll();
        Map<String, String> teamIdAndTeamName = new HashMap<>();
        for (DrillTeams drillTeam : drillTeamsList) {
            teamIdAndTeamName.put(drillTeam.getTeamId(), drillTeam.getTeamName());
        }
        return teamIdAndTeamName;
    }

    private Optional<TeamsParticipants> getTeamInfoForParticipant(
            String participantId, String drillId) {
        try {
            return teamsParticipantsRepository.findByParticipantIdAndIsRequestAccepted(
                    participantId, true);
        } catch (Exception e) {
            log.error("Exception while calling teams for participant search {}", e);
            return Optional.empty();
        }
    }

    //    public Object listActiveandPreviousDrills(String uId, InternityUser user, String name) {
    //        try {
    //            Map<String, List<Drill>> listActiveandPreviousDrill = new HashMap<>();
    //            List<Drill>
    //            if (checkIfUserIsWuelev8Superadmin(uId)) {
    //                List<Drill> listPreviousDrill =
    //
    // drillRepository.findByDrillLatestStatusOrderByCreatedTsDesc(DrillStatus.COMPLETED.name());
    //                List<Drill> listActiveDrill =
    //
    // drillRepository.findByDrillLatestStatusOrderByCreatedTsDesc(DrillStatus.LIVE.name());
    //                listActiveandPreviousDrill.put(
    //                        "Previous",
    //                        listPreviousDrill.isEmpty() ? Collections.emptyList() :
    // listPreviousDrill);
    //                listActiveandPreviousDrill.put(
    //                        "Active",
    //                        listActiveDrill.isEmpty() ? Collections.emptyList() :
    // listActiveDrill);
    //            } else {
    //                String companyId = getCompanyIdFromUId(uId);
    //                log.info("company id {}", companyId);
    //                List<Drill> listPreviousDrill =
    //
    // drillRepository.findByDrillPartnerIdAndDrillLatestStatusOrderByCreatedTsDesc(
    //                                companyId, DrillStatus.COMPLETED.name());
    //                List<Drill> listActiveDrill =
    //
    // drillRepository.findByDrillPartnerIdAndDrillLatestStatusOrderByCreatedTsDesc(
    //                                companyId, DrillStatus.LIVE.name());
    //                listActiveandPreviousDrill.put(
    //                        "Previous",
    //                        listPreviousDrill.isEmpty() ? Collections.emptyList() :
    // listPreviousDrill);
    //                listActiveandPreviousDrill.put(
    //                        "Active",
    //                        listActiveDrill.isEmpty() ? Collections.emptyList() :
    // listActiveDrill);
    //            }
    //            return listActiveandPreviousDrill;
    //        } catch (Exception e) {
    //            log.error("Exception while listing active and previous hackathons {}", e);
    //            return commonUtils.message(
    //                    HttpStatus.INTERNAL_SERVER_ERROR,
    //                    "Failed to list active or previous "
    //                            + "hackathon woth error "
    //                            + e.getMessage());
    //        }
    //    }

    private Map<String, String> getDrillIdAndDrillNameMap() {
        List<Drill> drillList = drillRepository.findAll();
        Map<String, String> drillIdAndDrillName = new HashMap<>();
        for (Drill drill : drillList) {
            drillIdAndDrillName.put(drill.getDrillId(), drill.getDrillName());
        }
        return drillIdAndDrillName;
    }

    public Object listActiveandPreviousDrills(String uId, InternityUser user, String name) {
        try {
            Map<String, List<Drill>> listActiveandPreviousDrill = new HashMap<>();
            if (checkIfUserIsWuelev8Superadmin(uId)) {
                List<Drill> listPreviousDrill =
                        drillRepository.findByDrillEndDtLessThan(LocalDateTime.now());
                List<Drill> listActiveDrill =
                        drillRepository.findByDrillEndDtGreaterThan(LocalDateTime.now());
                listActiveandPreviousDrill.put(
                        "Previous",
                        listPreviousDrill.isEmpty() ? Collections.emptyList() : listPreviousDrill);
                listActiveandPreviousDrill.put(
                        "Active",
                        listActiveDrill.isEmpty() ? Collections.emptyList() : listActiveDrill);
            } else {
                String companyId = getCompanyIdFromUId(uId);
                log.info("company id {}", companyId);
                List<Drill> listPreviousDrill =
                        drillRepository.findByDrillPartnerIdAndDrillEndDtLessThan(
                                companyId, LocalDateTime.now());
                List<Drill> listActiveDrill =
                        drillRepository.findByDrillPartnerIdAndDrillEndDtGreaterThan(
                                companyId, LocalDateTime.now());
                listActiveandPreviousDrill.put(
                        "Previous",
                        listPreviousDrill.isEmpty() ? Collections.emptyList() : listPreviousDrill);
                listActiveandPreviousDrill.put(
                        "Active",
                        listActiveDrill.isEmpty() ? Collections.emptyList() : listActiveDrill);
            }
            return listActiveandPreviousDrill;
        } catch (Exception e) {
            log.error("Exception while listing active and previous hackathons {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to list active or previous "
                            + "hackathon woth error "
                            + e.getMessage());
        }
    }

    private boolean checkIfUserIsWuelev8Superadmin(String uId) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                return (userObj.get()
                        .getURole()
                        .equalsIgnoreCase(UserRoles.WUEDRILLSUPERADMIN.name())
                        || userObj.get().getURole().equalsIgnoreCase(UserRoles.SUPERADMIN.name()));
            }
        } catch (Exception e) {
            log.error("Exception while checking if the user has role of Where U Elevate super admin");
        }
        return false;
    }

    private String getCompanyIdFromUId(String uId) {
        try {
            Optional<CustomerUser> customerUserObj = customerUserRepository.findById(uId);
            if (customerUserObj.isPresent()) {
                return customerUserObj.get().getCompanyId();
            } else {
                return "NOTPRESENT";
            }
        } catch (Exception e) {
            log.error(
                    "Exception while fetching the company id with uId {} ::: with exception {}",
                    uId,
                    e);
            return "Failed to fetch the company id";
        }
    }

    public Object updateListOfDrillSection(
            DrillSectionEnum section, List<Map<String, Object>> payload, InternityUser user) {
        ObjectMapper obj = new ObjectMapper();
        try {
            switch (section.getValue()) {
                case "overview":
                    for (Map<String, Object> map : payload) {
                        DrillOverview drillOverview = obj.convertValue(map, DrillOverview.class);
                        drillOverview
                                .getDrillDescription()
                                .replaceAll("&lt;", "<")
                                .replaceAll("&gt;", ">");
                        return drillOverviewRepository.save(drillOverview);
                    }

                case "prizes":
                    List<DrillPrizes> drillPrizesList = new ArrayList<>();
                    drillPrizesList =
                            payload.stream()
                                    .map(x -> obj.convertValue(x, DrillPrizes.class))
                                    .collect(Collectors.toList());
                    return drillPrizesRepository.saveAll(drillPrizesList);
                case "themes":
                    List<DrillThemes> drillThemesList = new ArrayList<>();
                    drillThemesList =
                            payload.stream()
                                    .map(x -> obj.convertValue(x, DrillThemes.class))
                                    .collect(Collectors.toList());
                    return drillThemesRepository.saveAll(drillThemesList);
                case "opportunities":
                    List<DrillOpportunities> drillOpportunitiesList = new ArrayList<>();
                    drillOpportunitiesList =
                            payload.stream()
                                    .map(x -> obj.convertValue(x, DrillOpportunities.class))
                                    .collect(Collectors.toList());
                    return drillOpportunitiesRepository.saveAll(drillOpportunitiesList);

                case "collaborators":
                    List<DrillCollaborators> drillCollaboratorsList = new ArrayList<>();
                    drillCollaboratorsList = payload.stream()
                            .map(x -> obj.convertValue(x, DrillCollaborators.class))
                            .collect(Collectors.toList());
                    return drillCollaboratorsRepository.saveAll(drillCollaboratorsList);

                case "faq":
                    List<DrillNewFaq> drillFaqList = new ArrayList<>();
                    drillFaqList =
                            payload.stream()
                                    .map(x -> obj.convertValue(x, DrillNewFaq.class))
                                    .collect(Collectors.toList());
                    return drillNewFaqRepository.saveAll(drillFaqList);

                case "judgingcriteria":
                    List<DrillJudgingCriteria> drillJudgingCriteriaList = new ArrayList<>();
                    drillJudgingCriteriaList = payload.stream()
                            .map(x -> obj.convertValue(x, DrillJudgingCriteria.class))
                            .collect(Collectors.toList());
                    return drillJudgingCriteriaRepository.saveAll(drillJudgingCriteriaList);

                case "events":
                    List<DrillEvent> drillEventList = new ArrayList<>();
                    drillEventList = payload.stream()
                            .map(x -> obj.convertValue(x, DrillEvent.class))
                            .collect(Collectors.toList());
                    return drillEventRepository.saveAll(drillEventList);

                case "problemstatement":
                    List<DrillProblemstatement> drillProblemstatementsList = new ArrayList<>();
                    drillProblemstatementsList = payload.stream()
                            .map(x -> obj.convertValue(x, DrillProblemstatement.class))
                            .collect(Collectors.toList());
                    return drillProblemStatementRepository.saveAll(drillProblemstatementsList);

                case "resources":
                    List<DrillResources> drillResourcesList = new ArrayList<>();
                    drillResourcesList = payload.stream()
                            .map(x -> obj.convertValue(x, DrillResources.class))
                            .collect(Collectors.toList());
                    return drillResourcesRepository.saveAll(drillResourcesList);

                case "phases":
                    List<DrillPhases> drillPhasesList = new ArrayList<>();
                    drillPhasesList = payload.stream()
                            .map(x -> obj.convertValue(x, DrillPhases.class))
                            .collect(Collectors.toList());
                    return drillPhasesRepository.saveAll(drillPhasesList);

                case "custom":
                    List<DrillCustom> drillCustoms = new ArrayList<>();
                    drillCustoms = payload.stream()
                            .map(x -> obj.convertValue(x, DrillCustom.class))
                            .collect(Collectors.toList());
                    return drillCustomRepository.saveAll(drillCustoms);

                case "organiserdetail":
                    List<DrillOrganiserDetails> drillOrganiserDetails = new ArrayList<>();
                    drillOrganiserDetails = payload.stream()
                            .map(x -> obj.convertValue(x, DrillOrganiserDetails.class))
                            .collect(Collectors.toList());
                    return drillOrganiserDetailsRepository.saveAll(drillOrganiserDetails);
            }
        } catch (Exception e) {
            log.error("Exception while updating list of section of Drill {}", e);
        }
        return null;
    }

    public Object updateStateOfAParticipantInBulk(
            String drillId,
            String listOfParticipantEmail,
            ParticipantState participantState,
            InternityUser user) {
        try {
            StringBuilder report = new StringBuilder();
            for (String participantEmail : listOfParticipantEmail.split(",")) {
                Optional<DrillParticipant> drillParticipantObj =
                        drillParticipantRepository.findByDrillIdAndEmail(
                                drillId, participantEmail.trim());
                if (drillParticipantObj.isPresent()) {
                    report.append(
                            updateParticipantState(
                                    drillParticipantObj.get(), participantState.getValue()));
                } else {
                    report.append(
                            "[NOT UPDATED] State does not get "
                                    + "updated for participant with email "
                                    + participantEmail
                                    + " \\n");
                }
            }
            return commonUtils.message(HttpStatus.OK, report.toString());
        } catch (Exception e) {
            log.error("Exception while bulk updating the participant State {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to update the participant state in bulk");
        }
    }

    private String updateParticipantState(
            DrillParticipant drillParticipant, String participantState) {
        try {
            drillParticipant.setParticipantState(participantState);
            drillParticipantRepository.save(drillParticipant);
            return "Participant state got successfully updated for "
                    + drillParticipant.getEmail()
                    + "\\n";
        } catch (Exception e) {
            return "[NOT UPDATED] Participant State not updated for " + drillParticipant.getEmail();
        }
    }

    public Map<String, List<String>> getHackathonOption() {
        try {
            log.info("Adding Hackathon common value");
            HashMap<String, List<String>> map = new HashMap<>();
            List<String> nature = new ArrayList<>();
            for (NatureOfHackathon natureHackathon : NatureOfHackathon.values())
                nature.add(String.valueOf(natureHackathon.getValue()));
            map.put("natureOfHackathon", nature);
            List<String> purpose = new ArrayList<>();
            for (PurposeOfHackathon purposeHackathon : PurposeOfHackathon.values())
                purpose.add(String.valueOf(purposeHackathon.getValue()));
            map.put("purposeOfHackathon", purpose);
            List<String> type = new ArrayList<>();
            for (TypeOfHackathon typeHackathon : TypeOfHackathon.values())
                type.add(String.valueOf(typeHackathon.getValue()));
            map.put("typeOfHackathon", type);
            List<String> status = new ArrayList<>();
            for (HackathonStatus hackathonStatus : HackathonStatus.values())
                status.add(String.valueOf(hackathonStatus.getValue()));
            map.put("hackathonStatus", status);
            List<String> invitation = new ArrayList<>();
            for (InvitationType invitationType : InvitationType.values())
                invitation.add(String.valueOf(invitationType.getValue()));
            map.put("invitationType", invitation);
            List<String> eligibility = new ArrayList<>();
            for (DrillEligibilityType eligibilityType : DrillEligibilityType.values())
                eligibility.add(String.valueOf(eligibilityType.getValue()));
            map.put("eligibility", eligibility);
            return map;
        } catch (Exception e) {
            log.error("Failed to save the common value for hackathon {}", e);
            return null;
        }
    }

    public Object getDrillCommonValues(InternityUser user) {
        Map<String, Object> commonvalues = new HashMap<>();
        List<String> listOfStates = drillParticipantStateMasterRepository.findAllStates();
        commonvalues.put("participantStates", listOfStates);

        return commonvalues;
    }

    public List<DrillParticipantDto> downloadSearchParticipants(
            SearchParticipantCriteria searchCriteria,
            int offset,
            int limit,
            String order,
            String name) {
        try {
            ParticipantSearchResultDto participantSearchResultDto =
                    this.searchParticipants(searchCriteria, offset, limit, order, name);
            return participantSearchResultDto.getDetails();
        } catch (Exception e) {
            log.error(
                    "Exception while downloading search participants into an Excel file "
                            + e.getMessage());
            return null;
        }
    }

    public ByteArrayInputStream getCSVLoad(List<DrillParticipantDto> drillParticipantDtos, String drillId) {
        Optional<Drill> drillOptional = drillRepository.findById(drillId);
        Drill drill = drillOptional.get();
        boolean isDrillPaid = drill.getIsDrillPaid(); // Check if the drill is paid

        final CSVFormat format = CSVFormat.DEFAULT
                .withQuoteMode(QuoteMode.MINIMAL);

        // Create a list to hold the headers
        List<String> headers = new ArrayList<>(Arrays.asList(
                "Full name",
                "Email id",
                "Contact Number",
                "Member Type",
                "Team Name",
                "Theme",
                "Team joining state",
                "Registered Date",
                "Current Location",
                "Years of experience",
                "College Name",
                "Resume",
                "Skills",
                "Willing for Job",
                "How did you hear about us"
        ));

        // Check if the drill is paid, then add the "Payment Status" header
        if (isDrillPaid) {
            headers.add("Payment Status");
        }

        format.withHeader(headers.toArray(new String[0]));

        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            // Print the header row
            csvPrinter.printRecord(headers);

            // Print participant data
            for (DrillParticipantDto drillParticipant : drillParticipantDtos) {
                List<String> data = new ArrayList<>(); // Create a mutable list for each participant

                // Add other fields to the data list
                data.add(drillParticipant.getFullName() + "");
                data.add(drillParticipant.getEmail() + "");
                data.add(drillParticipant.getContact() + "");
                data.add(drillParticipant.getCandidateType() + "");
                data.add(drillParticipant.getTeamName() + "");
                data.add(drillParticipant.getTheme() + "");
                data.add(drillParticipant.getTeamParticipationMessage() + "");
                data.add(drillParticipant.getUpdatedTs() + "");
                data.add(drillParticipant.getCurrentLoc() + "");
                data.add(drillParticipant.getYearsOfExperience() + "");
                data.add(drillParticipant.getClgName() + "");
                data.add(drillParticipant.getResumeLink() + "");
                data.add(drillParticipant.getSkills() + "");
                data.add(drillParticipant.getWillingForJob() + "");
                data.add(drillParticipant.getAffiliatePlatform()+"");


                // Check if the drill is paid, then add the payment status
                if (isDrillPaid) {
                    data.add(drillParticipant.getPaymentStatus() + "");
                }

                // Print the record to CSV
                csvPrinter.printRecord(data);
            }
            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
        }
    }



    private String getTeamMemberLeader(String participantId, Set<String> teamLeaderParticipantIds) {
        if (teamLeaderParticipantIds.contains(participantId)) {
            return "Team Leader";
        }
        return "Team Member";
    }

    private Map<String, DrillParticipant> fetchTeamLeadersDetails(Set<String> teamLeaderIds) {
        List<DrillParticipant> teamLeaders = drillParticipantRepository.findAllById(teamLeaderIds);
        return teamLeaders.stream().collect(Collectors.toMap(DrillParticipant::getParticipantId, Function.identity()));
    }

    private String getRequestedTeamDetails(String participantId) {
        List<TeamsParticipants> teamsParticipantList = teamsParticipantsRepository.findByParticipantId(participantId);

        if (teamsParticipantList.isEmpty()) {
            return null;
        }

        Set<String> teamLeaderIds = new HashSet<>();
        Map<String, String> teamNameMap = new HashMap<>();

        // Filter out participants who have at least one accepted request
        boolean hasAcceptedRequest = teamsParticipantList.stream().anyMatch(TeamsParticipants::isRequestAccepted);

        if (hasAcceptedRequest) {
            // Filter the list to include only records with isRequestAccepted as false
            List<TeamsParticipants> filteredList = teamsParticipantList.stream()
                    .filter(participant -> !participant.isRequestAccepted())
                    .collect(Collectors.toList());

            for (TeamsParticipants teamsParticipant : filteredList) {
                String teamId = teamsParticipant.getTeamId();
                Optional<DrillTeams> teamObj = drillTeamsRepository.findById(teamId);
                String teamLeaderParticipantId = "";
                if (teamObj.isPresent()) {
                    String teamName = teamObj.get().getTeamName();
                    teamLeaderParticipantId = teamObj.get().getTeamLeadParticipantId();
                    teamNameMap.put(teamId, teamName);
                    teamLeaderIds.add(teamLeaderParticipantId);
                }
                teamLeaderIds.add(teamLeaderParticipantId);
            }

            Map<String, DrillParticipant> teamLeadersDetails = fetchTeamLeadersDetails(teamLeaderIds);

            StringBuilder requestedTeamDetails = new StringBuilder();
            int teamCounter = 1;

            for (TeamsParticipants teamsParticipant : filteredList) {
                String teamId = teamsParticipant.getTeamId();
                String teamName = teamNameMap.get(teamId);
                String teamLeaderParticipantId = teamsParticipant.getParticipantId();
                DrillParticipant teamLeader = teamLeadersDetails.get(teamLeaderParticipantId);

                // Append team details to the StringBuilder
                requestedTeamDetails.append(teamCounter).append(". ");
                requestedTeamDetails.append("Team Name: ").append(teamName != null ? teamName : "").append(", ");
                requestedTeamDetails.append("Team Leader: ").append(teamLeader != null ? teamLeader.getFullName() : "").append(", ");
                requestedTeamDetails.append("Team Leader Email: ").append(teamLeader != null ? teamLeader.getEmail() : "").append(", ");
                requestedTeamDetails.append("Team Leader Contact: ").append(teamLeader != null ? teamLeader.getContact() : "").append("\n");
                teamCounter++;
            }

            return requestedTeamDetails.toString();
        } else {
            log.error("Participant already joined in a team");
            return null;
        }
    }

    public Object showOrHideDrill(String drillId, boolean action, InternityUser user) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {
                Drill drill = drillObj.get();
                drill.setActive(action);
                return drillRepository.save(drill);
            }
        } catch (Exception e) {
            log.error("Exception while showing or hiding the drill {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while showing or hiding the drill" + e.getMessage());
        }

        return commonUtils.message(
                HttpStatus.INTERNAL_SERVER_ERROR, "Failed to show or hide the drill");
    }

    public Object showOrHideListOfDrillSection(String drillId, Map<DrillSectionEnum, Boolean> sectionMap, InternityUser user) {
        try {
            Optional<Drill> optionalDrill = drillRepository.findById(drillId);
            if (!optionalDrill.isPresent()) {
                return commonUtils.message(HttpStatus.NOT_FOUND, "Drill not found for id: " + drillId);
            }

            Drill drill = optionalDrill.get();

            ObjectMapper objectMapper = new ObjectMapper();

            // Deserialize the JSON string to a Set
            Set<String> setOfSections = new HashSet<>(Arrays.asList(objectMapper.readValue(drill.getDrillSectionComplete(), String[].class)));

            // Update the set based on the provided section map
            sectionMap.forEach((section, isVisible) -> {
                if (isVisible) {
                    setOfSections.add(section.toString().toLowerCase()); // Convert section name to lowercase
                } else {
                    setOfSections.remove(section.toString().toLowerCase()); // Convert section name to lowercase
                }
            });

            // Serialize the Set back to a JSON string
            String updatedSections = objectMapper.writeValueAsString(setOfSections);

            // Update the drill object with the new sections
            drill.setDrillSectionComplete(updatedSections);

            // Save the updated drill object
            drillRepository.save(drill);

            return getDrillSectionWithStatus(drillId, user);
        } catch (JsonProcessingException e) {
            log.error("Exception while updating drill sections", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to update drill sections: " + e.getMessage());
        }
    }


    private boolean sectionIsValid(String drillId, DrillSectionEnum section, InternityUser user) {
        switch (section.getValue()) {
            case "overview":
                return drillOverviewRepository.findById(drillId).isPresent();
            case "prizes":
                return !drillPrizesRepository.findByDrillIdOrderByPositionOrder(drillId).isEmpty();
            case "themes":
                return !drillThemesRepository.findByDrillId(drillId).isEmpty();
            case "opportunities":
                return !drillOpportunitiesRepository.findByDrillId(drillId).isEmpty();
            case "collaborators":
                return !drillCollaboratorsRepository
                        .findByDrillIdAndCollaboratorTypeOrderByPositionOrder(
                                drillId, "collaborator")
                        .isEmpty();
            case "judges":
                return !drillCollaboratorsRepository
                        .findByDrillIdAndCollaboratorTypeOrderByPositionOrder(drillId, "judge")
                        .isEmpty();
            case "sponsors":
                return !drillCollaboratorsRepository
                        .findByDrillIdAndCollaboratorTypeOrderByPositionOrder(drillId, "sponsor")
                        .isEmpty();
            case "speakers":
                return !drillCollaboratorsRepository
                        .findByDrillIdAndCollaboratorTypeOrderByPositionOrder(drillId, "speaker")
                        .isEmpty();
            case "mentors":
                return !drillCollaboratorsRepository
                        .findByDrillIdAndCollaboratorTypeOrderByPositionOrder(drillId, "mentor")
                        .isEmpty();
            case "faqs":
                return drillNewFaqRepository.findByDrillId(drillId).isEmpty();
            case "judgingcriteria":
                return !drillJudgingCriteriaRepository.findByDrillId(drillId).isEmpty();
            case "events":
                return !drillEventRepository.findByDrillId(drillId).isEmpty();
            case "problemstatement":
                Optional<DrillProblemstatement> problemstatementObj =
                        drillProblemStatementRepository.findByDrillId(drillId);
                return problemstatementObj.isPresent();
            case "resources":
                return drillResourcesRepository.findByDrillId(drillId).isPresent();
            case "teams":
                return isDrillTeamBased(drillId);
            case "custom":
                return drillCustomRepository.findByDrillId(drillId).isEmpty();
        }
        return false;
    }

    private boolean isDrillTeamBased(String drillId) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {
                JSONObject jsonObject = new JSONObject(drillObj.get().getDrillTeamSize());
                return Integer.parseInt(jsonObject.get("max") + "") > 1;
            }
        } catch (Exception e) {
            log.error("Exception while checking if the drill is team based or not");
        }
        return false;
    }

    public Object showOrHideADrillSection(
            String drillId, DrillSectionEnum section, boolean action, InternityUser user) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {
                Drill drill = drillObj.get();
                ObjectMapper objectMapper = new ObjectMapper();
                Set<String> setOfSections =
                        objectMapper.readValue(
                                drill.getDrillSectionComplete().toLowerCase(),
                                new TypeReference<Set<String>>() {
                                });
                if (action) {
                    setOfSections.add(section.getValue());
                } else {
                    setOfSections.remove(section.getValue());
                }
                List<String> resultantList = new ArrayList<>();
                for (String sectionStr : setOfSections) {
                    resultantList.add("\"" + sectionStr + "\"");
                }
                drill.setDrillSectionComplete(resultantList.toString());
                return drillRepository.save(drill);
            }
        } catch (Exception e) {
            log.error("Exception while showing or hiding a drill section {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while showing or hiding a drill section" + e.getMessage());
        }

        return commonUtils.message(
                HttpStatus.INTERNAL_SERVER_ERROR, "Failed to show or hide a drill section");
    }


    public Object getDrillSectionWithStatus(String drillId, InternityUser user) {
        try {
            Map<String, Boolean> mapOfSectionWithStatus = new HashMap<>();
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {
                Drill drill = drillObj.get();
                ObjectMapper objectMapper = new ObjectMapper();
                List<String> listOfSections =
                        objectMapper.readValue(
                                drill.getDrillSectionComplete().toLowerCase(),
                                new TypeReference<List<String>>() {
                                });
                for (DrillSectionEnum sectionEnum : DrillSectionEnum.values()) {
                    if (listOfSections.contains(sectionEnum.getValue())) {
                        mapOfSectionWithStatus.put(sectionEnum.getValue(), true);
                    } else {
                        mapOfSectionWithStatus.put(sectionEnum.getValue(), false);
                    }
                }
            }
            return mapOfSectionWithStatus;
        } catch (Exception e) {
            log.error("Exception while fetching the section of a drill {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while fetching the sections" + "of a Drill " + e.getMessage());
        }
    }

    public boolean deleteSection(String drillId, DrillSectionEnum section, String sectionId) {
        try {
            switch (section.getValue()) {
                case "overview":
                    drillOverviewRepository.deleteById(drillId);
                    return true;
                case "prizes":
                    drillPrizesRepository.deleteById(sectionId);
                    return true;
                case "themes":
                    drillThemesRepository.deleteById(sectionId);
                    return true;
                case "opportunities":
                    drillOpportunitiesRepository.deleteById(sectionId);
                    return true;
                case "collaborators":
                    drillCollaboratorsRepository.deleteById(sectionId);
                    return true;
                case "judgingcriteria":
                    drillJudgingCriteriaRepository.deleteById(sectionId);
                    return true;
                case "events":
                    drillEventRepository.deleteById(Long.parseLong(sectionId));
                    return true;
                case "problemstatement":
                    drillProblemStatementRepository.deleteById(drillId);
                    return true;
                case "phases":
                    List<DrillPhases> drillPhaseList = drillPhasesRepository.findByDrillId(drillId);
                    if (drillPhaseList.size() > 1) {
                        drillPhasesRepository.deleteById(sectionId);
                        Drill drill = drillRepository.findById(drillId).get();
                        updatePhasesPositions(drill);
                        updateStartAndEndDateOfDrill(drill);
                        return true;
                    }
                    return false;
                case "organiserdetails":
                    drillOrganiserDetailsRepository.deleteById(sectionId);
                    return true;
                case "custom":
                    drillCustomRepository.deleteById(sectionId);
                    return true;
                case "faq":
                    drillNewFaqRepository.deleteById(sectionId);
                    return true;
                default:
                    log.error("section name was wrong");
                    return false;
            }
        } catch (Exception e) {
            log.error("Error while deleting section", e);
            return false;
        }
    }

    public Object manageProblemStatement(String drillId, String uId, InternityUser internityUser) {
        try {
            Optional<User> user = userRepository.findById(uId);
            if (user.isPresent()) {
                if (user.get().getURole().contains(UserRoles.WUEDRILLSUPERADMIN.name())
                        || user.get().getURole().contains(UserRoles.SUPERADMIN.name())
                        || user.get().getURole().contains(UserRoles.DRILLADMIN.name())) {
                    Optional<DrillProblemstatement> problemstatementObj =
                            drillProblemStatementRepository.findByDrillId(drillId);
                    if (problemstatementObj.isPresent()) {
                        return problemstatementObj.get();
                    }
                }
            } else {
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "User does not exist");
            }
        } catch (Exception e) {
            log.error("Exception while fetching problem statement for manage Drill");
        }
        return Collections.EMPTY_LIST;
    }

    public Map<String, String> sendMailToInviteForDrill(String emailIdList, String uId, String drillId) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            List<DrillPrizes> prizesList =
                    drillPrizesRepository.findByDrillIdOrderByPositionOrder(drillId);
            String first = null;
            String second = null;
            String third = null;

            for (DrillPrizes prize : prizesList) {
                if (prize.getPrizeTitle().equalsIgnoreCase("1st prize")) {
                    String firstPrizeValue = prize.getPrizeValue();
                    JSONObject json = new JSONObject(firstPrizeValue);
                    first = json.getString("value");
                } else if (prize.getPrizeTitle().equalsIgnoreCase("2nd prize")) {
                    String secondPrizeValue = prize.getPrizeValue();
                    JSONObject json = new JSONObject(secondPrizeValue);
                    second = json.getString("value");
                } else if (prize.getPrizeTitle().equalsIgnoreCase("3rd prize")) {
                    String thirdPrizeValue = prize.getPrizeValue();
                    JSONObject json = new JSONObject(thirdPrizeValue);
                    third = json.getString("value");
                }
            }
            if (userObj.isPresent() && drillObj.isPresent()) {
                EmailContent emailContent = new EmailContent();
                emailContent.setSubject(
                        "Where U Elevate | Job Invite for "
                                + drillObj.get().getDrillName()
                                + " from "
                                + userObj.get().getFullName());
                emailContent.setTemplateName("DrillInvitationMail");
                emailContent.setJobId(drillObj.get().getDrillId());
                Drill drill = drillObj.get();
                emailContent.setUserName(userObj.get().getFullName());
                String teamSize = drill.getDrillTeamSize();
                JSONObject json = new JSONObject(teamSize);
                String min = json.getString("min");
                String max = json.getString("max");
                emailContent.setMessage(
                        "<div class= Drill-card>"
                                + "  <div class= Drill-info>"
                                + "    <div class= Drill-title><strong>"
                                + drill.getDrillName()
                                + "</strong></div>"
                                + "    <div class= company-info >"
                                + "      <div class= company-name >"
                                + drill.getDrillPartnerName()
                                + "</div>"
                                + "    </div>"
                                + "    <br>"
                                + "    <div class= additional-info >"
                                + "      <span class= salary-value >"
                                + drill.getDrillNature()
                                + "</span>"
                                + "      <span class= experience-value >"
                                + drill.getDrillPurpose()
                                + "</span>"
                                + "      <span class= location-value >"
                                + "TeamSize:"
                                + min
                                + "-"
                                + max
                                + "</span>"
                                + "    </div>"
                                + "  </div>"
                                + "</div><br>"
                                + "<div class= prize-card>"
                                + "  <div class= Drill-info>"
                                + "    <div class= Drill-title>Prizes</div><br><br>"
                                + "<div class=additional-info>"
                                + "  <span class=prize-value>"
                                + "    First Prize"
                                + "    <span class= prize-amount><br><br>Rs."
                                + first
                                + "</span>"
                                + "  </span>"
                                + "  <span class=prize-value>"
                                + "    Second Prize"
                                + "    <span class=prize-amount><br><br>Rs."
                                + second
                                + "</span>"
                                + "  </span>"
                                + "  <span class= prize-value>"
                                + "    Third Prize"
                                + "    <span class=prize-amount><br><br>Rs."
                                + third
                                + "</span>"
                                + "  </span>"
                                + "</div>"
                                + "  </div>"
                                + "</div><br>");
                emailContent.setLink(domainUrl + "/drills/" + drillId);
                String[] emailIds = emailIdList.split(",");
                for (String emailId : emailIds) {
                    messageUtils.sendMail(emailId.trim(), emailContent);
                }
                log.info("Invitation email sent to " + emailIdList + " for drill " + drillId);
                return commonUtils.message(HttpStatus.OK, "Email sent successfully");
            } else {
                log.error("User or drill not found for invitation email");
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "User or job not found for inviting via email");
            }
        } catch (Exception exception) {
            log.error("Error sending invitation email: " + exception.getMessage());
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while sending email");
        }
    }

    public Map<String, String> sendMailForDrillInvite(
            String uId, String jobId, String emailIdList, InternityUser user) {
        try {
            sendMailToInviteForDrill(emailIdList, uId, jobId);
            return commonUtils.message(HttpStatus.OK, "Mail sent successfully for Hackathon Invite");
        } catch (Exception e) {
            log.error("Exception while sending Mail {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while sending email");

        }
    }

    public Map<String, Object> fetchDrills(String drillId, String type, String status, String mode, String eligibility,
                                           String invitationType, String purpose, String isActive, String partnerId,
                                           int limit, int offset, String order, InternityUser user) {
        Sort sort = Sort.by(order.equals("DESC") ? Sort.Direction.DESC : Sort.Direction.ASC, "createdTs");
        Pageable pageable = PageRequest.of(offset, limit, sort);

        Specification<Drill> spec = Specification.where(null);

        if (!isActive.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("isActive"), Boolean.parseBoolean(isActive)));
        }

        if (!drillId.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("drillId"), drillId));
        }

        if (!type.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("drillType"), type));
        }

        if (!purpose.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("drillPurpose"), purpose));
        }

        if (!status.equals("all")) {
            if (status.equalsIgnoreCase("Live")) {
                spec = spec.and((root, query, cb) -> cb.greaterThanOrEqualTo(root.get("drillEndDt"), LocalDateTime.now()))
                        .and((root, query, cb) -> cb.lessThanOrEqualTo(root.get("drillStartDt"), LocalDateTime.now()));
            } else if (status.equalsIgnoreCase("Completed")) {
                spec = spec.and((root, query, cb) -> cb.lessThanOrEqualTo(root.get("drillEndDt"), LocalDateTime.now()));
            } else {
                spec = spec.and((root, query, cb) -> cb.greaterThanOrEqualTo(root.get("drillStartDt"), LocalDateTime.now()));
            }
        }

        if (!mode.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("drillNature"), mode));
        }

        if (!eligibility.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("drillHiringExp"), eligibility));
        }

        if (!invitationType.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("drillInvitationType"), invitationType));
        }

        if (!partnerId.equals("all")) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("drillPartnerId"), partnerId));
        }

        Page<Drill> page = drillRepository.findAll(spec, pageable);
        List<Drill> content = page.getContent();

        Map<String, Object> response = new HashMap<>();
        response.put("totalRecords", page.getTotalElements());
        response.put("data", setPartnerWebsiteLink(content));

        return response;
    }


    public ResponseEntity<Boolean> fetchPublishRequest(String drillId, InternityUser user) {
        try {
            Optional<DrillPublishRequests> drillPublishRequestsObj =
                    drillPublishRequestsRepository.findByDrillId(drillId);
            if (drillPublishRequestsObj.isPresent()) {
                return new ResponseEntity(
                        true,
                        HttpStatus.OK);
            } else {
                return new ResponseEntity(
                        false,
                        HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while sending publish request to admin ::: {}", e);
        }
        return new ResponseEntity(
                true,
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private Map<String, String> userHasWueSuperadminAccessOnDrill(String uId, InternityUser internityUser) {
        Map<String, String> userRole = userManagementService.fetchRoleAccessForAUser(uId, internityUser);
        if (userRole.containsKey("role")) {
            userRole.put("hasAccess", commonUtils.isUserHasWueSuperadminAccessToDrill(commonUtils.getRoleEnum(userRole.get("role"))) + "");
            return userRole;
        } else {
            return userRole;
        }
    }

//    private Map<String, Object> userHasCustomerSuperadminAccessOnDrill(String uId, InternityUser internityUser){
//        Map<String, Object> userRole = userManagementService.fetchRoleAccessForAUser(uId, internityUser);
//        if(userRole.containsKey("role")){
//            userRole.put("hasAccess", commonUtils.isUserHasCustomerSuperadminAccessToDrill((UserRoles) userRole.get("role")));
//            return userRole;
//        }
//        else {
//            return userRole;
//        }
//    }
//    private Map<String, Object> userHasCustomerAdminAccessOnDrill(String uId, InternityUser internityUser){
//        Map<String, Object> userRole = userManagementService.fetchRoleAccessForAUser(uId, internityUser);
//        if(userRole.containsKey("role")){
//            userRole.put("hasAccess", commonUtils.isUserHasCustomerAdminAccessToDrill((UserRoles) userRole.get("role")));
//            return userRole;
//        }
//        else {
//            return userRole;
//        }
//    }

    private Map<String, String> userHasWueAdminAccessOnDrill(String uId, InternityUser internityUser) {
        Map<String, String> userRole = userManagementService.fetchRoleAccessForAUser(uId, internityUser);
        if (userRole.containsKey("role")) {
            userRole.put("hasAccess", commonUtils.isUserHasWueAdminAccessToDrill(commonUtils.getRoleEnum(userRole.get("role"))) + "");
            return userRole;
        } else {
            return userRole;
        }
    }

    public Map<String, String> saveDrillPhase(
            String drillId, String uId, DrillPhases payload, InternityUser user) {
        try {
            boolean isUserWueSuperAdmin;
            Map<String, String> userHasWueSuperadminAccess =
                    userHasWueSuperadminAccessOnDrill(uId, user);
            if (userHasWueSuperadminAccess.containsKey("role")) {
                isUserWueSuperAdmin = Boolean.parseBoolean(userHasWueSuperadminAccess.get("hasAccess"));
            } else {
                return userHasWueSuperadminAccess;
            }

            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {
                Drill drill = drillObj.get();
                if (drill.isActive() && !isUserWueSuperAdmin) {
                    return commonUtils.messageWithStatus(
                            HttpStatus.INTERNAL_SERVER_ERROR,
                            "Update is restricted with "
                                    + "published hackathon. Please contact support team at "
                                    + techSupportEmail);
                }
                payload.setDrillId(drillId);

                // if start month and end month not null
                if (!payload.isDateConfirmed()) {
                    if (payload.getStartMonth() != null && payload.getEndMonth() != null) {

                        // Parse the input strings into LocalDateTime objects
                        LocalDateTime startMonth = LocalDateTime.parse(payload.getStartMonth().replace("Z", ""));
                        LocalDateTime endMonth = LocalDateTime.parse(payload.getEndMonth().replace("Z", ""));
                        if (startMonth.isAfter(endMonth)) {
                            return commonUtils.messageWithStatus(
                                    HttpStatus.INTERNAL_SERVER_ERROR,
                                    "Start month cannot be after end month");
                        }
                        // Get the current month
                        Month currentMonth = LocalDateTime.now().getMonth();

                        // Extract the months from the input LocalDateTime objects
                        Month startInputMonth = startMonth.getMonth();
                        Month endInputMonth = endMonth.getMonth();

                        // Initialize variables for start and end DateTime
                        LocalDateTime startDateTime;
                        LocalDateTime endDateTime;

                        // Check if the start month is the same as the current month
                        if (startInputMonth == currentMonth) {
                            // Set startDateTime to the current LocalDateTime
                            startDateTime = LocalDateTime.now();
                        } else {
                            // Set startDateTime to the start of the input start month
                            startDateTime = startMonth.withDayOfMonth(1).withHour(0).withMinute(0).withSecond(0);
                        }

                        // Set endDateTime to the end of the input end month
                        endDateTime = endMonth.withDayOfMonth(endMonth.getMonth().length(endMonth.toLocalDate().isLeapYear())).withHour(23).withMinute(59).withSecond(59);
                        payload.setStartMonth(startDateTime.toString());
                        payload.setEndMonth(endDateTime.toString());
                        payload.setPhaseStartDt(startDateTime);
                        payload.setPhaseEndDt(endDateTime);
                    } else {
                        return commonUtils.messageWithStatus(
                                HttpStatus.INTERNAL_SERVER_ERROR,
                                "Please select start month and end month if date is not confirmed");
                    }
                }
                if (payload.getPhaseStartDt().isAfter(payload.getPhaseEndDt())) {
                    return commonUtils.messageWithStatus(
                            HttpStatus.INTERNAL_SERVER_ERROR,
                            "Phase Start date should be less than Phase End date");
                }
                List<DrillPhases> listOfPhases =
                        drillPhasesRepository.findByDrillIdOrderByPhaseStartDtAsc(drillId);
                if (listOfPhases.size() > 1) {
                    Map<String, String> validPhaseMsg = validateDatesSequenceOfPhases(payload);
                    if (!validPhaseMsg.isEmpty()) {
                        return commonUtils.messageWithStatus(
                                HttpStatus.INTERNAL_SERVER_ERROR, validPhaseMsg.get("msg"));
                    }
                    if (!drill.isSelfPaced()) {
                        Map<String, String> sequenceOfDatesMsg =
                                checkDatesOfPhasesForNonSelfpaced(listOfPhases);
                        if (!sequenceOfDatesMsg.isEmpty()) {
                            return commonUtils.messageWithStatus(
                                    HttpStatus.INTERNAL_SERVER_ERROR,
                                    sequenceOfDatesMsg.get("msg"));
                        }
                    }
                }
                if(StringUtils.isBlank(payload.getPhaseId())) {
                    payload.setPhaseStatus(DrillPhaseStatus.TOBEGIN.name());
                }
                drillPhasesRepository.save(payload);
                updatePhasesPositions(drill);
                updateStartAndEndDateOfDrill(drillObj.get());
            } else {
                return commonUtils.messageWithStatus(
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Drill is not present with this id ::: " + drillId);
            }

        } catch (Exception e) {
            log.error("Exception while saving the phase for drill with id ::: {} ::: {}", drillId, e);
        }
        return commonUtils.messageWithStatus(HttpStatus.OK, "Phase details saved successfully");
    }

    /**
     * Ensuring to update the start and end date of the hackathon
     * with creation of the hackathon phases and any addition or
     * updation done over the phases
     *
     * @param savedDrill
     * @return
     */
    private Map<String, String> updateStartAndEndDateOfDrill(Drill savedDrill) {
        try {
            String drillLocation = "";
            List<DrillPhases> drillPhasesList = drillPhasesRepository.findByDrillIdOrderByPhaseStartDtAsc(savedDrill.getDrillId());
            LocalDateTime minDt = drillPhasesList.get(0).getPhaseStartDt() == null
                    ?
                    LocalDateTime.parse(drillPhasesList.get(0).getStartMonth())
                    :
                    drillPhasesList.get(0).getPhaseStartDt();
            LocalDateTime maxDt = drillPhasesList.get(0).getPhaseEndDt() == null
                    ?
                    LocalDateTime.parse(drillPhasesList.get(0).getEndMonth())
                    :
                    drillPhasesList.get(0).getPhaseEndDt();

            if (drillPhasesList.size() > 1) {
                for (DrillPhases drillPhases : drillPhasesList) {

                    if (StringUtils.isBlank(drillLocation)) {
                        drillLocation = drillPhases.getPhaseLoc();
                    } else if (!drillLocation.equalsIgnoreCase(drillPhases.getPhaseLoc())) {
                        drillLocation = NatureOfHackathon.HYBRID.name();
                    }
                    if (minDt.isAfter(drillPhases.getPhaseStartDt())) {
                        minDt = drillPhases.getPhaseStartDt();
                    }
                    if (maxDt.isBefore(drillPhases.getPhaseEndDt())) {
                        maxDt = drillPhases.getPhaseEndDt();
                    }
                }
            }
            savedDrill.setDrillNature(drillLocation);
            savedDrill.setDrillStartDt(minDt);
            if (savedDrill.getDrillStartDt().isAfter(savedDrill.getDrillRegistrationStartDt())) {
                savedDrill.setDrillStartDt(savedDrill.getDrillRegistrationStartDt());
            }
            savedDrill.setDrillEndDt(maxDt);
            if (savedDrill.getDrillEndDt().isBefore(savedDrill.getDrillRegistrationEndDt())) {
                savedDrill.setDrillEndDt(savedDrill.getDrillRegistrationEndDt());
            }
            drillRepository.save(savedDrill);
        } catch (Exception e) {
            log.error("Exception while updating start and end date of Drill ::: {}", e);
        }
        return commonUtils.message(HttpStatus.OK, "Start and end date is saved with Drill");
    }

    public DrillPhases fetchTheLatestPhaseForTheParticipant(String drillId, String participantId) throws Exception {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            Optional<DrillParticipant> drillParticipantObj = drillParticipantRepository.findById(participantId);
            if (drillObj.isPresent() && drillParticipantObj.isPresent()) {
                Drill drill = drillObj.get();
                DrillParticipant drillParticipant = drillParticipantObj.get();

                if (drill.isSelfPaced()) {
                    List<DrillPhases> drillPhasesListInOrder = drillPhasesRepository.findByDrillIdAndPhaseStatusOrderByPhaseStartDtAsc(drillId, DrillPhaseStatus.RUNNING.name());
                    for (DrillPhases drillPhase : drillPhasesListInOrder) {
                        List<DrillParticipantSubmission> drillParticipantSubmission =
                                drillParticipantSubmissionRepository.findByParticipantIdAndPhaseId(participantId, drillPhase.getPhaseId());
                        if (drillParticipantSubmission.size() == 0) {
                            return drillPhase;
                        }
                    }
                    return drillPhasesListInOrder.get(drillPhasesListInOrder.size());
                }

            } else {
                throw new Exception("Either hackathon or participant is not present with the provided ids");
            }
        } catch (Exception e) {
            log.error("Exception while fetching the latest phase for a participant from a hackathon ::: {}", e);
        }
        throw new Exception("Exception while fetching the latest phase for a participant from a hackathon");
    }

    /**
     * Read excel file containing the details of the participants and their teams
     * and the resume
     *
     * @param file
     * @param drillId
     * @return
     */
    public List<String> readFromExcel(MultipartFile file, String drillId, String phaseId, Map<String, String> fieldMapping) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            Drill drill = null;
            if (drillObj.isPresent()) {
                drill = drillObj.get();
            }

            Workbook wb = null;
            List<DrillParticipant> drillParticipantInBulk = new ArrayList<>();
            List<DrillParticipantSubmission> submissionList = new ArrayList<>();
            Map<String, String> participantAndTheme = new HashMap<>();
            Map<String, String> participantAndValue = new HashMap<>();
            Map<String, String> participantAndDescription = new HashMap<>();

            DataFormatter fmt = new DataFormatter();
            Map<String, Integer> mapOfCell = new HashMap<String, Integer>();

            if (file.getOriginalFilename().endsWith("xls")) {
                wb = new HSSFWorkbook(file.getInputStream());
            } else {
                wb = new XSSFWorkbook(file.getInputStream());
            }

            Sheet sheet = wb.getSheetAt(0);
            Row firstRow = sheet.getRow(0);
            short minColIx = firstRow.getFirstCellNum();
            short maxColIx = firstRow.getLastCellNum();

            for (short colIx = minColIx; colIx < maxColIx; colIx++) {
                Cell cell = firstRow.getCell(colIx);
                mapOfCell.put(cell.getStringCellValue(), cell.getColumnIndex());
            }

            if (sheet.getPhysicalNumberOfRows() != 0) {
                for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                    Row row = sheet.getRow(i);
                    if (row == null) {
                        continue;
                    }
                    DrillParticipant drillParticipant = new DrillParticipant();
                    drillParticipant.setDrillId(drill.getDrillId());
                    drillParticipant.setDrillName(drill.getDrillName());

                    if (row.getCell(mapOfCell.get(fieldMapping.get("fullName"))) != null) {
                        try {
                            if (row.getCell(mapOfCell.get(fieldMapping.get("fullName"))).getCellType() == CellType.NUMERIC) {
                                drillParticipant.setFullName(row.getCell(mapOfCell.get(fieldMapping.get("fullName"))).getNumericCellValue() + "");
                            } else if (row.getCell(mapOfCell.get(fieldMapping.get("fullName"))).getCellType() == CellType.ERROR) {
                                drillParticipant.setFullName("NA");
                            } else {
                                drillParticipant.setFullName(row.getCell(mapOfCell.get(fieldMapping.get("fullName"))).getStringCellValue());
                            }
                        } catch (Exception e) {
                            log.error("Error while parsing full name ::: {}", e);
                            drillParticipant.setFullName("NA");
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("email"))) != null) {
                        try {
                            drillParticipant.setEmail(
                                    row.getCell(mapOfCell.get(fieldMapping.get("email"))).getStringCellValue());
                        } catch (Exception e) {
                            log.error("Error while parsing name ::: {}", e);
                            continue;
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("contact"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("contact"))).getCellType() == CellType.NUMERIC) {
                            drillParticipant.setContact(row.getCell(mapOfCell.get(fieldMapping.get("contact"))).getNumericCellValue() + "");
                        } else {
                            drillParticipant.setContact(row.getCell(mapOfCell.get(fieldMapping.get("contact")))
                                    .getStringCellValue());
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("clgSpecialization"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("clgSpecialization"))).getCellType() == CellType.NUMERIC) {
                            drillParticipant.setClgSpecialization(
                                    fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("clgSpecialization")))) + "");
                        } else {
                            drillParticipant.setClgSpecialization(
                                    row.getCell(mapOfCell.get(fieldMapping.get("clgSpecialization"))).getStringCellValue());
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("clgPassingSemester"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("clgPassingSemester"))).getCellType() == CellType.NUMERIC) {
                            drillParticipant.setClgPassingSemester(
                                    getPassingSemester(fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("clgPassingSemester")))) + "")
                            );
                        } else {
                            drillParticipant.setClgPassingSemester(
                                    getPassingSemester(row.getCell(mapOfCell.get(fieldMapping.get("clgPassingSemester"))).getStringCellValue())
                            );
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("clgPassingYear"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("clgPassingYear"))).getCellType() == CellType.NUMERIC) {
                            drillParticipant.setClgPassingYear(
                                    Integer.parseInt(
                                            fmt.formatCellValue(
                                                    row.getCell(
                                                            mapOfCell.get(fieldMapping.get("clgPassingYear")))) + ""));
                        } else {
                            drillParticipant.setClgPassingYear(
                                    Integer.parseInt(
                                            row.getCell(mapOfCell.get(fieldMapping.get("clgPassingYear"))).getStringCellValue()));
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("clgName"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("clgName"))).getCellType() == CellType.NUMERIC) {
                            drillParticipant.setClgName(
                                    fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("clgName")))) + "");
                        } else {
                            drillParticipant.setClgName(
                                    row.getCell(mapOfCell.get(fieldMapping.get("clgName"))).getStringCellValue());
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("teamName"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("teamName"))).getCellType() == CellType.NUMERIC) {
                            drillParticipant.setTeamName(
                                    fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("teamName")))) + "");
                        } else {
                            drillParticipant.setTeamName(
                                    row.getCell(mapOfCell.get(fieldMapping.get("teamName"))).getStringCellValue());
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("candidateType"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("candidateType"))).getCellType() == CellType.NUMERIC) {
                            drillParticipant.setCandidateType(
                                    fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("candidateType")))) + "");
                        } else {
                            drillParticipant.setCandidateType(
                                    row.getCell(mapOfCell.get(fieldMapping.get("candidateType"))).getStringCellValue());
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("theme"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("theme"))).getCellType() == CellType.NUMERIC) {
                            participantAndTheme.put(drillParticipant.getEmail(),
                                    fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("theme")))) + "");
                        } else {
                            participantAndTheme.put(drillParticipant.getEmail(),
                                    row.getCell(mapOfCell.get(fieldMapping.get("theme"))).getStringCellValue());
                        }
                    }


                    if (row.getCell(mapOfCell.get(fieldMapping.get("participantValue"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("participantValue"))).getCellType() == CellType.NUMERIC) {
                            participantAndValue.put(drillParticipant.getEmail(),
                                    fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("participantValue")))) + "");
                        } else {
                            participantAndValue.put(drillParticipant.getEmail(),
                                    row.getCell(mapOfCell.get(fieldMapping.get("participantValue"))).getStringCellValue());
                        }
                    }

                    if (row.getCell(mapOfCell.get(fieldMapping.get("projectDescription"))) != null) {
                        if (row.getCell(mapOfCell.get(fieldMapping.get("projectDescription"))).getCellType() == CellType.NUMERIC) {
                            participantAndDescription.put(drillParticipant.getEmail(),
                                    fmt.formatCellValue(row.getCell(mapOfCell.get(fieldMapping.get("projectDescription")))) + "");
                        } else {
                            participantAndDescription.put(drillParticipant.getEmail(),
                                    row.getCell(mapOfCell.get(fieldMapping.get("projectDescription"))).getStringCellValue());
                        }
                    }
                    log.info(drillParticipant);
                    drillParticipantInBulk.add(drillParticipant);
                }
            }

            log.info(drillParticipantInBulk + "count ::: " + drillParticipantInBulk.size());

            //addSubmission(drillId, phaseId, drillParticipantInBulk, participantAndDescription);

            //iterateAndSaveTeam(drillParticipantInBulk, participantAndTheme, participantAndValue);
            //iterateAndSaveUser(drillParticipantInBulk);
            //return iterateAndSaveUserDetails(userDetailsInBulk);
        } catch (Exception e) {
            log.error("exception {}", e);
        }
        return Collections.EMPTY_LIST;
    }

    private void addSubmission(String drillId, String phaseId, List<DrillParticipant> drillParticipantList, Map<String, String> participantAndDescription) {
        try {
            List<DrillParticipant> drillParticipantListFromDB = drillParticipantRepository.findByDrillId(drillId);
            Map<String, String> participantEmailAndId = new HashMap<>();
            Map<String, String> participantIdAndTeamId = new HashMap<>();
            Map<String, String> participantIdAndTeamName = new HashMap<>();
            Map<String, String> participantIdAndTheme = new HashMap<>();

            for (DrillParticipant drillParticipant : drillParticipantListFromDB) {
                participantEmailAndId.put(drillParticipant.getEmail(), drillParticipant.getParticipantId());
            }

            List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);

            for (DrillTeams drillTeam : drillTeamsList) {
                participantIdAndTeamId.put(drillTeam.getTeamLeadParticipantId(), drillTeam.getTeamId());
                participantIdAndTeamName.put(drillTeam.getTeamLeadParticipantId(), drillTeam.getTeamName());
                participantIdAndTheme.put(drillTeam.getTeamLeadParticipantId(), drillTeam.getSelectedTheme());
            }
            for (DrillParticipant drillParticipant : drillParticipantListFromDB) {

                List<DrillParticipantSubmission> participantSubmission = drillParticipantSubmissionRepository.findByParticipantIdAndPhaseId(drillParticipant.getParticipantId(), phaseId);
                if (!participantSubmission.isEmpty()) {
                    log.info("Submission is already present ");
                    continue;
                }
                if (!participantEmailAndId.keySet().contains(drillParticipant.getEmail())) {
                    log.info("Participant email is not present in Drill participant ::: {}", drillParticipant.getEmail());
                    continue;
                }

                DrillParticipantSubmission drillParticipantSubmission = new DrillParticipantSubmission();
                drillParticipantSubmission.setActiveSubmission(true);
                drillParticipantSubmission.setDrillId(drillParticipant.getDrillId());
                drillParticipantSubmission.setParticipantId(participantEmailAndId.get(drillParticipant.getEmail()));
                drillParticipantSubmission.setOtherSubmission(participantAndDescription.get(drillParticipant.getEmail()));
                drillParticipantSubmission.setPhaseId(phaseId);
                drillParticipantSubmission.setTeamId(participantIdAndTeamId.get(drillParticipant.getParticipantId()));
                drillParticipantSubmission.setProjectName(participantIdAndTeamName.get(drillParticipant.getParticipantId()));
                drillParticipantSubmission.setTheme(participantIdAndTheme.get(drillParticipant.getParticipantId()));
                drillParticipantSubmission.setVideo("{\"link\":\"\",\"instructions\":\"\"}");
                drillParticipantSubmission.setSourceCode("{\"link\":\"\",\"instructions\":\"\",\"repoLink\":\"\"}");
                drillParticipantSubmission.setPresentation("{\"link\":\"\",\"instructions\":\"\"}");
                drillParticipantSubmissionRepository.saveAndFlush(drillParticipantSubmission);
            }
        } catch (Exception e) {
            log.error("Exception while adding submission ::: {}", e);
        }
    }

    private void iterateAndSaveTeam(List<DrillParticipant> drillParticipantInBulk,
                                    Map<String, String> participantAndThemeMap,
                                    Map<String, String> participantAndValueMap) {
        for (DrillParticipant drillParticipant : drillParticipantInBulk) {
            try {
                Optional<DrillParticipant> participantObj = drillParticipantRepository.findByDrillIdAndEmail(drillParticipant.getDrillId(), drillParticipant.getEmail());
                DrillParticipant drillParticipant1 = participantObj.get();
                Optional<DrillTeams> drillTeamsObj = drillTeamsRepository.findByDrillIdAndTeamName(drillParticipant.getDrillId(), drillParticipant.getTeamName());
                if (!drillTeamsObj.isPresent()) {
                    log.info("team leader getting added {}", drillParticipant.getFullName());
                    DrillTeams drillTeams = new DrillTeams();
                    drillTeams.setDrillId(drillParticipant1.getDrillId());
                    drillTeams.setTeamLeadParticipantId(drillParticipant1.getParticipantId());
                    drillTeams.setTeamCurrentSize(6);
                    drillTeams.setTeamName(drillParticipant.getEmail().substring(0, drillParticipant.getEmail().indexOf("@")));
                    drillTeams.setSelectedTheme(participantAndThemeMap.get(drillParticipant1.getEmail()));
                    drillTeams.setParticipantValue(participantAndValueMap.get(drillParticipant1.getEmail()));
                    DrillTeams savedTeam = drillTeamsRepository.saveAndFlush(drillTeams);

                    TeamsParticipants teamsParticipants = new TeamsParticipants();
                    teamsParticipants.setParticipantId(drillParticipant1.getParticipantId());
                    teamsParticipants.setDrillId(drillParticipant.getDrillId());
                    teamsParticipants.setTeamId(savedTeam.getTeamId());
                    teamsParticipants.setRequestAccepted(true);
                    teamsParticipantsRepository.saveAndFlush(teamsParticipants);
                }

//                if(drillTeamsObj.isPresent() && drillParticipant.getCandidateType().equalsIgnoreCase("team member")){
//                    Optional<TeamsParticipants> teamsParticipantsObj = teamsParticipantsRepository.findByTeamIdAndParticipantId(drillTeamsObj.get().getTeamId(), drillParticipant1.getParticipantId());
//                    if (!teamsParticipantsObj.isPresent()) {
//                        log.info("team member getting added {}", drillParticipant.getFullName());
//                        TeamsParticipants teamsParticipants = new TeamsParticipants();
//                        teamsParticipants.setParticipantId(drillParticipant1.getParticipantId());
//                        teamsParticipants.setDrillId(drillParticipant.getDrillId());
//                        teamsParticipants.setTeamId(drillTeamsObj.get().getTeamId());
//                        teamsParticipants.setRequestAccepted(true);
//                        teamsParticipants.setParticipantValue("Team Member");
//                        teamsParticipantsRepository.saveAndFlush(teamsParticipants);
//
//                        DrillTeams drillTeams = drillTeamsObj.get();
//                        drillTeams.setTeamCurrentSize(drillTeams.getTeamCurrentSize() + 1);
//                        drillTeamsRepository.saveAndFlush(drillTeams);
//                    }
//                }
            } catch (Exception e) {
                log.error("Exception while saving team details ::: {}", e);
            }
        }
    }

    private void iterateAndSaveUser(List<DrillParticipant> drillParticipantInBulk) {
        int countOfNewUser = 0;
        int countOfUpdatedUser = 0;
        int countOfNewParticipantAdded = 0;
        int countOfUpdatedParticipantAdded = 0;
        for (DrillParticipant drillParticipant : drillParticipantInBulk) {
            try {
                log.info("saving drill participant ::: {}", drillParticipant.getEmail());
                UserDto user = new UserDto();
                user.setUsername(drillParticipant.getEmail());
                user.setUEmail(drillParticipant.getEmail());
                user.setPassword("User@123");
                user.setActive(true);
                String contactNum = drillParticipant.getContact().replaceAll("\\.", "");
                if (contactNum.contains("E")) {
                    contactNum = contactNum.substring(0, contactNum.indexOf("E"));
                }
                user.setUContact(contactNum);
                user.setUType("NEWUSER");
                user.setFullName(drillParticipant.getFullName());
                user.setUGroup("NEWUSER");
                user.setURole("USER");
                Optional<User> userObj = userRepository.findByEmail(user.getUEmail());
                Optional<User> userContactObj = userRepository.findByuContact(user.getUContact());
                log.info("email user present ::: {} ::: contact user present ::: {}", userObj.isPresent(), userContactObj.isPresent());
                User insertedObj = null;
                if (!userObj.isPresent()) {
                    long unixTime = System.currentTimeMillis() / 1000L;
                    Thread.sleep(500);
                    user.setUContact(unixTime + "");

                    User userEntity = modelMapper.map(user, User.class);
                    insertedObj = userRepository.save(userEntity);
                    log.info("Inserted user object ::: {}", insertedObj);
                    countOfNewUser++;
                    //profileManagementService.save(insertedObj, "", null);
                } else {
                    insertedObj = userObj.get();
                    //insertedObj.setUContact(user.getUContact());
                    countOfUpdatedUser++;
                    userRepository.save(insertedObj);
                }

                Optional<DrillParticipant> drillParticipant1 = drillParticipantRepository.findByDrillIdAndEmail(drillParticipant.getDrillId(), user.getUEmail());
                if (!drillParticipant1.isPresent()) {
                    //log.info("New participant ::: {}", drillParticipant1.get().getEmail());
                    drillParticipant.setPlatformUId(insertedObj.getUId());
                    drillParticipant.setContact(contactNum);
                    drillParticipant.setParticipantType("student");
                    drillParticipant.setSkills("NA");
                    drillParticipant.setYearsOfExperience(0);
                    DrillParticipant savedDrillParticipant = drillParticipantRepository.save(drillParticipant);
                    log.info("saved drill participant ::: {}", savedDrillParticipant);
                    countOfNewParticipantAdded++;
                } else {
                    DrillParticipant drillParticipant2 = drillParticipant1.get();
                    drillParticipant2.setContact(contactNum);
                    drillParticipant2.setParticipantType(StringUtils.isBlank(
                            drillParticipant2.getParticipantType()) ? "student" : drillParticipant2.getParticipantType());
                    drillParticipant2.setSkills(StringUtils.isBlank(
                            drillParticipant2.getSkills()) ? "NA" : drillParticipant2.getSkills());
                    DrillParticipant savedDrillParticipant = drillParticipantRepository.save(drillParticipant2);
                    log.info("updated drill participant ::: {}", savedDrillParticipant);
                    countOfUpdatedParticipantAdded++;
                }
            } catch (Exception e) {
                log.error("Exception while saving user for Drill Participant ::: {}", e);
            }
        }
        log.info("FINAL COUNT ::: new user {} ::: updated user {} ::: new participant {} ::: updated participant {}",
                countOfNewUser, countOfUpdatedUser, countOfNewParticipantAdded, countOfUpdatedParticipantAdded);

    }

    private int getPassingSemester(String clgPassingSemester) {
        if (StringUtils.isBlank(clgPassingSemester)) {
            return 0;
        }
        if (clgPassingSemester.contains("First") || clgPassingSemester.contains("first")) {
            return 1;
        } else if (clgPassingSemester.contains("Second") || clgPassingSemester.contains("second")) {
            return 3;
        } else if (clgPassingSemester.contains("Third") || clgPassingSemester.contains("third")) {
            return 5;
        } else if (clgPassingSemester.contains("Fourth") || clgPassingSemester.contains("fourth")) {
            return 7;
        } else if (clgPassingSemester.contains("Fifth") || clgPassingSemester.contains("fifth")) {
            return 8;
        } else {
            return Integer.parseInt(clgPassingSemester);
        }
    }

    public List<ConfigureParticipantFields> saveOrUpdateParticipantFields(List<ConfigureParticipantFields> payloadList, InternityUser user) {
        try {
            List<ConfigureParticipantFields> existingFields = configureParticipantFieldsRepository.findByDrillId(payloadList.get(0).getDrillId());

            if (!existingFields.isEmpty()) {
                // Update the existing fields, if any.
                for (ConfigureParticipantFields existingField : existingFields) {
                    for (ConfigureParticipantFields updatedField : payloadList) {
                        if (existingField.getId().equals(updatedField.getId())) {
                            // Update the fields that match by ID.
                            existingField.setFields(updatedField.getFields());
                            existingField.setGuidelines(updatedField.getGuidelines());
                            existingField.setCreatedBy(updatedField.getCreatedBy());
                            existingField.setUpdatedBy(updatedField.getUpdatedBy());
                            existingField.setDrillId(updatedField.getDrillId());
                        }
                    }
                }
            }

            // Save or update the fields in the list.
            return configureParticipantFieldsRepository.saveAll(payloadList);
        } catch (Exception e) {
            log.error("Exception while saving the participant fields: " + e.getMessage(), e);
            return Collections.emptyList(); // Handle the error gracefully.
        }
    }

    public List<ConfigureParticipantFields> fetchDrillParticipantFields(String drillId, InternityUser user) {
        try {
            List<ConfigureParticipantFields> fields = configureParticipantFieldsRepository.findByDrillId(drillId);

            if (!fields.isEmpty()) {
                return fields;
            }

            List<DefaultParticipantFields> defaultParticipantFields = defaultParticipantFieldsRepository.findAll();
            List<ConfigureParticipantFields> dtoList = new ArrayList<>();
            for (DefaultParticipantFields defaultField : defaultParticipantFields) {
                ConfigureParticipantFields dto = new ConfigureParticipantFields();
                dto.setFields(defaultField.toString());
                dtoList.add(dto);
            }

            return dtoList;
        } catch (Exception e) {
            log.error("Exception while fetching the participant fields: " + e.getMessage(), e);
            return Collections.emptyList(); // Handle the error gracefully.
        }
    }


    public DefaultParticipantFields saveOrUpdateDefaultParticipantFields(DefaultParticipantFields payload, InternityUser user) {
        try {
            return defaultParticipantFieldsRepository.save(payload);
        } catch (Exception e) {
            log.error("Exception while saving the participant fields: " + e.getMessage(), e);
            return null;
        }
    }

    public List<DefaultParticipantFields> fetchDefaultParticipantFields(InternityUser user) {
        try {
            return defaultParticipantFieldsRepository.findAll();
        } catch (Exception e) {
            log.error("Exception while fetching the participant fields {}", e);
        }
        return Collections.emptyList();
    }

    public Map<String, String> importJudges(String payload, String drillId, InternityUser user) {
        try {
            Map<String, String> result = new HashMap<>();
            for (String judgeName : payload.split(",")) {
                Optional<DrillCollaborators> drillCollaboratorFromDbObj = drillCollaboratorsRepository
                        .findByDrillIdAndCollaboratorName(drillId, judgeName);
                if (drillCollaboratorFromDbObj.isPresent()) {
                    result.put(drillCollaboratorFromDbObj.get().getCollaboratorId(),
                            drillCollaboratorFromDbObj.get().getCollaboratorName() + " Already in DB");
                    continue;
                }
                DrillCollaborators drillCollaborator = new DrillCollaborators();
                drillCollaborator.setCollaboratorDesc("<p>Hackathon Judge</p>");
                drillCollaborator.setDrillId(drillId);
                String randomAlphabets = RandomStringUtils.randomAlphabetic(2);
                String randomNumbers = RandomStringUtils.randomNumeric(4);
                String key = randomAlphabets + randomNumbers;
                drillCollaborator.setKey(key);
                drillCollaborator.setCollaboratorType("Judge");
                drillCollaborator.setCollaboratorDesignation("Hackathon Judge");
                drillCollaborator.setCollaboratorName(judgeName);
                drillCollaborator.setCollaboratorSocialLinks(
                        "{\"personalWebsite\":\"\",\"instagram\":\"\",\"linkedIn\":\"\",\"facebook\":\"\",\"github\":\"\",\"twitter\":\"\"}");
                DrillCollaborators res = drillCollaboratorsRepository.saveAndFlush(drillCollaborator);
                result.put(res.getCollaboratorId(), judgeName);
            }
            return result;
        } catch (Exception e) {
            log.error("Exception while importing judges ::: {}", e);
        }
        return Collections.EMPTY_MAP;
    }

    public ResponseEntity<?> validateDrill(String drillId, InternityUser user) {
        try {
            // Retrieve the drill details from repositories
            Optional<Drill> optionalDrill = drillRepository.findById(drillId);
            Optional<DrillOverview> optionalDrillOverview = drillOverviewRepository.findById(drillId);
            List<DrillPhases> drillPhasesList = drillPhasesRepository.findByDrillId(drillId);
            List<DrillNewFaq> drillFaqList = drillNewFaqRepository.findByDrillId(drillId);

            if (optionalDrill.isPresent() && optionalDrillOverview.isPresent()) {
                Drill drill = optionalDrill.get();
                DrillOverview drillOverview = optionalDrillOverview.get();

                double completenessPercentage = calculateCompleteness(drill, drillOverview, drillPhasesList, drillFaqList);

                if (completenessPercentage == 100.0) {
                    return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Drill is 100% complete and ready to publish.", null), HttpStatus.OK);
                }
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill is not 100% complete. Completeness Percentage: " + completenessPercentage + "%. Missing Fields: " + getMissingFieldsString(drill, drillOverview, drillPhasesList, drillFaqList), null), HttpStatus.BAD_REQUEST);
            } else {
                return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, "Drill not found", null), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Exception while validating drill {}", e);
            return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, null, new ResponseError("Exception while validating drill", e.getMessage())), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private double calculateCompleteness(Drill drill, DrillOverview drillOverview, List<DrillPhases> drillPhasesList, List<DrillNewFaq> drillNewFaq) {
        return Stream.of(
                check(drillOverview.getEligibility()),
                check(drillOverview.getDrillDescription()),
                checkRegistrationDates(drill),
                check(drill.getDrillCustUrl()),
                checkOptionalFaqCompleteness(drillNewFaq),
                check(drill.getDrillName()),
                checkDrillPhasesCompleteness(drillPhasesList),
                check(drill.getDrillType()),
                check(drill.getDrillPurpose()),
                check(drill.getDrillInvitationType())
        ).mapToDouble(Double::doubleValue).sum();
    }

    private double checkRegistrationDates(Drill drill) {
        if (drill.getDrillRegistrationEndDt() != null) {
            LocalDateTime currentDate = LocalDateTime.now();
            LocalDateTime registrationEndDate = drill.getDrillRegistrationEndDt();

            if (registrationEndDate.isBefore(currentDate)) {
                return 0.0; // End date is before current date
            } else {
                return 10.0; // End date is after or equal to current date
            }
        } else {
            return 0.0; // End date is not specified, treat as invalid
        }
    }

    private double check(String value) {
        return StringUtils.isBlank(value) ? 0.0 : 10.0;
    }

    private double checkOptionalFaqCompleteness(List<DrillNewFaq> drillNewFaq) {
        return !drillNewFaq.isEmpty() ? 10.0 : 0.0;
    }

    private double checkDrillPhasesCompleteness(List<DrillPhases> drillPhasesList) {
        boolean allPhasesComplete = drillPhasesList.stream()
                .allMatch(phase -> (phase.getPhaseStartDt() != null && phase.getPhaseEndDt() != null) ||
                        (phase.getStartMonth() != null && phase.getEndMonth() != null));

        return allPhasesComplete ? 10.0 : 0.0;
    }

    private String getMissingFieldsString(Drill drill, DrillOverview drillOverview, List<DrillPhases> drillPhasesList, List<DrillNewFaq> drillNewFaqList) {
        List<String> missingFields = new ArrayList<>();

        // Check each completeness criterion and add the missing fields to the list
        if (StringUtils.isBlank(drillOverview.getEligibility())) {
            missingFields.add("Eligibility");
        }

        if (StringUtils.isBlank(drillOverview.getDrillDescription())) {
            missingFields.add("Description");
        }
        if (drill.getDrillRegistrationEndDt() == null || drill.getDrillRegistrationEndDt().isBefore(LocalDateTime.now())) {
            missingFields.add("Registration End Date is Incorrectly Configured");
        }

        if (StringUtils.isBlank(drill.getDrillCustUrl())) {
            missingFields.add("Custom Url");
        }

        if (drillNewFaqList.isEmpty()) {
            missingFields.add("Faq Content");
        }

        if (StringUtils.isBlank(drill.getDrillName())) {
            missingFields.add("Drill Name");
        }

        boolean drillPhasesDatePresent = drillPhasesList.stream()
                .allMatch(phase -> phase.getPhaseStartDt() != null && phase.getPhaseEndDt() != null);

        if (!drillPhasesDatePresent) {
            missingFields.add("Drill Phases Dates (Phase Start Date and Phase End Date)");
        }

        if (StringUtils.isBlank(drill.getDrillType())) {
            missingFields.add("Drill Type");
        }

        if (StringUtils.isBlank(drill.getDrillPurpose())) {
            missingFields.add("Drill Purpose");
        }

        if (StringUtils.isBlank(drill.getDrillInvitationType())) {
            missingFields.add("Drill InvitationType");
        }

        return String.join(", ", missingFields);
    }

    public ResponseEntity<?> deleteDrill(String drillId, String uId, InternityUser user) {
        try {
            User userDetails = userRepository.findById(uId).orElse(null);

            // Check if the user exists and has the role SUPERADMIN
            if (userDetails != null && "SUPERADMIN".equals(userDetails.getURole())) {
                Drill drillToDelete = drillRepository.findById(drillId).orElse(null);
                if (drillToDelete != null) {
                    drillRepository.delete(drillToDelete);
                    return new ResponseEntity<>("Drill deleted successfully", HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(
                            "Drill with ID " + drillId + " not found",
                            HttpStatus.NOT_FOUND);
                }
            } else {
                // User is not authorized (403 Forbidden)
                return new ResponseEntity<>(
                        "You are not authorized to delete drills",
                        HttpStatus.FORBIDDEN);
            }
        } catch (Exception e) {
            // Handle exceptions and return an error response
            log.error("Exception while deleting drill {}", e);
            Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while deleting drill");
            return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public List<ParticipatedDrillStatusDto> listAllParticipatedHackathon(String uId, InternityUser user) {
        List<ParticipatedDrillStatusDto> submissionDetailsList = new ArrayList<>();
        try {
            List<DrillParticipant> participantList = drillParticipantRepository.findByPlatformUId(uId);

            if (!participantList.isEmpty()) {
                for (DrillParticipant participant : participantList) {
                    Optional<Drill> drillObj = drillRepository.findById(participant.getDrillId());

                    if (drillObj.isPresent()) {
                        Drill drill = drillObj.get();
                        boolean isTeamBased = isTeamBased(drill.getDrillTeamSize());

                        if (!isTeamBased) {
                            // The drill is not team-based, so directly check phase status
                            List<DrillPhases> phases = drillPhasesRepository.findByDrillId(drill.getDrillId());
                            boolean isPhaseRunning = phases.stream()
                                    .anyMatch(phase -> isPhaseRunning(phase.getPhaseStartDt(), phase.getPhaseEndDt()));

                            if (isPhaseRunning) {
                                // At least one phase is in running state
                                ParticipatedDrillStatusDto dto = new ParticipatedDrillStatusDto();
                                dto.setDrillDetails(drill);
                                dto.setStatus(ParticipatedDrillStatus.SUBMIT_OR_UPDATE_SOLUTION);
                                submissionDetailsList.add(dto);
                            }
                        } else {
                            // Check if the participant has joined a team
                            List<TeamsParticipants> teamsParticipants = teamsParticipantsRepository
                                    .findByParticipantIdAndDrillId(participant.getParticipantId(), drill.getDrillId());

                            if (!teamsParticipants.stream().anyMatch(TeamsParticipants::isRequestAccepted)) {
                                // Check if the participant has created their own team
                                Optional<DrillTeams> drillTeams = drillTeamsRepository.findByDrillIdAndTeamLeadParticipantId(drill.getDrillId(), participant.getParticipantId());
                                if (drillTeams.isPresent()) {
                                    // Participant has created their own team
                                    continue;
                                } else {
                                    // Participant has not joined a team and has not created a team
                                    ParticipatedDrillStatusDto dto = new ParticipatedDrillStatusDto();
                                    dto.setDrillDetails(drill);
                                    dto.setStatus(ParticipatedDrillStatus.CREATE_OR_JOIN_TEAM);
                                    submissionDetailsList.add(dto);
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Exception while fetching all participated hackathons ::: {}", e);
            return null;
        }
        return submissionDetailsList;
    }

    public boolean isTeamBased(String drillTeamSize) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            JsonNode jsonNode = objectMapper.readTree(drillTeamSize);
            int maxTeamSize = jsonNode.get("max").asInt();

            return maxTeamSize > 1;
        } catch (Exception e) {
            log.error("Error while determining if the drill is team-based: " + e.getMessage());
            return false;
        }
    }

    public boolean isPhaseRunning(LocalDateTime phaseStartDt, LocalDateTime phaseEndDt) {
        LocalDateTime now = LocalDateTime.now();
        return phaseStartDt.isBefore(now) && phaseEndDt.isAfter(now);
    }

    public Response fetchTheCompleteTrackOfHackathon(String drillId, String participantId, String uId,
                                                     String phaseId, InternityUser user) {
        Map<String, Object> result = new HashMap<>();

        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (drillObj.isPresent()) {

                if (participantId.equalsIgnoreCase("NA")) {
                    if (uId.equalsIgnoreCase("NA")) {
                        return new Response(500, false, null, new ResponseError("500", "No user id available to fetch hackathon information"));
                    } else {
                        Optional<DrillParticipant> drillParticipantFromUId = drillParticipantRepository.findByDrillIdAndPlatformUId(
                                drillId, uId);
                        if (drillParticipantFromUId.isPresent()) {
                            participantId = drillParticipantFromUId.get().getParticipantId();
                        }
                    }
                }
                Optional<DrillParticipant> drillParticipantObj = drillParticipantRepository
                        .findByDrillIdAndParticipantId(drillId, participantId);

                result.put("drill", drillObj.get());

                if (drillParticipantObj.isPresent()) {
                    result.put("isParticipated", true);
                    result.put("currentStatus", ParticipantState.PARTICIPANT.name());
                    result.put("drillParticipantId", participantId);
                    result.put("uId", drillParticipantObj.get().getPlatformUId());
                } else {
                    result.put("currentStatus", ParticipantState.NOTPARTICIPANT.name());
                }

                if (isDrillTeamBased(drillId)) {
                    result.put("isHackathonTeamBased", true);
                    result.put("isJoinedTeam", false);
                    Optional<TeamsParticipants> teamsParticipants = teamsParticipantsRepository
                            .findByParticipantIdAndDrillIdAndIsRequestAccepted(participantId, drillId, true);
                    if (teamsParticipants.isPresent()) {
                        result.put("isJoinedTeam", true);
                        result.put("participantType", MemberType.TEAMMEMBER.name());
                        result.put("currentStatus", ParticipantState.JOINEDTEAM.name());
                    }

                    Optional<DrillTeams> drillTeamsObj = drillTeamsRepository.findByDrillIdAndTeamLeadParticipantId(drillId,
                            participantId);
                    if (drillTeamsObj.isPresent()) {
                        result.put("isJoinedTeam", true);
                        result.put("participantType", MemberType.TEAMLEAD.name());
                        result.put("currentStatus", ParticipantState.JOINEDTEAM.name());
                    }
                } else {
                    result.put("isHackathonTeamBased", false);
                }
                List<DrillPhases> allDrillPhases = validateAndUpdateDrillPhases(drillId, "NA");
                List<DrillPhasesDto> drillPhasesDtoList = new ArrayList<>();
                for (DrillPhases drillPhases : allDrillPhases) {
                    if (!phaseId.equalsIgnoreCase("NA")
                            && !drillPhases.getPhaseId().equalsIgnoreCase(phaseId)) {
                        continue;
                    }
                    DrillPhasesDto drillPhasesDto = new DrillPhasesDto();
                    modelMapper.map(drillPhases, drillPhasesDto);

                    if (drillPhases.getPhaseStatus() != null && drillPhases.getPhaseStatus().equalsIgnoreCase(DrillPhaseStatus.RUNNING.name())) {
                        Optional<DrillParticipantSubmission> drillParticipantSubmission = drillParticipantSubmissionRepository.
                                findByDrillIdAndPhaseIdAndParticipantIdAndIsActiveSubmission(drillId,
                                        drillPhases.getPhaseId(), participantId, true);

                        if (drillParticipantSubmission.isPresent()) {
                            drillPhasesDto.setSolutionSubmittedByParticipant(true);
                            result.put("currentStatus", ParticipantState.SOLUTIONSUBMITTED.name());
                        }
                    }
                    drillPhasesDtoList.add(drillPhasesDto);
                }
                result.put("phases", drillPhasesDtoList);
            } else {
                new Response(500, false, null, new ResponseError("500",
                        "No record found for the hackathon with the given id"));
            }
        } catch (Exception e) {
            log.error("Exception while fetching the complete track of the hackathon ::: {}", e);
        }
        return new Response(200, true, result, null);
    }

    public ResponseEntity<?> sendPublishOrUnpublishRequestToAdmin(String drillId, DrillPublishRequestsDto payload, InternityUser user) {
        try {
            //  check for drill id
            if (StringUtils.isAnyBlank(drillId)) {
                log.error("Drill Id cannot be Blank");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), false, null, new ResponseError("400", "Drill Id cannot be Blank")), HttpStatus.BAD_REQUEST);
            }
            //  check for drill id matches payload id
            if (!drillId.equalsIgnoreCase(payload.getDrillId())) {
                log.error("Drill Id Mismatch");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), false, null, new ResponseError("400", "Drill Id Mismatch")), HttpStatus.BAD_REQUEST);
            }
            //  check for request payload
            if (!validateRequestPayload(payload)) {
                log.error("Invalid Request Missing payload details");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), false, null, new ResponseError("400", "Invalid Request Missing payload details")), HttpStatus.BAD_REQUEST);
            }
            //  check for user
            if (!userRepository.findById(payload.getRequestByUId()).isPresent()) {
                log.error("The User does not exist");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), false, null, new ResponseError("400", "The User does not exist")), HttpStatus.BAD_REQUEST);
            }
            if (!drillRepository.existsById(payload.getDrillId())) {
                log.error("The Drill does not exist");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), false, null, new ResponseError("400", "The Drill does not exist")), HttpStatus.BAD_REQUEST);
            }

            //  check for publish request
            Optional<DrillPublishRequests> drillPublishRequestsObj = drillPublishRequestsRepository.findById(payload.getDrillId());
            DrillPublishRequests drillPublishRequests = null;
            if (drillPublishRequestsObj.isPresent()) {
                drillPublishRequests = drillPublishRequestsObj.get();
            }

            //  check for drill validation here
            ResponseEntity<?> drillValidationResponse = validateDrill(payload.getDrillId(), user);
            if (!drillValidationResponse.getStatusCode().equals(HttpStatus.OK)) {
                log.error("Drill Validation Failed");
                // if Drill is not 100
                return drillValidationResponse;
            }

            // if drill is 100 % complete continue

            if (drillPublishRequests != null) {
                log.info("Request Present for Drill ");
                // cases for publish request send by user

                // if request is publish and status is pending return error
                if (payload.getRequestType().equals(DrillRequestType.PUBLISH) &&
                        drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.PENDING) &&
                        drillPublishRequests.getRequestType().equals(payload.getRequestType())) {
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Publish Request Already Present. Please wait for Admin Approval", null), HttpStatus.BAD_REQUEST);
                }

                // if request publish and status is rejected create new publish request
                else if (payload.getRequestType().equals(DrillRequestType.PUBLISH) &&
                        drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.REJECTED) &&
                        drillPublishRequests.getRequestType().equals(payload.getRequestType())) {

                    DrillPublishRequests drillPublishRequestsNew = getDrillPublishRequests(payload);
                    drillPublishRequestsRepository.save(drillPublishRequestsNew);
                    return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Drill Publish Request Sent Successfully", null), HttpStatus.OK);
                }

                // if request publish and status is approved
                else if (payload.getRequestType().equals(DrillRequestType.PUBLISH)
                        && drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.APPROVED) &&
                        drillPublishRequests.getRequestType().equals(payload.getRequestType())) {
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Invalid Request the Drill Already Published ", null), HttpStatus.BAD_REQUEST);
                }

                // if request is publish and (status is approved and drill is not published )
                else if (payload.getRequestType().equals(DrillRequestType.PUBLISH) &&
                        drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.APPROVED) &&
                        drillPublishRequests.getRequestType().equals(DrillRequestType.UNPUBLISH)) {
                    //create new request

                    DrillPublishRequests drillPublishRequestsNew = getDrillPublishRequests(payload);
                    drillPublishRequestsRepository.save(drillPublishRequestsNew);
                    return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Drill Publish Request Sent Successfully", null), HttpStatus.OK);
                }
                // if request is publish but ( status is pending or rejected and drill is publish)
                else if (payload.getRequestType().equals(DrillRequestType.PUBLISH) &&
                        (drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.PENDING) ||
                                drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.REJECTED)) &&
                        drillPublishRequests.getRequestType().equals(DrillRequestType.UNPUBLISH)) {

                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Invalid Request the Drill Already Published ", null), HttpStatus.BAD_REQUEST);

                }

                // cases for unpublish request send by user

                // if request is un-publish and status is pending
                if (payload.getRequestType().equals(DrillRequestType.UNPUBLISH) &&
                        drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.PENDING) &&
                        drillPublishRequests.getRequestType().equals(payload.getRequestType())) {
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Un-Publish Request Already Present. Please wait for Admin Approval", null), HttpStatus.BAD_REQUEST);
                }

                // if request un-publish and status is rejected create new publish request
                else if (payload.getRequestType().equals(DrillRequestType.UNPUBLISH) &&
                        drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.REJECTED) &&
                        drillPublishRequests.getRequestType().equals(payload.getRequestType())) {

                    DrillPublishRequests drillPublishRequestsNew = getDrillPublishRequests(payload);
                    drillPublishRequestsRepository.save(drillPublishRequestsNew);
                    return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Drill Un-Publish Request Sent Successfully", null), HttpStatus.OK);
                }

                // if request un-publish and status is approved
                else if (payload.getRequestType().equals(DrillRequestType.UNPUBLISH)
                        && drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.APPROVED) &&
                        drillPublishRequests.getRequestType().equals(payload.getRequestType())) {
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Invalid Request the Drill Already Un-Published ", null), HttpStatus.BAD_REQUEST);
                }
                //if request is unpublish and (status if approved and drill is publish)
                else if (payload.getRequestType().equals(DrillRequestType.UNPUBLISH) &&
                        drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.APPROVED) &&
                        drillPublishRequests.getRequestType().equals(DrillRequestType.PUBLISH)) {
                    // create new request
                    DrillPublishRequests drillPublishRequestsNew = getDrillPublishRequests(payload);
                    drillPublishRequestsRepository.save(drillPublishRequestsNew);
                    return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Drill Un-Publish Request Sent Successfully", null), HttpStatus.OK);

                }

                // if request is unpublish but ( status is pending or rejected and drill is not published)
                else if (payload.getRequestType().equals(DrillRequestType.UNPUBLISH) &&
                        (drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.REJECTED) ||
                                drillPublishRequests.getRequestStatus().equals(DrillRequestStatus.PENDING)) &&
                        drillPublishRequests.getRequestType().equals(DrillRequestType.PUBLISH)) {

                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Invalid Request the Drill not Published Yet ", null), HttpStatus.BAD_REQUEST);

                }
            }

            // if no requests found and user request publish
            else if (payload.getRequestType().equals(DrillRequestType.PUBLISH)) {
                log.info("Request is not Present for Drill creating one ");
                DrillPublishRequests drillPublishRequestsNew = getDrillPublishRequests(payload);
                drillPublishRequestsRepository.save(drillPublishRequestsNew);
                return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Drill Publish Request Sent Successfully", null), HttpStatus.OK);
            }
            // if no requests found and user request unpublish
            else {
                log.warn("Invalid Request ");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Invalid Request the Drill not Published Yet ", null), HttpStatus.BAD_REQUEST);
            }


        } catch (Exception e) {
            log.error("Exception while fetching the complete track of the hackathon ::: {}", e);
            return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, null, new ResponseError("Exception while fetching the complete track of the hackathon", e.getMessage())), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, "Something went wrong", null), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private boolean validateRequestPayload(DrillPublishRequestsDto payload) {
        if (payload.getRequestType() == null || StringUtils.isEmpty(payload.getRequestType().toString()) || StringUtils.isAnyBlank(payload.getRequestType().toString())) {
            return false;
        }
        if (payload.getRequestByUId() == null || StringUtils.isEmpty(payload.getRequestByUId()) || StringUtils.isAnyBlank(payload.getRequestByUId())) {
            return false;
        }
        if (payload.getDrillId() == null || StringUtils.isEmpty(payload.getDrillId()) || StringUtils.isAnyBlank(payload.getDrillId())) {
            return false;
        }
        return true;
    }

    private DrillPublishRequests getDrillPublishRequests(DrillPublishRequestsDto payload) {
        log.info("Inside getDrillPublishRequests");
        Optional<DrillPublishRequests> drillPublishRequests = drillPublishRequestsRepository.findByDrillId(payload.getDrillId());
        DrillPublishRequests drillPublishRequestsNew = new DrillPublishRequests();

        if (drillPublishRequests.isPresent()) {
            drillPublishRequestsNew = drillPublishRequests.get();
        } else {
            drillPublishRequestsNew.setDrillId(payload.getDrillId());
        }
        drillPublishRequestsNew.setRequestType(payload.getRequestType());
        drillPublishRequestsNew.setRequestByUId(payload.getRequestByUId());
        drillPublishRequestsNew.setRemarks(payload.getRemarks());
        drillPublishRequestsNew.setRequestStatus(DrillRequestStatus.PENDING);
        drillPublishRequestsNew.setApproverUid(null);

        log.info("Sending mail to Request user and Admin");
        sendMailForDrillPublishORUnpublishRequest(payload.getRequestByUId(), payload.getDrillId(), payload.getRequestType());
        log.info("Request created ");
        return drillPublishRequestsNew;

    }

    private void sendMailForDrillPublishORUnpublishRequest(String requestByUId, String drillId, DrillRequestType requestType) {

        try {
            log.info("Sending mail for Publish / UnPublish Request for Drill : {}", drillId);

            EmailContent emailContent = new EmailContent();

            Optional<Drill> drillObj = drillRepository.findById(drillId);
            Drill drill = drillObj.get();

            emailContent.setJobId(drill.getDrillId());

            emailContent.setLink(domainUrl + "/drills/" + drill.getDrillCustUrl());

            emailContent.setTemplateName("GenericMailForAllUsers");

            // mail detail for user
            User user = userRepository.findById(requestByUId).get();

            if (requestType.equals(DrillRequestType.PUBLISH)) {
                emailContent.setSubject("Request for Publish Hackathon Under Review");
                String bodyForUser = "<span style=\"font-family: Arial, sans-serif;\">"
                        + "<p>We wanted to inform you that your request to publish the <strong>"
                        + drill.getDrillName() + "</strong> Hackathon has been successfully submitted.</p>"
                        + "<p>Our team is currently reviewing the details provided, and we will notify you as soon as the request is approved.</p>"
                        + "<p>Thank you for choosing our platform to host your hackathon.</p>"
                        + "</span>";
                emailContent.setMessage(bodyForUser);
            } else {
                emailContent.setSubject("Request to Unpublish Hackathon Under Review");
                String bodyForUser = "<span style=\"font-family: Arial, sans-serif;\">"
                        + "<p>We wanted to inform you that we have received your request to unpublish the  <strong>"
                        + drill.getDrillName() + "</strong> Hackathon, and it is currently under review.</p>"
                        + "<p>Our team will  provide you with an update as soon as the review process is complete.</p>"
                        + "<p>Thank you for choosing our platform to host your hackathon.</p>"
                        + "</span>";
                emailContent.setMessage(bodyForUser);
            }

            emailContent.setUserName("Hi " + user.getFullName() + ",");
            messageUtils.sendMailForGenericUsers(user.getEmail(), emailContent);

            // mail details for Admin

            emailContent.setSubject(drill.getDrillName() + " Drill "
                    + requestType.toString().charAt(0) + requestType.toString().toLowerCase().substring(1)
                    + " Request Submitted By " + user.getFullName());

            String bodyForAdmin = "The " + requestType.toString().charAt(0) + requestType.toString().toLowerCase().substring(1)
                    + " request for <strong>" + drill.getDrillName()
                    + "</strong> has been submitted by " + user.getFullName();

            emailContent.setMessage(bodyForAdmin);

            emailContent.setUserName("Hi Admin,");

            messageUtils.sendMailForGenericUsers(techSupportEmail, emailContent);


            log.info("Publish / Unpublish mail sent successfully for drill: {}", drillId);
        } catch (MessagingException e) {
            log.error("Exception while sending mail to Admin and User For Publish / UnPublish drill: {}", drillId, e);
            throw new RuntimeException(e);
        }

    }

    public ResponseEntity<?> acceptOrRejectRequestForPublishOrUnpublishDrill(String drillId, boolean status, String uId, InternityUser user) {
        try {
            log.info("Accepting or rejecting request for drillId: {}, status: {}, uId: {}", drillId, status, uId);

            // Check if the drillId is blank
            if (StringUtils.isAnyBlank(drillId)) {
                log.error("Drill Id cannot be Blank");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill Id cannot be Blank", null), HttpStatus.BAD_REQUEST);
            }

            // Check if the uId is blank
            if (StringUtils.isAnyBlank(uId)) {
                log.error("User Id cannot be Blank");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "User Id cannot be Blank", null), HttpStatus.BAD_REQUEST);
            }
            // Check if the user exists
            if (!userRepository.findById(uId).isPresent()) {
                log.error("The User does not exist");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "The User does not exist", null), HttpStatus.BAD_REQUEST);
            }

            // Check if the user has super admin access
            boolean userHasWueSuperAdminAccess = Boolean.parseBoolean(userHasWueSuperadminAccessOnDrill(uId, user).get("hasAccess"));
            if (!userHasWueSuperAdminAccess) {
                log.error("User does not have super admin access");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE,
                        "Only Where U Elevate super admin can accept the request to publish a hackathon. " +
                                "Please contact support team at " + techSupportEmail, null), HttpStatus.BAD_REQUEST);
            }

            // Find the drill publish request object
            Optional<DrillPublishRequests> drillPublishRequestsObj = drillPublishRequestsRepository.findByDrillId(drillId);
            if (!drillPublishRequestsObj.isPresent()) {
                log.error("Request not found");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Request not found", null), HttpStatus.BAD_REQUEST);
            }

            // If the request status is not pending, reject the request
            if (!drillPublishRequestsObj.get().getRequestStatus().equals(DrillRequestStatus.PENDING)) {
                log.error("Request can only be Accepted or Rejected Once. the Current request is Already {}", drillPublishRequestsObj.get().getRequestStatus());
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Request can only be Accepted or Rejected Once. the Current request is Already " + drillPublishRequestsObj.get().getRequestStatus(), null), HttpStatus.BAD_REQUEST);
            }
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (!drillObj.isPresent()) {
                log.error("Drill not found");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill not found", null), HttpStatus.BAD_REQUEST);
            }
            if (status) {
                // Approve the request and update the drill status
                drillPublishRequestsObj.get().setRequestStatus(DrillRequestStatus.APPROVED);
                drillPublishRequestsObj.get().setApproverUid(uId);
                drillPublishRequestsRepository.save(drillPublishRequestsObj.get());
                Drill drill = drillObj.get();
                drill.setDrillLatestStatus(DrillStatus.ACTIVE.name());
                drill.setActive(true);
                drillRepository.save(drill);
                sendMailForDrillRequestAcceptOrRejectConfirmation(drillPublishRequestsObj.get().getRequestByUId(), drillId, true, drillPublishRequestsObj.get().getRequestType());
                log.info("Request Accepted Successfully");
                return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request Accepted Successfully", null), HttpStatus.OK);
            } else {
                // Reject the request and update the drill status
                drillPublishRequestsObj.get().setRequestStatus(DrillRequestStatus.REJECTED);
                drillPublishRequestsObj.get().setApproverUid(uId);
                drillPublishRequestsRepository.save(drillPublishRequestsObj.get());
                Drill drill = drillObj.get();
                drill.setDrillLatestStatus(DrillStatus.INACTIVE.name());
                drill.setActive(false);
                drillRepository.save(drill);
                sendMailForDrillRequestAcceptOrRejectConfirmation(drillPublishRequestsObj.get().getRequestByUId(), drillId, false, drillPublishRequestsObj.get().getRequestType());
                log.info("Request Rejected Successfully");
                return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request Rejected Successfully", null), HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while accepting/rejecting the drill request: {}", e.getMessage());
            return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, null, new ResponseError("Exception while accepting/rejecting the drill request", e.getMessage())), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void sendMailForDrillRequestAcceptOrRejectConfirmation(String requestByUId, String drillId, boolean status, DrillRequestType requestType) {
        try {
            log.info("Sending mail for Request Accept /Reject Confirmation for Drill : {}", drillId);

            EmailContent emailContent = new EmailContent();

            Optional<Drill> drillObj = drillRepository.findById(drillId);
            Drill drill = drillObj.get();

            emailContent.setJobId(drill.getDrillId());

            emailContent.setLink(domainUrl + "/drills/" + drill.getDrillCustUrl());

            emailContent.setTemplateName("GenericMailForAllUsers");

            // mail detail for user
            User user = userRepository.findById(requestByUId).get();

            // mail for publish
            if (requestType.equals(DrillRequestType.PUBLISH)) {
                // mail for publish request approved
                if (status) {
                    emailContent.setSubject("Approved: Your Request to Publish Hackathon");
                    String bodyForPublishApproved = "<p>We are pleased to inform you that your request to publish the <Strong>"
                            + drill.getDrillName() + "</strong> Hackathon, has been approved! Your hackathon is now live and visible to our platform.</p>"
                            + "<p>Participants can now discover and engage with your hackathon.</p>"
                            + "<p>Here is the link to your hackathon: https://whereuelevate.com/drills/" + drill.getDrillCustUrl() + "</p>"
                            + "<p>Thank you for choosing our platform to host your hackathon.</p>";
                    emailContent.setMessage(bodyForPublishApproved);
                }
                // mail for publish request rejected
                else {
                    emailContent.setSubject("Rejected: Your Request to Publish Hackathon");
                    String bodyForPublishRejected = "<p>We regret to inform you that your request to publish the <Strong>"
                            + drill.getDrillName() + "</strong> Hackathon has been rejected following a thorough review process.</p>"
                            + "<p>While your request has been rejected, we encourage you to revisit your hackathon details and explore "
                            + "ways to enhance your hackathon proposal. We believe that with some adjustments, your future publishing's "
                            + "may find success.</p>"
                            + "<p>Thank you for choosing our platform to host your hackathon.</p>";
                    emailContent.setMessage(bodyForPublishRejected);
                }
            }
            // mail for unpublish
            else {
                // mail for unpublish request approved
                if (status) {
                    emailContent.setSubject("Approved: Request to Unpublish Hackathon");
                    String bodyForUnpublishApproved = "<p>We're writing to inform you that your request to unpublish the " +
                            "<Strong>" + drill.getDrillName() + "</strong> Hackathon has been approved. As a result, "
                            + "your hackathon is no longer live on our platform.</p>"
                            + "<p>Thank you for choosing our platform to host your hackathon.</p>";
                    emailContent.setMessage(bodyForUnpublishApproved);
                }
                // mail for unpublish request rejected
                else {
                    emailContent.setSubject("Rejected: Your Request to Unpublish Hackathon");
                    String bodyForUnpublishRejected = "<p>We would like to inform you that your request to unpublish the "
                            + "<Strong>" + drill.getDrillName() + "</strong> Hackathon has been rejected. Therefore, "
                            + "your hackathon will remain live on our platform as scheduled.</p>"
                            + "<p>Thank you for your cooperation.</p>";
                    emailContent.setMessage(bodyForUnpublishRejected);
                }
            }

            emailContent.setUserName("Hi " + user.getFullName() + ",");
            messageUtils.sendMailForGenericUsers(user.getEmail(), emailContent);

            log.info(" Request Accept /Reject Confirmation mail sent successfully for drill: {}", drillId);
        } catch (MessagingException e) {
            log.error("Exception while sending mail for Request Accept /Reject Confirmation drill: {}", drillId, e);
            throw new RuntimeException(e);
        }

    }

    public Response inviteParticipantsForInviteOnlyDrill(String drillId, DrillParticipantsInviteOnlyRequestDto payload, InternityUser user) {

        log.info("Inviting participants for invite only drill: {}", drillId);
        Drill drill = drillRepository.findById(drillId).orElse(null);

        if (drill == null) {
            log.error("No record found for the drill with the given id: {}", drillId);
            return new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, "No record found for the drill with the given id", null);
        }
        Map<String, String> userDetailList = new HashMap<>();

        for (Map.Entry<String, String> entry : payload.getEmailsAndNames().entrySet()) {
            String name = entry.getValue();
            String email = entry.getKey();
            DrillParticipantsInviteOnly drillParticipantsInviteOnly = drillParticipantsInviteOnlyRepository.findByDrillIdAndParticipantEmail(drillId, email);
            if (drillParticipantsInviteOnly != null) {
                log.info("Participant already invited for drill: {} with email: {}", drillId, email);
                continue;
            }
            DrillParticipantsInviteOnly inviteOnly = new DrillParticipantsInviteOnly();
            inviteOnly.setDrillId(drillId);
            inviteOnly.setParticipantEmail(email);
            inviteOnly.setParticipated(false);
            inviteOnly.setParticipantName(name);

            userDetailList.put(email, name);
            drillParticipantsInviteOnlyRepository.save(inviteOnly);
        }

        log.debug("Email list for drill {}: {}", drillId, userDetailList);
        sendMailToInviteForInviteOnlyDrill(userDetailList, drillId, payload.getSubject(), payload.getBody());
        log.info("Invitation sent successfully for drill: {}", drillId);
        return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Invitation sent successfully", null);
    }

    private void sendMailToInviteForInviteOnlyDrill(Map<String, String> userDetailList, String drillId, String subject, String body) {

        log.info("Sending mail to invite participants for invite only drill: {}", drillId);

        try {
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject(subject);
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            Drill drill = drillObj.get();
            emailContent.setTemplateName("GenericMailForAllUsers");
            emailContent.setJobId(drill.getDrillId());
            emailContent.setMessage(body);
            emailContent.setLink(domainUrl + "/drills/" + drillId);

            for (Map.Entry<String, String> entry : userDetailList.entrySet()) {
                String emailId = entry.getKey();
                String name = entry.getValue();
                emailContent.setUserName(name);
                messageUtils.sendMailForGenericUsers(emailId, emailContent);
            }

            log.info("Invitation email sent successfully to " + userDetailList + " for drill " + drillId);
        } catch (MessagingException e) {
            log.error("Exception while sending mail to invite participants for invite only drill: {}", drillId, e);
            throw new RuntimeException(e);
        }
    }

    public ResponseEntity<?> getCurrentStateOfDrillRequest(String drillId, InternityUser user) {

        if (StringUtils.isAnyBlank(drillId)) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill Id cannot is Empty/Undefined", null), HttpStatus.BAD_REQUEST);
        }
        Optional<Drill> drill = drillRepository.findById(drillId);
        if (!drill.isPresent()) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill not found with the specified Id", null), HttpStatus.BAD_REQUEST);
        }
        Optional<DrillPublishRequests> request = drillPublishRequestsRepository.findByDrillId(drillId);
        return request.map(drillPublishRequests -> new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, drillPublishRequests, null), HttpStatus.OK)).orElseGet(() -> new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, null, null), HttpStatus.OK));

    }

    public Response getParticipantFields(String drillId, InternityUser user) {
        try {
            log.info("start getting participant fields for drill");
            if (StringUtils.isBlank(drillId)) {
                log.error("drill id cannot be blank or undefined");
                return responseUtil.badRequestResponse("drill id cannot be blank or undefined");
            }
            Drill drill = drillRepository.findById(drillId).orElse(null);
            if (drill == null) {
                log.error("Drill not found by specified Id");
                return responseUtil.badRequestResponse("Drill not found by specified Id");
            }
            DrillParticipantFields participantFields = drillParticipantFieldsRepository.findById(drillId).orElse(null);
            if (participantFields == null) {
                log.error("participant fields not found by specified Id");
                return responseUtil.badRequestResponse("participant fields not found by specified Id");
            }
            Map<String, Boolean> responseMap = new HashMap<>();
            ObjectMapper objectMapper = new ObjectMapper();
            log.info("building field list converting json to list");
            List<String> listOfFields =
                    objectMapper.readValue(
                            participantFields.getParticipantFields(),
                            new TypeReference<List<String>>() {
                            });
            if (listOfFields == null) {
                log.error("participant fields not found");
                return responseUtil.badRequestResponse("participant fields not found");
            }
            for (String field : listOfFields) {
                responseMap.put(field, true);
            }
            log.info("return success response");
            return responseUtil.successResponse(responseMap);
        } catch (Exception e) {
            log.error("Exception while getting participant fields ::: {}", e.getMessage());
            return responseUtil.internalServerErrorResponse("Exception while getting participant fields");
        }
    }

    public Response saveParticipantFields(String drillId, Map<String, Boolean> participantFieldMap, InternityUser user) {
        try {
            log.info("start saving participant fields for drill");
            if (StringUtils.isBlank(drillId)) {
                log.error("drill id cannot be blank or undefined");
                return responseUtil.badRequestResponse("drill id cannot be blank or undefined");
            }
            Drill drill = drillRepository.findById(drillId).orElse(null);
            if (drill == null) {
                log.error("Drill not found by specified Id");
                return responseUtil.badRequestResponse("Drill not found by specified Id");
            }
            if (participantFieldMap.isEmpty()) {
                log.error("participant field map cannot be blank or undefined");
                return responseUtil.badRequestResponse("participant field map cannot be blank or undefined");
            }

            DrillParticipantFields participantFields = drillParticipantFieldsRepository.findById(drillId).orElse(null);
            if (participantFields == null) {
                log.error("participant fields not found by specified Id");
                return responseUtil.badRequestResponse("participant fields not found by specified Id");
            }

            ObjectMapper objectMapper = new ObjectMapper();

            // Deserialize the JSON string to a Set
            log.info("converting json to set");
            HashSet setOFields = new HashSet<>(Arrays.asList(objectMapper.readValue(participantFields.getParticipantFields(), String[].class)));

            // Update the set based on the provided section map
            log.info("building map for update fields");
            participantFieldMap.forEach((fields, isVisible) -> {
                if (isVisible) {
                    setOFields.add(fields);
                } else {
                    setOFields.remove(fields);
                }
            });

            // Serialize the Set back to a JSON string
            String updatedParticipantField = objectMapper.writeValueAsString(setOFields);
            participantFields.setParticipantFields(updatedParticipantField);
            log.info("participant fields saved successfully");
            drillParticipantFieldsRepository.save(participantFields);
            log.info("return success response");
            return responseUtil.successResponse("participant fields saved successfully");
        } catch (Exception e) {
            log.error("Exception while saving participant fields ::: {}", e.getMessage());
            return responseUtil.internalServerErrorResponse("Exception while saving participant fields");
        }

    }

    /**
     * Retrieves a DrillParticipant by participant ID.
     *
     * @param participantId The ID of the participant to retrieve.
     * @param user          The authenticated user making the request.
     * @return A Response object containing the retrieved DrillParticipant or appropriate error response.
     */
    public Response getDrillParticipantByParticipantId(String participantId, InternityUser user) {
        try {
            log.info("Fetching DrillParticipant with ID: {}", participantId);

            // Check if participantId is blank
            if (StringUtils.isAnyBlank(participantId)) {
                log.error("Participant ID is blank.");
                return responseUtil.badRequestResponse("Participant ID is blank.");
            }

            // Retrieve the DrillParticipant from the repository
            Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(participantId);

            // Check if DrillParticipant exists
            if (!drillParticipantOptional.isPresent()) {
                log.error("DrillParticipant with ID {} not found.", participantId);
                return responseUtil.notFoundResponse("DrillParticipant not found.");
            }

            // Return successful response with the retrieved DrillParticipant
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, drillParticipantOptional.get(), null);
        } catch (Exception e) {
            log.error("Error retrieving DrillParticipant with ID {}: {}", participantId, e.getMessage());
            return responseUtil.internalServerErrorResponse("Internal server error occurred.");
        }
    }


    /**
     * Saves DrillPaid details based on participantType and amount for a specific drill.
     *
     * @param drillId The ID of the drill to save DrillPaid details for.
     * @param participantTypeAmountMap A map containing participantType as keys and corresponding amounts as values.
     * @param user The InternityUser associated with the operation.
     * @return A Response object indicating the success or failure of the operation.
     */
    public Response saveDrillPaidDetails(String drillId, Map<DrillParticipantType, Long> participantTypeAmountMap, InternityUser user) {
        try {
            log.info("Saving DrillPaid details for drill ID: {}", drillId);

            // Check if drillId is blank
            if (StringUtils.isAnyBlank(drillId)) {
                log.error("Drill ID is blank.");
                return responseUtil.badRequestResponse("Drill ID is blank.");
            }

            // Check if the drill exists
            Optional<Drill> drillOptional = drillRepository.findById(drillId);
            if (!drillOptional.isPresent()) {
                log.error("Drill with ID {} not found.", drillId);
                return responseUtil.notFoundResponse("Drill not found.");
            }

            List<DrillPaid> drillPaidList = new ArrayList<>();

            // Iterate over the map to create DrillPaid objects
            for (Map.Entry<DrillParticipantType, Long> entry : participantTypeAmountMap.entrySet()) {
                DrillParticipantType participantType = entry.getKey();
                Long amount = entry.getValue();

                // Check if the amount is valid
                if (amount == null || amount <= 0) {
                    log.error("Invalid amount provided for participant type: {}", participantType);
                    return responseUtil.badRequestResponse("Invalid amount provided for participant type: " + participantType);
                }

                // Create DrillPaid object and add it to the list
                DrillPaid drillPaid = new DrillPaid(drillId, participantType, amount);
                drillPaidList.add(drillPaid);
            }

            // Save all DrillPaid objects
            List<DrillPaid> savedDrillPaids = drillPaidRepository.saveAll(drillPaidList);

            log.info("Saved DrillPaid details for drill ID: {}", drillId);

            // Return successful response with the saved DrillPaid details
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedDrillPaids, null);
        } catch (Exception e) {
            log.error("Error saving DrillPaid details for drill ID {}: {}", drillId, e.getMessage());
            return responseUtil.internalServerErrorResponse("Internal server error occurred.");
        }
    }


    public Response getPaidDrillDetails(String drillId, InternityUser user) {
        try {
            log.info("start getting paid details");
            if (StringUtils.isBlank(drillId)) {
                log.error("drill id cannot be blank or undefined");
                return responseUtil.badRequestResponse("drill id cannot be blank or undefined");
            }
            Drill drill = drillRepository.findById(drillId).orElse(null);
            if (drill == null) {
                log.error("Drill not found by specified Id");
                return responseUtil.badRequestResponse("Drill not found by specified Id");
            }
            log.info("searching for paid details in db");
            List<DrillPaid> paidList = drillPaidRepository.findAllByDrillId(drillId);
            if (paidList.isEmpty()) {
                log.info("Paid details not found");
                return responseUtil.badRequestResponse("Paid details not found");
            }
            log.info("return success response ::: get paid details successfully");
            return responseUtil.successResponse(paidList);
        } catch (Exception e) {
            log.error("Exception while getting paid drill details ::: {}", e.getMessage());
            return responseUtil.internalServerErrorResponse("Exception while getting paid drill details");
        }
    }


    public Response updateParticipantPaymentStatusDetails(String participantId, PaymentStatus paymentStatus, InternityUser user) {
        try {
            log.info("Updating payment status details for participant ID: {}", participantId);

            // Check if participantId is blank
            if (StringUtils.isAnyBlank(participantId)) {
                log.error("Participant ID is blank.");
                return responseUtil.badRequestResponse("Participant ID is blank.");
            }

            // Check if the participant exists
            Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(participantId);
            if (!drillParticipantOptional.isPresent()) {
                log.error("Participant with ID {} not found.", participantId);
                return responseUtil.notFoundResponse("Participant not found.");
            }

            // Update the payment status and save the participant details
            DrillParticipant drillParticipant = drillParticipantOptional.get();
            drillParticipant.setPaymentStatus(paymentStatus);
            log.info("Saving updated payment status for participant ID: {}", participantId);
            drillParticipantRepository.saveAndFlush(drillParticipant);

            // Return successful response with the updated participant details
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, drillParticipant, null);
        } catch (Exception e) {
            log.error("Error updating payment status details for participant ID {}: {}", participantId, e.getMessage());
            return responseUtil.internalServerErrorResponse("Internal server error occurred.");
        }
    }


    public Response sendMailForParticipantPaymentReceived(String drillId, String participantId, PaymentStatus paymentStatus, String transactionId, Double transactionAmount, String date, InternityUser user) {
        try {
            log.info("Sending email for participant payment received.");

            // Validate input parameters
            if (StringUtils.isBlank(drillId)) {
                log.error("Drill ID cannot be blank or undefined.");
                return responseUtil.badRequestResponse("Drill ID cannot be blank or undefined.");
            }
            if (StringUtils.isBlank(participantId)) {
                log.error("Participant ID cannot be blank or undefined.");
                return responseUtil.badRequestResponse("Participant ID cannot be blank or undefined.");
            }

            // Check if the drill exists
            Optional<Drill> drillOptional = drillRepository.findById(drillId);
            if (!drillOptional.isPresent()) {
                log.error("Drill with ID {} not found.", drillId);
                return responseUtil.notFoundResponse("Drill not found.");
            }

            // Check if the participant exists
            Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(participantId);
            if (!drillParticipantOptional.isPresent()) {
                log.error("Participant with ID {} not found.", participantId);
                return responseUtil.notFoundResponse("Participant not found.");
            }

            Drill drill = drillOptional.get();
            DrillParticipant drillParticipant = drillParticipantOptional.get();

            // Prepare email content
            String subject = "Payment " + paymentStatus + ": " + drill.getDrillName() + " Hackathon Registration";
            String templateName = "DrillPaymentMail";
            String message = String.format("<div style='text-align: left;'>" +
                            "Hi %s,<br/><br/>" +
                            "Please find below the transaction status for participation in the %s:<br/><br/>" +
                            "Transaction ID:     %s <br/><br/>" +
                            "Transaction Amount: INR %s<br/><br/>" +
                            "Date and Time:      %s<br/><br/>" +
                            "Payment Status:     %s<br/><br/>" +
                            "</div>",
                    drillParticipant.getFullName(),
                    drill.getDrillName(),
                    transactionId,
                    transactionAmount,
                    commonUtils.convertToISTString(commonUtils.convertStringToDate(date)),
                    paymentStatus);

            EmailContent emailContent = new EmailContent();
            emailContent.setMessage(message);
            emailContent.setSubject(subject);
            emailContent.setTemplateName(templateName);
            emailContent.setUserName(drillParticipant.getFullName());
            emailContent.setMobile(drillParticipant.getContact());

            // Send email
            messageUtils.sendMail(drillParticipant.getEmail(), emailContent);

            log.info("Email sent successfully for participant payment received.");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Email sent successfully.", null);
        } catch (Exception e) {
            log.error("Error sending email for participant payment received: {}", e.getMessage());
            return responseUtil.internalServerErrorResponse("Error sending email.");
        }
    }


}



//    public ResponseEntity<String> acceptPublishRequestAndChangeStatusOfDrill(String drillId, boolean status, String uId, InternityUser user) {
//        try {
//            boolean userHasWueSuperAdminAccess = Boolean.parseBoolean(userHasWueSuperadminAccessOnDrill(uId, user).get("hasAccess"));
//            if (!userHasWueSuperAdminAccess) {
//                return new ResponseEntity<>("Only Where U Elevate super admin can accept the request to publish a hackathon. " +
//                        "Please contact support team at " + techSupportEmail, HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//            Optional<DrillPublishRequests> drillPublishRequestsObj =
//                    drillPublishRequestsRepository.findByDrillId(drillId);
//            if (drillPublishRequestsObj.isPresent()) {
//                DrillPublishRequests request = drillPublishRequestsObj.get();
//                request.setApproverUid(user.getUId());
//                request.setPublishStatus(status);
//                drillPublishRequestsRepository.save(request);
//                if (status) {
//                    Optional<Drill> drillObj = drillRepository.findById(drillId);
//                    if (drillObj.isPresent()) {
//                        Drill drill = drillObj.get();
//                        drill.setDrillLatestStatus(DrillStatus.ACTIVE.name());
//                        drill.setActive(status);
//                        drillRepository.save(drill);
//                        //sendRequestAcceptMailToOrganiserList(drillId);
//                        return new ResponseEntity<>("Request accepted successfully", HttpStatus.OK);
//                    }
//                } else {
//                    if (status) {
//                        drillPublishRequestsRepository.save(request);
//                        //sendRequestRejectMailToOrganiserList(drillId);
//                        return new ResponseEntity<>("Request rejected successfully", HttpStatus.OK);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            log.error("Exception while changing the status of the drill ::: {}", e);
//        }
//        return new ResponseEntity<>("Exception occurred while changing the status for the requested" +
//                "drill", HttpStatus.INTERNAL_SERVER_ERROR);
//    }


//    public Response fetchCurrentStateOfAParticipant(String participantId, String drillId){
//        try{
//            Optional<Drill> drillObj = drillRepository.findById(drillId);
//            if(drillObj.isPresent()){
//                Optional<DrillParticipant>
//            }
//            else {
//                return new Response(500, false, null, new ResponseError("500",
//                        "No record found for the given hackathon id"));
//            }
//        }
//        catch (Exception e){
//            log.error("Exception while fetching the current state of the participant ::: {}", e);
//            return new Response(500, false, null, new ResponseError("500",
//                    "Failed to fetch the current state of the participant in the hackathon"));
//        }
//    }

