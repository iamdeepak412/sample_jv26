package com.wue.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.constant.CommonConstants;
import com.wue.constant.FeaturedElementType;
import com.wue.constant.job.JobSkillsCategory;
import com.wue.custom.specification.JobsSpecification;
import com.wue.custom.specification.SearchCriteria;
import com.wue.custom.specification.SearchJobCriteria;
import com.wue.domain.*;
import com.wue.domain.ConfigureJob.JobScreeningQuestion;
import com.wue.domain.drill.Drill;
import com.wue.domain.drill.DrillParticipant;
import com.wue.dto.ApplicationDto;
import com.wue.dto.JobDto;
import com.wue.dto.SearchProfiles;
import com.wue.dto.SearchResultDto;
import com.wue.dto.response.Response;
import com.wue.dto.search.JobSpecification;
import com.wue.model.EmailContent;
import com.wue.repository.*;
import com.wue.repository.ConfigureJob.JobScreeningQuestionRepository;
import com.wue.repository.drill.DrillParticipantRepository;
import com.wue.repository.drill.DrillRepository;
import com.wue.service.drill.DrillService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.QueryParser;
import com.wue.util.SendMessageUtils;
import com.wue.util.drill.ResponseUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Field;
import java.util.*;
import java.util.function.Consumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Log4j2
public class JobsService {

	@Autowired
	JobsRepository jobsRepository;
	
	@Autowired 
	UserProfileRepository userProfileRepository;
	
	@Autowired
	PartnerRepository partnerRepository;
	
	@Autowired
	QueryParser parser;

	@Autowired
	ApplicationRepository applicationRepository;

	@Autowired
	CacheManager cacheManager;

	@Autowired
	CacheService cacheService;
	
	@Autowired
	UserRepository userRepository;

    @Autowired
	SendMessageUtils messageUtils;

    @Autowired
	UserSkillRepository userSkillRepository;

    @Autowired
	FeaturedRepository featuredRepository;

    @Autowired
	UserCandidateMandatoryFieldsRepository mandatoryFieldsRepository;

	@Autowired
	CommonUtils commonUtils;

	@Value("${domain.url:https://www.whereuelevate.com/}")
    String domainUrl;
    
    @Value("${certificate.generator.url:http://127.0.0.1:5069}")
	private String certificateGeneratorUrl;
    
    @Value("${resume.parsing.url:http://127.0.0.1:5069}")
    private String resumeParsingUrl;

	@Autowired
	JobScreeningQuestionRepository jobScreeningQuestionRepository;
	@Autowired
	ResponseUtil responseUtil;
	@Autowired
	DrillRepository drillRepository;
	@Autowired
	DrillParticipantRepository drillParticipantRepository;
	@Autowired
	DrillService drillService;
	@Autowired
	ApplicationService applicationService;

    /*
    Create a new job
     */
	public Job createJob(Job job, InternityUser user){
		try {
			Optional<Partner> companyObj = partnerRepository.findById(job.getPartnerId());
			if(companyObj.isPresent()) {
				Partner company = companyObj.get();
				job.setJobImageLink(company.getPartnerLogoPath());
				job.setPartnerName(company.getPartnerName());
				job.setJobLocation(setLocations(job.getJobLocation()));
				job.setJobSkills(setjobSkills(job.getJobSkills()));
				job.setCustUrl(getJobCustUrl(job,company));

				String screeningQuestions = job.getJobScreeningQuestions();
				job.setJobScreeningQuestions(null);
				Job savedJob = jobsRepository.save(job);

				if(!StringUtils.isBlank(screeningQuestions)){
					if(fetchAndSaveScreeningQuestions(savedJob, screeningQuestions).equals(CommonConstants.FAILED)){
						log.error("Exception while adding the screening question");
					//	return null;
					}
				}
				return savedJob;
			}
			else {
				return null;
			}
		}
		catch (Exception e){
			log.error("Exception while creating job {}", e);
			return null;
		}
	}

	private String getJobCustUrl( Job job, Partner company) {

		if (!StringUtils.isBlank(job.getCustUrl())) {
			String custUrl = job.getCustUrl().toLowerCase().replaceAll("[^a-zA-Z0-9\\s-]+", "-").replaceAll("\\s+", "-").replaceAll("-+", "-").replaceAll("-$", "");

			int count = jobsRepository.countByCustUrlStartingWith(custUrl);
			if(count>0){
				return custUrl+"-"+(count);
			}
			else{
				return custUrl;
			}
		}else {
			String custUrl = company.getPartnerDisplayName().toLowerCase()
					.replaceAll(" ", "-").replaceAll("\\.", "-")
					.replaceAll("\\s", "-")
					.replaceAll("/","").replaceAll("\\(","")
					.replaceAll("\\)","").replaceAll("-","")
					+ "-"
					+ job.getJobTitle().toLowerCase().replaceAll(" ", "-")
					.replaceAll("\\s", "-").replaceAll("\\.", "-")
					.replaceAll("/","").replaceAll("\\(","")
					.replaceAll("\\)","").replaceAll("-","");

			int count = jobsRepository.countByCustUrlStartingWith(custUrl);
			if(count>0){
				return custUrl+"-"+(count+1);
			}else {
				return custUrl+"-1";
			}
		}
	}

	private String fetchAndSaveScreeningQuestions(Job job, String screeningQuestions) {
	    try {
	        JSONArray questionJsonArr = new JSONArray(screeningQuestions);
	        ObjectMapper objectMapper = new ObjectMapper();
	        for (int i = 0; i < questionJsonArr.length(); i++) {
	            JSONObject innerObj = new JSONObject(questionJsonArr.getString(i));
	            String questionId = innerObj.getString("questionId"); // Assuming the question ID is provided in the JSON
	            // Check if the question already exists in the database
	            Optional<JobScreeningQuestion> existingQuestionObj = jobScreeningQuestionRepository.findById(questionId);
	            if (existingQuestionObj.isPresent()) {
					JobScreeningQuestion existingQuestion = existingQuestionObj.get();
	                // Update the existing question instead of creating a new one
	                existingQuestion.setQuestion(innerObj.getString("question"));
	                existingQuestion.setDecidingQuestion(Boolean.parseBoolean(innerObj.getString("isDecidingQuestion")));
	                existingQuestion.setExpectedAnswer(innerObj.getString("expectedAnswer"));
					existingQuestion.setAnswerType(innerObj.getString("answerType"));
	                // Update other properties as needed
	                jobScreeningQuestionRepository.save(existingQuestion);
	            } else {
	                // Create a new question
	                JobScreeningQuestion jobScreeningQuestion = new JobScreeningQuestion();
	                jobScreeningQuestion.setJobId(job.getJobId());
	                jobScreeningQuestion.setQuestion(innerObj.getString("question"));
	                jobScreeningQuestion.setDecidingQuestion(Boolean.parseBoolean(innerObj.getString("isDecidingQuestion")));
	                jobScreeningQuestion.setQuestionCategory("CUSTOM");
	                jobScreeningQuestion.setExpectedAnswer(innerObj.getString("expectedAnswer"));
					jobScreeningQuestion.setAnswerType(innerObj.getString("answerType"));
	                jobScreeningQuestion.setHidden(false);
	                // Set other properties as needed
	                jobScreeningQuestionRepository.save(jobScreeningQuestion);
	            }
	        }
	        return CommonConstants.SUCCESS;
	    } catch (Exception e) {
	        log.error("Exception while fetching and saving screening questions for the job ::: {}", e);
	        return CommonConstants.FAILED;
	    }
	}


	private String setLocations(String jobLocation) {

		return jobLocation
				.replaceAll("\",\"","/")
				.replaceAll("\\[","")
				.replaceAll("\\]","")
				.replaceAll("\"","");
	}

	private String setjobSkills(String jobSkills) {

		return jobSkills
				.replaceAll("\",\"",", ")
				.replaceAll("\\[","")
				.replaceAll("\\]","")
				.replaceAll("\"","");
	}

	public Response editJob(String jobId, Job payload, InternityUser user) {
		try {
			log.info("Editing job with ID ::: {}", jobId);
			Optional<Job> jobObj = jobsRepository.findById(jobId);
			if (!jobObj.isPresent()) {
				log.warn("Job not found for ID ::: {}", jobId);
				return responseUtil.notFoundResponse("Job not found for ID: " + jobId);
			}
			Job job = jobObj.get();

			if (StringUtils.isNoneBlank(payload.getPartnerId())) {
				Optional<Partner> customerObj = partnerRepository.findById(job.getPartnerId());
				if (!customerObj.isPresent()) {
					log.warn("Partner not found for ID :::{}",payload.getPartnerId());
					return responseUtil.notFoundResponse("partner not found");
				}
				Partner customer = customerObj.get();
				job.setPartnerName(customer.getPartnerName());
				job.setJobImageLink(customer.getPartnerLogoPath());
			}
			if (StringUtils.isNoneBlank(payload.getCustUrl())) {
				job.setCustUrl(payload.getCustUrl().toLowerCase().replaceAll("[^a-zA-Z0-9\\s-]+", "-").replaceAll("\\s+", "-").replaceAll("-+", "-").replaceAll("-$", ""));
			}
			if (StringUtils.isNoneBlank(payload.getJobTitle())) {
				job.setJobTitle(payload.getJobTitle());
			}
			if (StringUtils.isNoneBlank(payload.getJobType())) {
				job.setJobType(payload.getJobType());
			}
			if (StringUtils.isNoneBlank(payload.getJobCtcCategory())) {
				job.setJobCtcCategory(payload.getJobCtcCategory());
			}
			if (StringUtils.isNoneBlank(payload.getJobCategoryWeightage())) {
				job.setJobCategoryWeightage(payload.getJobCategoryWeightage());
			}
			if (StringUtils.isNoneBlank(payload.getJobCtcCurrency())) {
				job.setJobCtcCurrency(payload.getJobCtcCurrency());
			}
			if (StringUtils.isNoneBlank(payload.getJobDomain())) {
				job.setJobDomain(payload.getJobDomain());
			}
			if (StringUtils.isNoneBlank(payload.getJobDescription())) {
				job.setJobDescription(payload.getJobDescription());
			}
			if (StringUtils.isNoneBlank(payload.getJdLink())) {
				job.setJdLink(payload.getJdLink());
			}
			if (StringUtils.isNoneBlank(payload.getJobIndustryCategory())) {
				job.setJobIndustryCategory(payload.getJobIndustryCategory());
			}
			if (StringUtils.isNoneBlank(payload.getJobOtherSkills())) {
				job.setJobOtherSkills(payload.getJobOtherSkills());
			}
			if (StringUtils.isNoneBlank(payload.getJobMusthave())) {
				job.setJobMusthave(payload.getJobMusthave());
			}
			if (StringUtils.isNoneBlank(payload.getJobNoticePeriodAcceptable())) {
				job.setJobNoticePeriodAcceptable(payload.getJobNoticePeriodAcceptable());
			}
			if (StringUtils.isNoneBlank(payload.getJobRequisitionId())) {
				job.setJobRequisitionId(payload.getJobRequisitionId());
			}
			if (StringUtils.isNoneBlank(payload.getJobPostedBy())) {
				job.setJobPostedBy(payload.getJobPostedBy());
			}
			if (StringUtils.isNoneBlank(payload.getJobPriority())) {
				job.setJobPriority(payload.getJobPriority());
			}
			if (StringUtils.isNoneBlank(payload.getJobRounds())) {
				job.setJobRounds(payload.getJobRounds());
			}
			if (StringUtils.isNoneBlank(payload.getReferralCondition())) {
				job.setReferralCondition(payload.getReferralCondition());
			}
			if (StringUtils.isNoneBlank(payload.getJobSkills())) {
				job.setJobSkills(setjobSkills(payload.getJobSkills()));
			}
			if (StringUtils.isNoneBlank(payload.getJobLocation())) {
				job.setJobLocation(setLocations(payload.getJobLocation()));
			}
			if (payload.getJobMinCtcRange() >= 0.0) {
				job.setJobMinCtcRange(payload.getJobMinCtcRange());
			}
			if (payload.getJobMaxCtcRange() >= 0.0) {
				job.setJobMaxCtcRange(payload.getJobMaxCtcRange());
			}

			if (job.getJobEsopAcceptance() != payload.getJobEsopAcceptance()){
				job.setJobEsopAcceptance(payload.getJobEsopAcceptance());
			}
			if (payload.getJobMinYoe() >= 0.0) {
				job.setJobMinYoe(payload.getJobMinYoe());
			}
			if (payload.getJobMaxYoe() >= 0.0) {
				job.setJobMaxYoe(payload.getJobMaxYoe());
			}
			if (payload.getJobNumberOfVacancies() > 0){
				job.setJobNumberOfVacancies(payload.getJobNumberOfVacancies());
			}
			if (StringUtils.isNoneBlank(payload.getOtherTags())){
				job.setOtherTags(payload.getOtherTags());
			}
			if (StringUtils.isNoneBlank(payload.getDuration())){
				job.setDuration(payload.getDuration());
			}
			if (StringUtils.isNoneBlank(payload.getJobMode())){
				job.setJobMode(payload.getJobMode());
			}
			if (job.isPastInternshipExperience() != payload.isPastInternshipExperience()){
				job.setPastInternshipExperience(payload.isPastInternshipExperience());
			}
			if (job.getIsActive() != payload.getIsActive()){
				job.setIsActive(payload.getIsActive());
			}
			if (job.getIsCompanyNameHidden() != payload.getIsCompanyNameHidden()){
				job.setIsCompanyNameHidden(payload.getIsCompanyNameHidden());
			}
			if (job.getIsSalaryHidden() != payload.getIsSalaryHidden()){
				job.setIsSalaryHidden(payload.getIsSalaryHidden());
			}
			if (StringUtils.isNoneBlank(payload.getJobImageLink())){
				job.setJobImageLink(payload.getJobImageLink());
			}
			if (StringUtils.isNoneBlank(payload.getJobKeywords())){
				job.setJobKeywords(payload.getJobKeywords());
			}
			if (StringUtils.isNoneBlank(payload.getJobYoeTextForZero())){
				job.setJobYoeTextForZero(payload.getJobYoeTextForZero());
			}
			if (StringUtils.isNoneBlank(payload.getJobPositionOrder())){
				job.setJobPositionOrder(payload.getJobPositionOrder());
			}
			if (StringUtils.isNoneBlank(payload.getReferralCondition())){
				job.setReferralCondition(payload.getReferralCondition());
			}
			if (payload.getRewardDays() >= 0){
				job.setRewardDays(payload.getRewardDays());
			}
			if (job.isReferral() != payload.isReferral()){
				job.setReferral(payload.isReferral());
			}
			job.setUpdatedTs(new Date());
			jobsRepository.save(job);
			log.info("Job with ID {} updated successfully", jobId);
			return new Response(HttpStatus.OK.value(), Boolean.TRUE,job,null);

		} catch (Exception e) {
			log.error("Error editing job with ID {}: {}", jobId, e.getMessage());
			return responseUtil.internalServerErrorResponse("Failed to edit job with ID: " + jobId);

		}
	}
	
	public Job getJobDetails(String jobId,InternityUser user){
		try {
			
			Optional<Job> jobObj = jobsRepository.findById(jobId);
			Job job = new Job();
			if(jobObj.isPresent()) {
				job = jobObj.get();
				job.setPartner(partnerRepository.findById(job.getPartnerId()).get());
				List<JobScreeningQuestion> screeningQuestionObj = jobScreeningQuestionRepository.findByJobId(jobId);
				if(!screeningQuestionObj.isEmpty()){
					JSONArray arr = new JSONArray();
					JSONObject jsonObj = new JSONObject();
//					List<JSONObject> fieldsArr = new ArrayList<>();
//					JSONObject skillScore
//					for(JobScreeningQuestion question : screeningQuestionObj){
//						jsonObj.put("groupId", question);
//						jsonObj.put()
//					}
//					StringBuilder strr = new StringBuilder();
//					for(JobScreeningQuestion question : screeningQuestionObj){
//						strr.append(question.getQuestion());
//						strr.append(question.getQuestion());
//						strr.append("|");
//					}
					ObjectMapper objectMapper = new ObjectMapper();
					job.setJobScreeningQuestions(objectMapper.writeValueAsString(screeningQuestionObj));
				}
			}
			return job;
		}
		catch (Exception e){
			log.error("Exception while fetching job with jobid {} ::: {}", jobId, e);
			throw new RuntimeException("Failed to fetch the events");
		}
	}

	public List<Job> listOfFilteredJobs(String query, String uId, InternityUser user){
		try {
			if(null == query || query.equalsIgnoreCase("")) {
				query = "1=1 AND is_active = 1";
			}else if(query.equalsIgnoreCase("NA")) {
				query = "1=1";
			}
			//query = parser.parseQuery(query);
			List<Job> jobList = parser.getJobs(query);

			if(uId != null){
				jobList = removeJobsAlreadyApplied(jobList, uId);
			}
			return jobList;
		}
		catch(Exception e) {
			log.error(e);
			return Collections.emptyList();
		}
	}

	private List<Job> removeJobsAlreadyApplied(List<Job> jobList, String uId) {
		log.info("start checking jobs for user ::: {}", new Date());
		List<String> jobListAppliedByUser = applicationRepository.findJobListByuId(uId);
		List<Job> jobListForUser = new ArrayList<>();
		if(!jobListAppliedByUser.isEmpty()) {
			for (Job job : jobList) {
				if (!jobListAppliedByUser.contains(job.getJobId())){
					jobListForUser.add(job);
				}
			}
		}else{
			return jobList;
		}
		log.info("end checking jobs for user ::: {}", new Date());
		return jobListForUser;
	}

	public List<Job> getFilteredJobList(String filter,InternityUser user){
		try {
			if(filter.equalsIgnoreCase("NA")) {
				List<Job> results = jobsRepository.findAll();
				return results.isEmpty()?Collections.emptyList():results;
			}else {
				try {
					Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)(\\w+?),");
					Matcher matcher = pattern.matcher(filter + ",");
					
					Pattern patternForOr = Pattern.compile("(\\w+?)(:|<|>)(\\w+?);");
					Matcher matcherForOr = patternForOr.matcher(filter + ",");
					
					List  <JobsSpecification> jobspecs  = new ArrayList<>();
					List  <JobsSpecification> jobspecsForOr  = new ArrayList<>();
					
					while (matcherForOr.find()) {
						jobspecsForOr.add(new JobsSpecification(new SearchCriteria(matcherForOr.group(1), matcherForOr.group(2), matcherForOr.group(3))));   	
					}
					
					while (matcher.find()) {
						jobspecs.add(new JobsSpecification(new SearchCriteria(matcher.group(1), matcher.group(2), matcher.group(3))));   	
					}
					Specification<Job> spec = jobspecs.get(0);
					
					for(int i=1;i<jobspecs.size();i++) {
						log.info("...{}",jobspecs.get(i).toString());
						spec=Specification.where(spec).and(jobspecs.get(i));
					}
					Specification<Job> specForOr = jobspecsForOr.get(0);
					
					for(int i=1;i<jobspecsForOr.size();i++) {
						log.info("...{}",jobspecsForOr.get(i).toString());
						specForOr=Specification.where(specForOr).and(jobspecsForOr.get(i));
					}
					spec = Specification.where(spec).or(specForOr);
					List<Job> results = jobsRepository.findAll(spec);
					return results.isEmpty()?Collections.emptyList():results;
				}
				catch(Exception e) {
					e.printStackTrace();
					return Collections.emptyList();
				}
			}
			
		}
		catch (Exception e){
			throw new RuntimeException("Failed to fetch the events");
		}
	}

	public String updateJobStatus(String jobId,InternityUser user){
		try {
			
			Optional<Job> updateJobStatus = jobsRepository.findById(jobId);
			
			if(updateJobStatus.isPresent()) {
				updateJobStatus.get().setIsActive(!(updateJobStatus.get().getIsActive()));
				jobsRepository.save(updateJobStatus.get());
				return CommonConstants.SUCCESS;
			}else {
				return CommonConstants.NO_SUCH_JOB_EXISTS;
			}
			
		}
		catch (Exception e){
			throw new RuntimeException("Failed to fetch the job");
		}
	}

	/*
	Get the common values needed for in dropdowns w.r.t job
	 */
	public Map<String, Object> getAllHeaders(InternityUser user) {
		Map<String, Object> allHeaders = new HashMap<>();
		Set<String> allJobTitle = jobsRepository.findAllDistinctJobTitle();
		Set<String> allJobLocation = getJobLocations();
		Set<String> allJobType = jobsRepository.findAllDistinctJobType();
		allHeaders.put("jobTitle", allJobTitle);
		allHeaders.put("jobLocation", allJobLocation);
		allHeaders.put("jobType", allJobType);
		return allHeaders;
	}

	private Set<String> getJobLocations() {
		Set<String> jobLocationList = jobsRepository.findAllDistinctJobLocation();
		Set<String> result = new HashSet<>();
		for(String loc : jobLocationList){
			for(String location : loc.split("\\/|\\/\\s|\\||,|\\&")){
				location = location.trim();
				result.add(location);
			}
		}
		return result;
	}

	public boolean editJobStatus(String jobId, boolean action, InternityUser user) {
		try {
			Optional<Job> jobObj = jobsRepository.findById(jobId);
			
			if(jobObj.isPresent()) {
				Job job = jobObj.get();
				job.setIsActive(action);
				jobsRepository.save(job);
				return true;
			}
			else {
				return false;
			}
		}
		catch (Exception e){
			log.error("Exception while editing job status {}", e);
			throw new RuntimeException("Failed to update job status");
		}
	}

	public ResponseEntity<?> checkIfUserHasApplied(String jobId, String uId, InternityUser internityUser) {
		if(applicationRepository.findByuIdAndJobId(uId,jobId).isPresent()){
			return new ResponseEntity<>(true, HttpStatus.OK);
		}else{
			return new ResponseEntity<>(false, HttpStatus.OK);
		}
	}

	//@Cacheable("jobsresult")
	public SearchResultDto searchJobs(SearchJobCriteria searchCriteria,
									  int offset, int limit, String order, String profile) {
		log.info("Search criteria: {}", searchCriteria);
		SearchResultDto searchResultDTO = null;
		try{
			//log.info("Search criteria: {}", searchCriteria);
			String[] sort = order.split("\\.");
			Sort direction = Sort.by("desc".equalsIgnoreCase(sort[1])
					? Sort.Direction.DESC
					: Sort.Direction.ASC, sort[0]);
			Pageable pageable = PageRequest.of(offset, limit, direction);

			Page<Job> page = jobsRepository.findAll(new JobSpecification(searchCriteria), pageable);

			List<JobDto> jobs = page.getContent().stream().map(job -> new JobDto(job,drillRepository)).collect(Collectors.toList());

			setFeaturedJob(jobs);
			setPartnerIdNameAndImg(jobs);
			searchResultDTO = SearchResultDto.builder().data(jobs).totalRecordCount(page.getTotalElements())
					.build();
		}
		catch (Exception e){
			log.error("Exception while searching jobs {}", e);
		}
		log.info("cached data {}", cacheManager.getCache("jobs"));
		return searchResultDTO;
	}

	private void setPartnerIdNameAndImg(List<JobDto> jobs) {
		try{
			Map<String, Partner> mapOfPartnerIdAndPartnerObject = getMapOfPartnerIdAndPartnerObject();
			for(JobDto jobDto : jobs){
				Partner partner = mapOfPartnerIdAndPartnerObject.get(jobDto.getPartnerId());
				jobDto.setPartnerName(StringUtils.isBlank(partner.getPartnerDisplayName())?partner.getPartnerName():partner.getPartnerDisplayName());
				jobDto.setJobImageLink(partner.getPartnerLogoPath());
			}
		}
		catch (Exception e){
			log.error("Exception while setting up the partner id, name and partner logo URL ::: {}", e.getMessage());
		}
	}

	public Map<String, Partner> getMapOfPartnerIdAndPartnerObject(){
		List<Partner> partners = partnerRepository.findAll();
		Map<String, Partner> mapOfPartnerIdAndPartnerObject = new HashMap<>();

		for(Partner partner : partners){
			try{
				if (!StringUtils.isBlank(partner.getPartnerSocialLinks())) {
					mapOfPartnerIdAndPartnerObject.put(partner.getPartnerId(), partner);
				}
			}
			catch (Exception e){
				log.error("Exception while fetching website url ::: {}", e);
			}
		}
		return mapOfPartnerIdAndPartnerObject;
	}

	private List<JobDto> setFeaturedJob(List<JobDto> jobs) {
		try{
			List<Featured> featuredList = featuredRepository
					.findByElementTypeAndIsActiveOrderByPositionOrderDesc(FeaturedElementType.JOB.name(), true);
			List<String> jobIdFromFeatured = featuredList.stream().map(Featured::getElementId).collect(Collectors.toList());
			List<JobDto> finalJobDtoList = new ArrayList<>();
			for(JobDto jobDto : jobs){
				if(jobIdFromFeatured.contains(jobDto.getJobId())){
					jobDto.setFeatured(true);
					finalJobDtoList.add(jobDto);
				}
			}
			return finalJobDtoList;
		}
		catch (Exception e){
			log.error("Exception while setting featured flag with the job");
		}
		return jobs;
	}

	public Object fetchReferralCode(String uId, InternityUser user) {
		try{
		Optional<User> referralCode = userRepository.findById(uId);
		String result = referralCode.get().getReferralCode();
		return result;
	  } catch (Exception e) {
          log.error("Exception while fetching referral code {}", e);
          return new ResponseEntity<>("{\"msg\":\"" + CommonConstants.FAILED + " with exception " + e.getMessage() + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
      }

	}
	public void jobReferralWithReferralCode(String jobId, String uId,String email) {
		try {
            Optional<User> userObj = userRepository.findById(uId);
            Optional<Job>jobObj = jobsRepository.findById(jobId);
            if(userObj.isPresent()) {
                EmailContent emailContent = new EmailContent();
                emailContent.setSubject("Job Referral  " +
                        "for " + jobObj.get().getJobTitle() + "from"+userObj.get().getFullName());
                emailContent.setTemplateName("GenericMailForAllUsers");
                emailContent.setMessage("<h3>You are invited for Job Drive:</h3><table><tr>" +
                        "<td><b>Job Title</b>:</td><td>&nbsp; "+jobObj.get().getJobTitle()+"</td></tr><tr>"+
                        "<td><b>Company</b>:</td><td>&nbsp; "+jobObj.get().getPartnerName()+"</td></tr><tr>"+
                        "<td><b>Job Type</b>:</td><td>&nbsp; "+jobObj.get().getJobType()+"</td></tr><tr>"+
                        "<td><b>Job Skills</b>:</td><td>&nbsp; "+jobObj.get().getJobSkills()+"</td></tr><tr>"+
                        "<td><b>Referral Code</b>:</td><td>&nbsp; "+userObj.get().getReferralCode()+"</td></tr></table>");
                
                emailContent.setLink(domainUrl + "/jobs/"+jobId);
                messageUtils.sendMail(email, emailContent);
            }
		} catch (Exception exception) {
			log.info(exception.getMessage());
		}
			
	}
	public void jobInvite(String jobId, String recruiterUId,String emailIdList) {
		try {
            Optional<User> userObj = userRepository.findById(recruiterUId);
            Optional<Job> jobObj = jobsRepository.findById(jobId);
            if(userObj.isPresent()) {
                EmailContent emailContent = new EmailContent();
                emailContent.setSubject("Job Invite " +
                        "for " + jobObj.get().getJobTitle() + " from recruiter "
						+ userObj.get().getFullName() + " on Where U Elevate platform");
                emailContent.setTemplateName("JobInviteMail");
                emailContent.setJobId(jobObj.get().getJobId());
				Job job = jobObj.get();
                emailContent.setMessage(
                        "<h3>We are looking for "
                                + job.getJobTitle()
                                + " with "
                                + job.getPartnerName()
                                + ":</h3>"
                                + "<table style=\"margin-bottom:10px; border:1px solid #dddddd; border-style:groove; border-color: #1e324f;"
                                + "border-radius:10px; padding:10px; width:100%; border-collapse: collapse;\"><tr>"
                                + "<td><b>Salary range</b></td><td>&nbsp; "
                                + getJobCtc(job)+" </td></tr><tr>"
                                + "<td><b>Experience required</b></td><td>&nbsp; "
                                + job.getJobMinYoe()
                                + " - "
                                + job.getJobMaxYoe()
                                + " years </td></tr><tr>"
                                + "<td><b>Job Type</b></td><td>&nbsp; "
                                + job.getJobType()
                                + "</td></tr><tr>"
                                + "<td><b>Job Skills</b></td><td>&nbsp; "
                                + job.getJobSkills()
                                + "</td></tr></table>");
                emailContent.setLink(domainUrl + "/jobs/"+job.getCustUrl());

                for (String email : emailIdList.split(",")) {
                    if (!StringUtils.isBlank(email)) {
                        Optional<User> jobSeeker = userRepository.findByEmail(email);
                        String username = "Dear User";
                        if (jobSeeker.isPresent()) {
                            username = jobSeeker.get().getFullName();
                        }
                        emailContent.setUserName(username);
                        messageUtils.sendMail(email, emailContent);
						log.info("Mail sent to email {}", email);
					}
				}
            }
		} catch (Exception exception) {
			log.info(exception.getMessage());
		}
		
	}

	private String getJobCtc(Job job) {
		String ctc = job.getJobMinCtcRange() + "-" + job.getJobMaxCtcRange();
		if(job.getJobType().equalsIgnoreCase("Paid Internship")){
			return ctc + " " + job.getJobCtcCategory().toLowerCase();
		}
		else {
			return ctc + " LPA";
		}
	}

	public Object sendMailForRerralAndInvite(String type, String recruiterUId, String jobId,
											 String emailIdList, String mailSubject, String mailBody,
											 InternityUser user) {
		Optional<Job> jobObj = jobsRepository.findById(recruiterUId);
		try {
			jobInvite(jobId,recruiterUId,emailIdList);
			return commonUtils.message(HttpStatus.OK,"Mail sent successfully for Job Invite");
//		if(jobObj.get().isReferral()==true && type.equalsIgnoreCase("referral")) {
//			jobReferralWithReferralCode(emailIdList,recruiterUId,jobId);
//			return "Mail Send Successfully for Job Referral";
//		}
//		else {
		//}
	  } catch (Exception e) {
          log.error("Exception while sending Mail {}", e);
          return new ResponseEntity<>("{\"msg\":\"" + CommonConstants.FAILED + " with exception " + e.getMessage() + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
      }
	}

    public Object resumeScreeningAsPerJobDescription(
            String uId, String jobId, String skills, InternityUser user) {
        Map<String, Map<String, Object>> result = new HashMap<>();
        Map<String, Object> matchedSkillsWithPercentage = new HashMap<>();
        try {
			List<Job> jobList = new ArrayList<>();
			if(!jobId.equalsIgnoreCase("NA")){
				Optional<Job> jobObj = jobsRepository.findById(jobId);
				jobList.add(jobObj.get());
			}
			else {
				List<Job> jobListFromDb = jobsRepository.findAll();
				jobList.addAll(jobListFromDb);
			}

			List<User> userList = new ArrayList<>();
			if(!uId.equalsIgnoreCase("NA")){
				Optional<User> userObj = userRepository.findById(uId);
				userList.add(userObj.get());
			}
			else {
				List<User> userListFromDb = userRepository.findAll();
				userList.addAll(userListFromDb);
			}

            for (Job job : jobList) {
				for(User userObject : userList){
                    Optional<UserPersonalDetail> candidateObj =
                            userProfileRepository.findByuId(userObject.getUId());
                    if (candidateObj.isPresent()) {
                        String resumeLink = candidateObj.get().getResumeLink();
                        if (resumeLink == null || !resumeLink.matches("^https?://.+")) {
                            continue; // skip this user and go to the next iteration of the loop
                        }

						log.info("Resume getting parsed for user {}", userObject.getUId());

                        String resumeData = parseResume(resumeLink);

                        ObjectMapper objectMapper = new ObjectMapper();
                        Map<String, Object> resumeMap =
                                objectMapper.readValue(resumeData, Map.class);
                        List<String> userSkills = (List<String>) resumeMap.get("skills");
                        JSONObject jsonObj = new JSONObject(resumeMap);

						matchedSkillsWithPercentage =
								getSkillsMatchedPercentageForASingleUser(uId, job);
						log.info("matchedSkillsWithPercentage  ::: {}", matchedSkillsWithPercentage);
						JSONObject jsonObject = new JSONObject(matchedSkillsWithPercentage);
						List<Application> userApplication = applicationRepository.findByuId(uId);

						for (Application application : userApplication) {
							application.setSkillsMatchedDetails(jsonObject.toString());
							applicationRepository.save(application);
						}
                    }
                }
			}
        } catch (Exception e) {
			log.error("Error occurred while screening resumes as per job description ::: {}", e );
            return ("Error occurred while screening resumes as per job description"
                    + e);
        }
        return result;

    }

	/**
	 * Compare and return the primary, secondary skills with total Yoe
	 * with their score, expected and actual data
	 *
	 * @param uId
	 * @param job
	 * @return
	 */
	public Map<String, Object> getSkillsMatchedPercentageForASingleUser(String uId, Job job) {
		try{
			log.info("getSkillsMatchedPercentageForASingleUser ::: {} ::: {}", uId, job.getJobId());
			Optional<UserPersonalDetail> userObj = userProfileRepository.findByuId(uId);
			Map<String, Object> matchedSkillsWithPercentage = new HashMap<>();
			String projectDescription = "";

			if (!userObj.isPresent()) {
				return Collections.EMPTY_MAP;
			}

			String resumeLink = userObj.get().getResumeLink();
			Map<String, Object> resumeMap = new HashMap<>();

			Optional<UserCandidateMandatoryFields> mandatoryFields = mandatoryFieldsRepository.findByuId(uId);
            if (mandatoryFields.isPresent()) {
				UserCandidateMandatoryFields fields = mandatoryFields.get();
				if(StringUtils.isBlank(fields.getPrimarySkills())){
					String resumeData = parseResume(resumeLink);
					ObjectMapper objectMapper = new ObjectMapper();
					Map<String, Object> tempResumeMap = objectMapper.readValue(resumeData, Map.class);
					resumeMap.put("skills", tempResumeMap.get("skills")+"");
                } else {
                    resumeMap.put("skills", fields.getPrimarySkills());
				}
				resumeMap.put("totalYoE", fields.getYoe());
			}
			else {
				String resumeData = parseResume(resumeLink);
				ObjectMapper objectMapper = new ObjectMapper();
				resumeMap = objectMapper.readValue(resumeData, Map.class);
			}

			String resumeMapStr = resumeMap.get("skills")+"";

			resumeMapStr = resumeMapStr.replaceAll("\\[","").replaceAll("]","")
								.replaceAll("\"","");

			List<String> userSkills = Arrays.asList(resumeMapStr.split(","));
			Double totalYoeFromResume = null;
			try{
				totalYoeFromResume = Double.parseDouble(resumeMap.get("totalYoE")+"");
			}
			catch (Exception e){
				log.error("Exception while fetching the YoE from resume ::: {}", e);
			}

			JSONObject jsonObj = new JSONObject(resumeMap);

			int jobSkillSize = Arrays.asList(job.getJobSkills()).size();
			log.info("Resume getting parsed for user {}", uId);
			Map<String, Object> result = new HashMap<>();

			String jobSkillsStr = job.getJobSkills();

			jobSkillsStr = jobSkillsStr.replaceAll("\\[","").replaceAll("]","")
					.replaceAll("\"","");

			List<String> mandatorySkills = Arrays.asList(jobSkillsStr.split(","));

            result.put(
                    JobSkillsCategory.MANDATORY.name(),
                    compareSkills(
                            mandatorySkills,
                            userSkills,
                            mandatorySkills.size()));

			List<String> additionalSkills = getACategorySkillsFromJob("additional", job.getJobOtherSkills());
            result.put(
                    JobSkillsCategory.ADDITIONAL.name(),
                    compareSkills(
                            additionalSkills,
                            userSkills,
							additionalSkills.size()));

			List<String> secondarySkills = getACategorySkillsFromJob("secondary", job.getJobOtherSkills());
            result.put(
                    JobSkillsCategory.SECONDARY.name(),
                    compareSkills(
                            secondarySkills,
                            userSkills,
							secondarySkills.size()));

			result.put(
					CommonConstants.TOTAL_YOE,
					compareTotalYoe(job.getJobMinYoe(), job.getJobMaxYoe(), totalYoeFromResume));

			return result;
		}
		catch (Exception e){
			log.error("Exception while fetching the skills matched percentage for a single user {}", e);
			return Collections.EMPTY_MAP;
		}
	}

	private List<String> getACategorySkillsFromJob(String category, String jobSkills){
        if (!StringUtils.isBlank(jobSkills)) {
			log.info("job other skills ::: {}", jobSkills);
            JSONObject jobOtherSkills = new JSONObject(jobSkills+"");
            if (category.equalsIgnoreCase("additional") && !jobOtherSkills.isNull("additional")) {
                JSONObject additionalObj = jobOtherSkills.getJSONObject("additional");
                return Arrays.asList(additionalObj.get("skills").toString());
            } else if (category.equalsIgnoreCase("secondary")
                    && !jobOtherSkills.isNull("secondary")) {
                JSONObject additionalObj = jobOtherSkills.getJSONObject("secondary");
                return Arrays.asList(additionalObj.get("skills").toString());
            }
		}
		return Collections.emptyList();
	}

	public String parseResume(String resumeUrl) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
		String payloadJson = "{\"resume_s3_url\": \""+resumeUrl+"\"}";
		HttpEntity<String> request = new HttpEntity<String>(payloadJson,headers);
        String response =
                restTemplate.postForObject(
                        certificateGeneratorUrl,
                        request,
                        String.class);
        return response;
    }

    private Map<String, Object> compareTotalYoe(
			Double jobMinYoe,
			Double jobMaxYoe,
			Double yoeFromResume) {
		try{
			if(jobMinYoe==null || jobMaxYoe == null || yoeFromResume == null || yoeFromResume.isNaN()){
				return Collections.emptyMap();
			}

			Map<String, Object> result = new HashMap<>();
			if(yoeFromResume>=jobMinYoe && yoeFromResume<=jobMaxYoe){
				result.put("totalYoeScore", "100.0");
			}
			else if (yoeFromResume<jobMinYoe)
			{
				Double diffBetweenMinYoeAndResumeYoe = yoeFromResume - jobMinYoe;

				if(diffBetweenMinYoeAndResumeYoe>(-0.5)){
					result.put("totalYoeScore", "80.0");
				}
				else if(diffBetweenMinYoeAndResumeYoe<(-0.5) && diffBetweenMinYoeAndResumeYoe>(-1.0)){
					result.put("totalYoeScore", "60.0");
				}
				else{
					result.put("totalYoeScore", "0.0");
				}
			}
			else if (yoeFromResume>jobMaxYoe)
			{
				Double diffBetweenMaxYoeAndResumeYoe = yoeFromResume - jobMaxYoe;

				if(diffBetweenMaxYoeAndResumeYoe<(0.5)){
					result.put("totalYoeScore", "80.0");
				}
				else if(diffBetweenMaxYoeAndResumeYoe>(0.5) && diffBetweenMaxYoeAndResumeYoe<(1.0)){
					result.put("totalYoeScore", "60.0");
				}
				else if(diffBetweenMaxYoeAndResumeYoe>(1.0) && diffBetweenMaxYoeAndResumeYoe<(1.5)){
					result.put("totalYoeScore", "40.0");
				}
				else{
					result.put("totalYoeScore", "0.0");
				}
			}

			result.put("expectedTotalYoe", jobMinYoe + "-" + jobMaxYoe + " yrs");
			result.put("actualTotalYoe", yoeFromResume+"");

			return result;
		}
		catch (Exception e){
			log.error("Exception while comparing total yoe with resume parsed value ::: {}", e);
		}
		return null;
	}

	private Map<String, Object> compareSkills(List<String> jobSkills, List<String> userSkills, int jobSkillSize) {
	    try{
		if (jobSkills == null || userSkills == null || jobSkills.isEmpty() || userSkills.isEmpty()) {
	        return Collections.emptyMap();
	    }

	    // Convert job skills and user skills to lowercase
	    List<String> jobSkillsLower = jobSkills.stream().map(String::toLowerCase).collect(Collectors.toList());
	    List<String> userSkillsLower = userSkills.stream().map(String::toLowerCase).collect(Collectors.toList());

		log.info("user skills {} ::: job skills {}", userSkills, jobSkills);
        
	    List<String> resumeMatchedJobSkills = new ArrayList<>();
	    List<String> projectMatchedJobSkills = new ArrayList<>();

		for (String jobSkill : jobSkillsLower) {
	            if (userSkillsLower.toString().contains(jobSkill.trim())) {
	            	resumeMatchedJobSkills.add(jobSkill);
	        }
	    }

	    Set<String> setWithoutDuplicates = new LinkedHashSet<>(resumeMatchedJobSkills);
	    List<String> listWithoutDuplicates = new ArrayList<>(setWithoutDuplicates);
	    int matchedSkills = listWithoutDuplicates.size();
	    double percentageMatch = ((double) matchedSkills / (jobSkillSize)) * 100;
	    String percentageMatchFromResume = String.valueOf(percentageMatch);
	    Map<String, Object> result = new HashMap<>();
	    result.put("skillsMatchedFromResume", percentageMatchFromResume);
	  	log.info("All map percentage match from resume ::: {}", percentageMatchFromResume);

		result.put("matchedSkills",listWithoutDuplicates);

		result.put("actualJobSkills",jobSkillsLower);
		log.info("All map matchedSkills ::: {}", result);

		return result;
		}
		catch (Exception e){
			log.error("Exception while comparing mandatory, secondary and additional skills ::: {}", e);
		}
		return null;
	}



	public Object fetchJobidFromCusturl(String custUrl) {
		try {
			Optional<Job> jobObj = jobsRepository.findByCustUrl(custUrl);
			if (jobObj.isPresent()) {
				return jobObj.get().getJobId();
			} else {
				return commonUtils.message(
						HttpStatus.INTERNAL_SERVER_ERROR, "Please check the custom url for the Job");
			}
		} catch (Exception e) {
			log.error("Exception while fetching id from job custom URL {}", e);
		}
		return commonUtils.message(
				HttpStatus.INTERNAL_SERVER_ERROR,
				"Failed while fetching id from Job custom URL. Check the Job custom url");
	}

	public Object postCustUrlForAllPreviousJobs() {
		try{
			List<Job> listOfAllJob = jobsRepository.findAll();
			List<Partner> allPartners = partnerRepository.findAll();
			Map<String, String> partnerIdAndPartnerName = new HashMap<>();
			for(Partner partner : allPartners){
				partnerIdAndPartnerName.put(partner.getPartnerId(), partner.getPartnerName());
			}

			for(Job job : listOfAllJob){
                if (StringUtils.isBlank(job.getCustUrl())) {
					log.info("Saving custom url for job ::: {} with id ::: {}", job.getJobTitle(), job.getJobId());
					String partnerName = !StringUtils.isBlank(partnerIdAndPartnerName.get(job.getPartnerId()))
							?
							partnerIdAndPartnerName.get(job.getPartnerId()).replaceAll(" ", "-")
							:
							""
							;
					String custUrl =
							partnerName.toLowerCase()
									+ "-"
									+ job.getJobTitle().toLowerCase().replaceAll(" ", "-");
					Optional<Job> jobForCustUrl = jobsRepository.findByCustUrl(custUrl);
					if(jobForCustUrl.isPresent()){
						String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
						Random random = new Random();
						StringBuilder shortUrlBuilder = new StringBuilder();
						for (int i = 0; i < 4; i++) {
							shortUrlBuilder.append(characters.charAt(random.nextInt(characters.length())));
						}
						job.setCustUrl(
								partnerName.toLowerCase()
										+ "-"
										+ job.getJobTitle().toLowerCase().replaceAll(" ", "-")
										+ "-"
										+ shortUrlBuilder.toString());
                    } else {
                        job.setCustUrl(custUrl);
					}
                    jobsRepository.save(job);
				}
			}
			return commonUtils.message(HttpStatus.OK, "Successfully updated cust url of jobs");
		}
		catch (Exception e){
			log.error("Exception while setting cust url for job having cust url as null ::: {}", e);
			return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Error Occurred ::: {}"+e.getMessage());
		}
	}
	public void openToAllMail(String emailIdList) {
	    try {
	        List<String> elementIds = new ArrayList();
	        List<Featured> featuredJobList = featuredRepository.findAllByIsActiveTrue();
	        for (Featured featured : featuredJobList) {
	            elementIds.add(featured.getElementId());
	        }

	        List<Job> jobList = jobsRepository.findByJobIdIn(elementIds);
	        EmailContent emailContent = new EmailContent();
	        emailContent.setSubject("Where U Elevate | Job Recommendation");
	        emailContent.setTemplateName("ScheduledJobFeed");
	        StringBuilder messageBuilder = new StringBuilder();
	        for (Job job : jobList) {
	        	 messageBuilder.append("<div class= Job-card>"+
	    	            "  <img src= https://example.com/website.png  alt= Avatar  class= job-avatar >" +
	    	            "  <div class= job-info >" +
	    	            "    <div class= job-title >" + job.getJobTitle() + "</div>" +
	    	            "    <div class= company-info >" +
	    	            "      <div class= company-name >" + job.getPartnerName() + "</div>" +
	    	            "    </div>" +
	    	            "    <br>" +
	    	            "    <div class= additional-info >" +
	    	            "      <img src= https://example.com/experience.png  alt= Experience Logo >" +
	    	            "      <span class= experience-value >" + job.getJobMinYoe() + "</span>" +
	    	            "      <img src= https://example.com/location.png  alt= Location Logo >" +
	    	            "      <span class= location-value >" + job.getJobLocation() + "</span>" +
	    	            "      <img src= https://example.com/salary.png  alt= Salary Offered Logo >" +
	    	            "      <span class= salary-value >" + job.getJobMinCtcRange() + "-" + job.getJobMaxCtcRange() +"</span>" +
	    	            "    </div>" +
	    	            "  </div>" +
	    	            "  </div>" +
	    	            "<br>");
	        }
	        emailContent.setMessage(messageBuilder.toString());
	        
	        if (emailIdList.equalsIgnoreCase("NA")) { // Send to all users in UserRepository
	            List<User> userList = userRepository.findAll();
	            for (User user : userList) {
	                messageUtils.sendMail(user.getEmail(), emailContent);
	            }
	        } else { // Send to emailIdList
	            String[] emailIds = emailIdList.split(",");
	            for (String emailId : emailIds) {
	                messageUtils.sendMail(emailId.trim(), emailContent);
	            }
	        }
	    } catch (Exception exception) {
	        log.info(exception.getMessage());
	    }
	}
	public Object sendMailOpenToAll( String emailIdList,InternityUser user) {
		try {
			openToAllMail(emailIdList);
		return commonUtils.message(HttpStatus.OK,"Mail sent successfully for Job Invite");
		} catch (Exception e) {
		log.error("Exception while sending Mail {}", e);
		return new ResponseEntity<>("{\"msg\":\"" + CommonConstants.FAILED + " with exception " + e.getMessage() + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public Map<String, String> sendMailToInvite(String emailIdList, String uId, String jobId) {
	    try {
	        Optional<User> userObj = userRepository.findById(uId);
	        Optional<Job> jobObj = jobsRepository.findById(jobId);
	        
	        if (jobObj.isPresent()) {
	            EmailContent emailContent = new EmailContent();
	            emailContent.setSubject("Where U Elevate | Job Invite for " + jobObj.get().getJobTitle()
						+ (userObj.isPresent() ? " from " + userObj.get().getFullName() : ""));
	            emailContent.setTemplateName("JobInviteMail");
	            emailContent.setJobId(jobObj.get().getJobId());
	            Job job = jobObj.get();
	            emailContent.setUserName("User");
	            emailContent.setMessage("<div class= Job-card>" +
	                    "  <div class= job-info>" +
	                    "    <div class= job-title align=left><strong>" + job.getJobTitle() + "</strong></div>" +
	                    "    <div class= company-info >" +
	                    "      <div class= company-name >" + job.getPartnerName() + "</div>" +
	                    "    </div>" +
	                    "    <br>" +
	                    "    <div class= additional-info >" +
	                    "      <span class= salary-value > Salary: " + (job.getJobMaxCtcRange() != 0.0 ? (job.getJobMinCtcRange() + "-" + job.getJobMaxCtcRange()) + " " + job.getJobCtcCategory() : "Best in industry") + "</span>" +
	                    "      <span class= experience-value> Experience required: " + job.getJobMinYoe() + "-" + job.getJobMaxYoe() + " yrs </span>" +
	                    "      " +
	                    "    </div>" +
	                    "  </div>" +
	                    "</div><br>");
	            emailContent.setLink(domainUrl + "/jobs/" + job.getCustUrl());
		            String[] emailIds = emailIdList.split(",");
		            for (String emailId : emailIds) {
		                messageUtils.sendMail(emailId.trim(), emailContent);
		            }
	            log.info("Invitation email sent to " + emailIdList + " for job " + jobId);
				return commonUtils.message(HttpStatus.OK, "Email sent successfully");
			} else {
	            log.error("User or job not found for invitation email");
				return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "User or job not found for inviting via email");
			}
	    } catch (Exception exception) {
	        log.error("Error sending invitation email: " + exception.getMessage());
			return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while sending email");
		}
	}
	
	public Map<String, String> sendMailForInvite( String uId, String jobId,
			 String emailIdList,InternityUser user) {
		try {
			return sendMailToInvite(emailIdList,uId,jobId);
		} catch (Exception e) {
			log.error("Exception while sending Mail {}", e);
			return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while sending email");
		}
	}

	public String deleteScreeningQuestionById(String questionId) {
	    try {
	        Optional<JobScreeningQuestion> optionalQuestion = jobScreeningQuestionRepository.findById(questionId);
	        if (optionalQuestion.isPresent()) {
	            JobScreeningQuestion question = optionalQuestion.get();
	            jobScreeningQuestionRepository.deleteById(questionId);
	            return "Screening question with ID " + question.getQuestionId() + " has been deleted.";
	        } else {
	            return "Screening question not found.";
	        }
	    } catch (Exception e) {
	        return "Failed to delete screening question: " + e.getMessage();
	    }
	}

	public ResponseEntity<?> processPDF(String jobDescriptionLink) {
	    try {
	        if (jobDescriptionLink.equals("NA")) {
	            log.error("No job description link provided");
	            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "No job description link provided"), HttpStatus.INTERNAL_SERVER_ERROR);
	        }

	        String apiUrl = resumeParsingUrl + "/job-description?jobDescriptionLink=" + jobDescriptionLink;

	        RestTemplate restTemplate = new RestTemplate();
	        ResponseEntity<String> responseEntity = restTemplate.postForEntity(apiUrl, null, String.class);

	        return new ResponseEntity<>(responseEntity.getBody(), HttpStatus.OK);
	    } catch (Exception e) {
	        log.error("Error processing the job description link: {}", e.getMessage());
	        return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Error processing the job description link"), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}

	public Response createDrillBasedJob(String drillId, Job job, InternityUser user) {

		try {
			log.info("Inside createDrillBasedJob");
			if (StringUtils.isBlank(drillId)) {
				log.error("Drill Id cannot be empty or undefined");
				return responseUtil.badRequestResponse("Drill Id cannot be empty or undefined");
			}
			Optional<Drill> drillObj = drillRepository.findById(drillId);
			if (!drillObj.isPresent()) {
				log.error("Drill not found with the Specified Id");
				return responseUtil.internalServerErrorResponse("Drill not found with the Specified Id");
			}
			if (!drillObj.get().getDrillPurpose().equals("Hiring")) {
				log.error("Cannot Create Job for Non Hiring Hackathon");
				return responseUtil.badRequestResponse("Cannot Create Job for Non Hiring Hackathon");
			}

			log.info("Creating Drill Based Job");
			// creating drill based job
			Optional<Partner> companyObj = partnerRepository.findById(job.getPartnerId());
			if (companyObj.isPresent()) {
				Partner company = companyObj.get();
				job.setJobImageLink(company.getPartnerLogoPath());
				job.setPartnerName(company.getPartnerName());
				job.setJobLocation(setLocations(job.getJobLocation()));
				job.setJobSkills(setjobSkills(job.getJobSkills()));
				job.setCustUrl(getJobCustUrl(job, company));
				job.setDrillId(drillId);

				String screeningQuestions = job.getJobScreeningQuestions();
				job.setJobScreeningQuestions(null);
				Job savedJob = jobsRepository.save(job);

				if (!StringUtils.isBlank(screeningQuestions)) {
					if (fetchAndSaveScreeningQuestions(savedJob, screeningQuestions).equals(CommonConstants.FAILED)) {
						log.error("Exception while adding the screening question");
					}
				}
				log.info("Drill Based Job Created Successfully");
				return responseUtil.successResponse(savedJob);
			} else {
				log.error("Company not found with the Specified partner Id");
				return responseUtil.badRequestResponse("Company not found with the Specified partner Id");
			}
		} catch (Exception e) {
			log.error("Exception while creating drill based job: {}", e.getMessage());
			return responseUtil.internalServerErrorResponse("Exception while creating drill based job");
		}
	}

	public Response updateDrillBasedJob(String jobId, Job job, InternityUser user) {
		try {
			log.info("Inside updateDrillBasedJob");
			if (StringUtils.isBlank(jobId)) {
				log.error("Job Id cannot be empty or undefined");
				return responseUtil.badRequestResponse("Job Id cannot be empty or undefined");
			}
			if(!jobId.equals(job.getJobId())) {
				return responseUtil.badRequestResponse("Path Id and Object Id does not Match");
			}
			Optional<Job> jobOptional = jobsRepository.findById(jobId);
			if (jobOptional.isPresent()) {
				Job existingJob = jobOptional.get();
				Field[] fields = Job.class.getDeclaredFields();
				for (Field field : fields) {
					field.setAccessible(true);
					Object newValue = field.get(job);
					// Update the field regardless of whether it's null in the existing job
					if (!Objects.isNull(newValue)) {
						if (field.getType() == int.class || field.getType() == Integer.class) {
							int intValue = (int) newValue;
							if (intValue != 0) {
								field.set(existingJob, intValue);
							}
						} else if (field.getType() == double.class || field.getType() == Double.class) {
							double doubleValue = (double) newValue;
							if (doubleValue != 0.0) {
								field.set(existingJob, doubleValue);
							}
						} else if (field.getType() == boolean.class || field.getType() == Boolean.class) {
							boolean booleanValue = (boolean) newValue;
							field.set(existingJob, booleanValue);
						} else {
							field.set(existingJob, newValue);
						}
					}
				}
				existingJob.setJobScreeningQuestions(null);
				Job savedJob = jobsRepository.save(existingJob);
				if (!StringUtils.isBlank(existingJob.getJobScreeningQuestions())) {
					if (fetchAndSaveScreeningQuestions(savedJob, job.getJobScreeningQuestions()).equals(CommonConstants.FAILED)) {
						log.error("Exception while adding the screening question");
					}
				}
				log.info("Job updated successfully");
				return responseUtil.successResponse(savedJob);
				}
			 else {
				log.error("Job not found with the Specified Id");
				return responseUtil.internalServerErrorResponse("Job not found with the Specified Id");
			}
		} catch (Exception e) {
			log.error("Exception while updating drill based job: {}", e.getMessage());
			return responseUtil.internalServerErrorResponse("Exception while updating drill based job");
		}
	}

	public Response applyDrillBasedJob(String jobId, String drillId, DrillParticipant participant, InternityUser user) {

		try {
			log.info("Inside applyDrillBasedJob");
			if (StringUtils.isBlank(jobId)) {
				log.error("Job Id cannot be empty or undefined");
				return responseUtil.badRequestResponse("Job Id cannot be empty or undefined");
			}

			Optional<Job> jobObj = jobsRepository.findById(jobId);
			if (!jobObj.isPresent()) {
				log.error("Job not found with the Specified Id");
				return responseUtil.internalServerErrorResponse("Job not found with the Specified Id");
			}

			if (StringUtils.isBlank(drillId)) {
				log.error("Drill Id cannot be empty or undefined");
				return responseUtil.badRequestResponse("Drill Id cannot be empty or undefined");
			}

			Optional<Drill> drillObj = drillRepository.findById(drillId);
			if (!drillObj.isPresent()) {
				log.error("Drill not found with the Specified Id");
				return responseUtil.internalServerErrorResponse("Drill not found with the Specified Id");
			}
			log.info("Checking if user has already applied for drill");
			// check if participant is already applied for drill
			Optional<DrillParticipant> drillParticipantObj = drillParticipantRepository
					.findByDrillIdAndEmail(drillId, participant.getEmail());
			// not applied create drill participant
			if (!drillParticipantObj.isPresent()) {
				log.info("Creating new drill participant");
				Response response = drillService.saveDrillParticipant(participant, user);
				if (!response.getSuccess()) {
					log.error("Error occur while creating drill participant {}", response.getError().getMessage());
					return response;
				}
				else{
					log.info("Drill Participant Created Successfully");
				}
			}
			else{
				log.info("User has already applied for drill");
			}
			// check if participant is already applied for job
			Application application = applicationRepository.findByJobIdAndUId(jobId, participant.getPlatformUId());
			if (application == null) {
				log.info("Creating new job participant");
				ApplicationDto applicationDto = new ApplicationDto();
				applicationDto.setJobId(jobId);
				applicationDto.setUId(participant.getPlatformUId());
				applicationDto.setCurrentStatus("applied");
				ResponseEntity<?> responseEntity =  applicationService.addApplication(applicationDto, user);
                Response response = (Response) responseEntity.getBody();
                log.info("Application Response: {}",response.getResult());
				return response ;
			} else {
				log.info("You have already applied for this job");
				return responseUtil.badRequestResponse("You have already applied for this job");
			}
		} catch (Exception e) {
			log.error("Exception while applying drill based job: {}", e.getMessage());
			return responseUtil.internalServerErrorResponse("Exception while applying drill based job");
		}
	}

	private <T> void updateIfNotBlank(Consumer<T> setter, T value) {
		if (StringUtils.isNotBlank(String.valueOf(value))) {
			setter.accept(value);
		}
	}

}
	