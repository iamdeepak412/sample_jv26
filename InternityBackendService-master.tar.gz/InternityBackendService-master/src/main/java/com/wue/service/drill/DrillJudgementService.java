package com.wue.service.drill;

import com.wue.domain.drill.Drill;
import com.wue.domain.drill.DrillCollaborators;
import com.wue.domain.drill.DrillPhases;
import com.wue.domain.drill.judgement.DrillAssignPanel;
import com.wue.domain.drill.judgement.DrillJudgePanelLookup;
import com.wue.domain.drill.judgement.DrillJudgementPanel;
import com.wue.domain.drill.judgement.DrillSubmissionPanelLookup;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.dto.drill.DrillJudgeDto;
import com.wue.dto.drill.judgement.DrillAssignJudgePanelDto;
import com.wue.repository.drill.DrillCollaboratorsRepository;
import com.wue.repository.drill.DrillPhasesRepository;
import com.wue.repository.drill.DrillRepository;
import com.wue.repository.drill.judgement.DrillAssignJudgePanelRepository;
import com.wue.repository.drill.judgement.DrillJudgePanelLookupRepository;
import com.wue.repository.drill.judgement.DrillJudgementPanelRepository;
import com.wue.repository.drill.judgement.DrillSubmissionPanelLookupRepository;
import com.wue.repository.drill.submission.DrillParticipantSubmissionRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.drill.SendCustomMailUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.*;

@Service
@Log4j2
public class DrillJudgementService {
    @Autowired
    DrillJudgementPanelRepository drillJudgementPanelRepository;

    @Autowired
    DrillAssignJudgePanelRepository drillAssignJudgePanelRepository;

    @Autowired
    DrillCollaboratorsRepository drillCollaboratorsRepository;

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    DrillParticipantSubmissionRepository drillParticipantSubmissionRepository;

    @Autowired
    DrillPhasesRepository drillPhasesRepository;

    @Autowired
    DrillRepository drillRepository;
    
    @Autowired SendCustomMailUtils sendCustomMailUtils;

    @Value("${drill.url:https://drill.whereuelevate.com}")
    String drillUrl;

    public Object addOrUpdatePanel(DrillJudgementPanel payload, InternityUser user) {
        try{
            return drillJudgementPanelRepository.save(payload);
        }
        catch (Exception e) {
            log.error("Exception while adding the judgement panel with error {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to add or update judgement panel " + e.getMessage());
        }
    }

    public boolean deletePanel(String panelId, InternityUser user) {
        try{
            drillJudgementPanelRepository.deleteById(panelId);
            return true;
        }
        catch (Exception e) {
            log.error("Exception while deleting the judgement panel with error {}", e);
            return false;
        }
    }

    public DrillCollaborators fetchJudgeDetails(String drillId, String judgeId, InternityUser user){
        try{
            Optional<DrillCollaborators> drillCollaboratorObj = drillCollaboratorsRepository.findById(judgeId);
            if(drillCollaboratorObj.isPresent()){
                return drillCollaboratorObj.get();
            }
        }catch (Exception e){
            log.error("Exception while fetching the details of the judge {}", e);
        }
        return null;
    }

    public Object fetchPanelList(String drillId, String phaseId, String panelId, InternityUser user) {
        try{
            if(panelId.equals("NA")){
                if(phaseId.equals("NA")){
                    return drillJudgementPanelRepository.findByDrillId(drillId);
                } else {
                    return drillJudgementPanelRepository.findByDrillIdAndPhaseId(drillId, phaseId);
                }
            }
            return drillJudgementPanelRepository.findById(panelId);
        }
        catch (Exception e) {
            log.error("Exception while fetching panel list with error {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to fetch the panel list " + e.getMessage());
        }
    }

    //    public ResponseEntity<?> assignPanelv2(
    //            DrillAssignPanel payload,
    //            String drillId,
    //            String phaseId,
    //            String panelId,
    //            String type,
    //            InternityUser user) {
    //
    //        try{
    //            Optional<DrillAssignPanel> drillAssignPanelObj =
    // drillAssignJudgePanelRepository.findByPanelId(panelId);
    //            if(drillAssignPanelObj.isPresent()){
    //                DrillAssignPanel drillAssignPanel = drillAssignPanelObj.get();
    //                String judgeListFromPanelOfApi = drillAssignPanel.getJudgeidList();
    //                Set<String> judgeIdSet = new HashSet<>();
    //                if (!StringUtils.isBlank(drillAssignPanel.getJudgeidList())) {
    //                    for (String judgeIdFromDb : drillAssignPanel.getJudgeidList().split(","))
    // {
    //                        judgeIdSet.add(judgeIdFromDb);
    //                    }
    //                }
    //                Set<String> judgeIdsFromApi = new HashSet<>();
    //                if (!StringUtils.isBlank(payload.getJudgeidList())) {
    //                    for (String judgeIdPayload : payload.getJudgeidList().split(",")) {
    //                        judgeIdSet.add(judgeIdPayload);
    //                        judgeIdsFromApi.add(judgeIdPayload.replaceAll(",",""));
    //                    }
    //                }
    //                String judgeStr = "";
    //                for(String judge : judgeIdSet){
    //                    judgeStr = judgeStr + "," + judge;
    //                }
    //
    //                Map<String, String> panelIdAndAssignedJudgeList = new HashMap<>();
    //
    //                panelIdAndAssignedJudgeList.put(panelId, judgeStr);
    //
    //                List<DrillJudgementPanel> judgementPanelList =
    // drillJudgementPanelRepository.findByDrillId(drillId);
    //                for(DrillJudgementPanel judgementPanel : judgementPanelList){
    //                    if (!judgementPanel.getDrillJudgementPanelId().equals(panelId)) {
    //
    //                        Optional<DrillAssignPanel> drillAssignPanel1 =
    //                                drillAssignJudgePanelRepository.findByPanelId(
    //                                        judgementPanel.getDrillJudgementPanelId());
    //                        if (drillAssignPanel1.isPresent()) {
    //                            panelIdAndAssignedJudgeList.put(
    //                                    drillAssignPanel1.get().getPanelId(),
    //                                    drillAssignPanel1.get().getJudgeidList());
    //                        }
    //                    }
    //                }
    //
    //                // Map with panel id and list of judges in there
    //                for(String panelIdFromMap : panelIdAndAssignedJudgeList.keySet()){
    //                    for(String idFromApi : judgeIdsFromApi){
    //                        if(panelIdFromMap.contains(idFromApi)){
    //                            panelIdAndAssignedJudgeList.put(panelIdFromMap,
    //
    // panelIdAndAssignedJudgeList.get(panelIdFromMap).replaceAll(idFromApi,""));
    //                        }
    //                    }
    //                }
    //
    //                List<DrillAssignPanel> result = new ArrayList<>();
    //
    //                for(String panelIdFromMap : panelIdAndAssignedJudgeList.keySet()){
    //                    DrillAssignPanel drillAssignPanel2 =
    // drillAssignJudgePanelRepository.findByPanelId(panelIdFromMap).get();
    //
    // drillAssignPanel2.setJudgeidList(panelIdAndAssignedJudgeList.get(panelIdFromMap));
    //                    result.add(drillAssignPanel2);
    //                }
    //                drillAssignJudgePanelRepository.saveAll(result);
    //            return new
    // ResponseEntity<>(drillAssignJudgePanelRepository.findByPanelId(panelId), HttpStatus.OK);
    //            }
    //        }
    //        catch (Exception e){
    //            log.error("Exception while assigning judge");
    //        }
    //        return null;
    //    }
    @Autowired
    DrillJudgePanelLookupRepository drillJudgePanelLookupRepository;

    @Autowired
    DrillSubmissionPanelLookupRepository drillSubmissionPanelLookupRepository;

    public ResponseEntity<?> assignPanelv3(
            DrillAssignPanel payload,
            String drillId,
            String phaseId,
            String panelId,
            String type,
            InternityUser user) {
        try {
            List<DrillJudgePanelLookup> drillJudgePanelLookupList = new ArrayList<>();
            Set<String> listOfPanelIdsAffected = new HashSet<>();

            for (String judgeId : payload.getJudgeidList().split(",")) {
                Optional<DrillJudgePanelLookup> drillJudgePanelLookupObj =
                        drillJudgePanelLookupRepository.findByJudgeId(judgeId);
                if (drillJudgePanelLookupObj.isPresent()) {
                    DrillJudgePanelLookup drillJudgePanelLookup = drillJudgePanelLookupObj.get();
                    drillJudgePanelLookup.setPanelId(panelId);
                    drillJudgePanelLookupList.add(drillJudgePanelLookup);
                } else {
                    DrillJudgePanelLookup drillJudgePanelLookup = new DrillJudgePanelLookup();
                    drillJudgePanelLookup.setJudgeId(judgeId);
                    drillJudgePanelLookup.setPanelId(panelId);
                    drillJudgePanelLookup.setDrillId(drillId);
                    drillJudgePanelLookupList.add(drillJudgePanelLookup);
                }
            }
            drillJudgePanelLookupRepository.saveAll(drillJudgePanelLookupList);

            // fetch the ids
            List<DrillJudgementPanel> drillJudgementPanelList =
                    drillJudgementPanelRepository.findByDrillId(drillId);
            for (DrillJudgementPanel drillJudgementPanel : drillJudgementPanelList) {
                listOfPanelIdsAffected.add(drillJudgementPanel.getDrillJudgementPanelId());
            }

            for (String panelIdAffected : listOfPanelIdsAffected) {
                List<DrillJudgePanelLookup> drillJudgePanelLookups =
                        drillJudgePanelLookupRepository.findByPanelId(panelIdAffected);
                String judgeList = "";
                for (DrillJudgePanelLookup obj : drillJudgePanelLookups) {
                    judgeList = judgeList + "," + obj.getJudgeId();
                }
                Optional<DrillAssignPanel> drillAssignPanelObj =
                        drillAssignJudgePanelRepository.findByPanelId(panelIdAffected);
                if (drillAssignPanelObj.isPresent()) {
                    DrillAssignPanel drillAssignPanel = drillAssignPanelObj.get();
                    drillAssignPanel.setJudgeidList(judgeList);
                    drillAssignJudgePanelRepository.save(drillAssignPanel);
                } else {
                    DrillAssignPanel drillAssignPanel = new DrillAssignPanel();
                    drillAssignPanel.setPanelId(panelIdAffected);
                    drillAssignPanel.setPhaseId(phaseId);
                    drillAssignPanel.setJudgeidList(judgeList);
                    drillAssignJudgePanelRepository.save(drillAssignPanel);
                }
            }
            return new ResponseEntity<>(
                    drillAssignJudgePanelRepository.findByPanelId(panelId), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception {}", e);
            return null;
        }
    }

    public ResponseEntity<?> assignSubmissionv3(
            DrillAssignPanel payload,
            String drillId,
            String phaseId,
            String panelId,
            String type,
            InternityUser user) {
        try {
            List<DrillSubmissionPanelLookup> drillSubmissionPanelLookupList = new ArrayList<>();
            Set<String> listOfPanelIdsAffected = new HashSet<>();

            for (String submissionId : payload.getSubmissionidList().split(",")) {
                Optional<DrillSubmissionPanelLookup> drillSubmissionPanelLookupObj =
                        drillSubmissionPanelLookupRepository.findBySubmissionId(submissionId);
                if (drillSubmissionPanelLookupObj.isPresent()) {
                    DrillSubmissionPanelLookup drillSubmissionPanelLookup = drillSubmissionPanelLookupObj.get();
                    drillSubmissionPanelLookup.setPanelId(panelId);
                    drillSubmissionPanelLookupList.add(drillSubmissionPanelLookup);
                } else {
                    DrillSubmissionPanelLookup drillSubmissionPanelLookup = new DrillSubmissionPanelLookup();
                    drillSubmissionPanelLookup.setSubmissionId(submissionId);
                    drillSubmissionPanelLookup.setPanelId(panelId);
                    drillSubmissionPanelLookup.setDrillId(drillId);
                    drillSubmissionPanelLookupList.add(drillSubmissionPanelLookup);
                }
            }
            drillSubmissionPanelLookupRepository.saveAll(drillSubmissionPanelLookupList);

            // fetch the ids
            List<DrillJudgementPanel> drillJudgementPanelList =
                    drillJudgementPanelRepository.findByDrillId(drillId);
            for (DrillJudgementPanel drillJudgementPanel : drillJudgementPanelList) {
                listOfPanelIdsAffected.add(drillJudgementPanel.getDrillJudgementPanelId());
            }

            for (String panelIdAffected : listOfPanelIdsAffected) {
                List<DrillSubmissionPanelLookup> drillSubmissionPanelLookups =
                        drillSubmissionPanelLookupRepository.findByPanelId(panelIdAffected);
                String submissionList = "";
                for (DrillSubmissionPanelLookup obj : drillSubmissionPanelLookups) {
                    submissionList = submissionList + "," + obj.getSubmissionId();
                }
                Optional<DrillAssignPanel> drillAssignPanelObj =
                        drillAssignJudgePanelRepository.findByPanelId(panelIdAffected);
                if (drillAssignPanelObj.isPresent()) {
                    DrillAssignPanel drillAssignPanel = drillAssignPanelObj.get();
                    drillAssignPanel.setSubmissionidList(submissionList);
                    drillAssignJudgePanelRepository.save(drillAssignPanel);
                } else {
                    DrillAssignPanel drillAssignPanel = new DrillAssignPanel();
                    drillAssignPanel.setPanelId(panelIdAffected);
                    drillAssignPanel.setPhaseId(phaseId);
                    drillAssignPanel.setSubmissionidList(submissionList);
                    drillAssignJudgePanelRepository.save(drillAssignPanel);
                }
            }

            assignPanelAndPhaseToSubmission(payload.getSubmissionidList(), drillId, phaseId, panelId);

            return new ResponseEntity<>(
                    drillAssignJudgePanelRepository.findByPanelId(panelId), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception {}", e);
            return null;
        }
    }

    public ResponseEntity<?> assignPanel(DrillAssignPanel payload, String drillId, String phaseId, String panelId, String type, InternityUser user) {
        try{
            Optional<DrillAssignPanel> judgementPanel = drillAssignJudgePanelRepository.findByPanelId(panelId);
            DrillAssignPanel drillAssignPanel = new DrillAssignPanel();
            if(judgementPanel.isPresent()){
                drillAssignPanel = judgementPanel.get();
            }
            drillAssignPanel.setPanelId(panelId);
            drillAssignPanel.setPhaseId(phaseId);
            Set<String> judgeIdSet = new HashSet<>();
            if (!StringUtils.isBlank(drillAssignPanel.getJudgeidList())) {
                for (String judgeIdFromDb : drillAssignPanel.getJudgeidList().split(",")) {
                    judgeIdSet.add(judgeIdFromDb);
                }
            }
            if (!StringUtils.isBlank(payload.getJudgeidList())) {
                for (String judgeIdPayload : payload.getJudgeidList().split(",")) {
                    judgeIdSet.add(judgeIdPayload);
                }
            }
            String judgeStr = "";
            for(String judge : judgeIdSet){
                judgeStr = judgeStr + "," + judge;
            }

            if(type.equalsIgnoreCase("judge")){
                drillAssignPanel.setJudgeidList(judgeStr);
            } else if (type.equalsIgnoreCase("submission")) {
                drillAssignPanel.setSubmissionidList(drillAssignPanel.getSubmissionidList()+","+payload.getSubmissionidList());
            }

            boolean areJudgesRemoved = type.equalsIgnoreCase("judge")
                    ?removeJudgeIdFromOtherPanels(payload.getJudgeidList(), drillId, panelId):false;
            boolean areSubmissionsRemoved =  type.equalsIgnoreCase("submission")
                    ?removeSubmissionIdFromOtherPanels(payload.getSubmissionidList(), drillId, panelId):false;

            DrillAssignPanel savedAssignPanel = drillAssignJudgePanelRepository.save(drillAssignPanel);

            boolean assignPanelToSubmission =  type.equalsIgnoreCase("submission")
                    ?assignPanelAndPhaseToSubmission(payload.getSubmissionidList(), drillId, phaseId, panelId):false;
            return new ResponseEntity<>(savedAssignPanel, HttpStatus.OK);
        }
        catch (Exception e) {
            log.error("Exception while assigning judges to the panel with error {}", e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to assign the judgement panel " + e.getMessage())
                    , HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private boolean assignPanelAndPhaseToSubmission(String submissionIdList, String drillId, String phaseId, String panelId){
        try{
            List<DrillParticipantSubmission> drillParticipantSubmissionList = drillParticipantSubmissionRepository
                    .findBySubmissionIdIn(Arrays.asList(submissionIdList.split(",")));
            List<DrillParticipantSubmission> newParticipantSubmissionList = new ArrayList<>();
            for(DrillParticipantSubmission drillParticipantSubmission : drillParticipantSubmissionList){
                drillParticipantSubmission.setPanelId(panelId);
                drillParticipantSubmission.setPhaseId(phaseId);
                newParticipantSubmissionList.add(drillParticipantSubmission);
            }
            if (!newParticipantSubmissionList.isEmpty()) {
                drillParticipantSubmissionRepository.saveAll(newParticipantSubmissionList);
            }
            return true;
        }
        catch (Exception e){
            log.error("Exception while assigning Panel to Submission table after submission was assign");
        }
        return false;
    }

    private boolean removeJudgeIdFromOtherPanels(
            String judgeidList, String drillId, String assignedPanelId) {
        try {
            String[] judgeIds = judgeidList.split(",");
            List<String> judgeListFromApi = new ArrayList<>();
            for (String judgeIdStr : judgeIds) {
                judgeListFromApi.add(judgeIdStr);
            }
            for (String judgeId : judgeIds) {
                Optional<DrillAssignPanel> drillAssignPanelObj =
                        drillAssignJudgePanelRepository.findByJudgeidListContaining(judgeId);
                if (drillAssignPanelObj.isPresent()) {
                    DrillAssignPanel assignPanelFromDb = drillAssignPanelObj.get();
                    if (assignPanelFromDb.getPanelId().equals(assignedPanelId)) {
                        continue;
                    }
                    String newJudgeIdList = "";
                    for (String idFromDb : assignPanelFromDb.getJudgeidList().split(",")) {
                        if (!StringUtils.isBlank(idFromDb)
                                && !judgeListFromApi.contains(idFromDb)) {
                            newJudgeIdList = newJudgeIdList + ","+ idFromDb ;
                        }
                    }
                    assignPanelFromDb.setJudgeidList(newJudgeIdList);
                    drillAssignJudgePanelRepository.saveAndFlush(assignPanelFromDb);
                }
            }
            return true;
        } catch (Exception e) {
            log.error("Exception while removed judgeId from Panels other than assigned {}", e);
        }
        return false;
    }

//    private boolean removeSubmissionIdFromOtherPanels(
//            String submissionIdList, String drillId, String assignedPanelId) {
//        try {
//            String[] submissionIds = submissionIdList.split(",");
//            List<String> submissionListFromApi = new ArrayList<>();
//            for (String submissionIdStr : submissionIds) {
//                submissionListFromApi.add(submissionIdStr);
//            }
//            for (String submissionId : submissionIds) {
//                Optional<DrillAssignPanel> drillAssignPanelObj =
//                        drillAssignJudgePanelRepository.findByJudgeidListContaining(submissionId);
//                if (drillAssignPanelObj.isPresent()) {
//                    DrillAssignPanel assignPanelFromDb = drillAssignPanelObj.get();
//                    if (assignPanelFromDb.getPanelId().equals(assignedPanelId)) {
//                        continue;
//                    }
//                    String newSubmissionIdList = "";
//                    for (String idFromDb : assignPanelFromDb.getSubmissionidList().split(",")) {
//                        if (!StringUtils.isBlank(idFromDb)
//                                && !submissionListFromApi.contains(idFromDb)) {
//                            newSubmissionIdList = newSubmissionIdList + idFromDb + ",";
//                        }
//                    }
//                    assignPanelFromDb.setSubmissionidList(
//                            newSubmissionIdList.endsWith(",")
//                                    ? newSubmissionIdList.substring(0, newSubmissionIdList.length() - 1)
//                                    : newSubmissionIdList);
//                    drillAssignJudgePanelRepository.save(assignPanelFromDb);
//                }
//            }
//            return true;
//        } catch (Exception e) {
//            log.error("Exception while removed judgeId from Panels other than assigned {}", e);
//        }
//        return false;
//    }

//        private boolean removeJudgeIdFromOtherPanels(String judgeidList, String drillId, String assignedPanelId) {
//        try{
//            List<DrillJudgementPanel> panelList = drillJudgementPanelRepository.findByDrillId(drillId);
//            List<DrillAssignPanel> judgeIdRemovedPanelList = new ArrayList<>();
//
//            for(DrillJudgementPanel panel : panelList){
//                if(panel.getDrillJudgementPanelId().equals(assignedPanelId)){
//                   continue;
//                }
//                Optional<DrillAssignPanel> drillAssignPanel = drillAssignJudgePanelRepository
//                        .findByPanelId(panel.getDrillJudgementPanelId());
//                if (drillAssignPanel.isPresent()) {
//                    DrillAssignPanel assignPanel = drillAssignPanel.get();
//                    List<String> judgeListFromDb = new ArrayList<>();
//                    if (!StringUtils.isBlank(assignPanel.getJudgeidList())) {
//                        judgeListFromDb.addAll(
//                                Arrays.asList(assignPanel.getJudgeidList().split(",")));
//                        for (String judgeId : judgeidList.split(",")) {
//                            if (judgeListFromDb.contains(judgeId)) {
//                                judgeListFromDb.remove(judgeId);
//                            }
//                        }
//                        assignPanel.setJudgeidList(
//                                judgeListFromDb
//                                        .toString()
//                                        .replaceAll("\\[", "")
//                                        .replaceAll("]", ""));
//                    }
//                    judgeIdRemovedPanelList.add(assignPanel);
//                }
//            }
//            drillAssignJudgePanelRepository.saveAll(judgeIdRemovedPanelList);
//            return true;
//        }
//        catch (Exception e){
//            log.error("Exception while removed judgeId from Panels other than assigned {}", e);
//        }
//        return false;
//    }

    private boolean removeSubmissionIdFromOtherPanels(String submissionIdList,String drillId, String assignedPanelId) {
        try{
            List<DrillJudgementPanel> panelList = drillJudgementPanelRepository.findByDrillId(drillId);
            List<DrillAssignPanel> submissionIdRemovedPanelList = new ArrayList<>();

            for(DrillJudgementPanel panel : panelList){
                if(panel.getDrillJudgementPanelId().equals(assignedPanelId)){
                    continue;
                }
                Optional<DrillAssignPanel> drillAssignPanel = drillAssignJudgePanelRepository
                        .findByPanelId(panel.getDrillJudgementPanelId());
                if (drillAssignPanel.isPresent()) {
                    DrillAssignPanel assignPanel = drillAssignPanel.get();
                    List<String> submissionListFromDb = new ArrayList<>();
                    if (!StringUtils.isBlank(assignPanel.getSubmissionidList())) {
                        submissionListFromDb.addAll(
                                Arrays.asList(assignPanel.getSubmissionidList().split(",")));
                        for (String submissionId : submissionIdList.split(",")) {
                            if (submissionListFromDb.contains(submissionId)) {
                                submissionListFromDb.remove(submissionId);
                            }
                        }
                        assignPanel.setSubmissionidList(
                                submissionListFromDb
                                        .toString()
                                        .replaceAll("\\[", "")
                                        .replaceAll("]", ""));
                    }
                    submissionIdRemovedPanelList.add(assignPanel);
                }
            }
            drillAssignJudgePanelRepository.saveAll(submissionIdRemovedPanelList);
            return true;
        }
        catch (Exception e){
            log.error("Exception while removed judgeId from Panels other than assigned {}", e);
        }
        return false;
    }

    public Object fetchAssignedJudgesList(
            String drillId, String phaseId, String panelId, InternityUser user) {
        try {
            if (panelId.equals("NA")) {
                List<DrillPhases> drillPhaseList =
                        drillPhasesRepository.findByDrillIdOrderByPhaseStartDtAsc(drillId);
                Map<String, String> phaseIdAndphaseName = new HashMap<>();
                for (DrillPhases drillPhase : drillPhaseList) {
                    phaseIdAndphaseName.put(drillPhase.getPhaseId(), drillPhase.getPhaseName());
                }

                List<DrillJudgementPanel> drillJudgementPanelList =
                        drillJudgementPanelRepository.findByDrillId(drillId);
                Map<String, String> panelIdAndPanelName = new HashMap<>();
                Map<String, String> judgeIdAndPanelId = new HashMap<>();
                Map<String, String> panelIdAndPhaseId = new HashMap<>();
                for (DrillJudgementPanel drillJudgementPanel : drillJudgementPanelList) {
                    panelIdAndPanelName.put(
                            drillJudgementPanel.getDrillJudgementPanelId(),
                            drillJudgementPanel.getPanelName());
                    Optional<DrillAssignPanel> drillAssignJudgePanel =
                            drillAssignJudgePanelRepository.findByPanelId(
                                    drillJudgementPanel.getDrillJudgementPanelId());
                    if (drillAssignJudgePanel.isPresent()) {
                        panelIdAndPhaseId.put(
                                drillJudgementPanel.getDrillJudgementPanelId(),
                                drillJudgementPanel.getPhaseId());
                        if (drillAssignJudgePanel.get().getJudgeidList() != null) {
                            for (String judgeId :
                                    drillAssignJudgePanel.get().getJudgeidList().split(",")) {
                                judgeIdAndPanelId.put(
                                        judgeId, drillJudgementPanel.getDrillJudgementPanelId());
                            }
                        }
                    }
                }

                List<DrillCollaborators> drillCollaboratorsList =
                        drillCollaboratorsRepository.findByDrillIdAndCollaboratorTypeOrderByPositionOrder(drillId, "Judge");
                List<DrillJudgeDto> drillJudgesList = new ArrayList<>();

                for (DrillCollaborators judge : drillCollaboratorsList) {
                    DrillJudgeDto drillJudgeDto = new DrillJudgeDto();
                    String judgeId = judge.getCollaboratorId();
                    String assignedPanelId =
                            judgeIdAndPanelId.containsKey(judgeId)
                                    ? judgeIdAndPanelId.get(judgeId)
                                    : "NA";
                    String assignedPhaseId =
                            !StringUtils.isBlank(panelIdAndPhaseId.get(assignedPanelId))
                                    ? panelIdAndPhaseId.get(assignedPanelId)
                                    : "NA";

                    if(!phaseId.equals("NA")){
                        if (!assignedPhaseId.equals(phaseId)) {
                            continue;
                        }
                    }
                    drillJudgeDto.setDrillId(judge.getDrillId());
                    drillJudgeDto.setJudgeId(judgeId);
                    drillJudgeDto.setJudgeEmail(judge.getCollaboratorEmail());
                    drillJudgeDto.setJudgeDesignation(judge.getCollaboratorDesignation());
                    drillJudgeDto.setJudgeName(judge.getCollaboratorName());
                    drillJudgeDto.setJudgeTitle(judge.getCollaboratorTitle());
                    drillJudgeDto.setPanelId(assignedPanelId);
                    drillJudgeDto.setPanelName(panelIdAndPanelName.get(assignedPanelId));
                    drillJudgeDto.setPhaseId(assignedPhaseId);
                    drillJudgeDto.setPhaseName(phaseIdAndphaseName.get(assignedPhaseId));
                    if (!assignedPanelId.equals("NA")) {
                        drillJudgeDto.setJudgementLink(
                                "/drills/"
                                        + drillRepository.findById(judge.getDrillId()).get().getDrillName()
                                        + "/"
                                        + judge.getDrillId()
                                        + "/phases/"
                                        + assignedPhaseId
                                        + "/judgement/"
                                        + judge.getCollaboratorId()
                                        + "/key/"
                                        + judge.getKey());
                    }
                    drillJudgesList.add(drillJudgeDto);
                }
                DrillAssignJudgePanelDto drillAssignJudgePanelDto = new DrillAssignJudgePanelDto();
                
                drillAssignJudgePanelDto.setJudgesList(drillJudgesList);
                return drillAssignJudgePanelDto;
            } else {
                Optional<DrillAssignPanel> drillAssignJudgePanel =
                        drillAssignJudgePanelRepository.findByPanelId(panelId);
                if (drillAssignJudgePanel.isPresent()) {

                    DrillAssignPanel panelObj = drillAssignJudgePanel.get();

                    phaseId = panelObj.getPhaseId();
                    String phaseName="";
                    if(StringUtils.isBlank(phaseId) || phaseId.equals("NA")){
                        phaseName = "NA";
                    } else {
                        phaseName =
                                drillPhasesRepository
                                        .findById(panelObj.getPhaseId())
                                        .get()
                                        .getPhaseName();
                    }
                    String panelName = drillJudgementPanelRepository.findById(panelId).get().getPanelName();

                    DrillAssignJudgePanelDto drillAssignJudgePanelDto =
                            new DrillAssignJudgePanelDto();
                    drillAssignJudgePanelDto.setId(panelObj.getId());
                    drillAssignJudgePanelDto.setPanelId(panelObj.getPanelId());
                    drillAssignJudgePanelDto.setPhaseId(phaseId);
                    drillAssignJudgePanelDto.setPanelName(panelName);
                    drillAssignJudgePanelDto.setPhaseName(phaseName);

                    List<DrillJudgeDto> drillJudgesList = new ArrayList<>();

                    for (String judgeId : drillAssignJudgePanel.get().getJudgeidList().split(",")) {
                        Optional<DrillCollaborators> judgeObj =
                                drillCollaboratorsRepository.findById(judgeId);
                        if (judgeObj.isPresent()) {
                            DrillCollaborators judge = judgeObj.get();
                            DrillJudgeDto drillJudgeDto = new DrillJudgeDto();
                            drillJudgeDto.setDrillId(judge.getDrillId());
                            drillJudgeDto.setJudgeId(judge.getCollaboratorId());
                            drillJudgeDto.setJudgeEmail(judge.getCollaboratorEmail());
                            drillJudgeDto.setJudgeDesignation(judge.getCollaboratorDesignation());
                            drillJudgeDto.setJudgeName(judge.getCollaboratorName());
                            drillJudgeDto.setJudgeTitle(judge.getCollaboratorTitle());
                            drillJudgeDto.setPanelId(panelId);
                            drillJudgeDto.setPanelName(panelName);
                            drillJudgeDto.setPhaseId(phaseId);
                            drillJudgeDto.setPhaseName(phaseName);
                            drillJudgeDto.setJudgementLink(
                                    "/drills/"
                                            + drillRepository.findById(judge.getDrillId()).get().getDrillName()
                                            + "/"
                                            + judge.getDrillId()
                                            + "/phases/"
                                            + (StringUtils.isBlank(panelObj.getPhaseId())
                                                    ? "NA"
                                                    : panelObj.getPhaseId())
                                            + "/judgement/"
                                            + judge.getCollaboratorId()
                                            + "/key/"
                                            + judge.getKey());
                            drillJudgesList.add(drillJudgeDto);
                        }
                    }
                    drillAssignJudgePanelDto.setJudgesList(drillJudgesList);
                    
                    return drillAssignJudgePanelDto;
                } else {
                    return Collections.EMPTY_LIST;
                }
            }
        } catch (Exception e) {
            log.error("Exception while fetching judges list for Panels with error {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to fetch the judges list for Panels " + e.getMessage());
        }
    }

    public ResponseEntity<?> sendMailInviteLinkToJudges(String drillId, String phaseId,
                                                        String panelId, String judgeId,
                                                        int offset, int limit, String order, InternityUser user) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if(!drillObj.isPresent()){
                return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Hackathon is not " +
                        "present with the given Id. Please contact technical support"), HttpStatus.INTERNAL_SERVER_ERROR);
            } else {
                Drill drill = drillObj.get();
                // Call the method to fetch assigned judges list
                Object assignedJudgesList =
                        fetchAssignedJudgesList(drillId, phaseId, panelId, user);
                StringBuilder reportBuilder =
                        new StringBuilder("Emails sent successfully to the following judges:\n");

                if (assignedJudgesList instanceof DrillAssignJudgePanelDto) {
                    DrillAssignJudgePanelDto judgePanelDto =
                            (DrillAssignJudgePanelDto) assignedJudgesList;
                    List<DrillJudgeDto> judgeList = judgePanelDto.getJudgesList();

                    for (DrillJudgeDto judge : judgeList) {

                        if(!judgeId.equalsIgnoreCase("NA") && !judgeId.equalsIgnoreCase(judge.getJudgeId())){
                            continue;
                        }

                        String email = judge.getJudgeEmail();
                        String name = judge.getJudgeName();
                        String judgementLink = judge.getJudgementLink();

                        if (!email.isEmpty()) {
                            // Include judgementLink in the email body
                            String mailBody =
                                    "Dear "
                                            + name
                                            + ",<br/><br/>"
                                            + "We're thrilled you've accepted our invitation to judge the hackathon. Your expertise will be invaluable.<br/><br/>"
                                            + "Please use the following link for evaluating the submissions:<br/>"
                                            + "<a href=\""
                                            + drillUrl + judgementLink
                                            + "\">Judgement Link</a><br/>";

                            // Send email
                            sendCustomMailUtils.sendMailToJudges(
                                    "", email, "Judgement Invite Link | " + drill.getDrillName(), mailBody);

                            // Update the report
                            reportBuilder
                                    .append("Judge Name: ")
                                    .append(name)
                                    .append(", Judge ID: ")
                                    .append(judge.getJudgeId())
                                    .append(", Email: ")
                                    .append(email)
                                    .append("\n");
                        } else {
                            // Judge has no email, skip and update the report
                            reportBuilder
                                    .append("Judge Name: ")
                                    .append(name)
                                    .append(", Judge ID: ")
                                    .append(judge.getJudgeId())
                                    .append(" (No Email - Skipped)\n");
                        }
                    }

                    // Generate and log the final report
                    String finalReport = reportBuilder.toString();
                    log.info(finalReport);

                    return new ResponseEntity<>(finalReport, HttpStatus.OK);

                } else {
                    return new ResponseEntity<>(
                            "Failed to fetch judges list", HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred while sending invite link to the judge: {}", e.getMessage());
            return new ResponseEntity<>("Failed to send emails", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public byte[] downloadAssignedJudgesList(String drillId, String phaseId, String panelId,int offset, int limit, String order, InternityUser user) {
        try {
            // Call the method to fetch assigned judges list
            Object assignedJudgesList = fetchAssignedJudgesList(drillId, phaseId, panelId, user);

            if (assignedJudgesList instanceof DrillAssignJudgePanelDto) {
                DrillAssignJudgePanelDto judgePanelDto = (DrillAssignJudgePanelDto) assignedJudgesList;

                // Create a new Excel workbook
                Workbook workbook = new XSSFWorkbook();
                Sheet sheet = workbook.createSheet("Assigned Judges");

                // Create a header row
                Row headerRow = sheet.createRow(0);
                String[] headers = {"Judge Name", "Judge Email", "Contact", "Judgement Link", "Phase Name", "Panel Name"};
                for (int i = 0; i < headers.length; i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(headers[i]);
                }

                // Populate the data rows
                List<DrillJudgeDto> judgesList = judgePanelDto.getJudgesList();
                int rowNum = 1;
                for (DrillJudgeDto judge : judgesList) {
                    Row dataRow = sheet.createRow(rowNum++);
                    dataRow.createCell(0).setCellValue(StringUtils.isNotBlank(judge.getJudgeName()) ? judge.getJudgeName() : "NA");
                    dataRow.createCell(1).setCellValue(StringUtils.isNotBlank(judge.getJudgeEmail()) ? judge.getJudgeEmail() : "NA");
                    dataRow.createCell(2).setCellValue(StringUtils.isNotBlank(judge.getJudgeContact()) ? judge.getJudgeContact() : "NA");
                    dataRow.createCell(3).setCellValue(StringUtils.isNotBlank(judge.getJudgementLink()) ? judge.getJudgementLink() : "NA");
                    dataRow.createCell(4).setCellValue(StringUtils.isNotBlank(judge.getPhaseName()) ? judge.getPhaseName() : "NA");
                    dataRow.createCell(5).setCellValue(StringUtils.isNotBlank(judge.getPanelName()) ? judge.getPanelName() : "NA");
                }

                // Set column widths (adjust as needed)
                for (int i = 0; i < headers.length; i++) {
                    sheet.autoSizeColumn(i);
                }

                // Prepare the response
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);
                outputStream.close();

                return outputStream.toByteArray();
            } else {
                log.error("Assigned judges list is not an instance of DrillAssignJudgePanelDto.");
            }
        } catch (Exception e) {
            log.error("Exception occurred while downloading assign judge list in an Excel file: {}", e.getMessage());
        }
        return null;
    }
}
//    public ResponseEntity<?> sendInviteLinkToJudge(String mailTemplate, String receiverUniqueId,
//                                                   Map<String, String> msgDetails) {
//        try{
//
//        }
//        catch (Exception e){
//            log.error("Exception occurred while sending invite link to the judge");
//        }
//        return null;
//    }
