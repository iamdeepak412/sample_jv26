package com.wue.service.drill;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.constant.drill.certificate.*;
import com.wue.domain.User;
import com.wue.domain.drill.*;
import com.wue.domain.drill.certificate.DrillCertificateGenerator;
import com.wue.domain.drill.certificate.DrillCertificateGeneratorTemplate;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.domain.drill.submission.DrillSubmissionEvaluation;
import com.wue.dto.drill.certificate.DrillCertificateGeneratorFieldNamesWithXYCoordinates;
import com.wue.dto.drill.certificate.DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto;
import com.wue.dto.drill.certificate.DrillCertificateGeneratorModelForCreateCertificate;
import com.wue.dto.response.Response;
import com.wue.model.EmailContent;
import com.wue.repository.UserRepository;
import com.wue.repository.drill.*;
import com.wue.repository.drill.certificate.DrillCertificateGeneratorRepository;
import com.wue.repository.drill.certificate.DrillCertificateGeneratorTemplateRepository;
import com.wue.repository.drill.submission.DrillParticipantSubmissionRepository;
import com.wue.repository.drill.submission.DrillSubmissionEvaluationRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.SendMessageUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

@Service
@Slf4j
public class DrillCertificateService {

    @Autowired
    private DrillCertificateGeneratorRepository generateCertificateRepository;
    @Autowired
    private CommonUtils commonUtils;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private DrillRepository drillRepository;
    @Autowired
    private DrillPhasesRepository phasesRepository;
    @Autowired
    private DrillParticipantSubmissionRepository drillParticipantSubmissionRepository;
    @Autowired
    private DrillParticipantRepository drillParticipantRepository;
    @Autowired
    private DrillSubmissionEvaluationRepository drillSubmissionEvaluationRepository;
    @Autowired
    private TeamsParticipantsRepository teamsParticipantsRepository;
    @Autowired
    private DrillCertificateGeneratorTemplateRepository templateRepository;
    @Autowired
    private DrillTeamsRepository drillTeamsRepository;
    @Autowired
    private DrillLeaderboardRepository leaderboardRepository;
    @Autowired
    SendMessageUtils messageUtils;
    @Autowired
    private AmazonS3 s3Client;
    @Value("${bucket}")
    private String bucketName;
    @Value("${DOMAIN_URL}")
    private String domainUrl;

    public ResponseEntity<?> generateCertificates(String drillId, String uId, String templateId, DrillCertificateType certificateType, DrillCertificateTo certificateTo, List<String> restrictedList, List<String> extraParticipantsList, List<String> winnersList, List<String> otherList, String phaseId, DrillCertificateEventType eventType, InternityUser user) {
        try {

            log.info("Certificate generation request received");
            if (eventType.equals(DrillCertificateEventType.DRILL)) {
                return generateDrillCertificates(drillId, uId, templateId, certificateType, certificateTo, restrictedList, extraParticipantsList, winnersList, otherList, phaseId, eventType);
            } else if (eventType.equals(DrillCertificateEventType.WORKSHOP)) {
                return generateWorkshopCertificates(drillId, uId, templateId, certificateType, certificateTo, restrictedList, extraParticipantsList, winnersList, otherList, phaseId, eventType);
            } else if (eventType.equals(DrillCertificateEventType.CONFERENCE)) {
                return generateConferenceCertificates(drillId, uId, templateId, certificateType, certificateTo, restrictedList, extraParticipantsList, winnersList, otherList, phaseId, eventType);
            }


        } catch (Exception e) {
            log.error("Error while generating certificate: " + e.getMessage());
            return ResponseEntity.badRequest().body("Error while generating certificate");
        }
         return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, "Something went wrong !!! Error while generating certificate", null), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private ResponseEntity<?> generateConferenceCertificates(String drillId, String uId, String templateId, DrillCertificateType certificateType, DrillCertificateTo certificateTo, List<String> restrictedList, List<String> extraParticipantsList, List<String> winnersList, List<String> otherList, String phaseId, DrillCertificateEventType eventType) {
        return null;
    }

    private ResponseEntity<?> generateWorkshopCertificates(String drillId, String uId, String templateId, DrillCertificateType certificateType, DrillCertificateTo certificateTo, List<String> restrictedList, List<String> extraParticipantsList, List<String> winnersList, List<String> otherList, String phaseId, DrillCertificateEventType eventType) {
        return null;
    }

    private ResponseEntity<?> generateDrillCertificates(String drillId, String uId, String templateId,
                                                        DrillCertificateType certificateType, DrillCertificateTo certificateTo,
                                                        List<String> restrictedList, List<String> extraParticipantsList,
                                                        List<String> winnersList, List<String> otherList, String phaseId,
                                                        DrillCertificateEventType eventType) {
        try {
            if (StringUtils.isAnyBlank(uId)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide uId in path", null), HttpStatus.BAD_REQUEST);
            }
            Optional<User> userObj = userRepository.findById(uId);
            if (!userObj.isPresent()) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "User not found", null), HttpStatus.BAD_REQUEST);
            }
            if (StringUtils.isAnyBlank(drillId)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide drillId in path", null), HttpStatus.BAD_REQUEST);
            }
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (!drillObj.isPresent()) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill not found", null), HttpStatus.BAD_REQUEST);
            }
            if (StringUtils.isAnyBlank(phaseId)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide phaseId", null), HttpStatus.BAD_REQUEST);
            }
            Optional<DrillPhases> phaseObj = phasesRepository.findById(phaseId);

            if (!phaseObj.isPresent()) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Phase not found", null), HttpStatus.BAD_REQUEST);
            }

            if (certificateType == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide certificateType", null), HttpStatus.BAD_REQUEST);
            }
            if (StringUtils.isAnyBlank(templateId)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide templateId", null), HttpStatus.BAD_REQUEST);
            }

            Optional<DrillCertificateGeneratorTemplate> templateObj = templateRepository.findById(templateId);
            if (!templateObj.isPresent()) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Certificate template not found", null), HttpStatus.BAD_REQUEST);
            }

            ObjectMapper mapper = new ObjectMapper();
            List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data = mapper.readValue(templateObj.get().getTemplateData(), new TypeReference<List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto>>() {
            });

            if (data == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "data Not available in template", null), HttpStatus.BAD_REQUEST);
            }


            List<DrillCertificateGeneratorModelForCreateCertificate> dataList = new ArrayList<>();
            Drill drill = drillObj.get();
            if (certificateType.equals(DrillCertificateType.PARTICIPANTS)) {
                if (certificateTo == null) {
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide certificateTo", null), HttpStatus.BAD_REQUEST);
                }
                dataList = createListForCertificateProcessing(drill, data, certificateTo, certificateType, winnersList, otherList, restrictedList, extraParticipantsList, phaseId);
            } else if (certificateType.equals(DrillCertificateType.WINNERS)) {
                if (winnersList == null) {
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide winners  List", null), HttpStatus.BAD_REQUEST);
                }
                dataList = createListForCertificateProcessing(drill, data, certificateTo, certificateType, winnersList, otherList, restrictedList, extraParticipantsList, phaseId);
            } else if (certificateType.equals(DrillCertificateType.OTHER)) {
                if (otherList == null) {
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide other List", null), HttpStatus.BAD_REQUEST);
                }
                dataList = createListForCertificateProcessing(drill, data, certificateTo, certificateType, winnersList, otherList, restrictedList, extraParticipantsList, phaseId);
            }

            if (dataList.isEmpty()) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "No participants data available", null), HttpStatus.BAD_REQUEST);
            }
            for (DrillCertificateGeneratorModelForCreateCertificate text : dataList) {

                //   if (generateCertificateRepository.findByEventIdAndParticipantPlatformUIdAndCertificateTypeAndEventPhaseId(drillId, text.getParticipantPlatformUId(), certificateType, phaseId) == null) {
                InputStream s3Image = getImageFromS3(templateObj.get().getCertificateImageUrlInS3());
                BufferedImage jpgImage = ImageIO.read(s3Image);

                String id = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 12);

                addTextsToImage(jpgImage, text.getData(), id);

                // upload image to s3 and get link
                String images3Link = uploadImageToS3(jpgImage);

                DrillCertificateGenerator certificate = new DrillCertificateGenerator();
                certificate.setCertificateId(id);
                certificate.setCertificateUrlInS3(images3Link);
                certificate.setEventName(drill.getDrillName());
                certificate.setEventId(drillId);
                certificate.setEventPhaseId(phaseId);
                certificate.setParticipantPlatformUId(text.getParticipantPlatformUId());
                certificate.setCertificateCreatorPlatformUId(uId);
                certificate.setCertificateType(certificateType);
                certificate.setDrillCertificateEventType(eventType);

                generateCertificateRepository.save(certificate);
                sendMailToParticipantsWithCertificatePreview(certificate, text.getParticipantPlatformUId(), drillId, id);
                log.info("Certificate generated successfully for user {}", text.getParticipantPlatformUId());
//                } else {
//                    log.warn("Certificate already present for this user {}", text.getParticipantPlatformUId());
//                }
            }
            log.info("All the Certificate are Generated Successfully");
            return new ResponseEntity<>("All the Certificate are Generated Successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while generating certificate: " + e.getMessage());
            return ResponseEntity.badRequest().body("Error while generating certificate");
        }
    }


    private void sendMailToParticipantsWithCertificatePreview(DrillCertificateGenerator certificate, String participantPlatformUId, String drillId, String id) {

        try {
            log.info("Sending mail to participants");
            EmailContent emailContent = new EmailContent();

            Optional<Drill> drillObj = drillRepository.findById(drillId);
            Drill drill = drillObj.get();

            emailContent.setJobId(drill.getDrillId());

            emailContent.setLink(domainUrl + "/api/v1/drill/preview/certificates/" + id);

            emailContent.setTemplateName("GenericMailForAllUsers");

            // mail detail for user
            User user = userRepository.findById(participantPlatformUId).get();

            emailContent.setSubject("Congratulations! Your Certificate of Achievement Inside For " + drill.getDrillName());

            emailContent.setMessage("<p>Congratulations on receiving your certificate!</p>\n" +
                    "<p>We are pleased to inform you that you have successfully received your certificate.</p>\n" +
                    "<p>Please click on the link below to view your certificate:</p>\n" +
                    "<p>Link: <a href=\"" + domainUrl + "/internity/api/v1/drill/preview/certificates/" + id + "\">Preview Certificate</a></p>\n" +
                    "<p>Link for Download: <a href=\"" + domainUrl + "/internity/api/v1/drill/download/certificates/" + id + "\">Download Certificate</a></p>\n" +
                    "<p>Thank you for your participation!</p>");
            emailContent.setUserName(user.getFullName());
            messageUtils.sendMailForGenericUsers(user.getEmail(), emailContent);

        } catch (Exception e) {
            log.error("Error while sending mail to participants: " + e.getMessage());
        }
    }

    private List<DrillCertificateGeneratorModelForCreateCertificate> createListForCertificateProcessing(Drill drill, List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data, DrillCertificateTo certificateTo, DrillCertificateType certificateType, List<String> winnersList, List<String> otherList, List<String> restrictedList, List<String> extraParticipantsList, String phaseId) {

        List<DrillCertificateGeneratorModelForCreateCertificate> dataList = new ArrayList<>();
        List<DrillParticipant> extraParticipantsDetails = new ArrayList<>();

        if (extraParticipantsList != null) {
            extraParticipantsDetails = drillParticipantRepository.findAllByDrillIdAndPlatformUIdIn(drill.getDrillId(), extraParticipantsList);
        }
        if (certificateType.equals(DrillCertificateType.PARTICIPANTS)) {
            if (certificateTo.equals(DrillCertificateTo.ALLREGISTEREDPARTICIPANTS)) {
                List<DrillParticipant> participantList = drillParticipantRepository.findAllByDrillId(drill.getDrillId());

                helperMethodToAddExtraAndGetAllData(drill, data, restrictedList, dataList, extraParticipantsDetails, participantList, phaseId);
            } else if (certificateTo.equals(DrillCertificateTo.ONLYPARTICIPANTSWHOSUBMISTTEDSUBMISSIONS)) {

                List<DrillParticipant> participantList;
                List<DrillParticipantSubmission> drillParticipantSubmissions = drillParticipantSubmissionRepository.findAllByDrillIdAndPhaseIdAndIsActiveSubmissionTrue(drill.getDrillId(), phaseId);

                List<String> teamIds = new ArrayList<>();

                List<String> participantIds = new ArrayList<>();

                for (DrillParticipantSubmission drillParticipantSubmission : drillParticipantSubmissions) {
                    if (drillParticipantSubmission.getTeamId() != null) {
                        teamIds.add(drillParticipantSubmission.getTeamId());
                    } else {
                        participantIds.add(drillParticipantSubmission.getParticipantId());
                    }
                }

                if (participantIds.isEmpty()) {
                    List<TeamsParticipants> teamsParticipants = teamsParticipantsRepository.findAllByTeamIdIn(teamIds);

                    for (TeamsParticipants teamParticipant : teamsParticipants) {
                        participantIds.add(teamParticipant.getParticipantId());
                    }
                }

                participantList = drillParticipantRepository.findAllByParticipantIdIn(participantIds);

                helperMethodToAddExtraAndGetAllData(drill, data, restrictedList, dataList, extraParticipantsDetails, participantList, phaseId);
            } else if (certificateTo.equals(DrillCertificateTo.ONLYPARTICIPANTSWHOSJUDGEMENTISSUBMITTED)) {

                List<DrillParticipant> participantList;
                List<DrillSubmissionEvaluation> drillSubmissionEvaluations = drillSubmissionEvaluationRepository.findDistinctSubmissionIdByDrillIdAndPhaseId(drill.getDrillId(), phaseId);
                List<String> submissionIds = new ArrayList<>();
                List<String> participantIds = new ArrayList<>();
                for (DrillSubmissionEvaluation drillSubmissionEvaluation : drillSubmissionEvaluations) {
                    submissionIds.add(drillSubmissionEvaluation.getSubmissionId());
                }
                List<DrillParticipantSubmission> drillParticipantSubmissions = drillParticipantSubmissionRepository.findDistinctTeamIdBySubmissionIdIn(submissionIds);
                List<String> teamIds = new ArrayList<>();
                for (DrillParticipantSubmission drillParticipantSubmission : drillParticipantSubmissions) {
                    if (drillParticipantSubmission.getTeamId() != null) {
                        teamIds.add(drillParticipantSubmission.getTeamId());
                    } else {
                        participantIds.add(drillParticipantSubmission.getParticipantId());
                    }
                }

                if (participantIds.isEmpty()) {
                    List<TeamsParticipants> teamsParticipants = teamsParticipantsRepository.findAllByTeamIdIn(teamIds);
                    for (TeamsParticipants teamParticipant : teamsParticipants) {
                        participantIds.add(teamParticipant.getParticipantId());
                    }
                }
                participantList = drillParticipantRepository.findAllByParticipantIdIn(participantIds);

                helperMethodToAddExtraAndGetAllData(drill, data, restrictedList, dataList, extraParticipantsDetails, participantList, phaseId);

            }
        } else if (certificateType.equals(DrillCertificateType.WINNERS)) {
            List<DrillParticipant> participantList = drillParticipantRepository.findAllByDrillIdAndPlatformUIdIn(drill.getDrillId(), winnersList);
            helperMethodToAddExtraAndGetAllData(drill, data, restrictedList, dataList, extraParticipantsDetails, participantList, phaseId);

        } else if (certificateType.equals(DrillCertificateType.OTHER)) {

            List<User> participantList = userRepository.findByuIdIn(otherList);


            for (User user : participantList) {

                List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> newData = getDrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto(drill, data, null, user, phaseId);
                DrillCertificateGeneratorModelForCreateCertificate modelForCreateCertificate = new DrillCertificateGeneratorModelForCreateCertificate();
                modelForCreateCertificate.setParticipantPlatformUId(user.getUId());
                modelForCreateCertificate.setData(newData);
                dataList.add(modelForCreateCertificate);

            }

        }
        return dataList;

    }

    private void helperMethodToAddExtraAndGetAllData(Drill drill, List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data, List<String> restrictedList, List<DrillCertificateGeneratorModelForCreateCertificate> dataList, List<DrillParticipant> extraParticipantsDetails, List<DrillParticipant> participantList, String phaseId) {

        if (extraParticipantsDetails != null) {
            for (DrillParticipant participant : extraParticipantsDetails) {
                if (!participantList.contains(participant)) {
                    participantList.add(participant);
                }
            }
        }

        for (DrillParticipant participant : participantList) {
            if (restrictedList == null) {
                List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> newData = getDrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto(drill, data, participant, null, phaseId);
                DrillCertificateGeneratorModelForCreateCertificate modelForCreateCertificate = new DrillCertificateGeneratorModelForCreateCertificate();
                modelForCreateCertificate.setParticipantPlatformUId(participant.getPlatformUId());
                modelForCreateCertificate.setData(newData);
                dataList.add(modelForCreateCertificate);
            } else {
                if (!restrictedList.contains(participant.getPlatformUId())) {
                    List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> newData = getDrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto(drill, data, participant, null, phaseId);
                    DrillCertificateGeneratorModelForCreateCertificate modelForCreateCertificate = new DrillCertificateGeneratorModelForCreateCertificate();
                    modelForCreateCertificate.setParticipantPlatformUId(participant.getPlatformUId());
                    modelForCreateCertificate.setData(newData);
                    dataList.add(modelForCreateCertificate);
                }
            }
        }
    }

    private List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> getDrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto(Drill drill, List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data, DrillParticipant participant, User user, String phaseId) {
        List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> dataList = new ArrayList<>();
        if (user != null) {
            for (DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto changeDataList : data) {
                DrillCertificateGeneratorFieldNamesWithXYCoordinates newData = new DrillCertificateGeneratorFieldNamesWithXYCoordinates();

                if (changeDataList.getField().equals(DrillCertificatePredefinedFields.ID)) {
                    newData.setText("id");
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.NAME)) {
                    newData.setText(user.getFullName());
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.EMAIL)) {
                    newData.setText(user.getEmail());
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.DATE_TODAY)) {
                    newData.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.EVENT_NAME)) {
                    newData.setText(drill.getDrillName());
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.ISSUED_DATE)) {
                    newData.setText("Issued Date : " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.CUSTOM)) {
                    newData.setText(changeDataList.getCustomText());
                } else {
                    newData.setText("");
                }

                newData.setX(changeDataList.getX());
                newData.setY(changeDataList.getY());
                if (changeDataList.getColor() != null) {
                    newData.setColor(changeDataList.getColor());
                } else {
                    newData.setColor("#000000");
                }
                if (changeDataList.getFontStyle() != null) {
                    newData.setFontStyle(changeDataList.getFontStyle());
                } else {
                    newData.setFontStyle(DrillCertificateFontStyles.PLAIN);
                }
                if (changeDataList.getFontFamily() != null) {
                    newData.setFontFamily(changeDataList.getFontFamily());
                } else {
                    newData.setFontFamily(DrillCertificateFontFamily.ARIAL);
                }

                Optional<Object> sizeValue = Optional.of(changeDataList.getSize());
                int size = sizeValue.map(value -> (Integer) value).orElse(40);
                newData.setSize(size);
                dataList.add(newData);

            }
        } else {
            for (DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto changeDataList : data) {
                DrillCertificateGeneratorFieldNamesWithXYCoordinates newData = new DrillCertificateGeneratorFieldNamesWithXYCoordinates();

                if (changeDataList.getField().equals(DrillCertificatePredefinedFields.ID)) {
                    newData.setText("id");
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.NAME)) {
                    newData.setText(participant.getFullName());
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.EMAIL)) {
                    newData.setText(participant.getEmail());
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.DATE_TODAY)) {
                    newData.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.EVENT_NAME)) {
                    newData.setText(drill.getDrillName());
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.ISSUED_DATE)) {
                    newData.setText("Issued Date : " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.TEAM_NAME)) {
                    TeamsParticipants team = teamsParticipantsRepository.findByDrillIdAndParticipantId(drill.getDrillId(), participant.getParticipantId());
                    Optional<DrillTeams> teams = drillTeamsRepository.findByDrillIdAndTeamId(drill.getDrillId(), team.getTeamId());
                    if (teams.get().getTeamName() != null) {
                        newData.setText(teams.get().getTeamName());
                    } else {
                        newData.setText("");
                    }

                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.POSITION)) {
                    DrillLeaderboard leaderboard;
                    TeamsParticipants team = teamsParticipantsRepository.findByDrillIdAndParticipantId(drill.getDrillId(), participant.getParticipantId());
                    if (team != null && team.getTeamId() != null) {
                        leaderboard = leaderboardRepository.findByDrillIdAndPhaseIdAndTeamId(drill.getDrillId(), phaseId, team.getTeamId());
                    } else {
                        leaderboard = leaderboardRepository.findByDrillIdAndPhaseIdAndParticipantId(drill.getDrillId(), phaseId, participant.getParticipantId());
                    }
                    String position ="";
                    if(leaderboard != null) {
                        position = leaderboard.getPosition();
                        if (position == null) {
                            position = "";
                        }
                    }
                    newData.setText(position);
                } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.CUSTOM)) {
                    newData.setText(changeDataList.getCustomText());
                }

                newData.setX(changeDataList.getX());
                newData.setY(changeDataList.getY());
                if (changeDataList.getColor() != null) {
                    newData.setColor(changeDataList.getColor());
                } else {
                    newData.setColor("#000000");
                }
                if (changeDataList.getFontStyle() != null) {
                    newData.setFontStyle(changeDataList.getFontStyle());
                } else {
                    newData.setFontStyle(DrillCertificateFontStyles.PLAIN);
                }
                if (changeDataList.getFontFamily() != null) {
                    newData.setFontFamily(changeDataList.getFontFamily());
                } else {
                    newData.setFontFamily(DrillCertificateFontFamily.ARIAL);
                }

                if (changeDataList.getSize() == 0) {
                    newData.setSize(40);
                } else {
                    newData.setSize(changeDataList.getSize());
                }
                dataList.add(newData);
            }
        }
        return dataList;
    }

    private BufferedImage convertToJPEG(BufferedImage image) {
        BufferedImage convertedImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
        convertedImage.createGraphics().drawImage(image, 0, 0, Color.WHITE, null);
        return convertedImage;
    }

    private void addTextsToImage(BufferedImage image,
                                 List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> data, String id) {

        Graphics2D g2d = image.createGraphics();

        for (DrillCertificateGeneratorFieldNamesWithXYCoordinates text : data) {
            String texts = text.getText();
            int x = text.getX();
            int y = text.getY();
            int size = text.getSize();
            DrillCertificateFontFamily fontFamily = text.getFontFamily();

            String color = text.getColor();
            g2d.setColor(Color.decode(color));

            int fontStyle = getFontStyle(text.getFontStyle());
            Font font = new Font(fontFamily.getFamilyName(), fontStyle, size);
            g2d.setFont(font);
            if (Objects.equals(texts, "id")) {
                texts = "Certificate ID: " + id;
                g2d.drawString(texts, x, y);
            } else {
                g2d.drawString(texts, x, y);
            }

        }
        g2d.dispose();
        log.info("Texts added to image");
    }

    private int getFontStyle(DrillCertificateFontStyles fontStyle) {
        switch (fontStyle) {
            case ITALIC:
                return Font.ITALIC;
            case BOLD:
                return Font.BOLD;
            case BOLD_ITALIC:
                return Font.BOLD | Font.ITALIC;
            case PLAIN_ITALIC:
                return Font.ITALIC; // Font.PLAIN is already zero
            default:
                return Font.PLAIN;
        }
    }

    private byte[] convertImageToByteArray(BufferedImage image) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ImageIO.write(image, "jpg", outputStream);
        return outputStream.toByteArray();
    }

    public ResponseEntity<?> downloadCertificate(String id, InternityUser user) throws IOException {
        Optional<DrillCertificateGenerator> certificate = generateCertificateRepository.findById(id);
        if (!certificate.isPresent()) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Certificate details not found", null), HttpStatus.BAD_REQUEST);
        }
        String imageUrl = certificate.get().getCertificateUrlInS3();
        if (imageUrl == null) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Certificate not found", null), HttpStatus.BAD_REQUEST);
        }

        InputStream s3Image = getImageFromS3(imageUrl);
        byte[] image = convertImageToByteArray(ImageIO.read(s3Image));
        ByteArrayResource resource = new ByteArrayResource(image);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"certificate.jpg\"")
                .contentLength(resource.contentLength())
                .contentType(MediaType.IMAGE_JPEG)
                .body(resource);
    }

    public ResponseEntity<?> previewCertificate(String id, InternityUser user) throws IOException {
        Optional<DrillCertificateGenerator> certificate = generateCertificateRepository.findById(id);
        if (!certificate.isPresent()) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Certificate details not found", null), HttpStatus.BAD_REQUEST);
        }
        String imageUrl = certificate.get().getCertificateUrlInS3();
        if (imageUrl == null) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Certificate not found", null), HttpStatus.BAD_REQUEST);
        }

        InputStream s3Image = getImageFromS3(imageUrl);

        byte[] image = convertImageToByteArray(ImageIO.read(s3Image));
        ByteArrayResource resource = new ByteArrayResource(image);
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .body(resource);
    }

    public ResponseEntity<?> previewDemoCertificate(MultipartFile imageFile,
                                                    List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data,
                                                    String imageUrl, String s3Url, InternityUser user) {

        try {
            if (imageFile == null && imageUrl == null && s3Url == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Image is Missing both (image upload and url both are missing)", null), HttpStatus.BAD_REQUEST);
            }
            if (imageFile != null && imageUrl != null && s3Url != null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "We got both inputs for image we need any one", null), HttpStatus.BAD_REQUEST);
            }
            if (data == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Data is Missing", null), HttpStatus.BAD_REQUEST);
            }
            BufferedImage image = null;
            if (imageFile != null) {
                image = ImageIO.read(imageFile.getInputStream());
            }
            if (imageUrl != null) {
                // get image from external link
                URL url = new URL(imageUrl);
                image = ImageIO.read(url);
            }
            if (s3Url != null) {
                InputStream s3Image = getImageFromS3(s3Url);
                image = ImageIO.read(s3Image);
            }

            BufferedImage jpgImage = convertToJPEG(image);

            List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> newData = getDemoDrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto(data);

            addTextsToImage(jpgImage, newData, "demo1234ID56");

            byte[] imageData = convertImageToByteArray(jpgImage);

            ByteArrayResource resource = new ByteArrayResource(imageData);

            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .body(resource);

        } catch (IOException e) {
            log.error("Error while generating certificate: " + e.getMessage());
            return ResponseEntity.badRequest().body("Error while generating certificate");
        }

    }

    private List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> getDemoDrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto(List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data) {
        List<DrillCertificateGeneratorFieldNamesWithXYCoordinates> dataList = new ArrayList<>();

        for (DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto changeDataList : data) {
            DrillCertificateGeneratorFieldNamesWithXYCoordinates newData = new DrillCertificateGeneratorFieldNamesWithXYCoordinates();

            if (changeDataList.getField().equals(DrillCertificatePredefinedFields.ID)) {
                newData.setText("id");
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.NAME)) {
                newData.setText("Demo Name");
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.EMAIL)) {
                newData.setText(changeDataList.getField().toString().toLowerCase() + "demoemail@email.com");
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.DATE_TODAY)) {
                newData.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.EVENT_NAME)) {
                newData.setText("Demo Event Name");
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.ISSUED_DATE)) {
                newData.setText("Issued Date : " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.TEAM_NAME)) {
                newData.setText("Demo " + changeDataList.getField().toString().toLowerCase());
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.POSITION)) {
                newData.setText("1000");
            } else if (changeDataList.getField().equals(DrillCertificatePredefinedFields.CUSTOM)) {
                newData.setText(changeDataList.getCustomText());
            }
            newData.setX(changeDataList.getX());
            newData.setY(changeDataList.getY());

            if (changeDataList.getColor() != null) {
                newData.setColor(changeDataList.getColor());
            } else {
                newData.setColor("#000000");
            }
            if (changeDataList.getFontStyle() != null) {
                newData.setFontStyle(changeDataList.getFontStyle());
            } else {
                newData.setFontStyle(DrillCertificateFontStyles.PLAIN);
            }
            if (changeDataList.getFontFamily() != null) {
                newData.setFontFamily(changeDataList.getFontFamily());
            } else {
                newData.setFontFamily(DrillCertificateFontFamily.ARIAL);
            }
            if (changeDataList.getSize() == 0) {
                newData.setSize(40);
            } else {
                newData.setSize(changeDataList.getSize());
            }

            dataList.add(newData);
        }

        return dataList;
    }

    public ResponseEntity<?> saveCertificateTemplate(String drillId,
                                                     List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data,
                                                     MultipartFile imageFile,
                                                     String imageUrl,
                                                     String uId,
                                                     String templateName, InternityUser user) {
        try {
            if (StringUtils.isAnyBlank(templateName)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide template name", null), HttpStatus.BAD_REQUEST);
            }
            if (StringUtils.isAnyBlank(uId)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide uId", null), HttpStatus.BAD_REQUEST);
            }
            User newUser = userRepository.findById(uId).orElse(null);
            if (newUser == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "User not found", null), HttpStatus.BAD_REQUEST);
            }
            if (StringUtils.isAnyBlank(drillId)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide drillId in path", null), HttpStatus.BAD_REQUEST);
            }
            Drill drill = drillRepository.findById(drillId).orElse(null);
            if (drill == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill not found", null), HttpStatus.BAD_REQUEST);
            }
            if (data == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide data", null), HttpStatus.BAD_REQUEST);
            }
            if (imageFile == null && (StringUtils.isAnyBlank(imageUrl) || imageUrl == null)) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide image upload or image url both are no present", null), HttpStatus.BAD_REQUEST);
            }
            if (imageFile != null && imageUrl != null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide either image or imageUrl not both", null), HttpStatus.BAD_REQUEST);
            }

            String imageS3Url;
            if (imageFile != null) {
                BufferedImage image = ImageIO.read(imageFile.getInputStream());
                image = convertToJPEG(image);
                imageS3Url = uploadImageToS3(image);
            } else {
                URL url = new URL(imageUrl);
                BufferedImage image = ImageIO.read(url);
                image = convertToJPEG(image);
                imageS3Url = uploadImageToS3(image);
            }

            DrillCertificateGeneratorTemplate template = new DrillCertificateGeneratorTemplate();

            template.setTemplateName(templateName);
            template.setTemplateCreatorUId(uId);
            ObjectMapper mapper = new ObjectMapper();
            String jsonString = mapper.writeValueAsString(data);
            template.setTemplateData(jsonString);
            template.setEventId(drillId);
            template.setCertificateImageUrlInS3(imageS3Url);

            templateRepository.save(template);
            return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Template Saved Successfully", null), HttpStatus.OK);
        } catch (Exception e) {
            log.error(e.getMessage());
            return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, e.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }


    public ResponseEntity<?> getCertificateTemplate(String id, String drillId, InternityUser user) {
        if (StringUtils.isAnyBlank(drillId)) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide drillId in path", null), HttpStatus.BAD_REQUEST);
        }

        Drill drill = drillRepository.findById(drillId).orElse(null);
        if (drill == null) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Drill not found", null), HttpStatus.BAD_REQUEST);
        }

        if (id != null) {
            DrillCertificateGeneratorTemplate template = templateRepository.findById(id).orElse(null);
            if (template == null) {
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Template not found", null), HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, template, null), HttpStatus.OK);
        }

        List<DrillCertificateGeneratorTemplate> templateList = templateRepository.findByEventId(drillId);
        if (templateList.isEmpty()) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Template not found", null), HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, templateList, null), HttpStatus.OK);
    }

    public ResponseEntity<?> getCertificateTemplatePreview(String id, InternityUser user) throws JsonProcessingException {

        DrillCertificateGeneratorTemplate template = templateRepository.findById(id).orElse(null);
        if (template == null) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Template not found", null), HttpStatus.BAD_REQUEST);
        }
        ObjectMapper mapper = new ObjectMapper();
        List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data = mapper.readValue(template.getTemplateData(), new TypeReference<List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto>>() {
        });

        return previewDemoCertificate(null, data, null, template.getCertificateImageUrlInS3(),user);
    }

    public ResponseEntity<?> updateCertificateTemplate(String id, List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> template, InternityUser user) throws JsonProcessingException {
        if (StringUtils.isAnyBlank(id)) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide Template id", null), HttpStatus.BAD_REQUEST);
        }
        if (template == null) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide Template details", null), HttpStatus.BAD_REQUEST);
        }
        DrillCertificateGeneratorTemplate templateObj = templateRepository.findById(id).orElse(null);
        if (templateObj == null) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Template not found", null), HttpStatus.BAD_REQUEST);
        }

        ObjectMapper mapper = new ObjectMapper();
        String jsonString = mapper.writeValueAsString(template);
        templateObj.setTemplateData(jsonString);
        templateRepository.save(templateObj);
        return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Template Updated Successfully", null), HttpStatus.OK);
    }

    public ResponseEntity<?> deleteCertificateTemplate(String id, InternityUser user) {
        if (StringUtils.isAnyBlank(id)) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Please provide Template id", null), HttpStatus.BAD_REQUEST);
        }
        DrillCertificateGeneratorTemplate templateObj = templateRepository.findById(id).orElse(null);
        if (templateObj == null) {
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Template not found", null), HttpStatus.BAD_REQUEST);
        }
        templateRepository.delete(templateObj);
        return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, "Template Deleted Successfully", null), HttpStatus.OK);
    }

    private String uploadImageToS3(BufferedImage image) throws IOException {
        log.info("Uploading image to S3");

        byte[] imageData = convertImageToByteArray(image);

        // Specify the key (file name) for the image in the S3 bucket
        String key = UUID.randomUUID().toString().replaceAll("-", "") + ".jpg";

        // Create an input stream from the image data
        InputStream inputStream = new ByteArrayInputStream(imageData);

        // Create metadata for the image
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(imageData.length);
        metadata.setContentType("image/jpeg");

        // Upload the image to the specified S3 bucket
        PutObjectRequest request = new PutObjectRequest(bucketName, key, inputStream, metadata);
        s3Client.putObject(request);

        // Get the link (URL) of the uploaded image

        return String.valueOf(s3Client.getUrl(bucketName, key));
    }

    public InputStream getImageFromS3(String imageUrl) {
        // Parse the bucket name and key from the image URL
        String[] parts = imageUrl.split("/", 4);
        String key = parts[3];

        // Create a GetObjectRequest to fetch the image from S3
        GetObjectRequest getObjectRequest = new GetObjectRequest(bucketName, key);

        // Get the S3 object
        S3Object s3Object = s3Client.getObject(getObjectRequest);

        // Get the object's contents as an input stream
        return s3Object.getObjectContent();
    }


}

