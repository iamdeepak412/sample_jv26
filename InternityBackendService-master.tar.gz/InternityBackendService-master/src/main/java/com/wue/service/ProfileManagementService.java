package com.wue.service;

import com.wue.constant.CommonConstants;
import com.wue.constant.ProfileSectionEnum;
import com.wue.constant.UserProfileOtherDetailsType;
import com.wue.domain.*;
import com.wue.factory.UserProfileFactory;
import com.wue.repository.*;
import com.wue.user.profile.ProfileSection;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Log4j2
public class ProfileManagementService {

	@Autowired
	UserProfileRepository userProfileRepository;

	@Autowired
	SkillsLookupRepository skillsLLookupRepository;
	
	@Autowired
	EducationInformationRepository educationRepository;
	
	@Autowired
	WorkProfileRepository workRepository;

	@Autowired
	UserOtherDetailsRepository userOtherDetailsRepository;

	@Autowired
	UserSkillRepository skillRepository;

	@Autowired
	UserProjectRepository projectRepository;

	@Autowired
	CommonUtils commonUtils;

	private static int currentYear = Calendar.getInstance().get(Calendar.YEAR);
	
	public boolean update(Map<String, Object> requestpayload, String section, InternityUser user) {
		try {
			ProfileSection profileSection = UserProfileFactory.getProfileSection(section);
			profileSection.update(requestpayload);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean delete(Long id, String section, InternityUser user) {
		try {
			ProfileSection profileSection = UserProfileFactory.getProfileSection(section);
			return profileSection.delete(id, user.getUId());
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean save(User userObj, String resumeLink, InternityUser user) {
		try {
			Optional<UserPersonalDetail> userPersonalDetailObj = userProfileRepository.findByuId(userObj.getUId());
			UserPersonalDetail profile;
			if(userPersonalDetailObj.isPresent()){
				profile = userPersonalDetailObj.get();
			} else {
				profile = new UserPersonalDetail();
			}

			if (!StringUtils.isEmpty(resumeLink)) {
				profile.setResumeLink(resumeLink);
			}

			profile.setUId(userObj.getUId());

			userProfileRepository.saveAndFlush(profile);
			return true;
		} catch (Exception e) {
			log.error("Exception while saving the userid with profile {}", e);
		}
		return false;
	}

	public List<?> fetchSection(String section, String uId) {
		try {
			if(!section.equals(CommonConstants.COMPLETE_PROFILE)) {
				ProfileSection profileSection = UserProfileFactory.getProfileSection(section);
				return profileSection.fetch(uId);
			}
			else {
				return completeUserProfile(uId);
			}
		} catch (Exception e) {
			log.error("Exception while fetching profile {}", e);
		}
		return null;
	}

	private List<?> completeUserProfile(String uId) {
		List<Map<String,List<Map<String, Object>>>> listOfProfileSection = new ArrayList<>();

		Map<String, List<Map<String, Object>>> sectionMap = new HashMap<>();

		for(ProfileSectionEnum section : ProfileSectionEnum.values()){

			ProfileSection profileSection = UserProfileFactory.getProfileSection(section.getValue());

			sectionMap.put(section.getValue(),profileSection.fetch(uId));

		}

		listOfProfileSection.add(sectionMap);

		return listOfProfileSection;
	}

	public List<String> fetchAutocompleteSkillList(String initialLetters) {
		try {
		List<SkillsLookup> skillsLookupList = skillsLLookupRepository.findBySkillNameStartsWith(initialLetters);
		List<String> result = new ArrayList<>();

		for (SkillsLookup skill : skillsLookupList) {
			result.add(skill.getSkillName());
		}

		return result;
		}
		catch (Exception e) {
			log.error("Exception while fetching skills {}", e);
			return Collections.emptyList();
		}
	}

	public Map<String, Object> fetchCommonFields(String section, String uId) {
		switch (section) {
		case "personal":
			return getPersonalCommonFields();
		case "education":
			return getEducationCommonDetails();
		case "work":
			return getWorkCommonDetails();
		case "project":
			return getProjectCommonDetails(uId);
		case "skill":
			return getSkillCommonDetails();
		case "other":
			return getOtherCommonDetails();
		default:
			break;
		}
		return null;
	}

	private Map<String, Object> getOtherCommonDetails() {
		return null;
	}

	private Map<String, Object> getProjectCommonDetails(String uId) {
		Map<String, Object> fields = new HashMap<>();
		fields.put("designation", getAssociatedDesignation(uId));
		return fields;
	}

	private Object getAssociatedDesignation(String uId) {
		List<UserWorkProfile> workExpList = workRepository.findByuId(uId);
		List<Map<String, String>> listOfDesignationAndId = new ArrayList<>();
		for (UserWorkProfile workExp : workExpList) {
			Map<String, String> designationMap = new HashMap<>();
			designationMap.put("id",""+workExp.getExpCount());
			designationMap.put(	"value",workExp.getJobDesignation()+ ", " + workExp.getOrganisationName());
			listOfDesignationAndId.add(designationMap);
		}
		return listOfDesignationAndId;
	}

	private Map<String, Object> getWorkCommonDetails() {
		return null;
	}
	
	private Map<String, Object> getSkillCommonDetails() {
		return null;
	}

	private Map<String, Object> getEducationCommonDetails() {
		Map<String, Object> fields = new HashMap<>();
		fields.put("passingOutYear", getPassingOutYearList());
		fields.put("degree", getDegreeList());
		fields.put("specialization", getSpecialisationList());
		fields.put("colleges", getColleges());
		fields.put("medium", getSchoolMedium());
		fields.put("board", getBoardNames());
		return fields;
	}

	private Object getBoardNames() {
		return Arrays.asList("CBSE","ICSE","ISC","National Open School","Uttar Pradesh State Board"
				,"Andhra Pradesh State Board","Arunachal Pradesh State Board","Assam State Board"
				,"Bihar State Board","Chattisgarh State Board","Goa State Board","Gujarat State Board"
				,"Haryana State Board","Himachal Pradesh State Board","J & K State Board"
				,"Jharkhand State Board","Karnataka State Board","Kerela State Board"
				,"Madhya Pradesh State Board","Maharashtra State Board","Manipur State Board"
				,"Meghalaya State Board","Mizoram State Board","Nagaland State Board"
				,"Odisa State Board","Punjab State Board","Rajasthan State Board"
				,"Tamil Nadu State Board","Telangana State Board","Tripura State Board"
				,"Uttrakhand State Board","West Bengal State Board","Other");
	}

	private Object getSchoolMedium() {
		return Arrays.asList("English","Hindi","Konkani","Marathi","Assamese","Bengali","Gujarati",
				"Kannada","Malayalam","Manipuri","Oriya","Punjabi","Sanskrit","Tamil","Telugu","Urdu","Other");
	}

	private Object getPassingOutYearList() {
		List<Integer> passingOutYearList = new ArrayList<>();
		for (int i = 1972; i < currentYear + 10; i++) {
			passingOutYearList.add(i);
		}
		return passingOutYearList;
	}

	private Map<String, Object> getPersonalCommonFields() {
		Map<String, Object> fields = new HashMap<>();
		fields.put("languages", getLanguages());
		
		return fields;
	}
	
	private Object getSpecialisationList() {
		return Arrays.asList("Agriculture", "Automobile", "Aviation", "Bio-Chemistry", "Bio-Technology", "Biomedical",
				"Ceramics", "Chemical", "Civil", "Computer Science", "Electrical", "Electronics", "Telecommunication",
				"Energy", "Environmental", "Instrumentation", "Marine", "Mechanical", "Metallurgy", "Mineral", "Mining",
				"Nuclear", "Paint", "Oil", "Petroleum", "Plastics", "Production", "Industrial", "Textile");
	}

	private Object getDegreeList() {
		return Arrays.asList("B.A.", "B.Sc", "B.Tech", "B.E.", "B.Arch", "BCA", "B.B.A", "B.M.S.", "B.Com", "B.Ed",
				"BDS", "BHM", "B.Pharma", "LLB", "MBBS", "Diploma", "BAMS", "BHMS", "B.P.Ed", "B.El.Ed", "BHMCT",
				"B.Des", "BFA", "B.U.M.S", "MCA", "MBA", "M.Com", "M.Tech", "Ph.D", "MPHIL");
	}
	
	private Object getLanguages() {
		return Arrays.asList("Hindi", "English", "Marathi", "Bengali", "Tamil", "Malyalam", "Bhojpuri", "French",
				"German", "Punjabi", "Sanskrit", "Assamese", "Odia", "Maithili", "Gujarati", "Sindhi", "Nepali",
				"Chhattisgarhi", "Romani", "Kannada", "Kashmiri", "Mandarin", "Spanish", "Arabic", "Russian",
				"Portugese", "Indonesian");
	}
	
	private Object getColleges() {
		Set<String> colleges = Stream.of("Sharda University","Gautam Buddha University","IILM Graduate School of Management",
				"Galgotias Educational Institutions","ITS Engineering College","Bennett University","shiv nadar university",
				"mangalmay institute","EIS college","Accurate Institute of Management and Technology","Birla Institute Of Management Technology",
				"DRONACHARYA GROUP OF INSTITUTIONS,GAUTAM BUDDH NAGAR","Lloyd Law College","Army Institute of Management & Technology",
				"apeejay school of architecture and planning","Janhit College of Law","International Maritime Institute",
				"NIILM Center for Management Studies","Galgotias business school","Pandit Deendayal Upadhyaya Institute of Archaeology",
				"Gautam Buddha Universit","ACCMAN INSTITUTE OF MANAGEMENT","Galgotia University","Institute of Management Studies (IMS)",
				"Amity University","Jaypee Institute of Information Technology","Indian Institute of Finance (IIF)",
				"JSS Academy of Technical Education (JSSATEN)","Noida International University (NIU)",
				"Jagran Institute of Management and Mass Communication (JIMMC)","United Group of Institutions (UGI)",
				"IEC College of Engineering and Technology","Delhi Metropolitan Education (DME)","Bennett University (BU)",
				"Gulshan Kumar Journalism & Media Institute India","National Academy of Sports Management (NASM)",
				"Sunstone Eduversity (SE)","Ram Eesh Institute Of Education RIE","Rajiv Gandhi Institute Of Petroleum Technology",
				"Maharishi Gandharva Ved Vishwa Vidyapeeth","JSS ACADEMY OF TECHNICAL EDUCATION","ITS Engineering College",
				"Amity Institute of Behavioural and Allied Sciences","Amity International Centre for Post Harvest Technology Cold Chain Management",
				"Priyadarshani College of Computer Sciences","RICS School of Built Environment","JSS Academy Of Technical Education",
				"Amity Institute Of Rehabilitation Sciences AIRS","IIMT College of Science and Technology",
				"Amity Institute of Telecom Engineering and Management AITEM","Directorate of Innovation and Technology Transfer DITT",
				"Amity Institute of Space Science Technology AISST ","Amity Institute of Horticulture Studies Research AIHSR",
				"Amity College of Commerce Finance ACCF","Amity Institute of Anthropology AIA","Amity Institute of Social Sciences AISS",
				"Government Post Graduate College","Indian Institute Of Tourism Travel Management IITTM",
				"Hind Institute of Nautical Science and Engineering HINSAE","Sardar Vallabhbhai National Institute of Technology (SVNIT)",
				"C. K. Pithawala College of Engineering and Technology","Government Arts College (GAC)","V.T. Choksi Sarvajanik Law College (VTCSLC)",
				"Navyug Science College (NSC)","Sir P. T. Sarvajanik College of Science (PTSCS)",
				"Shree Ramkrishna Institute of Computer Education and Applied Sciences","Chhotubhai Gopalbhai Patel Institute of Technology (CGPIT)",
				"Shri Tapi Brahmcharyashram Sabha College Of Diploma Engineering","Bhulabhai Vanmalibhai Patel Institute Of Technology",
				"Shree Swami Atmanand Saraswati Institute of Technology","Dr.S.&S.S. Gandhy Government Engineering College",
				"Diwaliba Polytechnic","Jayvantrai Harrai Desai Polytechnic","Sitarambhai Naranji Patel Institute of Technology & Research Centre",
				"Shree Dhanvatary college of Diploma Engineering","MAHAVIR SWAMI COLLEGE OF ENGINEERING & TECHNOLOGY",
				"Indian Institute of Information Technology","Veer Narmad South Gujarat University","B.J. Patel College Of Education",
				"Babubhai B. Avichal Arts And Commerce College","Smt. G.N Pandya Commerce & Science College (GNPCSC)",
				"Smt. Z. S. Patel College of Computer Application","Galgotia","Synergy Institute of Engineering & Technology","CMR institute","Combridge University","Gopalan College of Engineering and Management"
				,"Rashtriya Sanskrit Vidyapeeth,","Indian Institute of Science,","Christ College, Hosur Road, Bangalore","BLDE University, Bangaramma Sajjan Campus,","Patel Institute Of Technology","Globus Engineering College","Lakshmibai National University of Physical Education","Bansal Institute of Research & Technology","Shree ram institute of Technology,jabalpur","Gandhi Engineering College","Millennium Institute of Technology","Ludhiana Group of Colleges","Mandava Institute of Engineering and Technology","Vijay Krishna College of Nursing","Krishna Institute of Technology & Management","SVS Group of Institutions","Rajasthan Institute of Engineering & Technology","Camellia Institute of Technology & Management","Bhagat College of Diploma In ENGG & TECH.-303","Sanghvi Institute of Management & Science","Ellenki Institute of Engineering & Technology","Institute of Professional Education and Research","Amity University","M. S. Ramaiah Management Institute","Mansarovar Institute of Science & Technology","Indore Institute of Science & Technology, Indore","Lucknow Institute Of Technology","Banaras Hindu University","Bhopal Institute of Technology, Bhopal","Vaishnavi Institute of Technology & Science, Medua","Bansal Institute of Engineering, Lko","Modi Institute of Technology","Apeejay Institute of Architecture and Planning","Kanpur Institute of Technology","Maharaja Harishchandra College of Higher Education, Hardoi","Yug Chetna Mahavidyalaya, Bharuwa","KCC Institute","NIU, Noida","Jaypee Institute, Noida","Symbiosis college","Darshan Institute","IIIT Pune","IEC,","Gujarat Vidyapith, PO Navjivan,","Apex Technology","Ramswarup Lucknow","Shivalik College of Engineering Dehradun","Invertis HOD","NIU HOD","IIIT Pune Director","AISSM College","Univ. of Pune","LBS Lucknow","Rohilkhand Univ","Nitte Meenakshi Institute of Technology",
				"Rajarajeshwari College of Engineering","Rajiv Gandhi Institute of Technology","RNS Institute of Technology","Shirdi Sai Engineering College","SJB Institute of Technology","Sri Belimatha Mahasmtana Institute of Technology","Sri Krishna Institute of Technology","T John Institute of Technology","The Oxford College of Engineering","University Visvesvaraya College of Engineering","Vijaya Vittala Institute of Technology","Sumandeep Vidyapeeth,","Maharishi Markandeshwar University","Birla Institute of Technology","Indian Institute of Science","National Institute of Mental Health and Neuro","International Institute of Information Technology","Bharati Vidyapeeth,","Homi Bhabha National Institute","Shanmugha Arts, Science, Technology","Vellore Institute of Technology,","SRM Institute of Science & Technology","Ponnaiyah Ramajayam Institute of Science & technology","Santosh University,","Manav Rachna International University,","B.S.Abdur Rahman Institute of Science &","Jain University","Indian Agricultural Research Institute,","Graphic Era University","IIS University","A P S College of Engineering","Acharya Institute of Technology","ACS College of Engineering","B.M.S.College of Engineering","Banglore College of Engineering & Technology","Banglore Institute of Technology","BNM Institute of Technology","Cambridge Institute of Technology","CMR Institute of Technology","Global Academy of Technology","GSS Institute of Technology","K.N.S. Institute of Technology","Institute of engineering & management","APEX institute of management and technology","ASBM institute of BBA","ACE college of engineering & management","Maulana Azad national institute of technology","college of engineering and management","Asnsol engineering college","sri sai Aditya institute of science & technology","Dhaneshwar Rath institute of engineering and management studies","Modinagar Institute of technology","Bansal college of engineering","Corporate institute of science & technology","G.H Raisoni college of engineering","Hindustan institute of technology and management","Shyam college of engineering and technology","Vidhyapeeth institute of science and technology",
				"Asians institute of technology","Murshidabad College of Engg. & Technology","Seemanta Engineering College","Noida Institute of EngineeringTechnology","M. S. Ramaiah Management Institute","Priyadarshini Institute of Engineering & Technology","MIT College of Engineering","Vishwakarma Institute of Management Pune (VIT)","Parmar Institute of Professional Studies, Gwalior","Mansarovar Institute of Science & Technology","Vidyasagar Institute of Technology","Indore Institute of Science & Technology, Indore","Basavakalyan Engineering College","New Horizon College of Engineering","Rungta College of Engineering and Technology, Raipur","Subharti Institute of Technology & Engineering","Bhubaneswar Institute of Technology","Indus College of Engineering,Bhubaneswar","Rajdhani Institute of Technology and Management","Accurate Institute of Management & Technology","Lucknow Institute Of Technology","S.R Institute of Management and Technology","Kashi Institute of Technology","Delhi College of Engineering","Mangalmay Institute of Management & Technology","Guru Nanak Institute of Technology","Karnal Institute of Technology & Management","Jagannath Institute of Technology & Management","ST. Thomas College of Engineering & Technology","Government Engineering College , Ajmer","IAMR College  of Engineering","Indian Institute of Management","Visvesvaraya National Institute of Technology Nagpur","National Institute of Technology Raipur","Indian Institute of Technology Delhi","National Instution of Technology Rourkela","Institute of Technoloty, Banaras Hindu University","Birla Institute of Technology","Indian Institute of Management Raipur","Sri Satya Sai College of Engineering","Netaji Subhash Engineering College","Oxford College of Engineering & Management","Purushottam Institute of Engineering & Technology","Radharaman Institute of Technology & Science","Saroj Mohan Institute of Technology","Heritage Institute of Technology","Gandhi Engineering College","Sri Sant Gadge Baba College of ENGG.&TECH","Global Academy of Technology Banglore","Amritsar College of Engineering & Technology","Future Institute of Engineering & Management","Adesh Institute of Engineering & Technology","C.V.Raman College of Engineering","Reva Institute of Technology and Management","Koustuv Institute of Technology Bhuneshwar","Rattan Institute of Technology & Management","Sri Siddhartha Institute of Technology","Gandhi Institute of Industrial Technology","Mahaveer Institute of Engineering & Technology","Bengal College of Engineering and Technology","Sobhasaria Engineering College","Mallabhum Institute of Technology","Maghnad Saha Institute of Technology","Stani Memorial College of Engineering and Technology","Aditya Engineering College","Godavari Institute of Engineering & Technology","Newtons Institute of Engineering","Nalanda Institute of Technology, Siddharth Nagar","Amara Institute of Engineering & Technology","Koneru Lakshmyiah College of Engineering","Nalanda Institute of Engineering & Technology","Guntur Engineering College","Nirma College of Engineering and Technology","S.S.N. Engineering College","Sri Venkateswara College of Engineering & Technology",
				"Indira Institute of Technology & Sciences","Maulana Azad College Of Engineering & Technology, Patna","Netaji Subhash Institute of Technology","Sri Bhagwat Prasad Singh Memorial B.Ed. College","Raghunath Prasad Sharma Institute Of Technology","Sityog Institute of Technology","Nalanda Open University","National Institute of Fashion Technology,Bihar","Indian Institute of Technology , Guwahati","BMS College of Engineering","B T L Institute of Technology and Mangement","AMC Engineering College","SJB Institute of Technology","S.E.A College of Engineering & Technology, Bangalore","Rajiv Gandhi Institute of Technology","KLS Gogte Institute of Technology","Shaikh College of Engineering & Technology","Ballari Institute of Technology & Management","Guru Nanak Dev Engineering College","Adichunchanagiri Institute of Technology","S.J.M Institute Of Technology","S.D.M College of Engineering & Technology","P.E.S. College of Engineering","Jawaharlal Nehru National College of Engineering","Channabasaveshwara Institute of Technology","Siddaganga Institute of Technology","Shridevi Institute of EngineeringTechnology","H.M.S. Institute of Technology","P.A. College of Engineering","Ghousia College of Engineering.","Sri Venkateshwara College of Engineering, Bengalaru","Cochin University College of Engineering","Swami Vivekanand College of Engineering","Oriental Institute of Science And Technology, Indore","Vindhya Institute of Technology and Science","Prestige Institute of Engineering & Science","Central India Institute of Technology","Malwa Institute of Science and Technology","International Institute of Professional Studies, DAVV","Indian Institute of Management Indore","Institute of Engineering & Technology.","Lakshmi Narain college of technology","Rishiraj Institute of Technology ,Indore","Patel College of Science & Technology","Shree Institute of Science & Technology","Technocrats Institute of Technology, Bhopal","Mittal Institute of Technology","Bhabha College of Engineering, Bhopal","Bhopal Institute of Technology, Bhopal","Vaishnavi Institute of Technology & Science, Medua","Vedica institute of technology","Patel Institute Of Technology","Iasscom Fortune Institute of Technology,Bhopal","Surabhi College of Engineering & Technology","Bagula Mukhi College of Technology","Jai Narain College of Technology","Surabhi group of institutions,bhopal","Laxmipati Institute of ScienceTechnology","Kailash Chandra Bansal College of Technology","Kailash Narayan Patidar College of Science & Technology","Kopal Institute of Science and Technology","NRI Group of Institutions","Knp College Of Science And Technology","All Saints College of Engineering","Barkatullah University Institute of Technology","Sam College of Engineering & Technology","Globus Engineering College","Satyam Educational & Social Welfare Society Group of Institutions","Oriental Institute of Science & Technology","IES Institute of Technology & Management","Institute of Technology & Management","Gwalior Engineering College","Shri Ram College of engineering & management","Gwalior Institute of Technology and Science (GITS)","Laxmi Narayan Institute of Technology",
				"Maharana Pratap College of Technology","ITM University","Gyan Ganga Institute of Technology & Science","Oriental Institute Of Science And Technology, Jabalpur","S.G .B.M. Institute of technology & science","Bansal Institute of Science & Technology","Scope College of Engineering","Sagar Institute of Science Technology & Engineering","Bansal Institute of Research & Technology","Sardar Patel Institute Of Education","Vindhya Institute of Technology & Science","Takshshila Institute of Engg. & Technology Jabalpur",
				"shree ram institute of Technology,jabalpur","Ojaswini Institute of Management & Technology","AISECT Institute of Science & Technology","Bansal College of Engineering, Mandideep","Jaytee University of Engineering & Technology","Swami Vivekanand University","Gyan Sagar College of Engineering","Sardar Patel College of Technology","Indian Institute of Technology, Bombay","Maharashtra Academy of Engineering","G.H. Raisoni Institute of Engineering & Technology","Sinhgad College of Engineering","N.B.N. Sinhgad School of Engineering","Indira College of Engineering and Management","JSPM Jayawantrao Sawant College of Engineering, Pune","Mitcon Institute of Management","Tulsiramji Gaikwad-Patil College of Engineering & Technology, Nagpur","Yeshwantrao Chavan College of Engineering","Vidarbha Institute of Technology","Priyadarshini Indira Gandhi College of Engineering, Nagpur","J.T. Mahajan College of Engineering, Faizpur","Manoharbhai Patel Institute of Engineering & Technology, Gondia","Marathwada Institute of Technology","Shri Shankarprasad Agnihotri College of Engineering","Gandhi Institute of Science and Technology, Rayagada","Rayagada Institute of Technology and Management","Ghanshyam Hemalata Institute of Technology & Management","Divine Institute of Engineering & Technology, Baripada","Samanta Chandrasekhar Institute of Technology and Management","SSB Regional Institute of Science & Technology","Mayurbhanj School Of Engineering","Central Institute of Plastic Engineering","Barrister Ranjit Mohanty International Institute Of Technology","Gandhi Institute For Education and Technology, Khudra","Ganesh Institute Of Engineering & Technology","Silicon Institute of Technology, Bhubaneswar","Eastern Academy of Science & Technology (EAST)","Modern Institute of Technology and Management","College of Engineering Bhubneshwar (CEB)","HI-TECH College of Engineering","Biju Patnaik Institute of Information Technology & Management Studies","KMBB College of Engineering and Technology","NM Institute of Engineering and Technology","Maharaja Institute of Technology","Synergy Institute of Technology , Bhubaneswar","College of Engineering & Technology, Bhubaneswar (CET)","Orissa Engineering College","Sophitorium Engineering College","Institute of management & information science","Einstein Academy of Technology & Management","Gandhi Institute For Technology","Raajdhani Engineering College","TempleCity Institute of Technology & Engineering","Konark Institute of Science & Technology",
				"Gurukula Institute of Technology","Trident Academy Of Technology,Bhubaneswar","KIIT University","Gandhi Institute OF Technology And Management","Aryan Institute of Engg. & Technology","Government College of Engineering Kalahandi","National Institute Of ScienceTechnology, Ganjam","Gandhi Academy of Technology and Engineering(GATE)","Synergy Institute of Engineering & Technology","Bhadrak Institute of Engineering & Technology","Hi-Tech Institute of Engineering & Management","Padmashree Krutartha Acharya College of Engineering , Bargarh","Adarsha College of Engineering","Kalinga Institute of Mining Engineering & Technology","Satyasai Engineering College","Pavitramohan Institute of Technology, Talchar","Jhadeswar Institute of Engineering & Technology","RajaKishore Chandra Academy of Technology","Vivekananda Institute of Technology","Balasore College of Engineering","Rourkela Institute of Technology","Rourkela Institute of Management Studies","Dr. Ambedkar Memorial Institute of Information Technology & Management",
				"Veer Surendra Sai University of Technology","Koenjhar school of Engineering","Pondicherry Engineering College","Rayat Institute of Engineering and Information Technology ","Guru Teg Bahadur Khalsa Institute of Engineering & Technology","shiv shankar institute of engineering & technology","Bhai Gurdas Institute of EngineeringTechnology","Gian Jyoti Group of Institutions","Swami Vivekanand Institute of Engineering & Technology ","Aryans College of Engineering","Surya School of Engineering & Technology","RIMT-Maharaja Agrasen Engineering College","Continental Institute of Engineering & Technology","RIMT Institute of Engineering Technology","Baba Banta Singh Bahadur Engineering College","Desh Bhagat Engineering College","Ghubaya College of Engineering & Technology","Sri Sukhmani Institute of Engineering & Technology","Swami Parmanand Engineering College","GGS College of Modern Technology","Universal Institute of Enginering & Technology","Punjab College Of Engineering & Technology","Chandigarh Engineering College","Chandigarh Group of Colleges","Punjab College of Engineering & Applied Research","Aryabhatta Group of Institutes, Barnala","Paras Institute of Information Technology & Management Studies","S. Sukhbinder singh Engineering & Technology","National Institute of Technology, Sikkim","Bhagwant University","Laxmi Devi Institute of Engineering & Technology,Chikani","Institute of Engineering & Technology, Alwar","Government Engineering College,Bharatpur","MLV Textile & Engineering College, Bilwara","Marudhar Engineering College","Faculty of Engineering & Department of Life Science","Kautilya Institute of Technology and Engineering","Manipal University Jaipur","MJRP University , Jaipur","Global Institute of Technology","Apex Institute of Management & Science","BMIT,Jaipur","Amity University.","Jaipur Institute of Technology (group of Institution)","Regional Institute of Polytechnic Studies","Jaipur National University","Poornima College Of Engineering","Dr Radhakrishnan Polytechnic College","Poornima University","Compucom Institute of Information Technology & Management, Jaipur","Jagannath University","Vivekananda Institute of Technology","Jagannath Gupta Institute of Engineering & Technology","APEX Institute of Engineering & Technology, Jaipur","MJRP College Of Engineering & Technology","Jaipur college of engineering,kukas","Arya College of Engg. & IT","Guru Nanak Dev Engineering College, Ludhiana","Lala Lajpat Rai Institute of Engineering & Technology","Pratap University","Govt. College of Engineering and Technology","Siddharth Institute of Technology","Universal Technical College","Swami Keshwanand Institute Of Technology","University of Engineering and management, Jaipur","Suresh Gyam Vihar University","Maharani Girls Engineering College","Maharishi Arvind Institute of Engineering & Technology","Rajeshthan Institute of Engineering & Technology","Dr. RadhaKrishnan Institute of Technology","Jaipur Institute of Engineering & Technology","Rajsthan college of Engineering for womens","Jayoti  Vidhyapeeth Women's University, Jaipur","Government Engineering College","Shridhar University Pilani","Jodhpur Engineering College & Research Centre","Jodhpur National University","Raj Engineering College","Mayurakshi Institute of Engineering and Technology","University College of Engineering","Nathdwara Institute of engineering and Technology","Dr. K. N. Modi University, Tonk","S S College of Engineering, Udaipur","College of Technology and Engineering","Indian Institute of Management,Udaipur","SRM University Chennai","Bharath University Selaiyur","DR. M G R Educational And Research Institute University","Dhanalakshmi College of Engineering","Hindustaan Institute of Technology & science, Chennai",
				"Dr MGR University","Arya Institute of Engineering & Technology, Kukas","Agni college of technology","Bharath Institute of Science and Technology","Karunya University","Annamalai University","SRM Institute of  Science and Technology","Hindustan Institute of Technology & Science","P.B. College of Engineering","Bharath University","Aarupadai Veedu Institute of Technology","Dhanlakshmi Srinivasan College of Engg. & Tech","Hindustan University","Archana Institute of Technology, Thimmapuram","Madurai Kamaraj University","Dhanlakshmi Srinivasan Engg. College","Sastra University","Shivani Engineering College ","GRT Institute of Engineering and Technology","Sri Nandhanam College of Engineering & Technology","VIT University","National Institute of Technology, Agartala","zakir hussain college of engg & technology","University of Allahabad","Sam Higginbotom Institute if Agriculture, Technology & Science","Jahangirabad Institute of Technology (JIT)","Future Institute of Engineering & Technology","Invertis Institute of Engineering & Technology","Allahabad College of Engineering & Management","GNIT Girls Institute of Technology","Om Sai  Institute of Technology & Science","Swaraj Institute of Management & Technology","Shri Krishna College of Engineering","Sarvottam Instititute of Technology & Management","IIMT College of Engineering, Greater Noida","Galgotias University","Institute ift Management Studies, Noida","IEC College of Engineering And Technology","Sharda University","I.T.S Engineering College","Galgotia College of Engineering and Technology","Skyline Institute of Engineering & Technology","Amity University","IIMT College of Management","Noida International University","KCC Institute of Technology & Management","Aryan Institute of Technology","SRM University( NCR Campus), Modinagar","K S Jain Institute of Engineering & Technology","Maharaja Agrasen Institute of Technology ","R. D. Engineering College (RDEC), Ghaziabad","Kedar Nath Ginni Devi Modi Engineering College","D. J. College of Engineering & Technology","HR Group of Institute Ghaziabad","Acme College of Engineering","Monad University","Institute of Technology and Science","Devendra Singh Institute Of Technology and Management","Institute of Professional Excellence & Management","Divya Jyoti College of Engineering & Technology","Sri Ganpati Institute of Technology","Vedant Institute of Management & Technology","vivekanand institute of technology & science","Hi-Tech Institute of Engineering & Technology","ABES Engineering College","V B S Purvanchal University","Bundelkhand University","Maharaja Agrasen College of EngineeringTechnology","D.N.S. College of Engineering & Technology","Indraprastha Institute of Technology","Pranveer Singh Academy of Technology","IIT, Kanpur","Pranveer Singh Institute of Technology","Naraina Vidyapeeth Engineering & Management","Krishna Institute of Technology","Chandra Sekhar Azad University of Agriculture & Technology","AXIS Institute of Technology and Management","Maharana Pratap Engineering College","Amity University ","Babu Banarasi Das Institute of Engineering Technology & Research Center",
				"Indian Institute of Management, Lucknow","Dr M. C. Saxena College of Engineering & Technology","Sanskriti Institute of ManagementTechnology","Tirthankar Mahabir University, College of Engineering, Bagarpur","IIS University","Apex Technology","Ramswaroop Lucknow","Shivalik College of Engineering Dehradun","Invertis HOD","NIU HOD","IIIT Pune Director","AISSM College","Univ. of Pune","LBS Lucknow","Rohilkhand Univ","Galgotia University","Synergy Institute of Engineering & Technology","CMR institute","Cambridge University","Gopalan College of Engineering and Management","Rashtriya Sanskrit Vidyapeeth,","Indian Institute of Science,","Christ College, Hosur Road, Bangalore","BLDE University, Bangaramma Sajjan Campus,","Patel Institute Of Technology","Globus Engineering College","Bansal Institute of Research & Technology","Lakshmibai National University of Physical Education","Shree ram institute of Technology,jabalpur","Gandhi Engineering College","Millennium Institute of Technology","Ludhiana Group of Colleges","Mandava Institute of Engineering and Technology","Vijay Krishna College of Nursing","Krishna Institute of Technology & Management","SVS Group of Institution","Rajasthan Institute of Engineering & Technology","Camellia Institute of Technology & Management","Bhagath College of Diploma in ENGG & TECH.-303","Institute of Professional Education and Research","Sanghvi Institute of Management & Science","Ellenki Institute of Engineering & Technology","Amity University","Mansarovar Institute of Science & Technology","M. S. Ramaiah Management Institute","Indore Institute of Science & Technology, Indore","Lucknow Institute Of Technology","Banaras Hindu University","Bhopal Institute of Technology, Bhopal","Vaishnavi Institute of Technology & Science, Medua","Modi Institute of Technology","Apeejay Institute of Architecture and Planning","Yug Chetna Mahavidyalaya, Bharuwa","KCC Institute","NIU, Noida","Jaypee Institute, Noida","Symbiosis college","Darshan Institute","IIIT Pune","IEC,","A P S College of Engineering","A.M.C. Engineering College","Acharya Institute of Technology","ACS College of Engineering","Adasha Institute of Technology","Alpha College of Engineering","Amrita School of Engineering","Atria Institute of Technology","B.M.S.College of Engineering","Banglore College of Engineering & Technology","Banglore Institute of Technology","Banglore Technological Institute","Basava Academy of Engineering","BNM Institute of Technology","Brindavan College of Engineering","BTL Institute of Technology and Management","Cambridge Institute of Technology","City Engineering College","CMR Institute of Technology","Dayananda Sagar Academy of Technology & Management Technical Campus","Dayananda Sagar College of Engineering","Don Bosco Institute of Technology","DR. Ambedkar Institute of Technology","East Point College of Engineering For Women","East West Institute of Technology","Global Academy of Technology","Gopalan College of Engineering and Management","Government S. K. S. J. T. Institute","GSS Institute of Technology","Hkbk College of Engineering","Impact College of Engineering and Applied Science","Islamiah Institute of Technology, Banglore","JSS Academy of Technical Education","Jyothi Institute of Technology","K.N.S. Institute of Technology, Banglore-64","K.S. School of Engineering and Management","K.S.Institute of Technology","M S Engineering College","M. S. Ramaiah Institute of Technology","MVJ College of Engineering","Nadgir Institute of Engineering and Technology","Nandi Institute of Technology and Management Science","New Horizon College of Engineering (E&T)","Nitte Meenakshi Institute of Technology","PNS Institute of Technology","R. R. Institute of Technology","Rajarajeshwari College of Engineering","Rajiv Gandhi Institute of Technology",
				"Reva Institute of Technology and Management","RNS Institute of Technology","S. E. A. College of Engineering & Technology","Sai Vidya Institute of Technology","Sambharam Institute of Technology","Sapathgiri College of Engineering","SCT Institute of Technology","Shirdi Sai Engineering College","Sir M.Visvesharay Institute of Technology","SJB Institute of Technology","Sri Belimatha Mahasmtana Institute of Technology","Sri Krishna Institute of Technology","Sri Krishna School of Engineering & Management","Sri Revana Siddheshwar Institute of Technology","Sri Vidhya Vinayak Institute of Technology","T John Institute of Technology","The Oxford College of Engineering","University Visvesvaraya College of Engineering","Vemana Institute of Technology","Vijaya Vittala Institute of Technology","Vivekananda Institute of Technology","Yellamma Dasappa Institute of Technology","Rashtriya Sanskrit Vidyapeeth,","Sri Sathya Sai Institute of Higher Learning","International Institute of Information Technology,","Gandhi Institute of Technology and Management","North Eastern Regional Institute of Science and technology","Bihar Yoga Bharati,","Nava Nalanda Mahavihara,","Punjab Engineering College","Gujarat Vidyapith, PO Navjivan,","Sumandeep Vidyapeeth,","National Dairy Research Institute,","National Brain Research Centre","Maharishi Markandeshwar University","Birla Institute of Technology,","Indian School of Mines","Indian Institute of Science,","Manipal Academy of Higher Education,","National Institute of Mental Health and Neuro","International Institute of Information Technology","Yenepoya University","BLDE University,","Jagadguru Sri Shivarathreeswara University","Kerala Kalamandalam,","Bharati Vidyapeeth,","Homi Bhabha National Institute","Kalinga Institute of Industrial Technology,","Thapar Institute of Engineering & Technology,","Birla Institute of Technology & Science,","The LNM Institute of information Technology,","Shanmugha Arts, Science, Technology","Vellore Institute of Technology,","SRM Institute of Science & Technology","Karunya Institute of Science and Technology","Ponnaiyah Ramajayam Institute of Science & technology","Indian Institute of Information Technology","Allahabad Agricultural Institute,","Jaypee Institute of Information Technology,","Shobhit Institute of Engineering","Santosh University","Manav Rachna International University"
				,"B.S.Abdur Rahman Institute of Science","Jain University","Graphic Era University","IIS University").collect(Collectors.toSet());
		
		colleges.addAll(educationRepository.findAllInstituteName());

		return colleges;
	}

	@Autowired
	UserProfileOtherDetailsRepository userProfileOtherDetailsRepository;

    public ResponseEntity<String> saveOtherDetailsv2(
            UserProfileOtherDetailsv2 requestPayload, InternityUser user) {
		try{
			UserProfileOtherDetailsv2 savedObj = userProfileOtherDetailsRepository.save(requestPayload);
			return new ResponseEntity<>(savedObj.toString(), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while saving other details ::: {}", e);
			return new ResponseEntity<>("{\"Error\":\"Unable to save details\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<String> updateOtherDetailsv2(
			UserProfileOtherDetailsv2 requestPayload, InternityUser user) {
		try{
			UserProfileOtherDetailsv2 savedObj = userProfileOtherDetailsRepository.save(requestPayload);
			return new ResponseEntity<>(savedObj.toString(), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while update other details ::: {}", e);
			return new ResponseEntity<>("{\"Error\":\"Unable to delete details\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<String> deleteOtherDetailsv2(Long sectionId, InternityUser user) {
		try{
			userProfileOtherDetailsRepository.deleteById(sectionId);
			JSONObject res = new JSONObject();
			res.put("msg","Deleted Successfully");
			return new ResponseEntity<>(res.toString(), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while delete other details ::: {}", e);
			return new ResponseEntity<>("{\"Error\":\"Unable to delete details\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
		public ResponseEntity<String> saveOtherDetails(UserOtherDetails requestPayload, String section, InternityUser user) {
    	try {
			if(null != requestPayload.getUId()) {
				Optional<UserOtherDetails> userOtherDetailsObj = userOtherDetailsRepository.findByuId(requestPayload.getUId());
				if (userOtherDetailsObj.isPresent()) {
					log.info("...{}",userOtherDetailsObj.get());
					UserOtherDetails otherDetails = userOtherDetailsObj.get();
					switch (section) {
						case "certificate":
							String certificateDetails = otherDetails.getCertification();
							JSONArray certificateList = new JSONArray(certificateDetails);
							JSONObject certificateFromObj = new JSONObject(requestPayload.getCertification());
							certificateList.put(certificateFromObj);
							otherDetails.setCertification(certificateList.toString());
							break;
						case "whitepaper":
							otherDetails.setWhitePaper(requestPayload.getWhitePaper());
							break;
						case "patent":
							otherDetails.setPatent(requestPayload.getPatent());
							break;
						case "worktohighlight":
							otherDetails.setWorkToHighlight(requestPayload.getWorkToHighlight());
							break;
						case "extracurricular":
							otherDetails.setExtraCurricular(requestPayload.getExtraCurricular());
							break;
						default:
							break;
					}
					log.info("other details {}",otherDetails);
					this.saveOtherdetailsSection(otherDetails);
				}
				else{
					log.info("in first else {}", requestPayload);
					saveOtherdetailsSection(requestPayload);
				}
			}
			else {
				log.info("in second else {}", requestPayload);
				saveOtherdetailsSection(requestPayload);
			}
			return new ResponseEntity<>("{\"msg\":\"Other details"+section+" saved successfully\"}", HttpStatus.OK);
		}
		catch (Exception e){
			log.error("exception {}",e);
			return new ResponseEntity<>("{\"Error\":\"Unable to save "+section+" section\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private boolean saveOtherdetailsSection(UserOtherDetails requestPayload){
		try {
			log.info("\n\n {}", requestPayload);
			 userOtherDetailsRepository.save(requestPayload);
			 return true;
		}
		catch (Exception e){
			log.error("exception {}",e);
			return false;
		}
	}

	public ResponseEntity<?> fetchOtherDetailsv2(UserProfileOtherDetailsType sectionType, String uId, InternityUser user) {
		try{
			List<UserProfileOtherDetailsv2> userProfileOtherDetailsv2List = userProfileOtherDetailsRepository
					.findByuIdAndOtherDetailsType(uId, sectionType);
			JSONArray res = new JSONArray();
			for(UserProfileOtherDetailsv2 userProfileOtherDetailsv2 : userProfileOtherDetailsv2List){
				res.put(new JSONObject(userProfileOtherDetailsv2));
			}
			return new ResponseEntity<>(res.toString(), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while fetching other details section {} with {}", sectionType, e);
		}
		JSONObject err = new JSONObject();
		err.put("ERROR", "Failed to fetch the certificate");
		return new ResponseEntity<>(err.toString(), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public ResponseEntity<?> fetchOtherDetails(String section, String uId, InternityUser user) {
		String response = "Unable to find section " + section;
		try{
			Optional<UserOtherDetails> otherDetailsObj = userOtherDetailsRepository.findByuId(uId);
			if(otherDetailsObj.isPresent()) {
				UserOtherDetails otherDetails = otherDetailsObj.get();
				switch (section) {
					case "certificate": response = otherDetails.getCertification();
					break;
					case "whitepaper": response = otherDetails.getWhitePaper();
					break;
					case "patent": response = otherDetails.getPatent();
					break;
					case "worktohighlight": response = otherDetails.getWorkToHighlight();
					break;
					case "extracurricular": response = otherDetails.getExtraCurricular();
					break;
					default:
						break;
				}
				if(response.startsWith("Unable")) {
					return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
				}else{
					return new ResponseEntity<>(response, HttpStatus.OK);
				}
			}
		}
		catch (Exception e){
			log.error("Exception while fetching other details section {} with {}", section, e);
		}
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}

    public ResponseEntity<?> findCompletePercentage(String uId, InternityUser user) {
		try {
			int percent = 0;
			Optional<UserPersonalDetail> personalDetailObj = userProfileRepository.findByuId(uId);
			if (personalDetailObj.isPresent()) {
				UserPersonalDetail personalDetail = personalDetailObj.get();
				if (!StringUtils.isEmpty(personalDetail.getResumeLink())) {
					log.info("resume");
					percent = percent + 50;
				}
				if (!StringUtils.isEmpty(personalDetail.getGovtIdLink())) {
					log.info("govt");
					percent = percent + 10;
				}
				if (!StringUtils.isEmpty(personalDetail.getProfilePicLink())) {
					log.info("profilepic");
					percent = percent + 5;
				}
				if (!skillRepository.findByuId(uId).isEmpty()) {
					log.info("skill");
					percent = percent + 10;
				}
				if (!workRepository.findByuId(uId).isEmpty()) {
					log.info("work");
					percent = percent + 7;
				}
				if (userOtherDetailsRepository.findByuId(uId).isPresent() || userProfileOtherDetailsRepository.findByuId(uId).size()>1) {
					log.info("other detail");
					percent = percent + 5;
				}
				if (!educationRepository.findByuId(uId).isEmpty()) {
					log.info("education");
					percent = percent + 6;
				}
				if (!projectRepository.findByuId(uId).isEmpty()) {
					log.info("project");
					percent = percent + 7;
				}
			}
			return new ResponseEntity<>(percent, HttpStatus.OK);
		}
		catch(Exception ex){
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<?> findByUidAndResumeLinkIsNull(String uId, InternityUser user) {
		try {
			Optional<UserPersonalDetail> userObj = userProfileRepository.findByuIdAndResumeLinkIsNotNull(uId);
			return new ResponseEntity<>(userObj.isPresent(), HttpStatus.OK);
		}
		catch (Exception e){
			return new ResponseEntity<>(false, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<?> saveUploadLink(String uId, UserUploadLink userUploadLink, InternityUser user) {
		try {
			Optional<UserPersonalDetail> personalDetailObj = userProfileRepository.findByuId(uId);
			if (personalDetailObj.isPresent()) {
				UserPersonalDetail personalDetail = personalDetailObj.get();
				String linkType = userUploadLink.getLinkType();
				if (null != linkType && linkType.equalsIgnoreCase("resume")) {
					personalDetail.setResumeLink(userUploadLink.getLink());
				} else if (null != linkType && linkType.equalsIgnoreCase("pan")) {
					personalDetail.setGovtIdLink(userUploadLink.getLink());
				}
				userProfileRepository.save(personalDetail);
			}
			return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "Uploaded successfully"), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while saving upload link {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save link"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    public void saveSkill(UserSkill requestPayload) {
		skillRepository.save(requestPayload);
		try {
			Optional<SkillsLookup> skillsLookup = skillsLLookupRepository.findBySkillName(requestPayload.getSkillName());
			if (!skillsLookup.isPresent()) {
				log.info("Skill is not present in the lookup table, hence saving");
				SkillsLookup skillsLookupObj = new SkillsLookup();
				skillsLookupObj.setSkillName(requestPayload.getSkillName());
				skillsLookupObj.setSkillTags(requestPayload.getSkillName());
				skillsLookupObj.setCreatedts(new Date());
				skillsLookupObj.setCreatedby(requestPayload.getUId());
				skillsLLookupRepository.save(skillsLookupObj);
			}
		}
		catch(Exception e){
			log.error("Exception while saving skill in Skill lookup table {}", e);
		}
    }
}
