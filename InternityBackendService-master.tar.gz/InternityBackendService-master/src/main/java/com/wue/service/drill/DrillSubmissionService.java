package com.wue.service.drill;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.constant.drill.DrillSubmissionFieldType;
import com.wue.constant.drill.DrillWinnerType;
import com.wue.constant.submission.SubmissionResult;
import com.wue.domain.drill.*;
import com.wue.domain.drill.judgement.DrillAssignPanel;
import com.wue.domain.drill.judgement.DrillJudgementPanel;
import com.wue.domain.drill.mails.DrillMailTemplate;
import com.wue.domain.drill.submission.ConfigureSubmissionFields;
import com.wue.domain.drill.submission.DefaultSubmissionFields;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.domain.drill.submission.DrillSubmissionEvaluation;
import com.wue.dto.drill.DrillSubmissionsForShortlistResponseDto;
import com.wue.dto.drill.UserSubmissionDto;
import com.wue.dto.drill.UserSubmissionResultDto;
import com.wue.dto.drill.judgement.DrillSubmissionJudgementEvaluationDto;
import com.wue.dto.drill.judgement.FinalEvaluationDto;
import com.wue.dto.drill.submission.DrillParticipantSubmissionDto;
import com.wue.dto.drill.submission.DrillSubmissionEvaluationDto;
import com.wue.dto.drill.submission.search.DrillSubmissionSearchCriteria;
import com.wue.dto.drill.submission.search.DrillSubmissionSearchResultDto;
import com.wue.dto.drill.submission.search.DrillSubmissionSpecification;
import com.wue.dto.response.Response;
import com.wue.model.EmailContent;
import com.wue.repository.UserRepository;
import com.wue.repository.drill.*;
import com.wue.repository.drill.judgement.DrillAssignJudgePanelRepository;
import com.wue.repository.drill.judgement.DrillJudgementPanelRepository;
import com.wue.repository.drill.mails.DrillMailTemplateRepository;
import com.wue.repository.drill.submission.DrillConfigureSubmissionFieldsRepository;
import com.wue.repository.drill.submission.DrillDefaultSubmissionFieldsRepository;
import com.wue.repository.drill.submission.DrillParticipantSubmissionRepository;
import com.wue.repository.drill.submission.DrillSubmissionEvaluationRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.OffsetBasedPageRequest;
import com.wue.util.SendMessageUtils;
import com.wue.util.drill.DrillValidationUtils;
import com.wue.util.drill.SendCustomMailUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;
import org.apache.commons.validator.routines.UrlValidator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;


@Service
@Log4j2
public class DrillSubmissionService {
    @Autowired
    DrillRepository drillRepository;

    @Autowired
    DrillParticipantSubmissionRepository drillParticipantSubmissionRepository;

    @Autowired
    DrillConfigureSubmissionFieldsRepository drillConfigureSubmissionFieldsRepository;

    @Autowired
    DrillDefaultSubmissionFieldsRepository drillDefaultSubmissionFieldsRepository;

    @Autowired
    DrillCollaboratorsRepository drillCollaboratorsRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    DrillTeamsRepository drillTeamsRepository;

    @Autowired
    SendMessageUtils messageUtils;

    @Autowired
    DrillSubmissionEvaluationRepository drillSubmissionEvaluationRepository;

    @Autowired
    SendCustomMailUtils sendCustomMailUtils;

    @Autowired
    DrillMailTemplateRepository drillMailTemplateRepository;

    @Autowired
    DrillAssignJudgePanelRepository drillAssignJudgeRepository;

    @Autowired
    DrillPhasesRepository drillPhasesRepository;

    @Value("${domain.url:http://api-dev.wuelev8.tech:8080}")
    String domainUrl;
    @Autowired
    CommonUtils commonUtils;
    @Autowired
    DrillJudgementPanelRepository drillJudgementPanelRepository;
    @Autowired
    DrillParticipantRepository drillParticipantRepository;
    @Autowired
    TeamsParticipantsRepository teamsParticipantsRepository;
    @Autowired
    DrillLeaderboardRepository drillLeaderboardRepository;
    @Autowired
    DrillLeaderboardService drillLeaderboardService;
    @Autowired
    DrillJudgingCriteriaRepository drillJudgingCriteriaRepository;
    @Autowired
    DrillValidationUtils drillValidationUtils;
    @Value("#{'${drill.participanttype.list}'.split(',')}:Participant,Shortlisted,Fighters,Winners")
    private List<String> participantList;

    public Object saveDrillSubmission(DrillParticipantSubmission payload, InternityUser user) {
        try {
            // Check if the Hackathon ID is blank
            if (org.apache.commons.lang3.StringUtils.isAnyBlank(payload.getDrillId())) {
                log.warn("Hackathon ID is blank");
                return commonUtils.message(HttpStatus.BAD_REQUEST, "Hackathon ID cannot be empty");
            }

            // Check if the Participant ID is blank
            if (org.apache.commons.lang3.StringUtils.isAnyBlank(payload.getParticipantId())) {
                log.info("Participant ID is blank");
                return commonUtils.message(HttpStatus.BAD_REQUEST, "Participant ID cannot be empty");
            }

            // Retrieve the Hackathon by ID
            Optional<Drill> optionalDrill = drillRepository.findById(payload.getDrillId());
            if (!optionalDrill.isPresent()) {
                log.warn("Hackathon not found for specified ID: {}", payload.getDrillId());
                return commonUtils.message(HttpStatus.NOT_FOUND, "Hackathon not found for this specified ID");
            }

            // Retrieve the Drill Participant by ID
            Optional<DrillParticipant> optionalDrillParticipant = drillParticipantRepository.findById(payload.getParticipantId());
            if (!optionalDrillParticipant.isPresent()) {
                log.info("Drill Participant not found for specified ID: {}", payload.getParticipantId());
                return commonUtils.message(HttpStatus.NOT_FOUND, "Drill Participant not found for this specified ID");
            }


            // Check if the drill is paid
            if (optionalDrill.isPresent() && optionalDrill.get().getIsDrillPaid()) {
                log.info("Drill is paid. Checking participant payment status...");

                // Check participant payment status
                Response paymentStatusResponse = drillValidationUtils.checkIfParticipantPaymentReceived(optionalDrillParticipant.get());

                // If the payment status response is not successful, return the response
                if (paymentStatusResponse.getHttpStatus() != HttpStatus.OK.value()) {
                    log.info("Participant payment status check failed. Returning response.");
                    return paymentStatusResponse;
                }
            }


            Drill drill = optionalDrill.get();

            // Add a check for submission allow or not
            Optional<DrillPhases> drillPhaseObj = drillPhasesRepository.findByDrillIdAndPhaseId(payload.getDrillId(), payload.getPhaseId());

            if (!drillPhaseObj.isPresent()) {
                log.error("Error occurred while checking the phase for this solution");
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                        "An error occurred while checking the phase for this solution. Please refresh the page and try again.");
            }

            DrillPhases currPhase = drillPhaseObj.get();
            int currPhasePosition = currPhase.getPhasePosition();

            if (currPhasePosition == 1) {
                if (currPhase.isSubmissionAllowed()) {
                    return saveSubmission(payload, drill, user);
                } else {
                    log.warn("Submission for Phase 1 is not allowed yet");
                    return commonUtils.message(HttpStatus.BAD_REQUEST, "Submission for This Phase is Not Allowed Yet");
                }
            } else {
                DrillPhases lastPhase = drillPhasesRepository.findByDrillIdAndPhasePosition(payload.getDrillId(), currPhasePosition - 1);

                if (lastPhase == null) {
                    log.error("Error occurred while checking the last phase for this solution");
                    return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                            "An error occurred while checking the last phase for this solution. Please refresh the page and try again.");
                }

                if (lastPhase.isSubmissionAllowed()) {
                    if (currPhase.isSubmissionAllowed()) {
                        DrillParticipantSubmission submission;
                        if (payload.getTeamId() != null) {
                            submission = drillParticipantSubmissionRepository.findByTeamIdAndPhaseIdAndIsActiveSubmission(payload.getTeamId(), lastPhase.getPhaseId(), true);
                        } else {
                            submission = drillParticipantSubmissionRepository.findByParticipantIdAndPhaseIdAndIsActiveSubmission(payload.getParticipantId(), lastPhase.getPhaseId(), true);
                        }

                        if (submission != null && submission.getSubmissionResult().equals(SubmissionResult.SHORTLISTED)) {
                            return saveSubmission(payload, drill, user);
                        } else if (submission != null && submission.getSubmissionResult().equals(SubmissionResult.REJECTED)) {
                            log.warn("Submission cannot be Submitted as you are Rejected in the Last Phase");
                            return commonUtils.message(HttpStatus.BAD_REQUEST, "Submission cannot be Submitted as you are Rejected in the Last Phase");
                        } else if (submission != null && submission.getSubmissionResult().equals(SubmissionResult.PENDING)) {
                            log.warn("Submission cannot be Submitted as your Result is Pending For the Last Phase");
                            return commonUtils.message(HttpStatus.BAD_REQUEST, "Submission cannot be Submitted as your Result is Pending For the Last Phase");
                        } else if (submission == null) {
                            log.warn("Submission cannot be Submitted Please submit your submission for Previous Phase");
                            return commonUtils.message(HttpStatus.BAD_REQUEST, "Submission cannot be Submitted Please submit your submission for Previous Phase");
                        }
                    } else {
                        log.warn("Submission for This Phase is Not Allowed Yet");
                        return commonUtils.message(HttpStatus.BAD_REQUEST, "Submission for This Phase is Not Allowed Yet");
                    }
                } else {
                    log.warn("Submission for This Hackathon is Not Allowed yet");
                    return commonUtils.message(HttpStatus.BAD_REQUEST, "Submission for This Hackathon is Not Allowed yet");
                }
            }
            log.error("Something went wrong during submission");
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong during submission");
        } catch (Exception e) {
            log.error("Exception while saving drill submission", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong please try again later");
        }
    }

    private boolean isTeamBasedDrill(Drill drill) {
        // Retrieve the team size information from the drill
        JSONObject teamSizeObj = new JSONObject(drill.getDrillTeamSize());

        // Check if the drill requires team formation
        if (teamSizeObj.has("max")) {
            int maxSize = teamSizeObj.getInt("max");
            return maxSize > 1;
        }

        return false;
    }

    public Object saveDrillIdeaSubmission(DrillParticipantSubmission payload, InternityUser user) {
        try {
            if (org.apache.commons.lang3.StringUtils.isAnyBlank(payload.getDrillId())) {
                log.warn("Hackathon Id is blank");
                return commonUtils.message(HttpStatus.BAD_REQUEST, "Hackathon Id cannot be empty");
            }

            Optional<Drill> optionalDrill = drillRepository.findById(payload.getDrillId());
            if (!optionalDrill.isPresent()) {
                log.warn("Hackathon not found for specified Id: {}", payload.getDrillId());
                return commonUtils.message(HttpStatus.NOT_FOUND, "Hackathon not found for this specified Id");
            }

            Drill drill = optionalDrill.get();

            payload.setActiveSubmission(true);

            if (isTeamBasedDrill(drill)) {
                String teamId = checkIfTeamIdIsNeededAndAvailable(payload.getDrillId(), payload.getParticipantId(), payload.getTeamId());
                if (org.apache.commons.lang3.StringUtils.isBlank(teamId) || teamId.equals("NA")) {
                    log.warn("Participant is not part of any team");
                    return commonUtils.message(HttpStatus.BAD_REQUEST, "You are currently not a part of any team. Please join a team to submit a solution");
                }
                payload.setTeamId(teamId);
            } else {
                payload.setTeamId(null);
            }

            JSONObject presentationJson = new JSONObject(payload.getPresentation());

            ObjectMapper objectMapper = new ObjectMapper();
            if (checkIfLinkIsPresent(presentationJson) && !org.apache.commons.lang3.StringUtils.isBlank(presentationJson.getString("link"))) {
                log.info("Presentation link is present");
            } else {
                log.error("Presentation link is missing");
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Presentation is needed. Please upload your presentation in ppt or pdf format");
            }

            deactivateAllOtherSubmissionOfThisTeam(payload.getDrillId(), payload.getParticipantId(), payload.getTeamId(), payload.getPhaseId());

            if (!org.apache.commons.lang3.StringUtils.isBlank(payload.getSendMail())) {
                if (payload.getSendMail().equalsIgnoreCase("true")) {
                    log.info("Sending mail to idea submission");
                    sendMailToIdeaSubmission(payload.getParticipantId(), payload.getDrillId());
                }
            }

            return drillParticipantSubmissionRepository.save(payload);
        } catch (Exception e) {
            log.error("Exception while saving the submission", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save the submission");
        }
    }


    private Object saveSubmission(DrillParticipantSubmission payload, Drill drill, InternityUser user) {
        try {
            log.info("Starting saveSubmission method");

            payload.setActiveSubmission(true);

            if (isTeamBasedDrill(drill)) {
                String teamId = checkIfTeamIdIsNeededAndAvailable(drill.getDrillId(), payload.getParticipantId(), payload.getTeamId());
                if (org.apache.commons.lang3.StringUtils.isBlank(teamId) || teamId.equals("NA")) {
                    log.warn("Participant is not part of any team");
                    return commonUtils.message(HttpStatus.BAD_REQUEST, "You are currently not a part of any team. Please join a team to submit a solution");
                }
                payload.setTeamId(teamId);
            } else {
                payload.setTeamId(null);
            }

            JSONObject sourceCodeJson = new JSONObject(payload.getSourceCode());
            JSONObject presentationJson = new JSONObject(payload.getPresentation());
            JSONObject videoCodeJson = new JSONObject(payload.getVideo());

            ObjectMapper objectMapper = new ObjectMapper();
            Object drillSubmissionDefaultFields = fetchDrillSubmissionFields(payload.getDrillId(), "NA", user);
            ConfigureSubmissionFields submissionFields = objectMapper.convertValue(drillSubmissionDefaultFields, ConfigureSubmissionFields.class);

            JSONArray arrayOfFields = new JSONArray(submissionFields.getFields());

            UrlValidator urlValidator = new UrlValidator(null);
            for (int i = 0; i < arrayOfFields.length(); i++) {
                JSONObject fieldJson = (JSONObject) arrayOfFields.get(i);
                if (fieldJson.getString("fieldId").toUpperCase().equals(DrillSubmissionFieldType.CODE_SOLUTION.name())) {
                    if (!fieldJson.isNull("required") && fieldJson.getBoolean("required")) {
                        if (checkIfLinkIsPresent(sourceCodeJson) && (!org.apache.commons.lang3.StringUtils.isBlank(sourceCodeJson.getString("link"))
                                || (!org.apache.commons.lang3.StringUtils.isBlank(sourceCodeJson.getString("repoLink")) &&
                                urlValidator.isValid(sourceCodeJson.getString("repoLink"))))) {
                            continue;
                        } else {
                            log.error("Code solution is missing");
                            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                                    "Code solution is needed. Please upload your zip file for code or paste a valid URL in your repo link");
                        }
                    }
                }
                // Similar checks for VIDEO_SOLUTION and PRESENTATION fields
            }

            deactivateAllOtherSubmissionOfThisTeam(payload.getDrillId(), payload.getParticipantId(), payload.getTeamId(), payload.getPhaseId());

            if (!org.apache.commons.lang3.StringUtils.isBlank(payload.getSendMail())) {
                if (payload.getSendMail().equalsIgnoreCase("true")) {
                    log.info("Sending mail to idea submission");
                    sendMailToIdeaSubmission(payload.getParticipantId(), payload.getDrillId());
                }
            }

            payload.setSubmissionResult(SubmissionResult.PENDING);
            return drillParticipantSubmissionRepository.save(payload);
        } catch (Exception e) {
            log.error("Exception while saving the submission", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save the submission");
        }
    }


    private boolean checkIfLinkIsPresent(JSONObject submissionFormFields) {
        return !submissionFormFields.isNull("link");
    }

    private String checkIfTeamIdIsNeededAndAvailable(String drillId, String participantId, String teamId) {
        if (!org.apache.commons.lang3.StringUtils.isBlank(teamId) && !teamId.equals("NA")) {
            return teamId;
        }

        Optional<TeamsParticipants> participant = teamsParticipantsRepository
                .findByParticipantIdAndIsRequestAccepted(participantId, true);
        return participant.map(TeamsParticipants::getTeamId).orElse(null);

    }

    private void sendMailToIdeaSubmission(String participantId, String drillId) {
        try {
            Optional<DrillParticipant> drillParticipantObj = drillParticipantRepository.findById(participantId);
            String fullName = "";
            String email = "";
            String drillName = "";
            if (drillParticipantObj.isPresent()) {
                DrillParticipant drillParticipant = drillParticipantObj.get();
                fullName = drillParticipant.getFullName();
                email = drillParticipant.getEmail();
                drillName = drillRepository.findById(drillId).get().getDrillName();
            }
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject(
                    String.format(drillName + " | Submission received successfully"));
            emailContent.setTemplateName("SubmissionMail");
            emailContent.setUserName(fullName);
            // emailContent.setBcc("avanish@wuelev8.tech");
            emailContent.setMessage("We have received your submission for " + drillName + ". If you are participating with a team" +
                    ", please make sure to keep them updated. We will consider the latest submission for evaluation.");
            messageUtils.sendMail(email, emailContent);
        } catch (Exception exception) {
            log.error("Exception while sending email {}", exception);
        }
    }

    private void deactivateAllOtherSubmissionOfThisTeam(String drillId, String participantId, String teamId, String phaseId) {
        try {
            if (StringUtils.isEmpty(teamId)) {
                List<DrillParticipantSubmission> listOfSubmissionByParticipant = drillParticipantSubmissionRepository
                        .findByDrillIdAndParticipantIdAndPhaseIdOrderByUpdatedTsDesc(drillId, participantId, phaseId);
                for (DrillParticipantSubmission submission : listOfSubmissionByParticipant) {
                    submission.setActiveSubmission(false);
                    drillParticipantSubmissionRepository.saveAndFlush(submission);
                }
            } else {
                List<DrillParticipantSubmission> listOfSubmission =
                        drillParticipantSubmissionRepository.findByDrillIdAndTeamIdAndPhaseId(
                                drillId, teamId, phaseId);
                for (DrillParticipantSubmission submission : listOfSubmission) {
                    submission.setActiveSubmission(false);
                    drillParticipantSubmissionRepository.saveAndFlush(submission);
                }
            }
        } catch (Exception e) {
            log.error("Exception while deactivating the submissions {}", e);
        }
    }

    public DrillSubmissionSearchResultDto searchDrillSubmissionsv2(
            DrillSubmissionSearchCriteria searchCriteria,
            int offset,
            int limit,
            String order,
            String profile) {
        try {
            List<DrillParticipantSubmissionDto> drillParticipantSubmissionDtos = new ArrayList<>();
            List<DrillParticipantSubmission> drillParticipantSubmissionList = drillParticipantSubmissionRepository
                    .findByDrillIdAndIsActiveSubmission(searchCriteria.getDrillId(), true);
            drillParticipantSubmissionDtos = drillParticipantSubmissionList.stream()
                    .map(submission -> new DrillParticipantSubmissionDto(submission))
                    .collect(Collectors.toList());

            DrillSubmissionSearchResultDto searchResultDTO = DrillSubmissionSearchResultDto.builder()
                    .data(drillParticipantSubmissionDtos).totalRecordCount(drillParticipantSubmissionDtos.size())
                    .build();
            setPhaseAndPanelName(searchResultDTO, searchCriteria.getDrillId());

            setTeamDetails(searchResultDTO, searchCriteria.getDrillId());

            return searchResultDTO;
        } catch (Exception e) {
            log.error("Exception while searching jobs {}", e);
        }
        return null;
    }

    public DrillSubmissionSearchResultDto searchDrillSubmissions(DrillSubmissionSearchCriteria searchCriteria,
                                                                 int offset, int limit, String order, String profile) {
        log.info("Search criteria: {}", searchCriteria);
        DrillSubmissionSearchResultDto searchResultDTO = null;
        try {
            //log.info("Search criteria: {}", searchCriteria);
            String[] sort = order.split("\\.");
            Sort direction = Sort.by("desc".equalsIgnoreCase(sort[1]) ? Sort.Direction.DESC : Sort.Direction.ASC, sort[0]);

            Page<DrillParticipantSubmission> page = drillParticipantSubmissionRepository
                    .findAll(new DrillSubmissionSpecification(searchCriteria, drillTeamsRepository, drillParticipantRepository),
                            OffsetBasedPageRequest.of(offset, limit, direction));

            List<DrillParticipantSubmissionDto> submissions = page.getContent().stream()
                    .map(submission -> new DrillParticipantSubmissionDto(submission))
                    .collect(Collectors.toList());

//            String result = new ObjectMapper().writerWithView(SearchProfiles.getProfileByName(profile))
//                    .writeValueAsString(submissions);
//
//            submissions = new ObjectMapper().readValue(result, new TypeReference<List<DrillParticipantSubmissionDto>>() {
//            });

            searchResultDTO = DrillSubmissionSearchResultDto.builder().data(submissions).totalRecordCount(page.getTotalElements())
                    .build();

            setPhaseAndPanelName(searchResultDTO, searchCriteria.getDrillId());

            setTeamDetails(searchResultDTO, searchCriteria.getDrillId());

            return searchResultDTO;
        } catch (Exception e) {
            log.error("Exception while searching jobs {}", e);
        }
        return searchResultDTO;
    }

    public ByteArrayInputStream getSubmissionCSVLoad(List<DrillParticipantSubmissionDto> submissionDto) {
        final CSVFormat format =
                CSVFormat.DEFAULT
                        .withQuoteMode(QuoteMode.MINIMAL)
                        .withHeader(
                                "Team Name",
                                "Project Name",
                                "Submitted by",
                                "Participant Email",
                                "Submission updated on",
                                "Submitted Source Code",
                                "Submitted Video",
                                "Submitted Presentation"
                        );

        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            for (DrillParticipantSubmissionDto participantSubmissionDto : submissionDto) {
                JSONObject sourceCode = new JSONObject(participantSubmissionDto.getSourceCode());
                JSONObject video = new JSONObject(participantSubmissionDto.getVideo());
                JSONObject presentation = new JSONObject(participantSubmissionDto.getPresentation());
                List<String> data =
                        Arrays.asList(
                                participantSubmissionDto.getTeamName() + "",
                                participantSubmissionDto.getProjectName() + "",
                                participantSubmissionDto.getParticipantName() + "",
                                participantSubmissionDto.getParticipantEmail() + "",
                                participantSubmissionDto.getUpdatedTs() + "",
                                "Url: "
                                        + (StringUtils.isEmpty(sourceCode.get("link"))
                                        ? "NA"
                                        : sourceCode.get("link"))
                                        + ""
                                        + "\n Instruction: "
                                        + (StringUtils.isEmpty(sourceCode.get("instructions"))
                                        ? "NA"
                                        : sourceCode
                                        .get("instructions")
                                        .toString()
                                        .replaceAll("<p>", "\n")
                                        .replaceAll("</p>", "")
                                        .replaceAll("&nbsp;", ""))
                                        .replaceAll("<.+?>", "")
                                        + "",
                                "Url: "
                                        + (StringUtils.isEmpty(video.get("link"))
                                        ? "NA"
                                        : video.get("link"))
                                        + ""
                                        + "\n Instruction: "
                                        + (StringUtils.isEmpty(video.get("instructions"))
                                        ? "NA"
                                        : video.get("instructions")
                                        .toString()
                                        .replaceAll("<p>", "\n")
                                        .replaceAll("</p>", "")
                                        .replaceAll("&nbsp;", ""))
                                        .replaceAll("<.+?>", "")
                                        + "",
                                "Url: "
                                        + (StringUtils.isEmpty(presentation.get("link"))
                                        ? "NA"
                                        : presentation.get("link"))
                                        + ""
                                        + "\n Instruction: "
                                        + (StringUtils.isEmpty(presentation.get("instructions"))
                                        ? "NA"
                                        : presentation
                                        .get("instructions")
                                        .toString()
                                        .replaceAll("<p>", "\n")
                                        .replaceAll("</p>", "")
                                        .replaceAll("&nbsp;", ""))
                                        .replaceAll("<.+?>", "")
                                        + "");
                csvPrinter.printRecord(data);
            }
            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    private void setPhaseAndPanelName(DrillSubmissionSearchResultDto searchResultDTO, String drillid) {
        try {
            List<DrillJudgementPanel> drillJudgementPanels = drillJudgementPanelRepository.findByDrillId(drillid);

            Map<String, String> panelIdAndPanelName = new HashMap<>();
            Map<String, String> phaseIdAndPhaseName = getPhaseIdAndPhaseName(drillid);

            for (DrillJudgementPanel judgementPanel : drillJudgementPanels) {
                panelIdAndPanelName.put(judgementPanel.getDrillJudgementPanelId(), judgementPanel.getPanelName());
            }

            List<DrillParticipantSubmissionDto> drillParticipantSubmissionDtos = new ArrayList<>();

            for (DrillParticipantSubmissionDto drillParticipantSubmissionDto : searchResultDTO.getData()) {
                drillParticipantSubmissionDto.setPanelName(
                        panelIdAndPanelName.get(drillParticipantSubmissionDto.getPanelId()));
                drillParticipantSubmissionDto.setPhaseName(phaseIdAndPhaseName.get(
                        drillParticipantSubmissionDto.getPhaseId()));
                drillParticipantSubmissionDtos.add(drillParticipantSubmissionDto);
            }
            searchResultDTO.setData(drillParticipantSubmissionDtos);
        } catch (Exception e) {
            log.error("Exception while saving the panel name to the fields fields {}", e);
        }
    }

    public Object saveOrUpdateSubmissionFields(ConfigureSubmissionFields payload, InternityUser internityUser) {
        try {
            if (StringUtils.isEmpty(payload.getPhaseId())) {
                Optional<ConfigureSubmissionFields> fields =
                        drillConfigureSubmissionFieldsRepository.findByDrillId(
                                payload.getDrillId());
                if (fields.isPresent()) {
                    payload.setId(fields.get().getId());
                }
            } else if (!StringUtils.isEmpty(payload.getPhaseId())) {
                Optional<ConfigureSubmissionFields> fields =
                        drillConfigureSubmissionFieldsRepository.findByDrillIdAndPhaseId(
                                payload.getDrillId(), payload.getPhaseId());
                if (fields.isPresent()) {
                    payload.setId(fields.get().getId());
                }
            }
            return drillConfigureSubmissionFieldsRepository.save(payload);
        } catch (Exception e) {
            log.error("Exception while saving the submission fields {}", e);
        }
        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save the submission fields");
    }

    public Object fetchDrillSubmissionFields(String drillId, String phaseId, InternityUser user) {
        try {
            if (phaseId.equals("NA")) {
                Optional<ConfigureSubmissionFields> fields =
                        drillConfigureSubmissionFieldsRepository.findByDrillId(drillId);
                if (fields.isPresent()) {
                    return fields.get();
                }
            } else {
                Optional<ConfigureSubmissionFields> fields =
                        drillConfigureSubmissionFieldsRepository.findByDrillIdAndPhaseId(
                                drillId, phaseId);
                if (fields.isPresent()) {
                    return fields.get();
                }
            }
            List<DefaultSubmissionFields> defaultSubmissionFields =
                    drillDefaultSubmissionFieldsRepository.findAll();
            ConfigureSubmissionFields dto = new ConfigureSubmissionFields();
            dto.setFields(defaultSubmissionFields.toString());
            return dto;
        } catch (Exception e) {
            log.error("Exception while fetching the submission fields {} {} ::: error {}", drillId, phaseId, e);
        }
        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch the submission fields for the drill");
    }

    public Object saveOrUpdateDefaultSubmissionFields(DefaultSubmissionFields payload, InternityUser user) {
        try {
            return drillDefaultSubmissionFieldsRepository.save(payload);
        } catch (Exception e) {
            log.error("Exception while saving the submission fields {}", e);
        }
        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save the default submission fields");
    }

    public Object fetchDefaultSubmissionFields(InternityUser user) {
        try {
            return drillDefaultSubmissionFieldsRepository.findAll();
        } catch (Exception e) {
            log.error("Exception while fetching the submission fields {}", e);
        }
        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch the default submission fields");
    }

    public List<String> fetchParticipantTypes(InternityUser user) {
        return participantList;
    }

    public Object addOrUpdateMailTemplates(DrillMailTemplate payload, String drillId, InternityUser user) {
        try {
            payload.setDrillId(drillId);
            return drillMailTemplateRepository.save(payload);
        } catch (Exception e) {
            log.error("Exception while adding mail template {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to add or update mail template" + e.getMessage());
        }
    }

    public Object fetchMailTemplates(String drillId, String templateId, InternityUser user) {
        try {
            if (!templateId.equals("NA")) {
                Optional<DrillMailTemplate> drillMailTemplateObj = drillMailTemplateRepository.findById(templateId);
                if (drillMailTemplateObj.isPresent()) {
                    List returnListWithTemplate = new ArrayList();
                    returnListWithTemplate.add(drillMailTemplateObj.get());
                    return returnListWithTemplate;
                }
            }
            return drillMailTemplateRepository.findByDrillId(drillId);
        } catch (Exception e) {
            log.error("Exception while adding mail template {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to add or update mail template" + e.getMessage());
        }
    }

    public Object saveOrUpdateAssignmentOfJudge(String drillId, String submissionId, String panelId, InternityUser user) {
        try {
            Optional<DrillParticipantSubmission> drillParticipantSubmissionObj =
                    drillParticipantSubmissionRepository.findById(submissionId);
            if (drillParticipantSubmissionObj.isPresent()) {

                DrillParticipantSubmission submissionObj = drillParticipantSubmissionObj.get();
                submissionObj.setPanelId(panelId);
                return drillParticipantSubmissionRepository.save(submissionObj);
            } else {
                log.error("No submission present for the drill id {} ::: submission id {}", drillId, submissionId);
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                        "No submission present");
            }
        } catch (Exception e) {
            log.error("Exception while saving or updating assignment of judge to the " +
                    "submission with error {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to add or update assignment of judge to the submission " + e.getMessage());
        }
    }

    public Object fetchDrillTeamSubmission(String drillId, String judgeId, String phaseId, InternityUser user) {
        try {
            Optional<Drill> drillObj = drillRepository.findById(drillId);
            if (LocalDateTime.now().isAfter(drillObj.get().getDrillEndDt())) {
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Hackathon is over");
            }
            Optional<DrillAssignPanel> panelObj = drillAssignJudgeRepository.findByJudgeidListContaining(judgeId);
            if (!panelObj.isPresent()) {
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Judge is not assigned to any panel." +
                        "Please assign the judge to a panel");
            }
            List<String> submissions = drillParticipantSubmissionRepository
                    .findBydrillIdAndPanelId(drillId, panelObj.get().getPanelId());
            List<DrillTeams> drillTeam = drillTeamsRepository.findByDrillId(drillId);
            List<Map<String, String>> listOfTeamIdAndNames = new ArrayList<Map<String, String>>();
            for (DrillTeams teamDetails : drillTeam) {
                if (submissions.contains(teamDetails.getTeamId())) {
                    Map<String, String> teamIdAndNames = new HashMap<String, String>();
                    teamIdAndNames.put("name", teamDetails.getTeamName());
                    teamIdAndNames.put("id", teamDetails.getTeamId());
                    listOfTeamIdAndNames.add(teamIdAndNames);
                }
            }
            return listOfTeamIdAndNames;
        } catch (Exception e) {
            log.error("Exception while fetching Drill Teams who submitted solutions " +
                    "submission with error {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to get Team details who submitted solutions" + e.getMessage());
        }
    }

    public Object fetchIndividualSubmission(String drillId, String phaseId, String teamId, String submissionId, InternityUser user) {
        try {
            if (teamId.equals("NA")) {
                Optional<DrillParticipantSubmission> individualSubmissions =
                        drillParticipantSubmissionRepository.findById(submissionId);
                return individualSubmissions.get();
            } else {
                Optional<DrillParticipantSubmission> individualSubmissions =
                        drillParticipantSubmissionRepository.findTop1ByDrillIdAndTeamIdAndPhaseIdOrderByUpdatedTsDesc(drillId, teamId, phaseId);
                return individualSubmissions.get();
            }
        } catch (Exception e) {
            log.error("Exception while fetching the individual submission of a team" +
                    "submission with error {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to get individual submission details of a Team" + e.getMessage());
        }
    }

    public Object saveDrillSubmissionEvaluation(DrillSubmissionEvaluation payload, InternityUser user) {
        try {
            Optional<DrillSubmissionEvaluation> drillSubmissionEvaluation = drillSubmissionEvaluationRepository
                    .findBySubmissionIdAndJudgeId(payload.getSubmissionId(), payload.getJudgeId());
            if (drillSubmissionEvaluation.isPresent()) {
                payload.setId(drillSubmissionEvaluation.get().getId());
            }
            String assignedPanel = getPanelIdForJudge(payload.getJudgeId());
            payload.setPanelId(assignedPanel);
            DrillSubmissionEvaluation evaluation = drillSubmissionEvaluationRepository.saveAndFlush(payload);
            //create leaderboard details for this evaluation
            createLeaderboardAndUpdateAllPositions(payload);
            return evaluation;
        } catch (Exception e) {
            log.error("Exception while saving the Drill Submission Evaluation fields {}", e);
        }
        return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save the Drill Submission Evaluation fields");
    }


    private void createLeaderboardAndUpdateAllPositions(DrillSubmissionEvaluation payload) {
        try {
            Optional<DrillParticipantSubmission> submission = drillParticipantSubmissionRepository.findById(payload.getSubmissionId());
            DrillLeaderboard leaderboard = drillLeaderboardRepository.findByDrillIdAndPhaseIdAndSubmissionId(payload.getDrillId(), payload.getPhaseId(), payload.getSubmissionId());
            if (leaderboard != null) {
                List<DrillSubmissionEvaluation> drillSubmissionEvaluations = drillSubmissionEvaluationRepository.findAllByDrillIdAndPhaseIdAndSubmissionId(payload.getDrillId(), payload.getPhaseId(), payload.getSubmissionId());
                double totalMarks = 0;
                for (DrillSubmissionEvaluation drillSubmissionEvaluation : drillSubmissionEvaluations) {
                    totalMarks += Double.parseDouble(drillSubmissionEvaluation.getCalculatedMarks());
                }
                leaderboard.setAverageMarks(String.valueOf(totalMarks / drillSubmissionEvaluations.size()));
                drillLeaderboardRepository.saveAndFlush(leaderboard);
            } else {
                DrillLeaderboard drillLeaderboard = new DrillLeaderboard();
                if (submission.get().getTeamId() != null) {
                    drillLeaderboard.setTeamId(submission.get().getTeamId());
                } else {
                    drillLeaderboard.setParticipantId(submission.get().getParticipantId());
                }
                drillLeaderboard.setPosition("0");
                drillLeaderboard.setProjectShow(true);
                drillLeaderboard.setWinnerType(DrillWinnerType.GENERAL);
                drillLeaderboard.setPhaseId(payload.getPhaseId());
                drillLeaderboard.setDrillId(payload.getDrillId());
                List<DrillSubmissionEvaluation> drillSubmissionEvaluations = drillSubmissionEvaluationRepository.findAllByDrillIdAndPhaseIdAndSubmissionId(payload.getDrillId(), payload.getPhaseId(), payload.getSubmissionId());
                double totalMarks = 0;
                for (DrillSubmissionEvaluation drillSubmissionEvaluation : drillSubmissionEvaluations) {
                    totalMarks += Double.parseDouble(drillSubmissionEvaluation.getCalculatedMarks());
                }

                drillLeaderboard.setAverageMarks(String.valueOf(totalMarks / (double) drillSubmissionEvaluations.size()));
                drillLeaderboard.setSubmissionId(payload.getSubmissionId());

                drillLeaderboardRepository.saveAndFlush(drillLeaderboard);
            }

            // updating positions
            List<DrillLeaderboard> leaderboardList = drillLeaderboardRepository.findAllByDrillIdAndPhaseId(payload.getDrillId(), payload.getPhaseId());

            // Sort the leaderboard list based on the calculated marks (descending order)
            leaderboardList.sort((leaderboard1, leaderboard2) -> {
                // Parse the calculated marks strings to numerical values
                double marks1 = Double.parseDouble(leaderboard1.getAverageMarks());
                double marks2 = Double.parseDouble(leaderboard2.getAverageMarks());

                // Compare the numerical values in reverse order to sort in descending order
                int marksComparison = Double.compare(marks2, marks1);

                // If marks are equal, compare submission timestamps to break the tie
                if (marksComparison == 0) {
                    Date submissionTime1 = leaderboard1.getRecordCreatedTs();
                    Date submissionTime2 = leaderboard2.getRecordCreatedTs();
                    // Compare submission timestamps in ascending order to give lower rank to earlier submissions
                    return submissionTime1.compareTo(submissionTime2);
                }

                return marksComparison;
            });

            // Update positions based on the sorted order
            for (int i = 0; i < leaderboardList.size(); i++) {
                leaderboardList.get(i).setPosition(String.valueOf(i + 1));
            }

            // Save the updated leaderboard list
            drillLeaderboardRepository.saveAll(leaderboardList);

            // Log the successful update
            log.info("Leaderboard positions updated successfully.");
        } catch (Exception e) {
            log.error("Exception while updating leaderboard positions {}", e);
        }

    }


    private String getPanelIdForJudge(String judgeId) {
        try {
            Optional<DrillAssignPanel> panelObj = drillAssignJudgeRepository.findByJudgeidListContaining(judgeId);
            if (panelObj.isPresent()) {
                return panelObj.get().getPanelId();
            }
        } catch (Exception e) {
            log.error("Exception while getch the panel id for the Judge {}", e);
        }
        return "NA";
    }

    public Object fetchDrillEvaluation(String drillId, String submissionId, String judgeId, InternityUser user) {
        try {
            if (!submissionId.equals("NA")) {
                Optional<DrillSubmissionEvaluation> obj = drillSubmissionEvaluationRepository.findBySubmissionIdAndJudgeId(submissionId, judgeId);
                if (obj.isPresent()) {
                    return obj.get();
                } else {
                    return Optional.empty();
                }
            }

            List<DrillSubmissionEvaluation> drillSubmissionEvaluation = drillSubmissionEvaluationRepository.findBydrillId(drillId);

            List<DrillTeams> listDrillTeams = drillTeamsRepository.findByDrillId(drillId);

            List<DrillCollaborators> collaborators = drillCollaboratorsRepository.findByDrillId(drillId);
            List<DrillJudgementPanel> panelList = drillJudgementPanelRepository.findByDrillId(drillId);
            List<DrillAssignPanel> drillAssignJudgePanelList = drillAssignJudgeRepository.findAll();


            Map<String, String> panelIdAndJudgesList = new HashMap<String, String>();
            for (DrillAssignPanel panelJudge : drillAssignJudgePanelList) {
                panelIdAndJudgesList.put(panelJudge.getJudgeidList(), panelJudge.getPanelId());
            }

            Map<String, String> panelIdAndNames = new HashMap<String, String>();
            for (DrillJudgementPanel panel : panelList) {
                panelIdAndNames.put(panel.getDrillJudgementPanelId(), panel.getPanelName());
            }
            Map<String, String> teamIdAndNames = new HashMap<String, String>();
            for (DrillTeams teamDetails : listDrillTeams) {
                teamIdAndNames.put(teamDetails.getTeamId(), teamDetails.getTeamName());
            }
            Map<String, String> collaboratorIdAndName = new HashMap<String, String>();
            for (DrillCollaborators drillJudge : collaborators) {
                collaboratorIdAndName.put(drillJudge.getCollaboratorId(), drillJudge.getCollaboratorName());
            }

            Map<String, DrillSubmissionEvaluationDto> drillSubmissionEvaluationDetails = new HashMap<>();
            ObjectMapper objectMapper = new ObjectMapper();

            List<DrillSubmissionEvaluationDto> submissionEvaluationDtos = drillSubmissionEvaluation.stream().map(
                    submission -> new DrillSubmissionEvaluationDto(submission)
            ).collect(Collectors.toList());

            for (DrillSubmissionEvaluationDto evaluatedSubmissionDto : submissionEvaluationDtos) {
                if (evaluatedSubmissionDto.getCriteriaMarks() == null) {
                    continue;
                } else {
                    log.info(evaluatedSubmissionDto.getCriteriaMarks());
                }

                if (drillSubmissionEvaluationDetails.containsKey(evaluatedSubmissionDto.getSubmissionId())) {
                    DrillSubmissionEvaluationDto oldDrillSubmissionEvaluation = drillSubmissionEvaluationDetails
                            .get(evaluatedSubmissionDto.getSubmissionId());

                    JSONObject newJsonObject = oldDrillSubmissionEvaluation.getResultantCriteriaMarks();
                    newJsonObject.put(collaboratorIdAndName.get(evaluatedSubmissionDto.getJudgeId())
                            , new JSONArray(evaluatedSubmissionDto.getCriteriaMarks().toString()));
                    oldDrillSubmissionEvaluation.setTotalMarks(Integer.parseInt(oldDrillSubmissionEvaluation.getTotalMarks())
                            + Integer.parseInt(evaluatedSubmissionDto.getTotalMarks()) + "");
                    drillSubmissionEvaluationDetails.put(evaluatedSubmissionDto.getSubmissionId(), oldDrillSubmissionEvaluation);
                } else {
                    DrillParticipantSubmission submission = drillParticipantSubmissionRepository
                            .findById(evaluatedSubmissionDto.getSubmissionId()).get();
                    evaluatedSubmissionDto.setProjectName(submission.getProjectName());
                    evaluatedSubmissionDto.setTeamId(submission.getTeamId());
                    evaluatedSubmissionDto.setTeamName(teamIdAndNames.get(submission.getTeamId()));
                    evaluatedSubmissionDto.setTheme(submission.getTheme());

                    for (String judgeList : panelIdAndJudgesList.keySet()) {
                        if (judgeList.contains(evaluatedSubmissionDto.getJudgeId())) {
                            evaluatedSubmissionDto.setPanelName(panelIdAndNames.get(panelIdAndJudgesList.get(judgeList)));
                        }
                    }

                    JSONObject jsonObject = new JSONObject();

                    log.info(evaluatedSubmissionDto.getJudgeId() + "==" +
                            collaboratorIdAndName.get(evaluatedSubmissionDto.getJudgeId()));

                    jsonObject.put(collaboratorIdAndName.get(evaluatedSubmissionDto.getJudgeId())
                            , new JSONArray(evaluatedSubmissionDto.getCriteriaMarks().toString()));

                    evaluatedSubmissionDto.setResultantCriteriaMarks(jsonObject);
                    drillSubmissionEvaluationDetails.put(evaluatedSubmissionDto.getSubmissionId(), evaluatedSubmissionDto);
                }
            }

            JSONObject result = new JSONObject();
            for (String key : drillSubmissionEvaluationDetails.keySet()) {
                result.put(key, drillSubmissionEvaluationDetails.get(key));
            }
            return result;
        } catch (Exception e) {
            log.error("exception {}", e);
        }
        return null;
    }

    public Object fetchDrillAllEvaluation(String drillId, String submissionId, String judgeId, InternityUser user) {
        try {
            List<DrillSubmissionEvaluation> drillSubmissionEvaluation = drillSubmissionEvaluationRepository.findBydrillId(drillId);

            List<DrillTeams> listDrillTeams = drillTeamsRepository.findByDrillId(drillId);

            List<DrillCollaborators> collaborators = drillCollaboratorsRepository.findByDrillId(drillId);
            List<DrillJudgementPanel> panelList = drillJudgementPanelRepository.findByDrillId(drillId);
            List<DrillAssignPanel> drillAssignJudgePanelList = drillAssignJudgeRepository.findAll();

            Map<String, String> panelIdAndJudgesList = new HashMap<String, String>();
            for (DrillAssignPanel panelJudge : drillAssignJudgePanelList) {
                panelIdAndJudgesList.put(panelJudge.getJudgeidList(), panelJudge.getPanelId());
            }
            log.info(panelIdAndJudgesList);
            Map<String, String> panelIdAndNames = new HashMap<String, String>();
            for (DrillJudgementPanel panel : panelList) {
                panelIdAndNames.put(panel.getDrillJudgementPanelId(), panel.getPanelName());
            }

            log.info(panelIdAndNames);

            Map<String, String> teamIdAndNames = new HashMap<String, String>();
            for (DrillTeams teamDetails : listDrillTeams) {
                teamIdAndNames.put(teamDetails.getTeamId(), teamDetails.getTeamName());
            }
            Map<String, String> collaboratorIdAndName = new HashMap<String, String>();
            for (DrillCollaborators drillJudge : collaborators) {
                collaboratorIdAndName.put(drillJudge.getCollaboratorId(), drillJudge.getCollaboratorName());
            }

            Map<String, DrillSubmissionEvaluationDto> drillSubmissionEvaluationDetails = new HashMap<>();
            ObjectMapper objectMapper = new ObjectMapper();

            List<DrillSubmissionEvaluationDto> submissionEvaluationDtos = drillSubmissionEvaluation.stream().map(
                    submission -> new DrillSubmissionEvaluationDto(submission)
            ).collect(Collectors.toList());

            for (DrillSubmissionEvaluationDto evaluatedSubmissionDto : submissionEvaluationDtos) {
                if (evaluatedSubmissionDto.getCriteriaMarks() == null) {
                    continue;
                }

                if (drillSubmissionEvaluationDetails.containsKey(evaluatedSubmissionDto.getSubmissionId())) {
                    DrillSubmissionEvaluationDto oldDrillSubmissionEvaluation = drillSubmissionEvaluationDetails
                            .get(evaluatedSubmissionDto.getSubmissionId());

//                    JSONObject resultantCriteriaMarksJsonObj = new JSONObject(
//                            oldDrillSubmissionEvaluation.getResultantCriteriaMarks());
//
//                    resultantCriteriaMarksJsonObj.put(collaboratorIdAndName.get(
//                            evaluatedSubmissionDto.getJudgeId())
//                            , evaluatedSubmissionDto.getCriteriaMarks()
//                                    .toString());
//
//                    oldDrillSubmissionEvaluation.setResultantCriteriaMarks(
//                            resultantCriteriaMarksJsonObj.toString().replaceAll("\\\"","\'"));
                    oldDrillSubmissionEvaluation.setTotalMarks(Integer.parseInt(
                            oldDrillSubmissionEvaluation.getTotalMarks())
                            + Integer.parseInt(evaluatedSubmissionDto.getTotalMarks()) + "");

                    drillSubmissionEvaluationDetails.put(evaluatedSubmissionDto.getSubmissionId(),
                            oldDrillSubmissionEvaluation);
                } else {
                    DrillParticipantSubmission submission = drillParticipantSubmissionRepository
                            .findById(evaluatedSubmissionDto.getSubmissionId()).get();
                    evaluatedSubmissionDto.setProjectName(submission.getProjectName());
                    evaluatedSubmissionDto.setTeamId(submission.getTeamId());
                    evaluatedSubmissionDto.setTeamName(teamIdAndNames.get(submission.getTeamId()));
                    evaluatedSubmissionDto.setTheme(submission.getTheme());

                    for (String judgeList : panelIdAndJudgesList.keySet()) {
                        if (judgeList.contains(evaluatedSubmissionDto.getJudgeId())) {
                            evaluatedSubmissionDto.setPanelName(panelIdAndNames.get(panelIdAndJudgesList.get(judgeList)));
                        }
                    }

//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put(collaboratorIdAndName.get(evaluatedSubmissionDto.getJudgeId())
//                            , evaluatedSubmissionDto.getCriteriaMarks()
//                                    .toString());
//                    evaluatedSubmissionDto.setResultantCriteriaMarks(jsonObject.toString()
//                            .replaceAll("\\\"","\'"));
                    drillSubmissionEvaluationDetails.put(evaluatedSubmissionDto.getSubmissionId(), evaluatedSubmissionDto);
                }
            }

            JSONObject result = new JSONObject();
            for (String key : drillSubmissionEvaluationDetails.keySet()) {
                result.put(key, drillSubmissionEvaluationDetails.get(key));
            }
            return drillSubmissionEvaluationDetails.values().toString();
        } catch (Exception e) {
            log.error("exception {}", e);
        }
        return null;
    }

    private DrillSubmissionSearchResultDto setTeamDetails(DrillSubmissionSearchResultDto searchResultDTO, String drillId) {
        List<DrillParticipantSubmissionDto> submissions = searchResultDTO.getData();
        List<DrillParticipantSubmissionDto> newSubmissionList = new ArrayList<>();
        List<DrillTeams> drillTeams = drillTeamsRepository.findByDrillId(drillId);
        List<DrillCollaborators> drilljudge = drillCollaboratorsRepository.findByDrillId(drillId);

        Map<String, String> teamIdAndNames = new HashMap<String, String>();
        for (DrillTeams teamDetails : drillTeams) {
            teamIdAndNames.put(teamDetails.getTeamId(), teamDetails.getTeamName());
        }

        Map<String, String> participantIdAndTeamId = new HashMap<>();

        Map<String, String> participantIdAndName = new HashMap<String, String>();
        Map<String, String> participantIdAndEmail = new HashMap<String, String>();
        List<DrillParticipant> drillParticipantList = drillParticipantRepository.findAll();
        for (DrillParticipant drillParticipant : drillParticipantList) {
            participantIdAndEmail.put(drillParticipant.getParticipantId(), drillParticipant.getEmail());
            participantIdAndName.put(drillParticipant.getParticipantId(), drillParticipant.getFullName());
        }

        for (DrillParticipantSubmissionDto submissionDetails : submissions) {
            if (org.apache.commons.lang3.StringUtils.isBlank(submissionDetails.getTeamId())) {
                submissionDetails.setTeamId(
                        checkIfTeamIdIsNeededAndAvailable(
                                drillId,
                                submissionDetails.getParticipantId(),
                                submissionDetails.getTeamId()));
            }
            submissionDetails.setTeamName(teamIdAndNames.get(submissionDetails.getTeamId()));
            submissionDetails.setParticipantName(participantIdAndName.get(submissionDetails.getParticipantId()));
            submissionDetails.setParticipantEmail(participantIdAndEmail.get(submissionDetails.getParticipantId()));
            newSubmissionList.add(submissionDetails);
        }
        searchResultDTO.setData(newSubmissionList);
        return searchResultDTO;
    }

    public Object drillJudgeUrlWithKey(String drillId, String judgeId, String key, InternityUser user) {
        try {
            Optional<DrillCollaborators> drillCollaboratorsObj = drillCollaboratorsRepository.findByCollaboratorTypeAndCollaboratorIdAndKey("judge", judgeId, key);
            if (drillCollaboratorsObj.isPresent()) {
                return commonUtils.message(HttpStatus.OK,
                        "The given key matches with the judge");
            } else {
                log.error("No judge is present of given key ::: judge id {}", judgeId);
                return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                        "Please enter valid key");
            }
        } catch (Exception e) {
            log.error("Exception while checking the drill judge key ::: error {}", e);
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to get Url " + e.getMessage());
        }
    }

    public Map<String, FinalEvaluationDto> searchEvaluationv2(
            String drillId, String phaseId, String panelId, String judgeId, InternityUser user) {
        try {
            List<DrillSubmissionEvaluation> drillSubmissionEvaluationList = new ArrayList<>();

            if (!phaseId.equals("NA") && panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPhaseId(
                                drillId, phaseId));
            } else if (phaseId.equals("NA") && !panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPanelId(
                                drillId, panelId));
            } else if (!phaseId.equals("NA") && !panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPhaseIdAndPanelId(
                                drillId, phaseId, panelId));
            } else {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillId(drillId));
            }
            System.out.println(drillSubmissionEvaluationList);

            Map<String, FinalEvaluationDto> finalEvaluationDtoMap = new HashMap<>();

            Map<String, String> panelIdAndPanelName = getPanelIdAndPanelName(drillId);
            Map<String, String> phaseIdAndPhaseName = getPhaseIdAndPhaseName(drillId);
            Map<String, String> teamIdAndTeamName = new HashMap<>();
            Map<String, String> judgeIdAndJudgeName = getJudgeIdAndJudgeName(drillId);
            Map<String, String> submissionIdAndParticipantId = new HashMap<>();
            Map<String, String> submissionIdAndProjectName = new HashMap<>();
            Map<String, String> submissionIdAndTeamId = new HashMap<>();
            Map<String, String> participantIdAndParticipantName = new HashMap<>();
            Map<String, String> participantIdAndParticipantEmail = new HashMap<>();

            for (DrillParticipantSubmission drillParticipantSubmission : drillParticipantSubmissionRepository.findByDrillId(drillId)) {
                submissionIdAndParticipantId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getParticipantId());
                submissionIdAndProjectName.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getProjectName());
                submissionIdAndTeamId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getTeamId());
            }

            for (DrillParticipant drillParticipant : drillParticipantRepository.findByDrillId(drillId)) {
                participantIdAndParticipantName.put(drillParticipant.getParticipantId(), drillParticipant.getFullName());
                participantIdAndParticipantEmail.put(drillParticipant.getParticipantId(), drillParticipant.getEmail());
            }

            List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);

            for (DrillTeams drillTeam : drillTeamsList) {
                teamIdAndTeamName.put(drillTeam.getTeamId(), drillTeam.getTeamName());
            }

            Set<String> submissionIdWithJudgeId = new HashSet<>();

            Map<String, Integer> submissionIdAndCountofjudges = new HashMap<>();

            for (DrillSubmissionEvaluation drillSubmissionEvaluation : drillSubmissionEvaluationList) {
                if (submissionIdAndCountofjudges.containsKey(drillSubmissionEvaluation.getSubmissionId())) {
                    submissionIdAndCountofjudges.put(drillSubmissionEvaluation.getSubmissionId(),
                            submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()) + 1);
                } else {
                    submissionIdAndCountofjudges.put(drillSubmissionEvaluation.getSubmissionId(), 1);
                }
            }

            for (DrillSubmissionEvaluation drillSubmissionEvaluation :
                    drillSubmissionEvaluationList) {
                if (finalEvaluationDtoMap.containsKey(
                        drillSubmissionEvaluation.getSubmissionId())) {
                    FinalEvaluationDto finalEvaluationDto =
                            finalEvaluationDtoMap.get(drillSubmissionEvaluation.getSubmissionId());
                    finalEvaluationDto.setTotalGivenMarks(
                            finalEvaluationDto.getTotalGivenMarks()
                                    + Float.parseFloat(
                                    drillSubmissionEvaluation.getCalculatedMarks()));

                    finalEvaluationDto.setAverageMarks(finalEvaluationDto.getTotalGivenMarks()
                            / submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()));

                    finalEvaluationDto.setPanelName(
                            panelIdAndPanelName.get(drillSubmissionEvaluation.getPanelId()));

                    finalEvaluationDto.setJudgeNameAndMarksGiven(
                            finalEvaluationDto.getJudgeNameAndMarksGiven()
                                    + "||"
                                    + judgeIdAndJudgeName.get(
                                    drillSubmissionEvaluation.getJudgeId())
                                    + "#"
                                    + drillSubmissionEvaluation.getCriteriaMarks());
                    finalEvaluationDtoMap.put(
                            drillSubmissionEvaluation.getSubmissionId(), finalEvaluationDto);
                } else {
                    FinalEvaluationDto finalEvaluationDto = new FinalEvaluationDto();
                    finalEvaluationDto.setSubmissionId(drillSubmissionEvaluation.getSubmissionId());
                    finalEvaluationDto.setPanelId(drillSubmissionEvaluation.getPanelId());
                    finalEvaluationDto.setParticipantName(participantIdAndParticipantName
                            .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setParticipantEmail(participantIdAndParticipantEmail
                            .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setProjectName(submissionIdAndProjectName
                            .get(drillSubmissionEvaluation.getSubmissionId()));
                    finalEvaluationDto.setPanelName(
                            panelIdAndPanelName.get(drillSubmissionEvaluation.getPanelId()));
                    finalEvaluationDto.setPhaseName(
                            phaseIdAndPhaseName.get(drillSubmissionEvaluation.getPhaseId()));
                    finalEvaluationDto.setTeamName(
                            teamIdAndTeamName.get(submissionIdAndTeamId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setTotalGivenMarks(
                            Float.parseFloat(drillSubmissionEvaluation.getCalculatedMarks()));
                    finalEvaluationDto.setAverageMarks(finalEvaluationDto.getTotalGivenMarks()
                            / submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()));
                    finalEvaluationDto.setJudgeNameAndMarksGiven(
                            judgeIdAndJudgeName.get(drillSubmissionEvaluation.getJudgeId())
                                    + "#"
                                    + drillSubmissionEvaluation.getCriteriaMarks());
                    submissionIdWithJudgeId.add(drillSubmissionEvaluation.getSubmissionId()
                            + "_" + drillSubmissionEvaluation.getJudgeId());
                    finalEvaluationDtoMap.put(
                            drillSubmissionEvaluation.getSubmissionId(), finalEvaluationDto);
                }
            }
            return finalEvaluationDtoMap;
        } catch (Exception e) {
            log.error("Exception while fetching the Drill Evaluation done for Finalise");
        }
        return null;
    }

    public List<FinalEvaluationDto> downloadSearchEvaluationv2(
            String drillId, String phaseId, String panelId, String judgeId, InternityUser user) {
        try {
            List<DrillSubmissionEvaluation> drillSubmissionEvaluationList = new ArrayList<>();

            if (!phaseId.equals("NA") && panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPhaseId(
                                drillId, phaseId));
            } else if (phaseId.equals("NA") && !panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPanelId(
                                drillId, panelId));
            } else if (!phaseId.equals("NA") && !panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPhaseIdAndPanelId(
                                drillId, phaseId, panelId));
            } else {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillId(drillId));
            }

            Map<String, FinalEvaluationDto> finalEvaluationDtoMap = new HashMap<>();

            Map<String, String> panelIdAndPanelName = getPanelIdAndPanelName(drillId);
            Map<String, String> phaseIdAndPhaseName = getPhaseIdAndPhaseName(drillId);
            Map<String, String> teamIdAndTeamName = new HashMap<>();
            Map<String, String> judgeIdAndJudgeName = getJudgeIdAndJudgeName(drillId);
            Map<String, String> submissionIdAndParticipantId = new HashMap<>();
            Map<String, String> submissionIdAndProjectName = new HashMap<>();
            Map<String, String> submissionIdAndTeamId = new HashMap<>();
            Map<String, String> participantIdAndParticipantName = new HashMap<>();
            Map<String, String> participantIdAndParticipantEmail = new HashMap<>();

            for (DrillParticipantSubmission drillParticipantSubmission : drillParticipantSubmissionRepository.findByDrillId(drillId)) {
                submissionIdAndParticipantId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getParticipantId());
                submissionIdAndProjectName.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getProjectName());
                submissionIdAndTeamId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getTeamId());
            }

            for (DrillParticipant drillParticipant : drillParticipantRepository.findByDrillId(drillId)) {
                participantIdAndParticipantName.put(drillParticipant.getParticipantId(), drillParticipant.getFullName());
                participantIdAndParticipantEmail.put(drillParticipant.getParticipantId(), drillParticipant.getEmail());
            }

            List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);

            for (DrillTeams drillTeam : drillTeamsList) {
                teamIdAndTeamName.put(drillTeam.getTeamId(), drillTeam.getTeamName());
            }

            Set<String> submissionIdWithJudgeId = new HashSet<>();

            Map<String, Integer> submissionIdAndCountofjudges = new HashMap<>();

            for (DrillSubmissionEvaluation drillSubmissionEvaluation : drillSubmissionEvaluationList) {
                if (submissionIdAndCountofjudges.containsKey(drillSubmissionEvaluation.getSubmissionId())) {
                    submissionIdAndCountofjudges.put(drillSubmissionEvaluation.getSubmissionId(),
                            submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()) + 1);
                } else {
                    submissionIdAndCountofjudges.put(drillSubmissionEvaluation.getSubmissionId(), 1);
                }
            }

            for (DrillSubmissionEvaluation drillSubmissionEvaluation :
                    drillSubmissionEvaluationList) {
                if (finalEvaluationDtoMap.containsKey(
                        drillSubmissionEvaluation.getSubmissionId())) {
                    FinalEvaluationDto finalEvaluationDto =
                            finalEvaluationDtoMap.get(drillSubmissionEvaluation.getSubmissionId());
                    finalEvaluationDto.setTotalGivenMarks(
                            finalEvaluationDto.getTotalGivenMarks()
                                    + Float.parseFloat(
                                    drillSubmissionEvaluation.getCalculatedMarks()));

                    finalEvaluationDto.setAverageMarks(finalEvaluationDto.getTotalGivenMarks()
                            / submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()));

                    finalEvaluationDto.setPanelName(
                            panelIdAndPanelName.get(drillSubmissionEvaluation.getPanelId()));

                    finalEvaluationDto.setJudgeNameAndMarksGiven(
                            finalEvaluationDto.getJudgeNameAndMarksGiven()
                                    + "||"
                                    + judgeIdAndJudgeName.get(
                                    drillSubmissionEvaluation.getJudgeId())
                                    + "#"
                                    + drillSubmissionEvaluation.getCriteriaMarks());
                    finalEvaluationDtoMap.put(
                            drillSubmissionEvaluation.getSubmissionId(), finalEvaluationDto);
                } else {
                    FinalEvaluationDto finalEvaluationDto = new FinalEvaluationDto();
                    finalEvaluationDto.setSubmissionId(drillSubmissionEvaluation.getSubmissionId());
                    finalEvaluationDto.setPanelId(drillSubmissionEvaluation.getPanelId());
                    finalEvaluationDto.setParticipantName(participantIdAndParticipantName
                            .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setParticipantEmail(participantIdAndParticipantEmail
                            .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setProjectName(submissionIdAndProjectName
                            .get(drillSubmissionEvaluation.getSubmissionId()));
                    finalEvaluationDto.setPanelName(
                            panelIdAndPanelName.get(drillSubmissionEvaluation.getPanelId()));
                    finalEvaluationDto.setPhaseName(
                            phaseIdAndPhaseName.get(drillSubmissionEvaluation.getPhaseId()));
                    finalEvaluationDto.setTeamName(
                            teamIdAndTeamName.get(submissionIdAndTeamId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setTotalGivenMarks(
                            Float.parseFloat(drillSubmissionEvaluation.getCalculatedMarks()));
                    finalEvaluationDto.setAverageMarks(finalEvaluationDto.getTotalGivenMarks()
                            / submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()));
                    finalEvaluationDto.setJudgeNameAndMarksGiven(
                            judgeIdAndJudgeName.get(drillSubmissionEvaluation.getJudgeId())
                                    + "#"
                                    + drillSubmissionEvaluation.getCriteriaMarks());
                    submissionIdWithJudgeId.add(drillSubmissionEvaluation.getSubmissionId()
                            + "_" + drillSubmissionEvaluation.getJudgeId());
                    finalEvaluationDtoMap.put(
                            drillSubmissionEvaluation.getSubmissionId(), finalEvaluationDto);
                }
            }
            List<FinalEvaluationDto> finalEvaluationDtoList = new ArrayList<>();
            for (String key : finalEvaluationDtoMap.keySet()) {
                finalEvaluationDtoList.add(finalEvaluationDtoMap.get(key));
            }
            return finalEvaluationDtoList;
        } catch (Exception e) {
            log.error("Exception while fetching the Drill Evaluation done for Finalise");
        }
        return null;
    }

    public Map<String, DrillSubmissionJudgementEvaluationDto> searchEvaluationv3(
            String drillId, String phaseId, String panelId, String judgeId, InternityUser user) {
        try {
            List<DrillSubmissionEvaluation> drillSubmissionEvaluationList = new ArrayList<>();

            if (!phaseId.equals("NA") && panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPhaseId(
                                drillId, phaseId));
            } else if (phaseId.equals("NA") && !panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPanelId(
                                drillId, panelId));
            } else if (!phaseId.equals("NA") && !panelId.equals("NA")) {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillIdAndPhaseIdAndPanelId(
                                drillId, phaseId, panelId));
            } else {
                drillSubmissionEvaluationList.addAll(
                        drillSubmissionEvaluationRepository.findBydrillId(drillId));
            }

            Map<String, FinalEvaluationDto> finalEvaluationDtoMap = new HashMap<>();

            Map<String, String> panelIdAndPanelName = getPanelIdAndPanelName(drillId);
            Map<String, String> phaseIdAndPhaseName = getPhaseIdAndPhaseName(drillId);
            Map<String, String> teamIdAndTeamName = new HashMap<>();
            Map<String, String> judgeIdAndJudgeName = getJudgeIdAndJudgeName(drillId);
            Map<String, String> submissionIdAndParticipantId = new HashMap<>();
            Map<String, String> submissionIdAndProjectName = new HashMap<>();
            Map<String, String> submissionIdAndTeamId = new HashMap<>();
            Map<String, String> participantIdAndParticipantName = new HashMap<>();
            Map<String, String> participantIdAndParticipantEmail = new HashMap<>();

            for (DrillParticipantSubmission drillParticipantSubmission : drillParticipantSubmissionRepository.findByDrillId(drillId)) {
                submissionIdAndParticipantId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getParticipantId());
                submissionIdAndProjectName.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getProjectName());
                submissionIdAndTeamId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getTeamId());
            }

            for (DrillParticipant drillParticipant : drillParticipantRepository.findByDrillId(drillId)) {
                participantIdAndParticipantName.put(drillParticipant.getParticipantId(), drillParticipant.getFullName());
                participantIdAndParticipantEmail.put(drillParticipant.getParticipantId(), drillParticipant.getEmail());
            }

            List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);

            for (DrillTeams drillTeam : drillTeamsList) {
                teamIdAndTeamName.put(drillTeam.getTeamId(), drillTeam.getTeamName());
            }

            Set<String> submissionIdWithJudgeId = new HashSet<>();

            Map<String, Integer> submissionIdAndCountofjudges = new HashMap<>();

            for (DrillSubmissionEvaluation drillSubmissionEvaluation : drillSubmissionEvaluationList) {
                if (submissionIdAndCountofjudges.containsKey(drillSubmissionEvaluation.getSubmissionId())) {
                    submissionIdAndCountofjudges.put(drillSubmissionEvaluation.getSubmissionId(),
                            submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()) + 1);
                } else {
                    submissionIdAndCountofjudges.put(drillSubmissionEvaluation.getSubmissionId(), 1);
                }
            }

            for (DrillSubmissionEvaluation drillSubmissionEvaluation :
                    drillSubmissionEvaluationList) {
                if (finalEvaluationDtoMap.containsKey(
                        drillSubmissionEvaluation.getSubmissionId())) {
                    FinalEvaluationDto finalEvaluationDto =
                            finalEvaluationDtoMap.get(drillSubmissionEvaluation.getSubmissionId());
                    finalEvaluationDto.setTotalGivenMarks(
                            finalEvaluationDto.getTotalGivenMarks()
                                    + Float.parseFloat(
                                    drillSubmissionEvaluation.getCalculatedMarks()));

                    finalEvaluationDto.setAverageMarks(finalEvaluationDto.getTotalGivenMarks()
                            / submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()));

                    finalEvaluationDto.setPanelName(
                            panelIdAndPanelName.get(drillSubmissionEvaluation.getPanelId()));

                    finalEvaluationDto.setJudgeNameAndMarksGiven(
                            finalEvaluationDto.getJudgeNameAndMarksGiven()
                                    + "||"
                                    + judgeIdAndJudgeName.get(
                                    drillSubmissionEvaluation.getJudgeId())
                                    + "#"
                                    + drillSubmissionEvaluation.getCriteriaMarks());
                    finalEvaluationDtoMap.put(
                            drillSubmissionEvaluation.getSubmissionId(), finalEvaluationDto);
                } else {
                    FinalEvaluationDto finalEvaluationDto = new FinalEvaluationDto();
                    finalEvaluationDto.setSubmissionId(drillSubmissionEvaluation.getSubmissionId());
                    finalEvaluationDto.setPanelId(drillSubmissionEvaluation.getPanelId());
                    finalEvaluationDto.setParticipantName(participantIdAndParticipantName
                            .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setParticipantEmail(participantIdAndParticipantEmail
                            .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setProjectName(submissionIdAndProjectName
                            .get(drillSubmissionEvaluation.getSubmissionId()));
                    finalEvaluationDto.setPanelName(
                            panelIdAndPanelName.get(drillSubmissionEvaluation.getPanelId()));
                    finalEvaluationDto.setPhaseName(
                            phaseIdAndPhaseName.get(drillSubmissionEvaluation.getPhaseId()));
                    //finalEvaluationDto.setRemarks(drillSubmissionEvaluation.getRemarks());
                    finalEvaluationDto.setTeamName(
                            teamIdAndTeamName.get(submissionIdAndTeamId.get(drillSubmissionEvaluation.getSubmissionId())));
                    finalEvaluationDto.setTotalGivenMarks(
                            Float.parseFloat(drillSubmissionEvaluation.getCalculatedMarks()));
                    finalEvaluationDto.setAverageMarks(finalEvaluationDto.getTotalGivenMarks()
                            / submissionIdAndCountofjudges.get(drillSubmissionEvaluation.getSubmissionId()));
                    finalEvaluationDto.setJudgeNameAndMarksGiven(
                            judgeIdAndJudgeName.get(drillSubmissionEvaluation.getJudgeId())
                                    + "#"
                                    + drillSubmissionEvaluation.getCriteriaMarks());
                    submissionIdWithJudgeId.add(drillSubmissionEvaluation.getSubmissionId()
                            + "_" + drillSubmissionEvaluation.getJudgeId());
                    finalEvaluationDtoMap.put(
                            drillSubmissionEvaluation.getSubmissionId(), finalEvaluationDto);
                }
            }
            List<FinalEvaluationDto> finalEvaluationDtoList = new ArrayList<>();
            for (String key : finalEvaluationDtoMap.keySet()) {
                finalEvaluationDtoList.add(finalEvaluationDtoMap.get(key));
            }
            //return finalEvaluationDtoList;
        } catch (Exception e) {
            log.error("Exception while fetching the Drill Evaluation done for Finalise");
        }
        return null;
    }

    public ByteArrayInputStream getCSVLoadOfFinalResult(List<FinalEvaluationDto> finalEvaluationDto) {
        final CSVFormat format =
                CSVFormat.DEFAULT
                        .withQuoteMode(QuoteMode.MINIMAL)
                        .withHeader(
                                "Team Name",
                                "Project Name",
                                "Lead Participant Name",
                                "Lead Participant Email",
                                "Panel Name",
                                "Phase/Round",
                                "Total Marks",
                                "Average Marks"
                        );

        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            for (FinalEvaluationDto evaluationDto : finalEvaluationDto) {
                List<String> data =
                        Arrays.asList(
                                evaluationDto.getTeamName() + "",
                                evaluationDto.getProjectName() + "",
                                evaluationDto.getParticipantName() + "",
                                evaluationDto.getParticipantEmail() + "",
                                evaluationDto.getPanelName() + "",
                                evaluationDto.getPhaseName() + "",
                                evaluationDto.getTotalGivenMarks() + "",
                                evaluationDto.getAverageMarks() + ""
                        );
                csvPrinter.printRecord(data);
            }
            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
        }

    }


    public Object searchEvaluationv3(
            String drillId, String phaseId, String panelId, String judgeId, String teamName, String sortOrder, InternityUser user) {
        try {
            List<DrillSubmissionEvaluation> drillSubmissionEvaluationList = new ArrayList<>();

            Map<String, FinalEvaluationDto> finalEvaluationDtoMap = new HashMap<>();

            Map<String, String> panelIdAndPanelName = getPanelIdAndPanelName(drillId);
            Map<String, String> phaseIdAndPhaseName = getPhaseIdAndPhaseName(drillId);
            Map<String, String> teamIdAndTeamName = new HashMap<>();
            Map<String, String> judgeIdAndJudgeName = getJudgeIdAndJudgeName(drillId);
            Map<String, String> submissionIdAndParticipantId = new HashMap<>();
            Map<String, String> submissionIdAndProjectName = new HashMap<>();
            Map<String, String> submissionIdAndTeamId = new HashMap<>();

            Map<String, String> participantIdAndParticipantName = new HashMap<>();
            Map<String, String> participantIdAndParticipantEmail = new HashMap<>();

            for (DrillParticipantSubmission drillParticipantSubmission : drillParticipantSubmissionRepository.findByDrillId(drillId)) {
                submissionIdAndParticipantId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getParticipantId());
                submissionIdAndProjectName.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getProjectName());
                submissionIdAndTeamId.put(drillParticipantSubmission.getSubmissionId(), drillParticipantSubmission.getTeamId());
            }

            for (DrillParticipant drillParticipant : drillParticipantRepository.findByDrillId(drillId)) {
                participantIdAndParticipantName.put(drillParticipant.getParticipantId(), drillParticipant.getFullName());
                participantIdAndParticipantEmail.put(drillParticipant.getParticipantId(), drillParticipant.getEmail());
            }

            List<DrillCollaborators> judgeList = drillCollaboratorsRepository.findByDrillId(drillId);
            for (DrillCollaborators drillCollaborator : judgeList) {
                judgeIdAndJudgeName.put(drillCollaborator.getCollaboratorId(), drillCollaborator.getCollaboratorName());
            }

            List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);

            for (DrillTeams drillTeam : drillTeamsList) {
                teamIdAndTeamName.put(drillTeam.getTeamId(), drillTeam.getTeamName());
            }

            for (DrillSubmissionEvaluation evaluation : drillSubmissionEvaluationRepository.findBydrillId(drillId)) {
                if ((phaseId.equals("NA") || evaluation.getPhaseId().equals(phaseId))
                        && (panelId.equals("NA") || evaluation.getPanelId().equals(panelId))
                        && (judgeId.equals("NA") || evaluation.getJudgeId().equals(judgeId))
                        && (teamName.equals("NA") || teamName.equalsIgnoreCase(
                        teamIdAndTeamName.get(submissionIdAndTeamId.get(evaluation.getSubmissionId()))))) {
                    drillSubmissionEvaluationList.add(evaluation);
                }
            }

            Map<String, DrillSubmissionJudgementEvaluationDto> result = new HashMap<>();


            for (DrillSubmissionEvaluation drillSubmissionEvaluation : drillSubmissionEvaluationList) {
                DrillSubmissionJudgementEvaluationDto finalEvaluationDto = new DrillSubmissionJudgementEvaluationDto();
                finalEvaluationDto.setId(drillSubmissionEvaluation.getId());
                finalEvaluationDto.setSubmissionId(drillSubmissionEvaluation.getSubmissionId());
                finalEvaluationDto.setPanelId(drillSubmissionEvaluation.getPanelId());
                finalEvaluationDto.setParticipantName(participantIdAndParticipantName
                        .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                finalEvaluationDto.setParticipantEmail(participantIdAndParticipantEmail
                        .get(submissionIdAndParticipantId.get(drillSubmissionEvaluation.getSubmissionId())));
                finalEvaluationDto.setProjectName(submissionIdAndProjectName
                        .get(drillSubmissionEvaluation.getSubmissionId()));
                finalEvaluationDto.setJudgeId(drillSubmissionEvaluation.getJudgeId());
                finalEvaluationDto.setJudgeName(judgeIdAndJudgeName.get(drillSubmissionEvaluation.getJudgeId()));
                finalEvaluationDto.setPanelName(
                        panelIdAndPanelName.get(drillSubmissionEvaluation.getPanelId()));
                finalEvaluationDto.setPhaseName(
                        phaseIdAndPhaseName.get(drillSubmissionEvaluation.getPhaseId()));
                finalEvaluationDto.setTeamName(
                        teamIdAndTeamName.get(submissionIdAndTeamId.get(drillSubmissionEvaluation.getSubmissionId())));
                finalEvaluationDto.setRemarks(drillSubmissionEvaluation.getRemarks());
                finalEvaluationDto.setTotalGivenMarks(
                        Float.parseFloat(drillSubmissionEvaluation.getCalculatedMarks()));
                String str1[] = drillSubmissionEvaluation.getCriteriaMarks().split("\\},\\{");
                StringBuilder marksResult = new StringBuilder();
                for (String ss : str1) {
                    String[] internal = ss.split(",");
                    for (String ii : internal) {
                        marksResult.append(ii.split(":")[1]);
                        marksResult.append("/");
                    }
                    marksResult.append("||");
                }

                finalEvaluationDto.setJudgeMarks(marksResult.toString().replaceAll("\"", "")
                        .replaceAll("/\\|\\|", ", ").replaceAll("}]", ""));
                result.put(drillSubmissionEvaluation.getJudgeId() + "_"
                        + drillSubmissionEvaluation.getSubmissionId(), finalEvaluationDto);
            }
            List<DrillSubmissionJudgementEvaluationDto> dtoList = new ArrayList<>(result.values());

            // Sort the list based on TotalGivenMarks and sortOrder
            Collections.sort(dtoList, new Comparator<DrillSubmissionJudgementEvaluationDto>() {
                @Override
                public int compare(DrillSubmissionJudgementEvaluationDto dto1, DrillSubmissionJudgementEvaluationDto dto2) {
                    // Use sortOrder to determine the sorting order
                    if ("asc".equalsIgnoreCase(sortOrder)) {
                        return Float.compare(dto1.getTotalGivenMarks(), dto2.getTotalGivenMarks());
                    } else {
                        return Float.compare(dto2.getTotalGivenMarks(), dto1.getTotalGivenMarks());
                    }
                }
            });
            return dtoList;
        } catch (Exception e) {
            log.error("Exception while fetching the Drill Evaluation done for Finalise");
        }
        return null;
    }


    private Map<String, String> getPhaseIdAndPhaseName(String drillId) {
        try {
            List<DrillPhases> drillPhasesList = drillPhasesRepository.findByDrillIdOrderByPhaseStartDtDesc(drillId);
            Map<String, String> phaseIdAndPhaseName = new HashMap<>();

            for (DrillPhases drillPhases : drillPhasesList) {
                phaseIdAndPhaseName.put(drillPhases.getPhaseId(), drillPhases.getPhaseName());
            }
            return phaseIdAndPhaseName;
        } catch (Exception e) {
            log.error("Exception while fetching the judge id and judge name {}", e);
            return Collections.EMPTY_MAP;
        }
    }

    private Map<String, String> getJudgeIdAndJudgeName(String drillId) {
        try {
            List<DrillCollaborators> drillCollaboratorsList = drillCollaboratorsRepository.findByDrillId(drillId);
            Map<String, String> judgeIdAndJudgeName = new HashMap<>();

            for (DrillCollaborators drillCollaborator : drillCollaboratorsList) {
                judgeIdAndJudgeName.put(drillCollaborator.getCollaboratorId(), drillCollaborator.getCollaboratorName());
            }
            return judgeIdAndJudgeName;
        } catch (Exception e) {
            log.error("Exception while fetching the judge id and judge name {}", e);
            return Collections.EMPTY_MAP;
        }
    }


    private Map<String, String> getPanelIdAndPanelName(String drillId) {
        List<DrillJudgementPanel> drillJudgementPanelList =
                drillJudgementPanelRepository.findByDrillId(drillId);
        Map<String, String> panelIdAndPanelName = new HashMap<>();
        for (DrillJudgementPanel drillJudgementPanel : drillJudgementPanelList) {
            panelIdAndPanelName.put(
                    drillJudgementPanel.getDrillJudgementPanelId(),
                    drillJudgementPanel.getPanelName());
        }
        return panelIdAndPanelName;

    }

    public List<Map<String, Object>> getDrillLeaderBoard(String drillId, String phaseId, String profile, InternityUser user) {
        try {
            List<DrillParticipant> participants = drillParticipantRepository.findByDrillId(drillId);
            Optional<Drill> optionalDrill = drillRepository.findById(drillId);

            if (optionalDrill.isPresent()) {
                Drill drill = optionalDrill.get();
                List<Map<String, Object>> leaderboardResponse = new ArrayList<>();

                // Parse drillTeamSize JSON
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode teamSizeJson = objectMapper.readTree(drill.getDrillTeamSize());
                int maxTeamSize = teamSizeJson.get("max").asInt();

                for (DrillParticipant participant : participants) {
                    Optional<DrillParticipantSubmission> latestSubmissionObj;

                    if ("NA".equalsIgnoreCase(phaseId)) {
                        // Use drillId directly if phaseId is "NA"
                        latestSubmissionObj = drillParticipantSubmissionRepository.findFirstByDrillIdAndParticipantIdAndIsActiveSubmissionOrderByCreatedTsDesc(drillId, participant.getParticipantId(), true);
                    } else {
                        latestSubmissionObj = drillParticipantSubmissionRepository.findByDrillIdAndPhaseIdAndParticipantIdAndIsActiveSubmission(drillId, phaseId, participant.getParticipantId(), true);
                    }

                    if (latestSubmissionObj.isPresent()) {
                        DrillParticipantSubmission latestSubmission = latestSubmissionObj.get();
                        List<DrillSubmissionEvaluation> evaluation = drillSubmissionEvaluationRepository.findBySubmissionId(latestSubmission.getSubmissionId());

                        if (evaluation.get(0) != null) {
                            double calculatedMarks = Double.parseDouble(evaluation.get(0).getCalculatedMarks());

                            Map<String, Object> leaderboardEntry = new HashMap<>();
                            if (maxTeamSize == 1) {
                                // Individual participant case
                                leaderboardEntry.put("participant", participant);
                            } else if (latestSubmission.getTeamId() != null) {
                                Optional<DrillTeams> optionalTeam = drillTeamsRepository.findById(latestSubmission.getTeamId());
                                if (optionalTeam.isPresent()) {
                                    DrillTeams team = optionalTeam.get();
                                    leaderboardEntry.put("team", team);
                                } else {
                                    log.error("Team not found for participantId: " + participant.getParticipantId());
                                    continue;
                                }
                            } else {
                                log.error("TeamId is null for participantId: " + participant.getParticipantId());
                                continue;
                            }

                            leaderboardEntry.put("calculatedMarks", calculatedMarks);
                            leaderboardEntry.put("latestSubmission", latestSubmission);
                            leaderboardResponse.add(leaderboardEntry);
                        } else {
                            log.error("Evaluation data not found for submissionId: " + latestSubmission.getSubmissionId());
                        }
                    } else {
                        log.error("Latest submission not found for participantId: " + participant.getParticipantId());
                    }
                }

                leaderboardResponse.sort((entry1, entry2) -> {
                    double marks1 = (double) entry1.get("calculatedMarks");
                    double marks2 = (double) entry2.get("calculatedMarks");
                    return Double.compare(marks2, marks1);
                });

                return leaderboardResponse;
            } else {
                log.error("Drill not found for drillId: " + drillId);
                return Collections.emptyList();
            }
        } catch (Exception e) {
            log.error("Error while fetching drill leaderboard: " + e.getMessage(), e);
            return Collections.emptyList();
        }
    }

    @SuppressWarnings("unchecked") // Suppress the unchecked warning for casting
    public Map<String, FinalEvaluationDto> fetchAndConvertEvaluationData(
            String drillId, String phaseId, String panelId, String judgeId, InternityUser user) {
        // Call the searchEvaluationv2 method to fetch the evaluation data
        Object evaluationData = searchEvaluationv2(drillId, phaseId, panelId, judgeId, user);

        // Check if the evaluationData is not null and is an instance of the expected type
        if (evaluationData != null && evaluationData instanceof Collection<?>) {
            Collection<FinalEvaluationDto> evaluationCollection = (Collection<FinalEvaluationDto>) evaluationData;

            // Convert the collection to a map with SubmissionId as the key
            Map<String, FinalEvaluationDto> evaluationMap = new HashMap<>();
            for (FinalEvaluationDto evaluationDto : evaluationCollection) {
                evaluationMap.put(evaluationDto.getSubmissionId(), evaluationDto);
            }

            return evaluationMap;
        }

        // Return an empty map if the data is not as expected
        return Collections.emptyMap();
    }

    @SuppressWarnings("unchecked") // Suppress the unchecked warning for casting
    public Map<String, DrillSubmissionJudgementEvaluationDto> fetchAndConvertExtendedEvaluationData(
            String drillId, String phaseId, String panelId, String judgeId, String teamName, String sortOrder, InternityUser user) {
        // Call the searchEvaluationv2 method to fetch the evaluation data
        Object extendedEvaluationData = searchEvaluationv3(drillId, phaseId, panelId, judgeId, teamName, sortOrder, user);

        // Check if the evaluationData is not null and is an instance of the expected type
        if (extendedEvaluationData != null && extendedEvaluationData instanceof Collection<?>) {
            Collection<DrillSubmissionJudgementEvaluationDto> extendedEvaluationCollection = (Collection<DrillSubmissionJudgementEvaluationDto>) extendedEvaluationData;

            // Convert the collection to a map with SubmissionId as the key
            Map<String, DrillSubmissionJudgementEvaluationDto> evaluationMap = new HashMap<>();
            for (DrillSubmissionJudgementEvaluationDto evaluationDto : extendedEvaluationCollection) {
                evaluationMap.put(evaluationDto.getSubmissionId(), evaluationDto);
            }

            return evaluationMap;
        }

        // Return an empty map if the data is not as expected
        return Collections.emptyMap();
    }


    public byte[] exportEvaluationv2(String drillId, String phaseId, String panelId, String judgeId, InternityUser user) {
        // Retrieve the evaluation data based on the provided parameters
        Map<String, FinalEvaluationDto> evaluationData = searchEvaluationv2(drillId, phaseId, panelId, judgeId, user);

        try {
            // Create an Excel workbook and sheet
            try (Workbook workbook = new XSSFWorkbook()) {
                Sheet sheet = workbook.createSheet("Evaluation Data");

                // Create headers manually for the selected fields
                String[] headers = {"Team Name", "Project Name", "Total Marks", "Panel"};
                Row headerRow = sheet.createRow(0);
                int colNum = 0;
                for (String header : headers) {
                    Cell cell = headerRow.createCell(colNum++);
                    cell.setCellValue(header);
                }

                // Populate data
                int rowNum = 1;
                for (FinalEvaluationDto evaluationDto : evaluationData.values()) {
                    Row row = sheet.createRow(rowNum++);
                    colNum = 0;

                    // Populate the selected fields
                    Cell cell1 = row.createCell(colNum++);
                    cell1.setCellValue(evaluationDto.getTeamName());

                    Cell cell2 = row.createCell(colNum++);
                    cell2.setCellValue(evaluationDto.getProjectName());

                    Cell cell3 = row.createCell(colNum++);
                    cell3.setCellValue(evaluationDto.getTotalGivenMarks());

                    Cell cell4 = row.createCell(colNum);
                    cell4.setCellValue(evaluationDto.getPanelName());
                }

                // Prepare the Excel data for download
                ByteArrayOutputStream excelBytes = new ByteArrayOutputStream();
                workbook.write(excelBytes);
                excelBytes.close();


                return excelBytes.toByteArray();
            }
        } catch (Exception e) {
            log.error("Error while exporting evaluation data: " + e.getMessage(), e);
            return null;
        }
    }

    public byte[] exportEvaluationv3(String drillId, String phaseId, String panelId, String judgeId, String teamName, String sortOrder,
                                     InternityUser user) {
        Optional<Drill> drillObj = drillRepository.findById(drillId);
        if (!drillObj.isPresent()) {
            log.error("Invalid Drill ID.Please Enter a valid drill ID");
            return null;
        }
        // Retrieve the evaluation data based on the provided parameters
        Map<String, DrillSubmissionJudgementEvaluationDto> evaluationData = fetchAndConvertExtendedEvaluationData(drillId, phaseId,
                panelId, judgeId, teamName, sortOrder, user);

        try {
            // Create an Excel workbook and sheet
            try (Workbook workbook = new XSSFWorkbook()) {
                Sheet sheet = workbook.createSheet("Evaluation Data");

                // Create headers manually for the selected fields
                String[] headers = {"Team Name", "Project Name", "Total Marks", "Panel", "Judge", "Phase", "Evaluation"};
                Row headerRow = sheet.createRow(0);
                int colNum = 0;
                for (String header : headers) {
                    Cell cell = headerRow.createCell(colNum++);
                    cell.setCellValue(header);
                }

                // Populate data
                int rowNum = 1;
                for (DrillSubmissionJudgementEvaluationDto evaluationDto : evaluationData.values()) {
                    Row row = sheet.createRow(rowNum++);
                    colNum = 0;

                    // Populate the selected fields
                    Cell cell1 = row.createCell(colNum++);
                    cell1.setCellValue(evaluationDto.getTeamName());

                    Cell cell2 = row.createCell(colNum++);
                    cell2.setCellValue(evaluationDto.getProjectName());

                    Cell cell3 = row.createCell(colNum++);
                    cell3.setCellValue(evaluationDto.getTotalMarks());

                    Cell cell4 = row.createCell(colNum++);
                    cell4.setCellValue(evaluationDto.getPanelName());

                    Cell cell5 = row.createCell(colNum++);
                    cell5.setCellValue(evaluationDto.getJudgeName());

                    Cell cell6 = row.createCell(colNum++);
                    cell6.setCellValue(evaluationDto.getPhaseName());

                    Cell cell7 = row.createCell(colNum);
                    cell7.setCellValue(evaluationDto.getJudgeMarks());
                }

                // Prepare the Excel data for download
                ByteArrayOutputStream excelBytes = new ByteArrayOutputStream();
                workbook.write(excelBytes);
                excelBytes.close();

                return excelBytes.toByteArray();
            }
        } catch (Exception e) {
            log.error("Error while exporting extended evaluation data: " + e.getMessage(), e);
            return null;
        }
    }

    public Map<String, String> fetchPreviousDrillEvaluation(String drillId, String phaseId, String teamId, String submissionId, InternityUser user) {
        try {

            if (!"NA".equals(submissionId)) {
                Optional<DrillParticipantSubmission> submissionObj =
                        drillParticipantSubmissionRepository.findById(submissionId);

                if (submissionObj.isPresent()) {
                    teamId = submissionObj.get().getTeamId();
                }
            } else if ("NA".equals(teamId)) {
                return Collections.EMPTY_MAP;
            }

            List<DrillParticipantSubmission> drillParticipantSubmissionList = new ArrayList<>();

            if ("NA".equals(phaseId)) {
                drillParticipantSubmissionList.addAll(drillParticipantSubmissionRepository.findByDrillIdAndTeamId(drillId, teamId));
            } else {
                drillParticipantSubmissionList.addAll(drillParticipantSubmissionRepository
                        .findByDrillIdAndTeamIdAndPhaseId(drillId, teamId, phaseId));
            }

            List<DrillPhases> drillPhasesList = drillPhasesRepository.findByDrillId(drillId);
            Map<String, String> phaseIdAndPhaseName = new HashMap<>();
            if (!drillPhasesList.isEmpty()) {
                for (DrillPhases drillPhases : drillPhasesList) {
                    phaseIdAndPhaseName.put(drillPhases.getPhaseId(), drillPhases.getPhaseName());
                }
            } else {
                return null;
            }
            List<DrillCollaborators> drillCollaboratorsList =
                    drillCollaboratorsRepository.findByDrillIdAndCollaboratorTypeOrderByPositionOrder(drillId, "Judge");

            Map<String, String> judgeIdAndJudgeName = new HashMap<>();
            for (DrillCollaborators collaborator : drillCollaboratorsList) {
                judgeIdAndJudgeName.put(collaborator.getCollaboratorId(), collaborator.getCollaboratorName());
            }
            Map<String, String> phaseAndRemarks = new HashMap<>();

            if (!drillParticipantSubmissionList.isEmpty()) {
                for (DrillParticipantSubmission submission : drillParticipantSubmissionList) {
                    try {
                        List<DrillSubmissionEvaluation> drillSubmissionEvaluation =
                                drillSubmissionEvaluationRepository.findBySubmissionId(submission.getSubmissionId());

                        if (!drillSubmissionEvaluation.isEmpty()) {
                            List<String> submissionByJudges = new ArrayList<>();
                            int i = 0;
                            for (DrillSubmissionEvaluation submissionEvaluation :
                                    drillSubmissionEvaluation) {
                                ++i;
                                submissionByJudges.add(i + ") Judge "
                                        + judgeIdAndJudgeName.get(submissionEvaluation.getJudgeId())
                                        + ": " + submissionEvaluation.getRemarks());
                            }
                            phaseAndRemarks.put(
                                    phaseIdAndPhaseName.get(submission.getPhaseId()),
                                    " " + submissionByJudges.toString());
                        }
                    } catch (Exception e) {
                        log.error("Exception while fetching remarks ::: {}", e);
                    }
                }
            }
            return phaseAndRemarks;
        } catch (Exception e) {
            log.error("Exception while fetching previous evaluation of the team ::: {}", e);
        }
        return Collections.EMPTY_MAP;
    }

    public UserSubmissionResultDto allSubmissionByAnUser(String uId, InternityUser user) {
        UserSubmissionResultDto result = new UserSubmissionResultDto();
        result.setUId(uId);

        try {
            List<DrillParticipant> participantList = drillParticipantRepository.findByPlatformUId(uId);

            if (!participantList.isEmpty()) {
                List<UserSubmissionDto> submissionDetailsList = new ArrayList<>();

                for (DrillParticipant participant : participantList) {
                    String drillId = participant.getDrillId();
                    String participantId = participant.getParticipantId();

                    // Fetch Drill Details from drillRepository using drillId
                    Optional<Drill> drillDetailsOptional = drillRepository.findById(drillId);

                    if (drillDetailsOptional.isPresent()) {
                        Drill drillDetails = drillDetailsOptional.get();

                        DrillParticipantSubmission latestSubmission = drillParticipantSubmissionRepository
                                .findTopByParticipantIdAndDrillIdAndIsActiveSubmissionOrderByUpdatedTsDesc(participantId, drillId, true);

                        if (latestSubmission != null && latestSubmission.isActiveSubmission()) {
                            String teamId = latestSubmission.getTeamId();
                            Optional<DrillTeams> drillTeamDetails = drillTeamsRepository.findByDrillIdAndTeamId(drillId, teamId);

                            if (drillTeamDetails.isPresent()) {
                                UserSubmissionDto submissionDetails = new UserSubmissionDto();
                                submissionDetails.setTeamDetails(drillTeamDetails.get());
                                submissionDetails.setDrillDetails(drillDetails);
                                submissionDetails.setProjectDetails(latestSubmission);
                                submissionDetails.setDrillId(drillId);
                                submissionDetails.setParticipantId(participantId);
                                submissionDetailsList.add(submissionDetails);
                            }
                        }
                    }
                }

                result.setDetails(submissionDetailsList);
                result.setTotalRecordCount(submissionDetailsList.size());
            }
        } catch (Exception e) {
            log.error("Exception occurred while processing allSubmissionByAnUser: {}", e.getMessage(), e);
            return null;
        }

        return result;
    }

    // method created for shortlist on basis or either marks threshold or set result to SHORTLISTED or Rejected on basis of map
    public ResponseEntity<?> getDrillSubmissionShortlist(String phaseId, String marksThreshold, Map<String, String> submissionResultMap, InternityUser user) {

        log.info("Shortlisting submissions: {} {}", submissionResultMap, marksThreshold);

        List<DrillParticipantSubmission> responseList = new ArrayList<>();

        try {
            if (org.apache.commons.lang3.StringUtils.isAnyBlank(phaseId)) {
                log.error("Phase Id not provided");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Phase Id not provided", null), HttpStatus.BAD_REQUEST);
            }

            Optional<DrillPhases> optionalDrillPhases = drillPhasesRepository.findById(phaseId);
            if (!optionalDrillPhases.isPresent()) {
                log.error("Invalid Phase Id: {}", phaseId);
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Invalid Phase Id", null), HttpStatus.BAD_REQUEST);
            }

            DrillPhases drillPhases = optionalDrillPhases.get();

            // Check if both threshold and submissionResultMap are absent
            if (org.apache.commons.lang3.StringUtils.isAnyBlank(marksThreshold) && submissionResultMap.isEmpty()) {
                log.error("Marks threshold and List of IDs to shortlist/reject both are not provided we need any one");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Marks threshold and List of IDs to shortlist/reject both are not provided we need any one", null), HttpStatus.BAD_REQUEST);
            }

//             Check if both are present
            if (!org.apache.commons.lang3.StringUtils.isAnyBlank(marksThreshold) && submissionResultMap.size() != 1) {
                log.error("Marks threshold and List of IDs to shortlist/reject both are present we need any one");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Marks threshold and List of IDs to shortlist/reject both are present we need any one", null), HttpStatus.BAD_REQUEST);
            }


            if (!org.apache.commons.lang3.StringUtils.isAnyBlank(marksThreshold)) {
                log.info("Marks threshold value: {}", marksThreshold);

                List<DrillJudgingCriteria> criteriaList = drillJudgingCriteriaRepository.findByDrillIdAndPhaseId(drillPhases.getDrillId(), phaseId);
                double totalCriteriaMarks = 0;
                for (DrillJudgingCriteria criteria : criteriaList) {
                    totalCriteriaMarks += criteria.getCriteriaMaxMarks();
                }
                if (totalCriteriaMarks == 0) {
                    log.error("Total criteria marks not available");
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Total criteria marks not available", null), HttpStatus.BAD_REQUEST);
                }
                double threshold = Double.parseDouble(marksThreshold);

                if (threshold <= 0) {
                    log.error("Invalid marks threshold value: {}", marksThreshold);
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Marks threshold value must be greater than 0", null), HttpStatus.BAD_REQUEST);
                }
                if (threshold > totalCriteriaMarks) {
                    log.error("Threshold value is greater than total marks");
                    return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Threshold value is greater than total marks", null), HttpStatus.BAD_REQUEST);
                }

                List<DrillLeaderboard> leaderboardList = drillLeaderboardRepository.findAllByDrillIdAndPhaseId(drillPhases.getDrillId(), drillPhases.getPhaseId());
                List<DrillParticipantSubmission> submissionList = drillParticipantSubmissionRepository.findAllByPhaseIdAndIsActiveSubmission(phaseId, true);

                for (DrillParticipantSubmission submission : submissionList) {
                    for (DrillLeaderboard leaderboard : leaderboardList) {
                        if (submission.getSubmissionId().equals(leaderboard.getSubmissionId())) {
                            if (Double.parseDouble(leaderboard.getAverageMarks()) >= threshold) {
                                submission.setSubmissionResult(SubmissionResult.SHORTLISTED);
                            } else {
                                submission.setSubmissionResult(SubmissionResult.REJECTED);
                            }
                            drillParticipantSubmissionRepository.save(submission);
                            responseList.add(submission);
                        }
                    }
                }
            }
            if (!submissionResultMap.isEmpty()) {

                log.info("Shortlisting submissions: {}", submissionResultMap);
                for (Map.Entry<String, String> entry : submissionResultMap.entrySet()) {
                    String submissionId = entry.getKey();
                    String result = entry.getValue().toUpperCase();
                    if (result.equals("SHORTLISTED")) {
                        Optional<DrillParticipantSubmission> submission = drillParticipantSubmissionRepository.findById(submissionId);
                        if (submission.isPresent()) {
                            submission.get().setSubmissionResult(SubmissionResult.SHORTLISTED);
                            drillParticipantSubmissionRepository.save(submission.get());
                            responseList.add(submission.get());
                        }
                    } else if (result.equals("REJECTED")) {
                        Optional<DrillParticipantSubmission> submission = drillParticipantSubmissionRepository.findById(submissionId);
                        if (submission.isPresent()) {
                            submission.get().setSubmissionResult(SubmissionResult.REJECTED);
                            drillParticipantSubmissionRepository.save(submission.get());
                            responseList.add(submission.get());
                        }
                    }
                }
            }
            if (responseList.isEmpty()) {
                log.error("No submissions found to shortlist/reject");
                return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - No submissions found to shortlist/reject", null), HttpStatus.BAD_REQUEST);
            }
            log.info("Shortlisted submissions: {}", responseList);
            return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, responseList, null), HttpStatus.OK);

        } catch (Exception e) {
            log.error("Error occurred while shortlisting submissions: {}", e.getMessage());
            return new ResponseEntity<>(new Response(HttpStatus.INTERNAL_SERVER_ERROR.value(), Boolean.FALSE, e.getMessage(), null), HttpStatus.INTERNAL_SERVER_ERROR);

        }

    }


    public ResponseEntity<?> getDrillActiveSubmissionOfPhase(String drillId, String phaseId, InternityUser user) {

        // Check if phaseId is blank
        if (org.apache.commons.lang3.StringUtils.isAnyBlank(phaseId)) {
            log.error("Phase ID is blank");
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Phase ID is blank", null), HttpStatus.BAD_REQUEST);
        }

        // Check if the phase exists
        Optional<DrillPhases> drillPhaseObj = drillPhasesRepository.findById(phaseId);
        if (!drillPhaseObj.isPresent()) {
            log.error("Phase not found: {}", phaseId);
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Phase not found: " + phaseId, null), HttpStatus.BAD_REQUEST);
        }

        // Check if drillId is blank
        if (org.apache.commons.lang3.StringUtils.isAnyBlank(drillId)) {
            log.error("Drill ID is blank");
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Drill ID is blank", null), HttpStatus.BAD_REQUEST);
        }

        // Check if the drill exists
        Optional<Drill> drillObj = drillRepository.findById(drillId);
        if (!drillObj.isPresent()) {
            log.error("Drill not found: {}", drillId);
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - Drill not found: " + drillId, null), HttpStatus.BAD_REQUEST);
        }

        // Retrieve all active submissions for the given phase
        List<DrillParticipantSubmission> submissionList = drillParticipantSubmissionRepository.findAllByPhaseIdAndIsActiveSubmission(phaseId, true);

        // Return error if no submissions are found
        if (submissionList.isEmpty()) {
            log.error("No submissions found for phase: {}", phaseId);
            return new ResponseEntity<>(new Response(HttpStatus.BAD_REQUEST.value(), Boolean.FALSE, "Error - No submissions found for phase: " + phaseId, null), HttpStatus.BAD_REQUEST);
        }

        // Prepare the response DTO list
        List<DrillSubmissionsForShortlistResponseDto> responseDtoList = new ArrayList<>();

        //find total criteria marks
        List<DrillJudgingCriteria> criteriaList = drillJudgingCriteriaRepository.findByDrillIdAndPhaseId(drillId, phaseId);
        double totalCriteriaMarks = 0;
        for (DrillJudgingCriteria criteria : criteriaList) {
            totalCriteriaMarks += criteria.getCriteriaMaxMarks();
        }

        // Iterate over each submission and create the response DTO
        for (DrillParticipantSubmission submission : submissionList) {
            DrillSubmissionsForShortlistResponseDto responseDto = new DrillSubmissionsForShortlistResponseDto();
            List<DrillParticipant> drillParticipants = new ArrayList<>();
//
            DrillLeaderboard leaderboard = drillLeaderboardRepository.findByDrillIdAndPhaseIdAndSubmissionId(submission.getDrillId(), submission.getPhaseId(), submission.getSubmissionId());
            // If the submission is associated with a team, retrieve team details and participants
            if (!StringUtils.isEmpty(submission.getTeamId())
                    && !submission.getTeamId().equalsIgnoreCase("NA")
                    && submission.getTeamId() != null) {
                responseDto.setDrillTeamDetails(drillTeamsRepository.findById(submission.getTeamId()).get());
                List<TeamsParticipants> teamsParticipantsList = teamsParticipantsRepository.findByDrillIdAndTeamId(submission.getDrillId(), submission.getTeamId());
                if (!teamsParticipantsList.isEmpty()) {
                    for (TeamsParticipants teamsParticipants : teamsParticipantsList) {
                        Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(teamsParticipants.getParticipantId());
                        drillParticipantOptional.ifPresent(drillParticipants::add);
                    }
                }
            } else {
                // If the submission is not associated with a team, retrieve participant details
                Optional<DrillParticipant> drillParticipantOptional = drillParticipantRepository.findById(submission.getParticipantId());
                drillParticipantOptional.ifPresent(drillParticipants::add);
                responseDto.setDrillTeamDetails(null);
            }

            // Set the submission and participants details in the response DTO
            responseDto.setCriteriaTotalMarks(totalCriteriaMarks);
            responseDto.setDrillLatestSubmission(submission);
            responseDto.setTeamAllParticipantsDetails(drillParticipants);
            responseDto.setPhasesDetails(drillPhaseObj.get());
            responseDto.setDrillId(drillObj.get().getDrillId());
            if (submission.getPanelId() != null) {
                responseDto.setPanelDetails(drillJudgementPanelRepository.findById(submission.getPanelId()).orElse(null));
            } else {
                responseDto.setPanelDetails(null);
            }

            // Set phase marks if evaluation exists
            if (leaderboard == null) {
                responseDto.setPhaseAverageMarks(null);
            } else {
                responseDto.setPhaseAverageMarks(leaderboard.getAverageMarks());
            }

            // Add the response DTO to the list
            responseDtoList.add(responseDto);
        }

        // Return the response DTO list
        return new ResponseEntity<>(new Response(HttpStatus.OK.value(), Boolean.TRUE, responseDtoList, null), HttpStatus.OK);
    }


}
