package com.wue.service;

import java.util.*;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.constant.SearchProfile;
import com.wue.constant.UserRoles;
import com.wue.custom.specification.SearchBlogPostCriteria;
import com.wue.custom.specification.SearchReportAbuseCriteria;
import com.wue.domain.User;
import com.wue.domain.blog.*;
import com.wue.dto.BlogPostCommentResponseDto;
import com.wue.dto.BlogPostDto;
import com.wue.dto.BlogPostSearchResultDto;
import com.wue.dto.response.Response;
import com.wue.dto.search.BlogPostSpecification;
import com.wue.dto.search.ReportAbuseSpecification;
import com.wue.repository.UserCandidateMandatoryFieldsRepository;
import com.wue.repository.UserProfileRepository;
import com.wue.repository.UserRepository;
import com.wue.repository.blog.*;
import com.wue.util.drill.ResponseUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.apache.commons.lang3.StringUtils;
import com.wue.dto.BlogPostUpdateRequestDto;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;

import lombok.extern.log4j.Log4j2;

import javax.management.relation.Role;

@Service
@Log4j2
public class BlogService {

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    BlogPostRepository blogPostRepository;

    @Autowired
    BlogCategoryRepository blogCategoryRepository;

    @Autowired
    CommentRepository commentRepository;

    @Autowired
    ReactionRepository reactionRepository;

    @Autowired
    ReportAbuseRepository reportAbuseRepository;

    @Autowired
    ResponseUtil responseUtil;

    @Autowired
    UserRepository userRepository;

    @Autowired
    ReactionTypeRepository reactionTypeRepository;
    @Autowired
    UserCandidateMandatoryFieldsRepository userCandidateMandatoryFieldsRepository;
    @Autowired
    UserProfileRepository userProfileRepository;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    CommentReactionRepository commentReactionRepository;


    public Response saveBlogPost(BlogPost payload, InternityUser user) {
        try {
            log.info("Blog Post save Request Received ::: {}", payload);
            if (StringUtils.isAnyBlank(payload.getUId())) {
                log.warn("User ID is blank ::: {}", payload.getUId());
                return responseUtil.badRequestResponse("User ID should not be empty or undefined");
            }
            if (StringUtils.isAnyBlank(payload.getCategoryId())) {
                log.warn("Blog Category ID is blank ::: {}", payload.getCategoryId());
                return responseUtil.badRequestResponse("Blog Category ID should not be empty or undefined");
            }
            if (StringUtils.isAnyBlank(payload.getTitle())) {
                log.warn("Blog title is blank ::: {}", payload.getTitle());
                return responseUtil.badRequestResponse("Blog title should not be empty or undefined");
            }
            if (StringUtils.isAnyBlank(payload.getContent())) {
                log.warn("Blog content is blank ::: {}", payload.getContent());
                return responseUtil.badRequestResponse("Blog content should not be empty or undefined");
            }
            Optional<User> userOptional = userRepository.findById(payload.getUId());
            if (!userOptional.isPresent()) {
                log.warn("User not found with the specified ID ::: {}", payload.getUId());
                return responseUtil.notFoundResponse("User not found with the specified ID");
            }
            Optional<BlogCategory> blogCategoryOptional = blogCategoryRepository.findById(payload.getCategoryId());
            if (!blogCategoryOptional.isPresent()) {
                log.warn("Blog Category not found with the specified ID ::: {}", payload.getUId());
                return responseUtil.notFoundResponse("Blog Category not found with the specified ID");
            }

            // Set custUrl if it is blank
            if (StringUtils.isBlank(payload.getCustUrl())) {
                String custUrl = payload.getTitle().toLowerCase().replaceAll("[^a-zA-Z0-9\\s-]+", "-").replaceAll("\\s+", "-").replaceAll("-+", "-").replaceAll("-$", "");
                int count = blogPostRepository.countByCustUrlStartingWith(custUrl);
                if (count > 0) {
                    custUrl = custUrl + "-" + (count);
                }
                payload.setCustUrl(custUrl);
            } else {
                //check if url already exists
                String custUrl= payload.getCustUrl().toLowerCase().replaceAll("[^a-zA-Z0-9\\s-]+", "-").replaceAll("\\s+", "-").replaceAll("-+", "-").replaceAll("-$", "");
                Optional<BlogPost> blogPostOptional = blogPostRepository.findByCustUrl(custUrl);
                if (blogPostOptional.isPresent()) {
                    log.warn("Blog Post already exists with the specified custUrl ::: {} ::: {}", payload.getCustUrl(),custUrl);
                    return responseUtil.conflictResponse("Blog Post already exists with the specified custom URL");
                }
                //set custUrl
                payload.setCustUrl(custUrl);
            }
            payload.setName(userOptional.get().getFullName());

            BlogPost savedBlogPost = blogPostRepository.save(payload);
            log.info("Blog post successfully ::: {}", savedBlogPost);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedBlogPost, null);
        } catch (Exception e) {
            log.error("Exception while saving blog post: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while saving blog post. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response getBlogPosts(SearchBlogPostCriteria searchCriteria, int offset, int limit, String order, SearchProfile profile, InternityUser user) {
        try {
            log.info("Search criteria: {}", searchCriteria);

            BlogPostSearchResultDto blogPostSearchResultDto = null;
            String[] sort = order.split("\\.");
            Sort direction = Sort.by("desc".equalsIgnoreCase(sort[1]) ? Sort.Direction.DESC : Sort.Direction.ASC, sort[0]);
            Pageable pageable = PageRequest.of(offset, limit, direction);
            Page<BlogPost> page = blogPostRepository.findAll(new BlogPostSpecification(searchCriteria, blogCategoryRepository), pageable);

            List<BlogPostDto> blogPostDtos = page.getContent().stream().map(blogPost ->
                    new BlogPostDto(blogPost, userCandidateMandatoryFieldsRepository, userProfileRepository, blogCategoryRepository)).collect(Collectors.toList());
            blogPostSearchResultDto =
                    BlogPostSearchResultDto.builder()
                            .data(blogPostDtos)
                            .totalRecordCount(page.getTotalElements())
                            .build();
            log.info("get blog post successfully ::: {}");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, blogPostSearchResultDto, null);
        } catch (Exception e) {
            log.error("Exception while fetching blog posts: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Error occurred while fetching blog posts.");
        }
    }

    public Response updateBlogPost(String blogPostId, BlogPost payload, InternityUser user) {
        try {
            log.info("update Blog post request received ::: {}", payload);
            Optional<BlogPost> blogPostOptional = blogPostRepository.findById(blogPostId);
            if (!blogPostOptional.isPresent()) {
                log.warn("Blog Post Id not exits ::: {}", blogPostId);
                return responseUtil.notFoundResponse("Blog post with blogpostId " + blogPostId + " not found.");
            }

            BlogPost existingBlogPost = blogPostOptional.get();

            if (StringUtils.isNoneBlank(payload.getUId())) {
                Optional<User> userOptional = userRepository.findById(payload.getUId());
                if (!userOptional.isPresent()) {
                    log.warn("user not exits with this Id ::: {}", payload.getUId());
                    return responseUtil.notFoundResponse("user not found with this ID");
                }
                if (!existingBlogPost.getUId().equals(payload.getUId()) && !userOptional.get().getURole().equals(UserRoles.SUPERADMIN.toString())) {
                    return responseUtil.forbiddenResponse("You do not have permission to update this blog post.");
                }

            }

            // Check and update each attribute of the payload if it's not null
            if (StringUtils.isNoneBlank(payload.getTitle())) {
                existingBlogPost.setTitle(payload.getTitle());
            }

            if (StringUtils.isNoneBlank(payload.getCategoryId())) {
                Optional<BlogCategory> blogCategoryOptional = blogCategoryRepository.findById(payload.getCategoryId());
                if (!blogCategoryOptional.isPresent()) {
                    log.warn("category Id not exits ::: {}");
                    return responseUtil.notFoundResponse("Blog Post update Category Id Invalid ::: {}");
                }
                existingBlogPost.setCategoryId(payload.getCategoryId());
            }

            if (StringUtils.isNoneBlank(payload.getContent())) {
                existingBlogPost.setContent(payload.getContent());
            }

            if (StringUtils.isNoneBlank(payload.getSummary())) {
                existingBlogPost.setSummary(payload.getSummary());
            }

            if (StringUtils.isNoneBlank(payload.getCoverImgUrl())) {
                existingBlogPost.setCoverImgUrl(payload.getCoverImgUrl());
            }

            if (StringUtils.isNoneBlank(payload.getTags())) {
                existingBlogPost.setTags(payload.getTags());
            }
            if (StringUtils.isNoneBlank(payload.getCustUrl())) {
                existingBlogPost.setCustUrl(payload.getCustUrl().toLowerCase().replaceAll("[^a-zA-Z0-9\\s-]+", "-").replaceAll("\\s+", "-").replaceAll("-+", "-").replaceAll("-$", ""));
            }

            log.info("Blog Post Updated Successfully ::: {}");
            BlogPost updatedBlogPost = blogPostRepository.save(existingBlogPost);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, updatedBlogPost, null);
        } catch (Exception e) {
            log.error("Exception while updating blog post: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while updating blog post. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response updateBlogPostStatus(String blogpostId, String status, String uId, BlogPostUpdateRequestDto updateRequest, InternityUser user) {
        try {
            log.info("Update blog Post request status received ::: {}", status);
            if (StringUtils.isAnyBlank(uId)) {
                log.warn("User ID is blank ::: {}", uId);
                return responseUtil.badRequestResponse("User ID should not be empty or undefined");
            }
            Optional<User> optionalUser = userRepository.findById(uId);
            if (!optionalUser.isPresent()) {
                log.warn("User not exits with specified ID ::: {}", uId);
                return responseUtil.notFoundResponse("");
            }
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(blogpostId);
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not exits ::: {} ");
                return responseUtil.notFoundResponse("Blog post with ID " + blogpostId + " not found");
            }
            BlogPost blogPost = optionalBlogPost.get();
            switch (status.toLowerCase()) {
                case "isfeatured":
                    if (updateRequest.getIsFeatured() != null) {
                        String role = optionalUser.get().getURole();
                        if (!role.equalsIgnoreCase(UserRoles.SUPERADMIN.toString())) {
                            log.warn("User didn't have super admin role so does not change features status");
                            return responseUtil.notFoundResponse("user have not authority to change post to feature");
                        }
                        blogPost.setFeatured(updateRequest.getIsFeatured());
                    }
                    break;
                case "isactive":
                    if (updateRequest.getIsActive() != null) {
                        blogPost.setActive(updateRequest.getIsActive());
                    }
                    break;
                default:
                    return responseUtil.badRequestResponse("Invalid status provided. Supported statuses are 'isFeatured' and 'isActive'.");
            }

            BlogPost updatedBlogPost = blogPostRepository.save(blogPost);
            log.info("Blog Post update status request successfully");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, updatedBlogPost, null);
        } catch (Exception e) {
            log.error("Exception while updating blog post: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("\"Exception while updating blog post. Please contact admin or mail \" +\n" +
                    "                            \"to support@wuelev8.tech\"");
        }
    }

    public Response saveBlogCategory(BlogCategory payload, InternityUser user) {
        try {
            log.info("Blog post category request received ::: {}", payload);
            if (StringUtils.isAnyBlank(payload.getName())) {
                log.warn("Blog Category Name is blank ::: {}", payload.getName());
                responseUtil.badRequestResponse("Blog Category Name should not be empty or undefined");
            }

            if (StringUtils.isAnyBlank(payload.getBackgroundImg())) {
                log.warn("Blog Category Img url is blank ::: {}", payload.getName());
                responseUtil.badRequestResponse("Blog Category Img url should not be empty or undefined");
            }
            log.info("Successfully save blog category");
            BlogCategory savedBlogCategory = blogCategoryRepository.save(payload);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedBlogCategory, null);
        } catch (Exception e) {
            log.error("Exception while saving blog category::: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while saving blog category. Please contact admin or mail " +
                    "to support@wuelev8.tech");

        }
    }

    public Response getBlogCategories(String categoryId, InternityUser user) {
        try {
            log.info("get blog post request ::: {}");
            if ("NA".equalsIgnoreCase(categoryId)) {
                log.info("get all blog category ::: {} ");
                List<BlogCategory> blogCategories = blogCategoryRepository.findAll();
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, blogCategories, null);
            } else {
                log.info("get blog category ID ::: {}", categoryId);
                Optional<BlogCategory> blogCategory = blogCategoryRepository.findById(categoryId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, blogCategory.get(), null);
            }
        } catch (Exception e) {
            log.error("Exception while retrieving blog categories: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while retrieving blog categories. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response updateBlogCategory(String categoryId, BlogCategory payload, InternityUser user) {
        try {
            log.info("update Blog Category request received ::: {}", payload);
            Optional<BlogCategory> optionalBlogCategory = blogCategoryRepository.findById(categoryId);
            if (!optionalBlogCategory.isPresent()) {
                log.warn("Blog Category not found with the specified ID ::: {}", categoryId);
                return responseUtil.notFoundResponse("Blog Category not found with the specified ID");
            }
            BlogCategory blogCategory = optionalBlogCategory.get();
            if (StringUtils.isNoneBlank(payload.getName())) {
                log.info("Update Blog Category Name ::: {}", payload.getName());
                blogCategory.setName(payload.getName());
            }
            if (StringUtils.isNoneBlank(payload.getBackgroundImg())) {
                log.info("update Blog Category Img url ::: {}", payload.getBackgroundImg());
                blogCategory.setBackgroundImg(payload.getBackgroundImg());
            }
            log.info("blog category updated successfully ::: {}");
            BlogCategory updatedBlogCategory = blogCategoryRepository.save(blogCategory);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, updatedBlogCategory, null);

        } catch (Exception e) {
            log.error("Exception while updating blog category: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while updating blog category. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response saveComment(Comment payload, InternityUser user) {
        try {
            log.info("Comment request received ::: {}", payload);
            // Check if blogpostId is blank
            if (StringUtils.isAnyBlank(payload.getBlogpostId())) {
                log.warn("BlogpostId is blank or null");
                return responseUtil.badRequestResponse("BlogpostId is blank or null");
            }

            // Check if UId is blank
            if (StringUtils.isAnyBlank(payload.getUId())) {
                log.warn("UId is blank or null");
                return responseUtil.badRequestResponse("UId is blank or null");
            }

            // Find user by UId
            Optional<User> optionalUser = userRepository.findById(payload.getUId());
            if (!optionalUser.isPresent()) {
                log.warn("User not found for UId: {}", payload.getUId());
                return responseUtil.notFoundResponse("");
            }

            // Find blog post by blogpostId
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(payload.getBlogpostId());
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not found for blogpostId: {}", payload.getBlogpostId());
                return responseUtil.notFoundResponse("");
            }

            BlogPost blogPost = optionalBlogPost.get();
            blogPost.setCommentCount(blogPost.getCommentCount() + 1);
            blogPostRepository.save(blogPost);
            // save commenterName
            payload.setCommenterName(optionalUser.get().getFullName());
            // Save the comment
            if (StringUtils.isBlank(payload.getParentCommentId())) {
                payload.setParentCommentId("NA");
            }
            Comment savedComment = commentRepository.save(payload);
            log.info("Comment saved successfully");

            // Return success response
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedComment, null);
        } catch (Exception e) {
            // Log error if any exception occurs
            log.error("Exception while saving comment: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while saving comment. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }


    public Response getComments(String commentId, String blogpostId, String uId, InternityUser user, String parentCommentId) {
        try {
            log.info("Get comment request received");
            List<Comment> comments = null;
            if ("NA".equalsIgnoreCase(blogpostId) && "NA".equalsIgnoreCase(uId) && "NA".equalsIgnoreCase(commentId) && "NA".equalsIgnoreCase(parentCommentId)) {
                // If all three parameters are "NA," retrieve all comments
                log.info("Retrieving all comments");
                comments = commentRepository.findAll();
            } else {
                // If any of the parameters (blogpostId or uId) is provided, retrieve comments based on provided parameters
                log.info("Retrieving comments based on blogpostId: {}, uId: {}, parentCommentId: {}, commentId: {}", blogpostId, uId, parentCommentId, commentId);
                if (!"NA".equalsIgnoreCase(blogpostId)) {
                    log.info("Retrieving comments based on blogpostId: {}", blogpostId);
                    comments = commentRepository.findByBlogpostIdAndParentCommentId(blogpostId, "NA");
                } else if (!"NA".equalsIgnoreCase(uId) && "NA".equalsIgnoreCase(parentCommentId) && "NA".equalsIgnoreCase(commentId) && "NA".equalsIgnoreCase(blogpostId)) {
                    log.info("Retrieving comments based on uId: {}", uId);
                    comments = commentRepository.findByuId(uId);
                } else if (!"NA".equalsIgnoreCase(parentCommentId)) {
                    log.info("Retrieving comments based on parentCommentId: {}", parentCommentId);
                    comments = commentRepository.findByParentCommentId(parentCommentId);
                } else if (!"NA".equalsIgnoreCase(commentId)) {
                    log.info("Retrieving comments based on commentId: {}", commentId);
                    comments = commentRepository.findByCommentId(commentId);
                }
            }

            if (comments == null) {
                log.warn("No comments found for this Blog Post");
                return responseUtil.badRequestResponse("No comments found for this Blog Post");
            }
            // Sort the comments based on recordCreatedTs (latest first)
            comments.sort(Comparator.nullsLast(Comparator.comparing(Comment::getRecordCreatedTs, Comparator.reverseOrder())));

            List<BlogPostCommentResponseDto> commentResponseList = comments.stream()
                    .map(comment -> {
                        BlogPostCommentResponseDto commentResponseDto = objectMapper.convertValue(comment, BlogPostCommentResponseDto.class);
                        //set user profile
                        userProfileRepository.findByuId(comment.getUId()).ifPresent(userProfile -> commentResponseDto.setCommenterImageUrl(userProfile.getProfilePicLink()));
                        // Retrieve comment reaction if exists
                        if (!"NA".equalsIgnoreCase(uId)) {
                            CommentReaction commentReaction = commentReactionRepository.findByuIdAndCommentId(uId, comment.getCommentId());
                            if (commentReaction != null) {
                                commentResponseDto.setCommentReaction(commentReaction);
                            }
                        }
                        // set child comments count
                        commentResponseDto.setChildCommentsCount(commentRepository.countByParentCommentId(comment.getCommentId()));
                        // return
                        return commentResponseDto;
                    })
                    .collect(Collectors.toList());
            log.info("Comments retrieved successfully");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, commentResponseList, null);
        } catch (Exception e) {
            log.error("Exception while retrieving comments: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while retrieving comments. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response updateComment(String commentId, Comment payload, InternityUser user) {
        try {
            log.info("update comment request received ::: {}", payload);
            Optional<Comment> optionalComment = commentRepository.findById(commentId);
            if (!optionalComment.isPresent()) {
                log.warn("Comment Id Does not exists");
                return responseUtil.notFoundResponse("Comment not found with this specified Id");
            }
            Comment comment = optionalComment.get();
            if (StringUtils.isNoneBlank(payload.getContent())) {
                comment.setContent(payload.getContent());
            }
            Comment updatedComment = commentRepository.save(comment);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, updatedComment, null);

        } catch (Exception e) {
            log.error("Exception while updating comment: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while updating comment. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response saveReaction(Reaction payload, InternityUser user) {
        try {
            // Check if blogpostId is blank
            if (StringUtils.isAnyBlank(payload.getPostId())) {
                log.warn("BlogpostId is blank or null");
                return responseUtil.badRequestResponse("BlogpostId is blank or null");
            }

            // Check if UId is blank
            if (StringUtils.isAnyBlank(payload.getUId())) {
                log.warn("UId is blank or null");
                return responseUtil.badRequestResponse("UId is blank or null");
            }

            // Find user by UId
            Optional<User> optionalUser = userRepository.findById(payload.getUId());
            if (!optionalUser.isPresent()) {
                log.warn("User not found for UId: {}", payload.getUId());
                return responseUtil.notFoundResponse("");
            }

            // Find blog post by blogpostId
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(payload.getPostId());
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not found for blogpostId: {}", payload.getPostId());
                return responseUtil.notFoundResponse("");
            }
            Reaction reaction = reactionRepository.findByuIdAndPostId(payload.getUId(), payload.getPostId());
            if (reaction != null) {
                return responseUtil.badRequestResponse("Reaction already exists");
            }
            BlogPost blogPost = optionalBlogPost.get();
            blogPost.setReactionCount(blogPost.getReactionCount() + 1);
            blogPostRepository.save(blogPost);

            Reaction savedReaction = reactionRepository.save(payload);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedReaction, null);
        } catch (Exception e) {
            log.error("Exception while saving reaction: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while saving reaction. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response getReactions(String reactionId, String postId, String uId, InternityUser user) {
        try {
            List<Reaction> reactions = null;
            if ("NA".equalsIgnoreCase(reactionId) && "NA".equalsIgnoreCase(postId) && "NA".equalsIgnoreCase(uId)) {
                reactions = reactionRepository.findAll();
            } else if (!"NA".equals(reactionId)) {
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, reactionRepository.findByReactionId(reactionId), null);
            } else if (!"NA".equals(postId) && "NA".equals(uId)) {
                reactions = reactionRepository.findByPostId(postId);
            } else if ("NA".equals(postId) && !"NA".equals(uId)) {
                reactions = reactionRepository.findByuId(uId);
            } else if (!"NA".equals(postId)) {
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, reactionRepository.findByuIdAndPostId(uId, postId), null);
            }
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, reactions, null);
        } catch (Exception e) {
            log.error("Exception while retrieving reactions: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while retrieving reactions. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response updateReaction(String reactionId, Reaction payload, InternityUser user) {
        try {
            if (StringUtils.isBlank(reactionId)) {
                log.warn("ReactionId is blank or null");
                return responseUtil.badRequestResponse("ReactionId is blank or null");
            }
            Optional<Reaction> optionalReaction = reactionRepository.findById(reactionId);
            if (!optionalReaction.isPresent()) {
                log.warn("Reaction not found with ID ::: {}");
                return responseUtil.badRequestResponse("Reaction not found with specified ID :::{}");
            }
            if (StringUtils.isBlank(payload.getPostId())) {
                log.warn("PostId is blank or null");
                return responseUtil.badRequestResponse("PostId is blank or null");
            }
            // Find blog post by blogpostId
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(payload.getPostId());
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not found for blogpostId: {}", payload.getPostId());
                return responseUtil.notFoundResponse("");
            }
            Reaction reaction = optionalReaction.get();
            if (payload.getType().equalsIgnoreCase("NONE")) {
                reactionRepository.delete(reaction);
                optionalBlogPost.get().setReactionCount(optionalBlogPost.get().getReactionCount() - 1);
                blogPostRepository.save(optionalBlogPost.get());
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "update reaction successfully", null);
            }
            if (StringUtils.isNoneBlank(payload.getType())) {
                reaction.setType(payload.getType());
            }
            Reaction updatedReaction = reactionRepository.save(reaction);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, updatedReaction, null);

        } catch (Exception e) {
            log.error("Exception while updating reaction: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while updating reaction. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response getReportAbuseEntries(String reportId, String postId, InternityUser user) {
        try {
            if ("NA".equalsIgnoreCase(reportId) && "NA".equalsIgnoreCase(postId)) {
                List<ReportAbuse> reportAbuseEntries = reportAbuseRepository.findAll();
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, reportAbuseEntries, null);
            } else {
                List<ReportAbuse> reportAbuseEntries = reportAbuseRepository.findByReportIdOrPostId(reportId, postId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, reportAbuseEntries, null);
            }
        } catch (Exception e) {
            log.error("Exception while retrieving report abuse entries: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while retrieving report abuse entries. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response saveReportAbuse(ReportAbuse payload, InternityUser user) {
        try {
            // Check if blogpostId is blank
            if (StringUtils.isAnyBlank(payload.getPostId())) {
                log.warn("BlogpostId is blank or null");
                return responseUtil.badRequestResponse("BlogpostId is blank or null");
            }

            // Check if UId is blank
            if (StringUtils.isAnyBlank(payload.getUId())) {
                log.warn("UId is blank or null");
                return responseUtil.badRequestResponse("UId is blank or null");
            }

            // Find user by UId
            Optional<User> optionalUser = userRepository.findById(payload.getUId());
            if (!optionalUser.isPresent()) {
                log.warn("User not found for UId: {}", payload.getUId());
                return responseUtil.notFoundResponse("User not found for UId");
            }

            // Find blog post by blogpostId
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(payload.getPostId());
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not found for blogpostId: {}", payload.getPostId());
                return responseUtil.notFoundResponse("blog post not found with specified ID");
            }
            if (!StringUtils.isBlank(payload.getCommentId())) {
                Comment comment = commentRepository.findById(payload.getCommentId()).orElse(null);
                if (comment == null) {
                    log.warn("Comment not found for commentId: {}", payload.getCommentId());
                    return responseUtil.notFoundResponse("Comment not found for commentId: " + payload.getCommentId());
                }
                comment.setReportAbuseCount(comment.getReportAbuseCount() + 1);
                commentRepository.save(comment);
            } else {
                payload.setCommentId(null);
                optionalBlogPost.get().setReportAbuseCount(optionalBlogPost.get().getReportAbuseCount() + 1);
                blogPostRepository.save(optionalBlogPost.get());
            }
            ReportAbuse savedReportAbuse = reportAbuseRepository.save(payload);

            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedReportAbuse, null);
        } catch (Exception e) {
            log.error("Exception while saving report abuse: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while saving report abuse. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response getAllReactionTypes(String reactionTypeId, InternityUser user) {
        try {
            if ("NA".equalsIgnoreCase(reactionTypeId)) {
                List<ReactionType> reactionTypeList = reactionTypeRepository.findAll();
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, reactionTypeList, null);
            } else {
                List<ReactionType> reactionTypeList = reactionTypeRepository.findByReactionTypeId(reactionTypeId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, reactionTypeList, null);
            }
        } catch (Exception e) {
            log.error("Exception while retrieving reaction Type entries: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while retrieving reaction type entries. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response saveReactionType(ReactionType payload, InternityUser user) {
        try {
            log.info("Attempting to save reaction type.");

            if (StringUtils.isAnyBlank(payload.getName())) {
                log.warn("Name field is blank in the payload. Cannot proceed.");
                return responseUtil.badRequestResponse("Name field cannot be blank.");
            }

            if (StringUtils.isAnyBlank(payload.getImgUrl())) {
                log.warn("Image URL field is blank in the payload. Cannot proceed.");
                return responseUtil.badRequestResponse("Image URL field cannot be blank.");
            }

            ReactionType reactionType = reactionTypeRepository.save(payload);
            log.info("Reaction type saved successfully.");

            return new Response(HttpStatus.OK.value(), Boolean.TRUE, reactionType, null);

        } catch (Exception e) {
            log.error("Exception while saving reaction Type entries: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while saving reaction type entries. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response addBlogPostShareCount(String blogPostId, InternityUser user) {
        try {
            // Check if blogpostId is blank
            if (StringUtils.isAnyBlank(blogPostId)) {
                log.warn("BlogpostId is blank or null");
                return responseUtil.badRequestResponse("BlogpostId is blank or null");
            }

            // Find blog post by blogpostId
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(blogPostId);
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not found for blogpostId: {}", blogPostId);
                return responseUtil.notFoundResponse("blog post not found for blogpostId");
            }
            // check if count exist then increment it else save 1
            log.info("Blog post share count: {}", optionalBlogPost.get().getShareCount());
            optionalBlogPost.get().setShareCount(optionalBlogPost.get().getShareCount() + 1);
            log.info("saving info in db after count update");
            BlogPost savedBlog = blogPostRepository.save(optionalBlogPost.get());

            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedBlog.getShareCount(), null);
        } catch (Exception e) {
            log.error("Exception while adding blog post share count: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while adding blog post share count. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response getBlogPostShareCount(String blogPostId, InternityUser user) {
        try {
            // Check if blogpostId is blank
            if (StringUtils.isAnyBlank(blogPostId)) {
                log.warn("BlogpostId is blank or null");
                return responseUtil.badRequestResponse("BlogpostId is blank or null");
            }
            // Find blog post by blogpostId
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(blogPostId);
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not found for blogpostId: {}", blogPostId);
                return responseUtil.notFoundResponse("blog post not found for blogpostId");
            }
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, optionalBlogPost.get().getShareCount(), null);
        } catch (Exception e) {
            log.error("Exception while getting blog post share count: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while getting blog post share count. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response saveCommentReaction(CommentReaction payload, InternityUser user) {
        try {
            // Check if blogpostId is blank
            if (StringUtils.isAnyBlank(payload.getPostId())) {
                log.warn("BlogpostId is blank or null");
                return responseUtil.badRequestResponse("BlogpostId is blank or null");
            }

            // Check if UId is blank
            if (StringUtils.isAnyBlank(payload.getUId())) {
                log.warn("UId is blank or null");
                return responseUtil.badRequestResponse("UId is blank or null");
            }
            if (StringUtils.isAnyBlank(payload.getCommentId())) {
                log.warn("CommentId is blank or null");
                return responseUtil.badRequestResponse("CommentId is blank or null");
            }

            // Find user by UId
            Optional<User> optionalUser = userRepository.findById(payload.getUId());
            if (!optionalUser.isPresent()) {
                log.warn("User not found for UId: {}", payload.getUId());
                return responseUtil.notFoundResponse("");
            }

            // Find blog post by blogpostId
            Optional<BlogPost> optionalBlogPost = blogPostRepository.findById(payload.getPostId());
            if (!optionalBlogPost.isPresent()) {
                log.warn("Blog post not found for blogpostId: {}", payload.getPostId());
                return responseUtil.notFoundResponse("");
            }

            // Find comment by commentId
            Optional<Comment> optionalComment = commentRepository.findById(payload.getCommentId());
            if (!optionalComment.isPresent()) {
                log.warn("Comment not found for commentId: {}", payload.getCommentId());
                return responseUtil.notFoundResponse("comment not found for commentId");
            }
            CommentReaction existingReaction = commentReactionRepository.findByuIdAndCommentId(payload.getUId(), payload.getCommentId());
            if (existingReaction != null) {
                return responseUtil.badRequestResponse("Reaction already exists");
            }
            CommentReaction savedReaction = commentReactionRepository.save(payload);
            optionalComment.get().setCommentReactionCount(optionalComment.get().getCommentReactionCount() + 1);
            commentRepository.save(optionalComment.get());
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, savedReaction, null);
        } catch (Exception e) {
            log.error("Exception while saving reaction: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while saving reaction. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response updateCommentReaction(String reactionId, CommentReaction payload, InternityUser user) {
        try {
            Optional<CommentReaction> optionalReaction = commentReactionRepository.findById(reactionId);
            if (!optionalReaction.isPresent()) {
                log.warn("Reaction not found with ID ::: {}");
                return responseUtil.badRequestResponse("Reaction not found with specified ID :::{}");
            }
            if (StringUtils.isAnyBlank(payload.getCommentId())) {
                log.warn("CommentId is blank or null");
                return responseUtil.badRequestResponse("CommentId is blank or null");
            }

            // Find comment by commentId
            Optional<Comment> optionalComment = commentRepository.findById(payload.getCommentId());
            if (!optionalComment.isPresent()) {
                log.warn("Comment not found for commentId: {}", payload.getCommentId());
                return responseUtil.notFoundResponse("Comment not found for commentId");
            }
            CommentReaction reaction = optionalReaction.get();
            if (payload.getType().equalsIgnoreCase("NONE")) {
                commentReactionRepository.delete(reaction);
                optionalComment.get().setCommentReactionCount(optionalComment.get().getCommentReactionCount() - 1);
                commentRepository.save(optionalComment.get());
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "update reaction successfully", null);
            }
            if (StringUtils.isNoneBlank(payload.getType())) {
                reaction.setType(payload.getType());
            }
            CommentReaction updatedReaction = commentReactionRepository.save(reaction);
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, updatedReaction, null);

        } catch (Exception e) {
            log.error("Exception while updating reaction: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while updating reaction. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
    }

    public Response getCommentReactions(String commentReactionId, String commentId, String uId, String blogPostId, InternityUser user) {
        try {
            if (!"NA".equalsIgnoreCase(commentReactionId)) {
                // If commentReactionId is provided, retrieve reactions based on commentReactionId only
                Optional<CommentReaction> commentReaction = commentReactionRepository.findById(commentReactionId);
                return commentReaction.map(reaction -> new Response(HttpStatus.OK.value(), Boolean.TRUE, reaction, null)).orElseGet(() -> responseUtil.badRequestResponse("comment reaction not found with specified ID"));
            } else if (!"NA".equalsIgnoreCase(commentId) && "NA".equalsIgnoreCase(uId)) {
                Comment comment = commentRepository.findById(commentId).orElse(null);
                if (comment == null) {
                    log.warn("Comment not found for commentId: {}", commentId);
                    return responseUtil.notFoundResponse("comment not found for commentId");
                }
                // If commentId is provided, retrieve reactions based on commentId only
                List<CommentReaction> commentReactions = commentReactionRepository.findByCommentId(commentId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, commentReactions, null);
            } else if (!"NA".equalsIgnoreCase(uId) && "NA".equalsIgnoreCase(commentId)) {
                User getUser = userRepository.findById(uId).orElse(null);
                if (getUser == null) {
                    log.warn("User not found for uId: {}", uId);
                    return responseUtil.notFoundResponse("user not found for uId");
                }
                // If uId is provided, retrieve reactions based on uId only
                List<CommentReaction> commentReactions = commentReactionRepository.findByuId(uId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, commentReactions, null);
            } else if (!"NA".equalsIgnoreCase(uId) && !"NA".equalsIgnoreCase(commentId)) {
                Comment comment = commentRepository.findById(commentId).orElse(null);
                if (comment == null) {
                    log.warn("Comment not found for commentId: {}", commentId);
                    return responseUtil.notFoundResponse("comment not found for commentId");
                }
                User getUser = userRepository.findById(uId).orElse(null);
                if (getUser == null) {
                    log.warn("User not found for uId: {}", uId);
                    return responseUtil.notFoundResponse("user not found for uId");
                }
                List<CommentReaction> commentReactions = commentReactionRepository.findAllByuIdAndCommentId(uId, commentId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, commentReactions, null);
            } else if (!"NA".equalsIgnoreCase(blogPostId) && "NA".equalsIgnoreCase(uId)) {
                BlogPost blogPost = blogPostRepository.findById(blogPostId).orElse(null);
                if (blogPost == null) {
                    log.warn("Blog post not found for blogPostId: {}", blogPostId);
                    return responseUtil.notFoundResponse("blog post not found for blogPostId");
                }
                // If blogPostId is provided, retrieve reactions based on blogPostId only
                List<CommentReaction> commentReactions = commentReactionRepository.findByPostId(blogPostId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, commentReactions, null);
            } else if (!"NA".equalsIgnoreCase(blogPostId) && !"NA".equalsIgnoreCase(uId)) {
                BlogPost blogPost = blogPostRepository.findById(blogPostId).orElse(null);
                if (blogPost == null) {
                    log.warn("Blog post not found for blogPostId: {}", blogPostId);
                    return responseUtil.notFoundResponse("blog post not found for blogPostId");
                }
                User getUser = userRepository.findById(uId).orElse(null);
                if (getUser == null) {
                    log.warn("User not found for uId: {}", uId);
                    return responseUtil.notFoundResponse("user not found for uId");
                }
                List<CommentReaction> commentReactions = commentReactionRepository.findByuIdAndPostId(uId, blogPostId);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, commentReactions, null);
            }
        } catch (Exception e) {
            log.error("Exception while getting comment reactions: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception while getting comment reactions. Please contact admin or mail " +
                    "to support@wuelev8.tech");
        }
        return responseUtil.internalServerErrorResponse("Something went wrong, please try again later");
    }

    public Response getReportAbuseEntriesSearch(SearchReportAbuseCriteria searchCriteria, int offset, int limit, String order, InternityUser user, SearchProfile profile) {
        try {
            log.info("Search criteria: {}", searchCriteria);
            List<ReportAbuse> reportAbuseEntries;
            String[] sort = order.split("\\.");
            Sort direction = Sort.by("desc".equalsIgnoreCase(sort[1]) ? Sort.Direction.DESC : Sort.Direction.ASC, sort[0]);
            Pageable pageable = PageRequest.of(offset, limit, direction);
            log.info("retrieving report abuse entries from db");
            Page<ReportAbuse> page = reportAbuseRepository.findAll(new ReportAbuseSpecification(searchCriteria, reportAbuseRepository), pageable);
            reportAbuseEntries = page.getContent();
            log.info("get report abuse entries successfully");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, reportAbuseEntries, null);
        } catch (Exception e) {
            log.error("Exception while fetching report abuse entries: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Error occurred while fetching report abuse entries.");
        }
    }
}
