package com.wue.service.drill;

import com.wue.constant.drill.*;
import com.wue.custom.specification.SearchDrillChangeRequestCriteria;
import com.wue.domain.drill.DrillChangeRequest;
import com.wue.domain.drill.DrillParticipant;
import com.wue.domain.drill.DrillTeams;
import com.wue.domain.drill.TeamsParticipants;
import com.wue.dto.drill.DrillChangeRequestDto;
import com.wue.dto.drill.DrillChangeRequestSearchResultDto;
import com.wue.dto.drill.DrillTeamsDto;
import com.wue.dto.response.Response;
import com.wue.dto.search.DrillChangeRequestSpecification;
import com.wue.repository.drill.DrillChangeRequestRepository;
import com.wue.repository.drill.DrillParticipantRepository;
import com.wue.repository.drill.DrillTeamsRepository;
import com.wue.repository.drill.TeamsParticipantsRepository;
import com.wue.util.InternityUser;
import com.wue.util.drill.DrillChangeValidationUtil;
import com.wue.util.drill.DrillMailUtil;
import com.wue.util.drill.DrillValidationUtils;
import com.wue.util.drill.ResponseUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Log4j2
public class DrillChangeRequestService {

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    DrillMailUtil drillMailUtil;

    @Autowired
    ResponseUtil responseUtil;

    @Autowired
    DrillValidationUtils drillValidationUtils;

    @Autowired
    DrillChangeValidationUtil drillChangeValidationUtil;

    @Autowired
    DrillChangeRequestRepository drillChangeRequestRepository;

    @Autowired
    TeamsParticipantsRepository teamsParticipantsRepository;
    @Autowired
    DrillTeamsRepository drillTeamsRepository;

    @Autowired
    DrillParticipantRepository drillParticipantRepository;

    @Autowired
    DrillTeamService drillTeamService;

    public Response updateRequestDetails(String requestId, String userId, RequestStatus status, InternityUser user) {
        try {
            log.info("Updating request details - Request ID ::: {}, User ID ::: {}, New Status ::: {}", requestId, userId, status);

            // Check for empty or undefined request ID
            if (StringUtils.isAnyBlank(requestId)) {
                log.warn("Request ID is blank or undefined :::{}", requestId);
                return responseUtil.badRequestResponse("Request ID should not be empty or undefined");
            }

            // Check for empty or undefined user ID
            if (StringUtils.isAnyBlank(userId)) {
                log.warn("User ID is blank or undefined ::: {}", userId);
                return responseUtil.badRequestResponse("User ID should not be empty or undefined");
            }

            // Validate request ID
            if (!drillChangeValidationUtil.isRequestIdValid(requestId)) {
                log.warn("Request not found with the specified ID - Request ID ::: {}", requestId);
                return responseUtil.notFoundResponse("Request not found with the specified ID");
            }

            // Validate user ID
            if (!drillChangeValidationUtil.isUserIdValid(userId)) {
                log.warn("User not found with the specified ID - User ID ::: {}", userId);
                return responseUtil.notFoundResponse("User not found with the specified ID");
            }

            // Check if the user is an admin
            if (!drillChangeValidationUtil.isUserAdmin(userId)) {
                log.warn("User is not a super admin - User ID ::: {}", userId);
                return responseUtil.badRequestResponse("Not a super admin");
            }

            // Retrieve the drill change request
            Optional<DrillChangeRequest> optionalDrillChangeRequest = drillChangeRequestRepository.findById(requestId);
            DrillChangeRequest drillChangeRequest = optionalDrillChangeRequest.get();

            // Handle drill team-related requests
            if (EntityType.DRILLTEAM.equals(drillChangeRequest.getEntityType())) {
                if (RequestType.NEW_TEAM_MEMBER.equals(drillChangeRequest.getRequestType())) {
                    log.info("Handling new team member request ::: {}", drillChangeRequest.getRequestType());
                    return handleNewTeamMemberRequest(drillChangeRequest, userId, status);
                } else if (RequestType.TEAM_NAME.equals(drillChangeRequest.getRequestType())) {
                    log.info("Handling team name request ::: {}", drillChangeRequest.getRequestType());
                    return handleTeamNameRequest(drillChangeRequest, userId, status);
                } else if (RequestType.TEAM_LEAD.equals(drillChangeRequest.getRequestType())) {
                    log.info("Handling team lead request ::: {}", drillChangeRequest.getRequestType());
                    return handleTeamLeadRequest(drillChangeRequest, userId, status);
                } else if (RequestType.REMOVE_MEMBER.equals(drillChangeRequest.getRequestType())) {
                    log.info("Handling remove member request ::: {}", drillChangeRequest.getRequestType());
                    return handleRemoveMemberRequest(drillChangeRequest, userId, status);
                } else if (RequestType.TEAM_STATUS.equals(drillChangeRequest.getRequestType())) {
                    log.info("Handling team status request ::: {}", drillChangeRequest.getRequestType());
                    return handleTeamStatusRequest(drillChangeRequest, userId, status);
                }
            }

            log.info("Request processed successfully ::: {}");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request processed successfully", null);

        } catch (Exception e) {
            log.error("Exception while processing request details ::: {}", e);
            return responseUtil.internalServerErrorResponse("Error processing request details");
        }
    }

    // Handle NEW_TEAM_MEMBER request
    private Response handleNewTeamMemberRequest(DrillChangeRequest drillChangeRequest, String uId, RequestStatus status) {
        try {
            log.info("Processing new team member request - Request ID ::: {}, User ID ::: {}, Status ::: {}",
                    drillChangeRequest.getRequestId(), uId, status);

            // Validate the request data
            if (StringUtils.isAnyBlank(drillChangeRequest.getRequestData())) {
                log.warn("Participant ID is blank or undefined :::", drillChangeRequest.getRequestData());
                return responseUtil.badRequestResponse("Participant ID should not be empty or undefined");
            }

            // Validate the participant ID
            Optional<DrillParticipant> optionalDrillParticipant = drillValidationUtils.isParticipantIdValid(drillChangeRequest.getRequestData());
            if (!optionalDrillParticipant.isPresent()) {
                log.warn("Invalid participant ID - Participant ID :::: {}", drillChangeRequest.getRequestData());
                return responseUtil.notFoundResponse("Invalid participant ID");
            }

            // Check if there is a pending request for the participant
            Optional<TeamsParticipants> optionalTeamsParticipants = teamsParticipantsRepository.findByParticipantIdAndIsRequestAccepted(
                    drillChangeRequest.getRequestData(), false);
            if (!optionalTeamsParticipants.isPresent()) {
                log.warn("No pending request found for the specified participant - Participant ID ::: {}", drillChangeRequest.getRequestData());
                return responseUtil.notFoundResponse("No pending request found for the specified participant");
            }

            TeamsParticipants teamsParticipants = optionalTeamsParticipants.get();

            // Retrieve the drill team
            Optional<DrillTeams> optionalDrillTeams = drillTeamsRepository.findById(teamsParticipants.getTeamId());
            if (!optionalDrillTeams.isPresent()) {
                log.warn("Team not found for the specified request - Team ID ::: {}", teamsParticipants.getTeamId());
                return responseUtil.notFoundResponse("Team not found for the specified request");
            }

            DrillTeams team = optionalDrillTeams.get();

            if (status.equals(RequestStatus.APPROVED)) {
                log.info("Approving team member request to join team ::: {}", status);
                team.setTeamCurrentSize(team.getTeamCurrentSize() + 1);
                teamsParticipants.setRequestAccepted(true);
                teamsParticipants.setStage(Stage.ACCEPTED);
                drillChangeRequest.setRequestStatus(RequestStatus.APPROVED);
                drillTeamsRepository.saveAndFlush(team);
                teamsParticipantsRepository.saveAndFlush(teamsParticipants);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response memberMailResponse = drillMailUtil.sendNotificationToTeamMemberForJoiningTeam(teamsParticipants.getDrillId(),
                        team.getTeamLeadParticipantId(), optionalDrillParticipant.get(), teamsParticipants.getTeamId(), team.getTeamName(),
                        TeamInviteType.SEARCHED, "ACCEPT");
                if (memberMailResponse.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Error sending notification to team member ::: {}");
                    return memberMailResponse;
                }
                Response leadMailResponse = drillMailUtil.sendNotificationToLeadForNewTeamMemberJoin(teamsParticipants.getDrillId(),
                        team.getTeamLeadParticipantId(), optionalDrillParticipant.get(), team, teamsParticipants, TeamInviteType.SEARCHED,
                        "ACCEPT");
                if (leadMailResponse.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Error sending notification to team lead ::: {}");
                    return leadMailResponse;
                }
                log.info("Approved team member request to join team successfully ::: {}");
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Approved team member request to join team successfully", null);
            } else {
                log.info("Rejecting team member request to join team ::: {}", status);
                teamsParticipants.setStage(Stage.REJECTED);
                teamsParticipantsRepository.saveAndFlush(teamsParticipants);
                drillChangeRequest.setRequestStatus(RequestStatus.REJECTED);
                drillChangeRequest.setApprovedBy(uId);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response memberMailResponse = drillMailUtil.sendNotificationToTeamMemberForJoiningTeam(teamsParticipants.getDrillId(),
                        team.getTeamLeadParticipantId(), optionalDrillParticipant.get(), teamsParticipants.getTeamId(), team.getTeamName(),
                        TeamInviteType.SEARCHED, "REJECT");
                if (memberMailResponse.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Error sending notification to team member ::: {}");
                    return memberMailResponse;
                }
                Response leadMailResponse = drillMailUtil.sendNotificationToLeadForNewTeamMemberJoin(teamsParticipants.getDrillId(),
                        team.getTeamLeadParticipantId(), optionalDrillParticipant.get(), team,
                        teamsParticipants, TeamInviteType.SEARCHED, "REJECT");
                if (leadMailResponse.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Error sending notification to team member ::: {}");
                    return leadMailResponse;
                }
                log.info("Rejected team member request to join team successfully ::: {}");
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Rejected team member request to join team successfully", null);
            }
        } catch (Exception e) {
            log.error("Exception while processing new member request details ::: {}", e);
            return responseUtil.internalServerErrorResponse("Error processing new member request details");
        }
    }


    // Handle TEAM_SIZE request
//    private Response handleTeamSizeRequest(DrillChangeRequest drillChangeRequest, String uId, RequestStatus status) {
//        try {
//            log.info("Processing team size change request - Request ID ::: {}, User ID ::: {}, Status ::: {}",
//                    drillChangeRequest.getRequestId(), uId, status);
//
//            // Validate request data
//            if (StringUtils.isAnyBlank(drillChangeRequest.getRequestData())) {
//                log.warn("Team size is blank or undefined ::: {}",drillChangeRequest.getRequestData());
//                return responseUtil.badRequestResponse("Team size should not be empty or undefined");
//            }
//
//            // Validate entity ID
//            if (StringUtils.isAnyBlank(drillChangeRequest.getEntityId())) {
//                log.warn("Entity ID is blank or undefined ::: {}",drillChangeRequest.getEntityId());
//                return responseUtil.badRequestResponse("Entity ID should not be empty or undefined");
//            }
//
//            // Validate team ID
//            Optional<DrillTeams> optionalDrillTeams = drillValidationUtils.isTeamIdValid(drillChangeRequest.getEntityId());
//            if (!optionalDrillTeams.isPresent()) {
//                log.warn("Invalid team ID - Team ID ::: {}", drillChangeRequest.getEntityId());
//                return responseUtil.notFoundResponse("Invalid team ID");
//            }
//
//            DrillTeams team = optionalDrillTeams.get();
//
//            // Parse the requested team size
//            int requestedTeamSize = Integer.parseInt(drillChangeRequest.getRequestData());
//
//            // Check if the updated team size is within the limits set by the drill
//            // Note: Uncomment the following lines if validation is required
//            // if (!drillValidationUtils.isTeamSizeWithinDrillLimits(requestedTeamSize, optionalDrillTeams)) {
//            //     return responseUtil.conflictResponse("Updated team size exceeds the allowed limit set by the drill.");
//            // }
//
//            if (RequestStatus.APPROVED.equals(status)) {
//                log.info("Approving team size change request ::: {}",status);
//                team.setDeclaredTeamSize(requestedTeamSize);
//                drillTeamsRepository.saveAndFlush(team);
//                drillChangeRequest.setRequestStatus(RequestStatus.APPROVED);
//                drillChangeRequest.setApprovedBy(uId);
//                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
//               Response response =  drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "", "",
//                       drillChangeRequest.getRequestedBy(), requestedTeamSize, new ArrayList<>(), false, status,RequestType.TEAM_SIZE);
//                if (response.getHttpStatus() != HttpStatus.OK.value()){
//                    log.warn("Failed to send notification to lead for team size ::: {} - {}");
//                    return response;
//                }
//                log.info("Request approved for team size update successfully ::: {}");
//                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request approved for team size update successfully", null);
//            } else {
//                log.info("Rejecting team size change request ::: {}",status);
//                drillChangeRequest.setRequestStatus(RequestStatus.REJECTED);
//                drillChangeRequest.setApprovedBy(uId);
//                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
//                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "", "",
//                        drillChangeRequest.getRequestedBy(), requestedTeamSize, new ArrayList<>(), false, status,RequestType.TEAM_SIZE);
//                if (response.getHttpStatus() != HttpStatus.OK.value()){
//                    log.warn("Failed to send notification to lead for team size ::: {} - {}");
//                    return response;
//                }
//                log.info("Request rejected for team size update successfully ::: {}");
//                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request rejected for team size update successfully", null);
//            }
//        } catch (Exception e) {
//            log.error("Exception while processing team size request details ::: {}", e);
//            return responseUtil.internalServerErrorResponse("Error processing team size request details");
//        }
//    }
//

    // Handle TEAM_NAME request

    private Response handleTeamNameRequest(DrillChangeRequest drillChangeRequest, String uId, RequestStatus status) {
        try {
            log.info("Processing team name change request - Request ID: {}, User ID: {}, Status: {}", drillChangeRequest.getRequestId(),
                    uId, status);

            // Validate request data
            if (StringUtils.isAnyBlank(drillChangeRequest.getRequestData())) {
                log.warn("Team name is blank or undefined");
                return responseUtil.badRequestResponse("Team name should not be empty or undefined");
            }

            // Validate entity ID
            if (StringUtils.isAnyBlank(drillChangeRequest.getEntityId())) {
                log.warn("Entity ID is blank or undefined");
                return responseUtil.badRequestResponse("Entity ID should not be empty or undefined");
            }

            // Validate team ID
            Optional<DrillTeams> optionalDrillTeams = drillValidationUtils.isTeamIdValid(drillChangeRequest.getEntityId());
            if (!optionalDrillTeams.isPresent()) {
                log.warn("Invalid team ID - Team ID: {}", drillChangeRequest.getEntityId());
                return responseUtil.notFoundResponse("Invalid team ID");
            }

            // Get team name from the request
            String teamName = drillChangeRequest.getRequestData();

            // Check if the new team name is unique within the drill
            DrillTeams team = optionalDrillTeams.get();
            if (drillValidationUtils.isTeamNameUniqueForDrill(team.getDrillId(), teamName)) {
                log.warn("Team name is not unique - Team name: {}", teamName);
                return responseUtil.conflictResponse("A team with the same name already exists in this hackathon. "
                        + "Please choose another name for your team");
            }

            if (RequestStatus.APPROVED.equals(status)) {
                log.info("Approving team name change request");
                // Update the team name in the database
                team.setTeamName(teamName);
                drillTeamsRepository.saveAndFlush(team);

                // Update the request status to approved
                drillChangeRequest.setRequestStatus(RequestStatus.APPROVED);
                drillChangeRequest.setApprovedBy(uId);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, teamName, "",
                        drillChangeRequest.getRequestedBy(), new ArrayList<>(), false, status, RequestType.TEAM_NAME);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification to lead for team name ::: {} - {}");
                    return response;
                }
                log.info("Request approved for team name update successfully");
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request approved for team name update successfully", null);
            } else {
                log.info("Rejecting team name change request");
                // Update the request status to rejected
                drillChangeRequest.setRequestStatus(RequestStatus.REJECTED);
                drillChangeRequest.setApprovedBy(uId);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, teamName, "",
                        drillChangeRequest.getRequestedBy(), new ArrayList<>(), false, status, RequestType.TEAM_NAME);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification to lead for team name ::: {} - {}");
                    return response;
                }
                log.info("Request rejected for team name update successfully");
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request rejected for team name update successfully", null);
            }
        } catch (Exception e) {
            log.error("Exception while processing team name request details", e);
            return responseUtil.internalServerErrorResponse("Error processing team name request details");
        }
    }


    // Handle TEAM_LEAD request
    private Response handleTeamLeadRequest(DrillChangeRequest changeRequest, String approverUserId, RequestStatus status) {
        try {
            log.info("Processing team lead change request - Request ID ::: {}, User ID ::: {}, Status ::: {}",
                    changeRequest.getRequestId(), approverUserId, status);
            // Validate request data
            if (StringUtils.isAnyBlank(changeRequest.getRequestData())) {
                log.warn("Request data is blank or undefined ::: {}");
                return responseUtil.badRequestResponse("Participant ID should not be empty or undefined");
            }

            // Validate entity ID
            if (StringUtils.isAnyBlank(changeRequest.getEntityId())) {
                log.warn("entity is blank or undefined ::: {}");
                return responseUtil.badRequestResponse("Entity ID should not be empty or undefined");
            }

            // Validate team ID
            Optional<DrillTeams> optionalDrillTeams = drillValidationUtils.isTeamIdValid(changeRequest.getEntityId());
            if (!optionalDrillTeams.isPresent()) {
                log.warn("Invalid team ID - Team ID ::: {}", changeRequest.getEntityId());
                return responseUtil.notFoundResponse("Invalid team ID");
            }

            // Validate participant ID
            Optional<DrillParticipant> optionalDrillParticipant = drillValidationUtils.isParticipantIdValid(changeRequest.getRequestData());
            if (!optionalDrillParticipant.isPresent()) {
                log.warn("Invalid participant ID - Participant ID: {}", changeRequest.getRequestData());
                return responseUtil.notFoundResponse("Invalid participant ID");
            }

            // Check if the participant is already a team lead
            if (drillValidationUtils.isParticipantTeamLead(optionalDrillParticipant)) {
                log.warn("The selected participant is already a team lead");
                return responseUtil.notFoundResponse("The selected participant is already a team lead");
            }

            DrillTeams team = optionalDrillTeams.get();

            // Check if the participant already belongs to a team in the drill
            if (drillValidationUtils.doesMemberHaveTeamInDrill(team.getDrillId(), changeRequest.getRequestData())) {
                log.warn("The selected participant already belongs to another team in this drill");
                return responseUtil.conflictResponse("The selected participant already belongs to another team in this drill");
            }

            if (RequestStatus.APPROVED.equals(status)) {
                // Update participant roles and team lead information
                DrillParticipant selectedParticipant = optionalDrillParticipant.get();

                Optional<DrillParticipant> teamLeadOptional = drillParticipantRepository.findById(team.getTeamLeadParticipantId());
                DrillParticipant currentTeamLead = teamLeadOptional.get();

                selectedParticipant.setMemberType(MemberType.TEAMLEAD);
                currentTeamLead.setMemberType(MemberType.TEAMMEMBER);

                team.setTeamLeadParticipantId(changeRequest.getRequestData());

                changeRequest.setRequestStatus(RequestStatus.APPROVED);
                changeRequest.setApprovedBy(approverUserId);
                drillParticipantRepository.saveAndFlush(selectedParticipant);
                drillParticipantRepository.saveAndFlush(currentTeamLead);
                drillTeamsRepository.saveAndFlush(team);
                drillChangeRequestRepository.saveAndFlush(changeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "",
                        team.getTeamLeadParticipantId(), changeRequest.getRequestedBy(), new ArrayList<>(),
                        false, status, RequestType.TEAM_LEAD);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification -  ::: {}");
                    return response;
                }
                log.info("Team lead change request Approved successfully ::: {}", status);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request approved for team lead update successfully", null);
            } else {
                changeRequest.setRequestStatus(RequestStatus.REJECTED);
                changeRequest.setApprovedBy(approverUserId);
                drillChangeRequestRepository.saveAndFlush(changeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "",
                        team.getTeamLeadParticipantId(), changeRequest.getRequestedBy(), new ArrayList<>(),
                        false, status, RequestType.TEAM_LEAD);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification -  ::: {}");
                    return response;
                }
                log.info("Team lead change request Rejected successfully ::: {}", status);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Request rejected for team lead update successfully", null);
            }
        } catch (Exception e) {
            log.error("Exception while processing team lead request details", e);
            return responseUtil.internalServerErrorResponse("Error processing team lead request details");
        }
    }


    // Handle REMOVE_MEMBER request
    private Response handleRemoveMemberRequest(DrillChangeRequest drillChangeRequest, String uId, RequestStatus status) {
        try {
            log.info("Processing team member removal request - Request ID ::: {}, User ID ::: {}, Status ::: {}",
                    drillChangeRequest.getRequestId(), uId, status);

            // Validate request data
            if (StringUtils.isAnyBlank(drillChangeRequest.getRequestData())) {
                log.warn("Request Data is blank or undefined ::: {}");
                return responseUtil.badRequestResponse("Member ID should not be empty or undefined");
            }

            // Validate entity ID
            if (StringUtils.isAnyBlank(drillChangeRequest.getEntityId())) {
                log.warn(" entity ID is blank or undefined ::: {}");
                return responseUtil.badRequestResponse("Entity ID should not be empty or undefined");
            }

            // Validate team ID
            Optional<DrillTeams> optionalDrillTeams = drillValidationUtils.isTeamIdValid(drillChangeRequest.getEntityId());
            if (!optionalDrillTeams.isPresent()) {
                log.warn("Invalid team ID - Team ID ::: {}", drillChangeRequest.getEntityId());
                return responseUtil.notFoundResponse("Invalid team ID");
            }

            DrillTeams team = optionalDrillTeams.get();

            // Split the string based on the comma (,) delimiter
            String[] stringArray = drillChangeRequest.getRequestData().split(",");
            List<String> memberIdList = Arrays.stream(stringArray).collect(Collectors.toList());

            if (status.equals(RequestStatus.APPROVED)) {

                for (String memberId : memberIdList) {
                    //one check for lead check
                    Optional<DrillParticipant> optionalDrillParticipant = drillParticipantRepository.findById(memberId);
                    if (!drillValidationUtils.isParticipantTeamLead(optionalDrillParticipant)) {
                        List<TeamsParticipants> participantsList = teamsParticipantsRepository.findByParticipantId(memberId);

                        if (!participantsList.isEmpty()) {
                            TeamsParticipants participant = participantsList.get(0);
                            teamsParticipantsRepository.delete(participant);

                        }
                    }

                }

                drillChangeRequest.setApprovedBy(uId);
                drillChangeRequest.setRequestStatus(RequestStatus.APPROVED);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "", "",
                        drillChangeRequest.getRequestedBy(), memberIdList, false, status, RequestType.REMOVE_MEMBER);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification - {}");
                    return response;
                }
                log.info("Member removal request accepted successfully - Status: {}", status);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Member removal request accepted successfully", null);
            } else {
                // Update the request status to rejected
                drillChangeRequest.setApprovedBy(uId);
                drillChangeRequest.setRequestStatus(RequestStatus.REJECTED);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "", "",
                        drillChangeRequest.getRequestedBy(), memberIdList, false, status, RequestType.REMOVE_MEMBER);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification - {}");
                    return response;
                }
                log.info("Member removal request rejected successfully - Status: {}", status);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Member removal request rejected successfully", null);
            }

        } catch (Exception e) {
            log.error("Exception while processing team member remove request details", e);
            return responseUtil.internalServerErrorResponse("Error processing team member remove request details");
        }
    }


    // Handle TEAM_STATUS request

    private Response handleTeamStatusRequest(DrillChangeRequest drillChangeRequest, String uId, RequestStatus status) {
        try {
            log.info("Processing team status change request - Request ID ::: {}, User ID ::: {}, Status ::: {}",
                    drillChangeRequest.getRequestId(), uId, status);
            // Validate request data
            if (StringUtils.isAnyBlank(drillChangeRequest.getRequestData())) {
                log.warn("Request data  is blank or undefined ::: {}", drillChangeRequest.getRequestData());
                return responseUtil.badRequestResponse("Team status data should not be empty or undefined");
            }

            // Validate entity ID
            if (StringUtils.isAnyBlank(drillChangeRequest.getEntityId())) {
                log.warn("Entity ID  is blank or undefined ::: {}", drillChangeRequest.getEntityId());
                return responseUtil.badRequestResponse("Entity ID should not be empty or undefined");
            }

            // Validate team ID
            Optional<DrillTeams> optionalDrillTeams = drillValidationUtils.isTeamIdValid(drillChangeRequest.getEntityId());
            if (!optionalDrillTeams.isPresent()) {
                log.warn("Invalid team ID - Team ID ::: {}", drillChangeRequest.getEntityId());
                return responseUtil.notFoundResponse("Invalid team ID");
            }

            // Retrieve the team details
            DrillTeams team = optionalDrillTeams.get();

            if (status.equals(RequestStatus.APPROVED)) {
                // Update team status to inactive
                team.setActive(false);

                // Retrieve team lead participant details
                Optional<DrillParticipant> optionalDrillParticipant = drillParticipantRepository.findById(team.getTeamLeadParticipantId());
                DrillParticipant drillParticipant = optionalDrillParticipant.get();
                drillParticipant.setMemberType(MemberType.TEAMMEMBER);

                // Retrieve and delete all team participants
                List<TeamsParticipants> participantsList = teamsParticipantsRepository.findByTeamId(team.getTeamId());
                if (!participantsList.isEmpty()) {
                    for (TeamsParticipants participants : participantsList) {
                        teamsParticipantsRepository.delete(participants);
                    }
                }


                drillTeamsRepository.saveAndFlush(team);
                drillParticipantRepository.saveAndFlush(drillParticipant);

                // Update the request status to approved
                drillChangeRequest.setApprovedBy(uId);
                drillChangeRequest.setRequestStatus(RequestStatus.APPROVED);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "",
                        "", drillChangeRequest.getRequestedBy(), new ArrayList<>(), true, status, RequestType.TEAM_STATUS);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification - ::: {}");
                    return response;
                }
                log.info("Team status request accepted successfully - Status ::: {}", status);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Team status request accepted successfully", null);
            } else {
                // Update the request status to rejected
                drillChangeRequest.setApprovedBy(uId);
                drillChangeRequest.setRequestStatus(RequestStatus.REJECTED);
                drillChangeRequestRepository.saveAndFlush(drillChangeRequest);
                Response response = drillMailUtil.sendNotificationToLeadForTeamDetailsChangeByAdmin(team.getDrillId(), team, "",
                        "", drillChangeRequest.getRequestedBy(), new ArrayList<>(), true, status, RequestType.TEAM_STATUS);
                if (response.getHttpStatus() != HttpStatus.OK.value()) {
                    log.warn("Failed to send notification - ::: {}");
                    return response;
                }
                log.info("Team status request rejected successfully - Status ::: {}", status);
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Team status request rejected successfully", null);
            }

        } catch (Exception e) {
            log.error("Exception while processing team status request details", e);
            return responseUtil.internalServerErrorResponse("Error processing team status request details");
        }
    }

    public Response searchAllDrillChangeRequest(SearchDrillChangeRequestCriteria searchCriteria, int offset, int limit, String order,
                                                String name, InternityUser user) {
        log.info("Search criteria: {}", searchCriteria);
        DrillChangeRequestSearchResultDto requestSearchResultDto = null;

        try {

            String[] sort = order.split("\\.");
            Sort direction = Sort.by("desc".equalsIgnoreCase(sort[1]) ? Sort.Direction.DESC : Sort.Direction.ASC, sort[0]);
            Pageable pageable = PageRequest.of(offset, limit, direction);

            // Perform the search using specifications
            Page<DrillChangeRequest> page = drillChangeRequestRepository.findAll(new DrillChangeRequestSpecification(searchCriteria), pageable);

            // Convert the entities to DTOs
            List<DrillChangeRequestDto> drillChangeRequestDtos = page.getContent().stream()
                    .map(DrillChangeRequestDto::new)
                    .collect(Collectors.toList());

            // Set drill teams information for each request
            Response response = setDrillTeamsDto(drillChangeRequestDtos);
            if (response.getHttpStatus() != HttpStatus.OK.value()) {
                return response;
            }

            // Build the response DTO
            requestSearchResultDto = DrillChangeRequestSearchResultDto.builder()
                    .data(drillChangeRequestDtos)
                    .totalRecordCount(page.getTotalElements())
                    .build();

            return new Response(HttpStatus.OK.value(), Boolean.TRUE, requestSearchResultDto, null);
        } catch (Exception e) {
            log.error("Exception while searching drill change requests", e);
            return responseUtil.internalServerErrorResponse("Error occurred during the search operation.");
        }
    }

    private Response setDrillTeamsDto(List<DrillChangeRequestDto> drillChangeRequestDtos) {
        try {
            if (!drillChangeRequestDtos.isEmpty()) {
                for (DrillChangeRequestDto dto : drillChangeRequestDtos) {
                    String teamId = dto.getEntityId();

                    // Validate teamId
                    if (StringUtils.isBlank(teamId)) {
                        return responseUtil.badRequestResponse("TeamId cannot be blank.");
                    }
                    Optional<DrillTeams> optionalDrillTeams = drillValidationUtils.isTeamIdValid(teamId);
                    if (!optionalDrillTeams.isPresent()) {
                        return responseUtil.notFoundResponse("Invalid TeamId: " + teamId);
                    }

                    DrillTeams drillTeams = optionalDrillTeams.get();
                    DrillTeamsDto drillTeamsDto = this.modelMapper.map(drillTeams, DrillTeamsDto.class);

                    // Set participant information for the drill teams
                    List<DrillTeamsDto> teamsDtoList = new ArrayList<>();
                    teamsDtoList.add(drillTeamsDto);
                    Response response = drillTeamService.setDrillTeamsRequestedParticipantInfo(teamsDtoList, drillTeams.getDrillId());
                    if (response.getHttpStatus() != HttpStatus.OK.value()) {
                        return response;
                    }

                    teamsDtoList = (List<DrillTeamsDto>) response.getResult();
                    dto.setDrillTeamsDto(teamsDtoList.get(0));
                }
                return new Response(HttpStatus.OK.value(), Boolean.TRUE, drillChangeRequestDtos, null);
            }
        } catch (Exception e) {
            log.error("Error while setting drill teams information", e);
            return responseUtil.internalServerErrorResponse("Error occurred while setting drill teams information.");
        }

        // Return an empty response if the input list is empty
        return new Response(HttpStatus.OK.value(), Boolean.TRUE, Collections.emptyList(), null);
    }

}