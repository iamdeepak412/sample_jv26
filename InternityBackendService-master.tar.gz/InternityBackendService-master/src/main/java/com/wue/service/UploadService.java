package com.wue.service;
import org.springframework.beans.factory.annotation.Autowired;
import com.wue.util.UploadFileUtil;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.wue.util.CommonUtils;

import java.util.Map;


@Service
public class UploadService {


    @Autowired
    UploadFileUtil upload;
    @Autowired
    CommonUtils commonUtils;
    public Map<String,String> uploadFileService(String drillId, String teamId, String participantId, String theme, String solutionType, MultipartFile multipartFile){



        try {
         return upload.saveFile(drillId,teamId,participantId,theme,solutionType,multipartFile);

        } catch (Exception e) {
            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,"Failed to upload the file. Please submit again or contact us at techsupport@wuelev8.tech");
        }

    }


}
