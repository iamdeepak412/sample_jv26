package com.wue.service.saarthi;

import com.wue.constant.SearchProfile;
import com.wue.custom.specification.SearchSaarthiCriteria;
import com.wue.domain.saarthi.Saarthi;
import com.wue.dto.response.Response;
import com.wue.dto.saarthi.SaarthiDto;
import com.wue.dto.saarthi.SaarthiSearchResultDto;
import com.wue.dto.search.SaarthiSpecification;
import com.wue.model.EmailContent;
import com.wue.repository.saarthi.SaarthiRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.SendMessageUtils;
import com.wue.util.drill.ResponseUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Service
@Log4j2
public class SaarthiService {

    @Autowired
    SaarthiRepository saarthiRepository;

    @Autowired
    ResponseUtil responseUtil;

    @Autowired
    SendMessageUtils messageUtils;

    @Autowired
    CommonUtils commonUtils;

    @Value("${support.mail.id:techsupport@wuelev8.tech}")
    private String techSupportEmail;

    public Response addSaarthi(Saarthi payload, InternityUser user) {
        try {
            log.info("Attempting to add Saarthi ::: {}",payload);

            // Validate mandatory fields
            if (StringUtils.isAnyBlank(payload.getName())) {
                log.warn("Name field is blank in the payload. Cannot proceed.");
                return responseUtil.badRequestResponse("Name field cannot be blank.");
            }
            if (StringUtils.isAnyBlank(payload.getEmailId())) {
                log.warn("Email ID field is blank in the payload. Cannot proceed.");
                return responseUtil.badRequestResponse("Email ID field cannot be blank.");
            }
            if (StringUtils.isAnyBlank(payload.getContactNo())) {
                log.warn("Contact number field is blank in the payload. Cannot proceed.");
                return responseUtil.badRequestResponse("Contact number field cannot be blank.");
            }
            if (!commonUtils.isEmailValid(payload.getEmailId())) {
                log.warn("Email ID format is invalid. Cannot proceed.");
                return responseUtil.badRequestResponse("Invalid email format.");
            }
            if (!commonUtils.isMobileValid(payload.getContactNo())) {
                log.warn("Contact number format is invalid. Cannot proceed.");
                return responseUtil.badRequestResponse("Invalid contact number format.");
            }

            // Check if Saarthi already exists
            Optional<Saarthi> optionalSaarthiByEmail = saarthiRepository.findByEmailId(payload.getEmailId());
            if (optionalSaarthiByEmail.isPresent()) {
                log.warn("A Saarthi with the provided email already exists. Cannot proceed.");
                return responseUtil.badRequestResponse("A Saarthi with the provided email already exists.");
            }

            Optional<Saarthi> optionalSaarthiByContactNo = saarthiRepository.findByContactNo(payload.getContactNo());
            if (optionalSaarthiByContactNo.isPresent()) {
                log.warn("A Saarthi with the provided contact number already exists. Cannot proceed.");
                return responseUtil.badRequestResponse("A Saarthi with the provided contact number already exists.");
            }

            // Additional validation based on registration type
            if (payload.getRegistrationType() != null) {
                switch (payload.getRegistrationType()) {
                    case CAMPUS:
                        if (StringUtils.isAnyBlank(payload.getOrganizationName()) || StringUtils.isAnyBlank(payload.getLevelOfStudy()) ||
                                StringUtils.isAnyBlank(payload.getYearOfStudy()) || payload.getPassingYear() == 0) {
                            log.warn("Mandatory fields for Campus Saarthi are missing. Cannot proceed.");
                            return responseUtil.badRequestResponse("Mandatory fields for Campus Saarthi are missing.");
                        }


                        break;
                    case ACADEMIC:
                        if (StringUtils.isAnyBlank(payload.getOrganizationName())) {
                            log.warn("Organization name field is blank for Academic Saarthi. Cannot proceed.");
                            return responseUtil.badRequestResponse("Organization name field cannot be blank.");
                        }
                        break;
                    case MENTOR:
                        if (StringUtils.isAnyBlank(payload.getCurrCompanyName()) || StringUtils.isAnyBlank(payload.getPrimarySkills()) ||
                                StringUtils.isAnyBlank(payload.getLevelOfStudy()) || payload.getTotalExperience() == 0) {
                            log.warn("Mandatory fields for Mentor Saarthi are missing. Cannot proceed.");
                            return responseUtil.badRequestResponse("Mandatory fields for Mentor Saarthi are missing.");
                        }
                        break;
                    case COMMUNITY:
                        if (StringUtils.isAnyBlank(payload.getOrganizationName()) || StringUtils.isAnyBlank(payload.getCommunityName())) {
                            log.warn("Mandatory fields for Community Saarthi are missing. Cannot proceed.");
                            return responseUtil.badRequestResponse("Mandatory fields for Community Saarthi are missing.");
                        }
                        break;
                }
            }

            // Save Saarthi
            Saarthi saarthi = saarthiRepository.save(payload);
            log.info("Saarthi added successfully.");

            // Send registration email
            Response response = sendMailForSaarthiRegistration(saarthi);
            if (response.getHttpStatus() != HttpStatus.OK.value()) {
                log.warn("Failed to send registration email to Saarthi.");
                return response;
            }

            return new Response(HttpStatus.OK.value(), Boolean.TRUE, saarthi, null);
        } catch (Exception e) {
            log.error("Exception occurred while adding Saarthi: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception occurred while adding Saarthi. Please contact the admin or mail to support@wuelev8.tech");
        }
    }


    private Response sendMailForSaarthiRegistration(Saarthi saarthi) {
        try {
            log.info("Sending registration email to Saarthi.");

            // Prepare email content for user
            EmailContent userEmailContent = new EmailContent();
            userEmailContent.setTemplateName("GenericMailForAllUsers");
            userEmailContent.setUserName("Hi " + saarthi.getName() + ",");
            userEmailContent.setSubject("Welcome to Saarthi");
            String userMessage = "Thank you for registering with WUE. Your registration is successful. You will receive an email shortly with further details.";
            userEmailContent.setMessage(userMessage);
            messageUtils.sendMailForGenericUsers(saarthi.getEmailId(), userEmailContent);

            // Prepare email content for admin
            EmailContent adminEmailContent = new EmailContent();
            adminEmailContent.setTemplateName("GenericMailForAllUsers");
            adminEmailContent.setUserName("Hi Admin,");
            adminEmailContent.setSubject("New User Registration for Saarthi " + saarthi.getRegistrationType().toString().toLowerCase());
            String adminMessage = "New User Registration. Name: " + saarthi.getName() + " Email: " + saarthi.getEmailId() + " For: " + saarthi.getRegistrationType();
            adminEmailContent.setMessage(adminMessage);
            messageUtils.sendMailForGenericUsers(techSupportEmail, adminEmailContent);

            log.info("Registration emails sent successfully.");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Emails sent successfully", null);
        } catch (Exception e) {
            log.error("Exception occurred while sending registration emails: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception occurred while sending registration emails.");
        }
    }


    public Response getSaarthiById(String saarthiId) {
        Optional<Saarthi> saarthi = saarthiRepository.findById(saarthiId);
        return saarthi.map(value -> new Response(HttpStatus.OK.value(), Boolean.TRUE, value, null)).orElseGet(() -> new Response(HttpStatus.OK.value(), Boolean.TRUE, "No Saarthi found with Saarthi Id", null));
    }

    public Response getAllSaarthi(SearchSaarthiCriteria searchCriteria, int limit, int offset, String order, SearchProfile profile, InternityUser user) {
        try {
            log.info("Attempting to retrieve Saarthi records with search criteria: {}", searchCriteria);

            String[] sort = order.split("\\.");
            Sort direction = Sort.by("desc".equalsIgnoreCase(sort[1]) ? Sort.Direction.DESC : Sort.Direction.ASC, sort[0]);
            Pageable pageable = PageRequest.of(offset, limit, direction);

            Page<Saarthi> page = saarthiRepository.findAll(new SaarthiSpecification(searchCriteria), pageable);

            List<SaarthiDto> saarthiDtos = page.getContent().stream()
                    .map(SaarthiDto::new)
                    .collect(Collectors.toList());

            SaarthiSearchResultDto saarthiSearchResultDto = SaarthiSearchResultDto.builder()
                    .data(saarthiDtos)
                    .totalRecordCount(page.getTotalElements())
                    .build();

            log.info("Saarthi records retrieved successfully.");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, saarthiSearchResultDto, null);
        } catch (Exception e) {
            log.error("Exception occurred while retrieving Saarthi records: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception occurred while retrieving Saarthi records.");
        }
    }

    public Response updateSaarthiDetails(String saarthiId, Saarthi payload, InternityUser user) {
        try {
            log.info("Attempting to update Saarthi details for ID: {}", saarthiId);

            Optional<Saarthi> saarthiOptional = saarthiRepository.findById(saarthiId);
            if (!saarthiOptional.isPresent()) {
                log.warn("Saarthi with ID {} not found. Cannot update details.", saarthiId);
                return responseUtil.badRequestResponse("Saarthi not found with ID: " + saarthiId);
            }

            Saarthi existingSaarthi = saarthiOptional.get();

            // Update fields based on payload
            updateFieldIfNotBlank(existingSaarthi::setName, payload.getName());
            updateFieldIfNotBlank(existingSaarthi::setEmailId, payload.getEmailId());
            updateFieldIfNotBlank(existingSaarthi::setContactNo, payload.getContactNo());
            updateFieldIfNotBlank(existingSaarthi::setGender, payload.getGender());
            updateFieldIfNotBlank(existingSaarthi::setLocation, payload.getLocation());
            updateFieldIfNotBlank(existingSaarthi::setState, payload.getState());

            // Update fields based on registration type
            if (payload.getRegistrationType() != null) {
                switch (payload.getRegistrationType()) {
                    case COMMUNITY:
                        updateFieldIfNotBlank(existingSaarthi::setCommunityName, payload.getCommunityName());
                        updateFieldIfNotBlank(existingSaarthi::setOrganizationName, payload.getOrganizationName());
                        updateFieldIfNotBlank(existingSaarthi::setPartOfSolution, payload.getPartOfSolution());
                        updateFieldIfNotBlank(existingSaarthi::setWhoAreYou, payload.getWhoAreYou());
                        updateFieldIfNotBlank(existingSaarthi::setExpectationsFromUs, payload.getExpectationsFromUs());
                        updateFieldIfNotBlank(existingSaarthi::setWhyJoin, payload.getWhyJoin());
                        updateFieldIfNotBlank(existingSaarthi::setProfileLinks, payload.getProfileLinks());
                        updateFieldIfNotBlank(existingSaarthi::setAnythingElseText, payload.getAnythingElseText());
                        updateFieldIfNotBlank(existingSaarthi::setGotToKnowPlatform, payload.getGotToKnowPlatform());
                        break;
                    case MENTOR:
                        updateFieldIfNotBlank(existingSaarthi::setCurrCompanyName, payload.getCurrCompanyName());
                        updateFieldIfNotBlank(existingSaarthi::setPrimarySkills, payload.getPrimarySkills());
                        updateFieldIfNotBlank(existingSaarthi::setLevelOfStudy, payload.getLevelOfStudy());
                        if (payload.getTotalExperience() != 0) {
                            existingSaarthi.setTotalExperience(payload.getTotalExperience());
                        }
                        updateFieldIfNotBlank(existingSaarthi::setCurrRole, payload.getCurrRole());
                        updateFieldIfNotBlank(existingSaarthi::setProfileLinks, payload.getProfileLinks());
                        updateFieldIfNotBlank(existingSaarthi::setWhyJoin, payload.getWhyJoin());
                        updateFieldIfNotBlank(existingSaarthi::setAnythingElseText, payload.getAnythingElseText());
                        updateFieldIfNotBlank(existingSaarthi::setGotToKnowPlatform, payload.getGotToKnowPlatform());
                        updateFieldIfNotBlank(existingSaarthi::setReferralCode, payload.getReferralCode());
                        break;
                    case ACADEMIC:
                        updateFieldIfNotBlank(existingSaarthi::setOrganizationName, payload.getOrganizationName());
                        updateFieldIfNotBlank(existingSaarthi::setPartOfSolution, payload.getPartOfSolution());
                        updateFieldIfNotBlank(existingSaarthi::setWhoAreYou, payload.getWhoAreYou());
                        updateFieldIfNotBlank(existingSaarthi::setGotToKnowPlatform, payload.getGotToKnowPlatform());
                        break;
                    case CAMPUS:
                        updateFieldIfNotBlank(existingSaarthi::setOrganizationName, payload.getOrganizationName());
                        updateFieldIfNotBlank(existingSaarthi::setYearOfStudy, payload.getYearOfStudy());
                        if (payload.getPassingYear() != 0.0) {
                            existingSaarthi.setPassingYear(payload.getPassingYear());
                        }
                        updateFieldIfNotBlank(existingSaarthi::setLevelOfStudy, payload.getLevelOfStudy());
                        updateFieldIfNotBlank(existingSaarthi::setNoOfSocietiesClubInstitute, payload.getNoOfSocietiesClubInstitute());
                        updateFieldIfNotBlank(existingSaarthi::setProfileLinks, payload.getProfileLinks());
                        updateFieldIfNotBlank(existingSaarthi::setWhyJoin, payload.getWhyJoin());
                        updateFieldIfNotBlank(existingSaarthi::setAnythingElseText, payload.getAnythingElseText());
                        updateFieldIfNotBlank(existingSaarthi::setGotToKnowPlatform, payload.getGotToKnowPlatform());
                        updateFieldIfNotBlank(existingSaarthi::setReferralCode, payload.getReferralCode());
                        break;
                }
            }

            Saarthi updatedSaarthi = saarthiRepository.saveAndFlush(existingSaarthi);
            log.info("Saarthi details updated successfully.");
            return new Response(HttpStatus.OK.value(), Boolean.TRUE, updatedSaarthi, null);
        } catch (Exception e) {
            log.error("Exception occurred while updating Saarthi details: {}", e.getMessage(), e);
            return responseUtil.internalServerErrorResponse("Exception occurred while updating Saarthi details.");
        }
    }

    private <T> void updateFieldIfNotBlank(Consumer<T> setter, T value) {
        if (StringUtils.isNotBlank(String.valueOf(value))) {
            setter.accept(value);
        }
    }

}
