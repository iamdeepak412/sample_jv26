package com.wue.service.customurl;

import com.wue.constant.customurl.CustomUrlEntityType;
import com.wue.constant.job.ElementType;
import com.wue.domain.Job;
import com.wue.domain.blog.BlogPost;
import com.wue.domain.customurl.CustomUrl;
import com.wue.domain.drill.Drill;
import com.wue.dto.response.Response;
import com.wue.repository.JobsRepository;
import com.wue.repository.blog.BlogPostRepository;
import com.wue.repository.customurl.CustomUrlRepository;
import com.wue.repository.drill.DrillRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.drill.ResponseUtil;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Random;
import java.util.Optional;

@Service
@Log4j2
public class CustomUrlService {
	
	@Autowired
	CustomUrlRepository custUrlRepository;
	
	@Autowired
	CommonUtils commonUtils;
	@Autowired
	ResponseUtil responseUtil;
	@Autowired
	JobsRepository jobsRepository;
	@Autowired
	DrillRepository drillRepository;
	@Autowired
	BlogPostRepository blogPostRepository;


	public Object getLongUrl(String shortUrl, String entityId, InternityUser user) {
	    try {
			if(!entityId.equalsIgnoreCase("NA")){
				Optional<CustomUrl> custUrl = custUrlRepository.findByEntityId(entityId);
				if (custUrl.isPresent()) {
					return custUrl.get();
				} else {
					return null;
				}
            } else {
                Optional<CustomUrl> custUrl = custUrlRepository.findByShortUrl(shortUrl);
                if (custUrl.isPresent()) {
                    return custUrl.get();
                } else {
                    return null;
                }
			}
	    } catch (Exception e) {
            log.error("Exception while fetching the longUrl {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to fetch the longUrl");
        }
	}

    public Object shortenUrl(
            String originalUrl,
            String custUrlFromUser,
            String entityId,
			CustomUrlEntityType entityType,
            InternityUser user) {
        try {
			Optional<CustomUrl> originalurlObj = custUrlRepository.findByOriginalUrl(originalUrl);
			CustomUrl url = new CustomUrl();

			if(originalurlObj.isPresent()){
				url.setId(originalurlObj.get().getId());
			}

			String shortUrl = generateShortUrl(custUrlFromUser);
            url.setShortUrl(shortUrl);
            url.setOriginalUrl(originalUrl);
            url.setEntityId(entityId);
            custUrlRepository.save(url);
            return commonUtils.message(HttpStatus.OK, shortUrl);
        } catch (Exception e) {
            log.error("Exception while generating the shortUrl {}", e);
            return commonUtils.message(
                    HttpStatus.INTERNAL_SERVER_ERROR, "Failed to generate shortUrl");
        }
    }

	    private String generateShortUrl(String custUrlFromUser) {
	        // Generate a unique short URL using random letters and digits
	        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	        Random random = new Random();

	        StringBuilder shortUrlBuilder = new StringBuilder();

	        String shortUrl = custUrlFromUser;

	        // Check if the short URL already exists in the database, and generate a new one if it does
			Optional<CustomUrl> customUrlObj = custUrlRepository.findByShortUrl(shortUrl);

	        if (customUrlObj.isPresent()) {
	            shortUrlBuilder.setLength(0);
	            for (int i = 0; i < 3; i++) {
	                shortUrlBuilder.append(characters.charAt(random.nextInt(characters.length())));
	            }
	            shortUrl =  shortUrl + "-" + shortUrlBuilder.toString();
	        }

	        return shortUrl;
	    }

	    private String getUniqueEntityId(String entityId) {
	        // Add a number suffix to the entity ID to make it unique
	        int suffix = 1;
	        String uniqueEntityId = entityId;
	        while (isEntityIdExists(uniqueEntityId)) {
	            suffix++;
	            uniqueEntityId = entityId + suffix;
	        }
	        return uniqueEntityId;
	    }


	    public boolean isEntityIdExists(String entityId) {
	    	boolean result = custUrlRepository.existsByEntityId(entityId);
			return result;
	    }

    public Response checkCustomUrlValidity(String customUrl, ElementType elementType, InternityUser user) {
		try {
			log.info("Checking custom URL validity {}", customUrl);
			if (StringUtils.isBlank(customUrl)) {
				log.warn("Custom URL is blank");
				return responseUtil.badRequestResponse("Custom URL cannot be blank");
			}
			if (!customUrl.matches("[a-zA-Z0-9\\s-]+")) {
				StringBuilder nonAllowedChars = new StringBuilder();
				for (char c : customUrl.toCharArray()) {
					if (!Character.isLetterOrDigit(c) && c != '-' && c != ' ') {
						nonAllowedChars.append(c).append(",");
					}
				}
				log.warn("Custom URL contains invalid characters: {}", nonAllowedChars);
				return responseUtil.badRequestResponse("Custom URL contains invalid characters. Only alphanumeric characters, hyphens are allowed. Non-allowed characters found: " + nonAllowedChars.toString().trim().replaceAll(",$", ""));
			}
			String formatedUrl = customUrl.toLowerCase().replaceAll("[^a-zA-Z0-9\\s-]+", "-").replaceAll("\\s+", "-").replaceAll("-+", "-").replaceAll("-$", "");

			if (ElementType.DRILL.equals(elementType)) {
				log.info("Checking custom URL for drill existence");
				Optional<Drill> customUrlOptional = drillRepository.findByDrillCustUrl(formatedUrl);
				if (customUrlOptional.isPresent()) {
					log.warn("Custom URL already exists for a drill");
					return responseUtil.conflictResponse("Custom URL already exists for another drill");
				}
			}
			if (ElementType.JOB.equals(elementType)) {
				log.info("Checking custom URL for job existence");
				Optional<Job> jobOptional = jobsRepository.findByCustUrl(formatedUrl);
				if (jobOptional.isPresent()) {
					log.warn("Custom URL already exists for a job");
					return responseUtil.conflictResponse("Custom URL already exists for another job");
				}
			}
			if (ElementType.BLOG.equals(elementType)) {
				log.info("Checking custom URL for Blog existence");
				Optional<BlogPost> blogOptional = blogPostRepository.findByCustUrl(formatedUrl);
				if (blogOptional.isPresent()) {
					log.warn("Custom URL already exists for a Blog post");
					return responseUtil.conflictResponse("Custom URL already exists for another Blog Post");
				}
			}



			log.info("Custom URL is valid");
			return new Response(HttpStatus.OK.value(), Boolean.TRUE, "Custom URL is valid. the Url will be: ' "+ formatedUrl+" '", null);
		} catch (Exception e) {
			log.error("Exception while checking custom URL validity", e);
			return responseUtil.internalServerErrorResponse("Error checking custom URL validity");
		}
    }
}

