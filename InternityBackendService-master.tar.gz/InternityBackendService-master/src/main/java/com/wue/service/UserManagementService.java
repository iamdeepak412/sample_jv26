package com.wue.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.wue.constant.AuthenticationPlatform;
import com.wue.constant.CommonConstants;
import com.wue.constant.Rbac.Roles;
import com.wue.constant.UserRoles;
import com.wue.constant.job.PlatformEntityCategory;
import com.wue.custom.specification.SearchCandidateCriteria;
import com.wue.custom.specification.SearchUserCriteria;
import com.wue.domain.*;
import com.wue.domain.CandidateApplication.JobApplicationScreeningAnswer;
import com.wue.domain.drill.DrillParticipant;
import com.wue.domain.subscription.Subscription;
import com.wue.dto.*;
import com.wue.dto.assessprofile.UserDetailsInBulk;
import com.wue.dto.response.Response;
import com.wue.dto.response.ResponseError;
import com.wue.dto.search.CandidateSpecification;
import com.wue.dto.search.UserSpecification;
import com.wue.model.EmailContent;
import com.wue.model.GoogleAuthentication;
import com.wue.repository.*;
import com.wue.repository.CandidateApplication.JobApplicationScreeningAnswerRepository;
import com.wue.repository.Rbac.RoleManagementRepository;
import com.wue.repository.blog.*;
import com.wue.repository.drill.CustomerUserRepository;
import com.wue.repository.drill.DrillParticipantRepository;
import com.wue.repository.subscription.SubscriptionRepository;
import com.wue.service.drill.DrillService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.OffsetBasedPageRequest;
import com.wue.util.ResumeParser.AwsIntegration;
import com.wue.util.ResumeParser.ResumeParser;
import com.wue.util.SendMessageUtils;
import com.wue.util.drill.ResponseUtil;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.csv.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.http.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@Log4j2
public class UserManagementService {
    private static final ModelMapper modelMapper = new ModelMapper();

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserProfileRepository userProfileRepository;

    @Autowired
    ProfileManagementService profileManagementService;

    @Autowired
    SendMessageUtils messageUtils;

    @Autowired
    UserVerifyRepository userVerifyRepository;

    @Value("${domain.url:http://whereuelevate.com}")
    String domainUrl;

    @Value("${application.jwt.secretKey:fsjfkwjdwqjirjqfknqfmqwkfnqwjfqwfwlfkwf-sknfkjWJFQWDFW-QWDOWQORI22NKRNK}")
    String secretKey1;

    @Value("${application.jwt.tokenExpirationAfterDays:1}")
    int expirationNumberOfDays;

    @Value("${application.jwt.tokenPrefix:'Bearer '}")
    String tokenPrefix;

    @Value("${support.mail.id:techsupport@wuelev8.tech}")
    private String techSupportEmail;

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    CacheManager cacheManager;

    @Autowired
    CacheService cacheService;

    @Autowired
    LoginAttemptRepository loginAttemptRepository;

    @Autowired
    SubscriptionRepository subscriptionRepository;

    @Autowired
    CustomerUserRepository customerUserRepository;

    @Autowired
    PartnerRepository partnerRepository;

    @Autowired
    UserSkillRepository userSkillRepository;

    @Autowired
    ResumeParsingReportRepository parsingReportRepository;

    @Autowired
    EducationInformationRepository educationInformationRepository;

    @Autowired
    WorkProfileRepository workProfileRepository;

    @Autowired
    UserCandidateMandatoryFieldsRepository userCandidateMandatoryFieldsRepository;

    @Autowired
    UserCandidateMandatoryFieldsHistoryRepository userCandidateMandatoryFieldsHistoryRepository;

    @Autowired
    RoleManagementRepository roleManagementRepository;

    @Autowired
    JobApplicationScreeningAnswerRepository screeningAnswerRepository;

    @Autowired
    AwsIntegration awsIntegration;

    @Autowired
    ApplicationRepository applicationRepository;

    @Autowired
    DrillParticipantRepository drillParticipantRepository;

    @Autowired
    BlogPostRepository blogPostRepository;

    @Autowired
    BlogCategoryRepository blogCategoryRepository;

    @Autowired
    CommentRepository commentRepository;

    @Autowired
    ReactionRepository reactionRepository;

    @Autowired
    ReportAbuseRepository reportAbuseRepository;

    @Autowired
    WishlistRepository wishlistRepository;

    @Autowired
    PageviewRepository pageviewRepository;

    @Autowired
    DrillService drillService;

    private String resumeLink;

    @Value("${resume.parsing.url:http://127.0.0.1:5069}")
    private String resumeParsingUrl;

    @Autowired
    ResumeParser resumeParser;
    @Autowired
    ResponseUtil responseUtill;

    public ResponseEntity<String> registerOrUpdate(UserDto userObj, InternityUser user) {
        String verifyUserResponse = checkIfUserAlreadyExists(userObj);
        if (verifyUserResponse.equals("BULKUSER")) {
            userObj.setUId(userRepository.findByEmail(userObj.getUEmail()).get().getUId());
        } else if (!verifyUserResponse.equals("VALID")) {
            return new ResponseEntity<String>("{\"Error\":\"" + verifyUserResponse + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        final int CODE_LENGTH = 6;
        Random random = new Random();
        StringBuilder referralCode = new StringBuilder();
        for (int i = 0; i < CODE_LENGTH; i++) {
            int index = random.nextInt(CHARS.length());
            referralCode.append(CHARS.charAt(index));
        }
        try {
            log.info("register the user {}", userObj);
            userObj.setUserCreatedby(user.getUserName());
            userObj.setUserUpdatedby(user.getUserName());
            userObj.setPassword((new BCryptPasswordEncoder().encode(userObj.getPassword())));
            userObj.setUGroup("GENERAL");
            userObj.setURole("USER");
            userObj.setUsername(userObj.getUEmail());
            userObj.setReferralCode(referralCode.toString());

            User userEntity = modelMapper.map(userObj, User.class);
            log.info("user object to be stored in DB {} ::: {} ::: {}", userEntity, userObj, user);
            User insertedObj = userRepository.save(userEntity);
            log.info("database inserted record {}", insertedObj);

            // Saving details in User Profile
            profileManagementService.save(insertedObj, userObj.getResumeLink(), user);

            sendWelcomeEmailAndOtp(insertedObj, userObj.getReturnUrl());

            return new ResponseEntity<String>("{\"u_id\":\"" + insertedObj.getUId() + "\"}", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in registering user {}", e);
            return new ResponseEntity<String>("{\"Error\":\"Not Registered. Please fill the details properly or contact admin\",\n\"SystemError\":\""
                    + e.getMessage() + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Add user by Admin
     *
     * @param userObj
     * @param user
     * @return
     */
    public ResponseEntity<String> addUserFromAdmin(UserDto userObj, InternityUser user) {
        String verifyUserResponse = checkIfUserAlreadyExists(userObj);
        if (verifyUserResponse.equals("BULKUSER")) {
            userObj.setUId(userRepository.findByEmail(userObj.getUEmail()).get().getUId());
        } else if (!verifyUserResponse.equals("VALID")) {
            return new ResponseEntity<String>("{\"Error\":\"" + verifyUserResponse + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (StringUtils.isBlank(userObj.getPassword())) {
            userObj.setPassword("User@123");
        }
        final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        final int CODE_LENGTH = 6;
        Random random = new Random();
        StringBuilder referralCode = new StringBuilder();
        for (int i = 0; i < CODE_LENGTH; i++) {
            int index = random.nextInt(CHARS.length());
            referralCode.append(CHARS.charAt(index));
        }
        try {
            log.info("register the user {}", userObj);
            userObj.setUserCreatedby(user.getUserName());
            userObj.setUserUpdatedby(user.getUserName());
            userObj.setPassword((new BCryptPasswordEncoder().encode(userObj.getPassword())));
            userObj.setUGroup("GENERAL");
            userObj.setURole("USER");
            userObj.setUsername(userObj.getUEmail());
            userObj.setActive(true);
            userObj.setReferralCode(referralCode.toString());

            User userEntity = modelMapper.map(userObj, User.class);
            log.info("user object to be stored in DB {} ::: {} ::: {}", userEntity, userObj, user);
            User insertedObj = userRepository.save(userEntity);
            log.info("database inserted record {}", insertedObj);

            // Saving details in User Profile
            profileManagementService.save(insertedObj, userObj.getResumeLink(), user);

            return new ResponseEntity<String>("{\"uId\":\"" + insertedObj.getUId() + "\"}", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error in registering user {}", e);
            return new ResponseEntity<String>("{\"Error\":\"Not Registered. Please fill the details properly or contact admin\",\n\"SystemError\":\""
                    + e.getMessage() + "\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public boolean checkIfUserAlreadyExistsWithUid(String uId) {
        return userRepository.findById(uId).isPresent();
    }

    public User checkAndReturnUserObjWithUid(String uId) {
        Optional<User> userObj = userRepository.findById(uId);
        if (userObj.isPresent()) {
            return userObj.get();
        }
        return null;
    }

    private String checkIfUserAlreadyExists(UserDto userObj) {
        Optional<User> emailObj = userRepository.findByEmail(userObj.getUEmail());
        if (!emailObj.isPresent()) {
            if (checkIfContactNumberExists(userObj.getUContact())) {
                return "VALID";
            } else {
                return "Contact number already exists";
            }
        } else {
            User bulkDataUser = emailObj.get();
            if (bulkDataUser.getUGroup().equalsIgnoreCase("NEWUSER")) {
                log.info("User {} with email {} is from bulk data", userObj.getFullName(), userObj.getUEmail());
                if (checkIfContactNumberExists(userObj.getUContact())) {
                    return "BULKUSER";
                } else {
                    return "Contact number already exists";
                }
            }
            return "Email address already exists";
        }
    }

    private boolean checkIfContactNumberExists(String contactNumber) {
        try {
            Optional<User> contactObj = userRepository.findByuContact(contactNumber);
            if (!contactObj.isPresent()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            log.error("Exception while checking phone number {}", e);
            return false;
        }
    }

    private boolean checkIfEmailAlreadyExists(String email) {
        try {
            Optional<User> emailObj = userRepository.findByEmail(email);
            return emailObj.isPresent();
        } catch (Exception e) {
            log.error("Exception while checking email {}", e);
            return false;
        }
    }

    private void sendWelcomeEmailAndOtp(User user, String returnUrl) {
        // send welcome email to user
        try {
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject("Welcome to Where U Elevate, " + user.getFullName());
            emailContent.setTemplateName("WelcomeEmail");
            emailContent.setUserName(user.getFullName());
            emailContent.setMobile(user.getUContact());

            //Delete all entries except one to be added
            userVerifyRepository.deleteAllByUserEmailAndType(user.getEmail(), CommonConstants.REGISTER);

            String otp = savePasswordInDb(user, CommonConstants.REGISTER);
            String encodedUrl = Base64.getEncoder().encodeToString((user.getEmail()).getBytes());
            emailContent.setLink(domainUrl + "/users/verify/" + encodedUrl + "X18=" + otp + "?returnUrl=" + returnUrl);
            messageUtils.sendMail(user.getEmail(), emailContent);
        } catch (Exception exception) {
            log.info(exception.getMessage());
        }
    }


    private void sendForgotPasswordEmail(User user, String returnUrl) {
        // send forgot password email to user
        try {
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject("Forgot your password? No worries " + user.getFullName());
            emailContent.setTemplateName("ForgotPassword");
            emailContent.setUserName(user.getFullName());
            emailContent.setMobile(user.getUContact());

            //Delete all entries except one to be added
            userVerifyRepository.deleteAllByUserEmailAndType(user.getEmail(), CommonConstants.FORGOTPASSWORD);

            String otp = savePasswordInDb(user, CommonConstants.FORGOTPASSWORD);
            emailContent.setLink(domainUrl + "/resetpassword/" + user.getEmail() + "/" + otp + "?returnUrl=" + returnUrl);
            messageUtils.sendMail(user.getEmail(), emailContent);
        } catch (Exception exception) {
            log.error(exception.getMessage());
        }
    }


    private void sendVerificationEmail(User user, String returnUrl) {
        // send welcome email to user
        try {
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject("Please verify your email, " + user.getFullName());
            emailContent.setTemplateName("Verification");
            emailContent.setUserName(user.getFullName());
            emailContent.setMobile(user.getUContact());

            //Delete all entries except one to be added
            userVerifyRepository.deleteAllByUserEmailAndType(user.getEmail(), CommonConstants.REGISTER);

            String otp = savePasswordInDb(user, CommonConstants.REGISTER);
            String encodedUrl = Base64.getEncoder().encodeToString((user.getEmail()).getBytes());
            emailContent.setLink(domainUrl + "/users/verify/" + encodedUrl + "X18=" + otp + "?returnUrl=" + returnUrl);
            messageUtils.sendMail(user.getEmail(), emailContent);
        } catch (Exception exception) {
            log.info(exception.getMessage());
        }
    }


    private String savePasswordInDb(User user, String type) {

        String generatedOtp = generatedOtp();

        UserVerify verify = new UserVerify();
        verify.setUserEmail(user.getEmail());
        verify.setOtp(generatedOtp);
        verify.setType(type);

        //Add one entry
        userVerifyRepository.save(verify);

        return generatedOtp;
    }

    private String generatedOtp() {
        int leftLimit = 97; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 10;

        return new Random().ints(leftLimit, rightLimit + 1).limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
    }

    public User loginUser(String uEmail, String password, InternityUser internityUser) throws Exception {
        Optional<User> userObj = userRepository.findByEmail(uEmail);
        log.info(userObj.get());
        if (userObj.isPresent()) {
            User user = userObj.get();

            if (user.isActive() && user.getPassword().equalsIgnoreCase(password)) {
                return user;
            } else if (!user.isActive()) {
                throw new Exception("Please verify your email id");
            }
        }
        return null;
    }

    public boolean addProfile(UserPersonalDetail userProfileObj, InternityUser user) {
        try {
            userProfileObj.setProfileCreatedby(user.getUserName());
            userProfileObj.setProfileUpdatedby(user.getUserName());
            userProfileRepository.save(userProfileObj);

            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public List<User> getUsers(String query, InternityUser internityUser) {

        List<User> resumeUpdatedList = new ArrayList<>();

        if (query.equals("NA")) {
            List<User> userList = userRepository.findAll();
            for (User userObj : userList) {
                try {
                    Optional<UserPersonalDetail> personalDetail = userProfileRepository.findByuId(userObj.getUId());
                    if (personalDetail.isPresent()) {
                        userObj.setResumeLink(personalDetail.get().getResumeLink());
                    }
                } catch (Exception e) {
                    log.error("Error while adding resume link to user {}", e);
                }
                userObj.setPassword(null);
                resumeUpdatedList.add(userObj);
            }
            return resumeUpdatedList;
        } else {
            return Collections.emptyList();
        }
    }

    public User getSingleUser(String uid) {
        Optional<User> userObj = userRepository.findById(uid);
        if (userObj.isPresent()) {
            User user = userObj.get();
            user.setPassword((null));
            return user;
        } else {
            return new User();
        }
    }

    public UserAuthDto getUserDetails(String username) {
        Optional<User> userObj = userRepository.findByUsername(username);
        if (userObj.isPresent()) {
            User user = userObj.get();
            return new UserAuthDto(user.getUsername(), user.getPassword(), getAuthority(user.getURole()));
        }
        return null;
    }

    /**
     * Getting authority
     *
     * @param role
     */
    private Collection<? extends GrantedAuthority> getAuthority(String role) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority(role));
        return authorities;
    }

    public ResponseEntity<String> verifyUser(String encodedString, InternityUser userObj) {
        String[] strArr = encodedString.split("X18=");
        Map<String, String> responseMap = new HashMap<>();
        responseMap.put("status", "200");
        responseMap.put("message", "User account is active. Thank you for your patience. Please login and continue.");
        String email = new String(Base64.getDecoder().decode(strArr[0].getBytes()));
        Optional<User> userEntry = userRepository.findByEmail(email);
        if (userEntry.isPresent()) {
            if (userEntry.get().isActive()) {
                return new ResponseEntity<>(
                        "{\"msg\":\"User is already verified.\"}",
                        HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<>(
                    "{\"msg\":\"User is not registered. This issue will be reported to the Admin support team\"}",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        Optional<UserVerify> entry = userVerifyRepository.findByUserEmailAndOtp(email, strArr[1]);
        if (entry.isPresent()) {
            User user = userEntry.get();
            if (!user.isActive()) {
                user.setActive(true);
                userRepository.save(user);
                userVerifyRepository.delete(entry.get());
                return new ResponseEntity<>(
                        "{\"msg\":\"User account is active. Thank you for your patience. Please login and continue\"",
                        HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        "{\"msg\":\"User account is already Active\"", HttpStatus.OK);
            }
        } else {
            return new ResponseEntity<>("{\"msg\":\"Nothing to verify. " +
                    "This issue will be reported to the Admin support team\"}",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public Map<String, String> forgotPassword(String emailid, String returnUrl, InternityUser user) {
        Map<String, String> response = new HashMap<>();
        try {
            Optional<User> userObj = userRepository.findByEmail(emailid);
            if (userObj.isPresent()) {
                sendForgotPasswordEmail(userObj.get(), returnUrl);
            } else {
                response.put(CommonConstants.ERROR, "User is not registered yet, please register.");
            }
            response.put(CommonConstants.MSG, "Please check your email account for resetting password");
        } catch (Exception e) {
            response.put(CommonConstants.ERROR, "Unable to sent notification for resetting password. " + e.getMessage());
        }
        return response;
    }

    public Map<String, String> updateForgotPassword(UpdatePassword body, InternityUser internityUser) {

        Map<String, String> response = new HashMap<>();

        try {
            String email = body.getEmailid();
            Optional<User> userObj = userRepository.findByEmail(email);
            if (userObj.isPresent()) {
                User user = userObj.get();
                body.setEmailid(email);
                Optional<UserVerify> obj = userVerifyRepository.findByUserEmailAndOtp(email, body.getOldPassword());
                if (obj.isPresent()) {
                    updatePasswordForUser(user, body.getNewPassword());
                    response.put("msg", "Password updated successfully");
                } else {
                    response.put("Error", "Invalid details. Please refer to your mail again or send another recovery link");
                }
            } else {
                response.put("Error", "User is not present in our database. Kindly check once with our support team.");
            }
        } catch (Exception e) {
            throw new RuntimeException("Error while updating the password. Please contact support team");
        }
        return response;
    }

    private void updatePasswordForUser(User user, String newPassword) {
        user.setPassword((new BCryptPasswordEncoder().encode(newPassword)));
        userRepository.save(user);
    }

    public ResponseEntity<?> changePasswordAfterLogin(String uId, UpdatePassword body) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                User user = userObj.get();
                updatePasswordForUser(user, body.getNewPassword());
            }
            return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "Password changed successfully")
                    , HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage())
                    , HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> getListOfLoginAttempt(String email, InternityUser internityUser) {
        try {
            return new ResponseEntity<List<LoginAttempt>>(loginAttemptRepository
                    .findByAttemptEmail(email), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
                    , "Failed to fetch Login attempt"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> saveLoginAttempt(LoginAttempt loginAttemptObj, InternityUser internityUser) {
        try {
            loginAttemptRepository.save(loginAttemptObj);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.OK
                    , "Login attempt saved"), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
                    , "Failed to fetch Login attempt"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<Map<String, String>> resendVerification(String emailid, String returnUrl, InternityUser user) {
        try {
            Optional<User> userObj = userRepository.findByEmail(emailid);
            if (userObj.isPresent()) {
                if (userObj.get().isActive()) {
                    return new ResponseEntity<Map<String, String>>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                            "You account is verified. Please click on Forgot Password or " +
                                    "contact " + techSupportEmail + " for further support"),
                            HttpStatus.INTERNAL_SERVER_ERROR);
                } else {
                    sendVerificationEmail(userObj.get(), returnUrl);
                    return new ResponseEntity<Map<String, String>>(commonUtils.message(HttpStatus.OK,
                            "Verification link is sent successfully"), HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<Map<String, String>>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                        "User is not registered yet. Please register."), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            return new ResponseEntity<Map<String, String>>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Please contact " + techSupportEmail + " for further support"),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public UserSearchResultDto searchUser(SearchUserCriteria searchCriteria, int offset,
                                          int limit, String order, String profile) {
        log.info("Search criteria: {}", searchCriteria);
        UserSearchResultDto userSearchResultDTO = null;
        try {
            // log.info("Search criteria: {}", searchCriteria);
            String[] sort = order.split("\\.");
            Sort direction =
                    Sort.by(
                            "desc".equalsIgnoreCase(sort[1])
                                    ? Sort.Direction.DESC
                                    : Sort.Direction.ASC,
                            sort[0]);
            Page<User> page = null;
            if (!searchCriteria.getEmail().equals("all")) {
                page =
                        userRepository.findAll(
                                new UserSpecification(searchCriteria),
                                OffsetBasedPageRequest.of(offset, limit, direction));
            } else if (searchCriteria.getIsActive().equals("NA")) {
                page = userRepository.findAll(OffsetBasedPageRequest.of(offset, limit, direction));
            } else {
                page =
                        userRepository.findAll(
                                new UserSpecification(searchCriteria),
                                OffsetBasedPageRequest.of(offset, limit, direction));
            }
            List<UserFilterDto> users =
                    page.stream().map(user -> new UserFilterDto(user)).collect(Collectors.toList());

            String result =
                    new ObjectMapper()
                            .writerWithView(SearchProfiles.getProfileByName(profile))
                            .writeValueAsString(users);

            users =
                    new ObjectMapper()
                            .readValue(result, new TypeReference<List<UserFilterDto>>() {
                            });

            userSearchResultDTO =
                    UserSearchResultDto.builder()
                            .Details(users)
                            .totalRecordCount(page.getTotalElements())
                            .build();
        } catch (Exception e) {
            log.error("Exception while searching users {}", e);
        }
        log.info("cached data {}", cacheManager.getCache("users"));
        return userSearchResultDTO;
    }

    public ResponseEntity<?> userHasAccessToDrill(String uId, String component, String componentId) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                Optional<Subscription> subscriptionObj = subscriptionRepository
                        .findByuIdAndComponentAndComponentIdAndIsActiveTrue(uId, component, componentId);
                if (subscriptionObj.isPresent()) {
                    return new ResponseEntity<>(userObj.get(), HttpStatus.OK);
                }
            } else {
                return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                        "User is not present. please contact " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Exception while fetching the subscription of the user {}", e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while fetching the subscription of the user with error" +
                            e.getMessage() + ". please contact " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                "Failed to fetch details of the user. please contact " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ResponseEntity<?> assignUserToCustomer(CustomerUser payload, InternityUser internityUser) {
        try {
            return new ResponseEntity<>(customerUserRepository.save(payload), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while assigning user to customer {}", e);
            return new ResponseEntity<>(
                    commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                            "Failed while assigning user to customer"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> updateSingleTargetOfUser(String uid, String target, User user) {
        try {
            Optional<User> userObj = userRepository.findById(uid);
            if (userObj.isPresent()) {
                User userObject = userObj.get();
                if (target.equalsIgnoreCase("role")) {
                    userObject.setURole(user.getURole());
                } else if (target.equalsIgnoreCase("type")) {
                    userObject.setUType(user.getUType());
                } else {
                    commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, target);

                }
                userRepository.save(userObject);
                return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "Target Updated Successfully"), HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while updating the details of the user {}", e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Exception while updating the details of the user" + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "Target Updated Successfully"), HttpStatus.OK);


    }

    public ResponseEntity<?> activateSingleUser(String uId, boolean action, InternityUser internityUser) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                User user = userObj.get();
                user.setActive(action);
                userRepository.save(user);
                return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "User updated successfully"),
                        HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while activating a single user ::: {}", e);
        }
        return new ResponseEntity<>(
                commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to activate the user"),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ResponseEntity<?> fetchCustomerOfUser(String uId, InternityUser internityUser) {
        try {
            Optional<CustomerUser> customerUserObj = customerUserRepository.findById(uId);
            if (customerUserObj.isPresent()) {
                Optional<Partner> partnerObj = partnerRepository.findById(customerUserObj.get().getCompanyId());
                if (partnerObj.isPresent()) {
                    return new ResponseEntity<>(partnerObj.get(), HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Customer is not found in the database. Please contact " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
                }
            } else {
                return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "User is not found related to any customer. Please contact " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Failed to fetch the customer id with error ::: {}", e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch the customer id with error " + e.getMessage() + ". Please contact " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public ResponseEntity<?> bulkImportMails(String bulkEmails, int startingContactNumber) {
        try {
            String[] listOfEmails = bulkEmails.split(",");
            for (String email : listOfEmails) {
                createUser(email.trim(), startingContactNumber);
                startingContactNumber++;
            }
            return new ResponseEntity<>("Imported successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception while importing bulk emails {}", e);
        }
        return new ResponseEntity<>("Imported successfully", HttpStatus.OK);
    }

    private void createUser(String email, int startingContactNumber) {
        try {
            User user = new User();
            user.setPassword("User@123");
            user.setActive(false);
            user.setUContact(startingContactNumber + "");
            user.setUType("NEWUSER");
            user.setFullName("User");
            user.setEmail(email);
            user.setUGroup("NEWUSER");
            user.setUsername(email);
            userRepository.save(user);
            log.info("User registered {} ::: {}", email, startingContactNumber);
        } catch (Exception e) {
            log.error("Email not registered {} ::: {}", email, e.getMessage());
        }
    }

    public LoginAttempt setLoginAttemptObj(User user, HttpServletRequest request) {
        try {
            LoginAttempt loginAttempt = new LoginAttempt();
            loginAttempt.setAttemptEmail(user.getEmail());
            loginAttempt.setAttemptTime(LocalDateTime.now());
            loginAttempt.setDevice(request.getHeader("User-Agent"));
            return loginAttempt;
        } catch (Exception e) {
            log.error("Exception while creating object for Login Attempt {}", e);
            return null;
        }
    }

    public ByteArrayInputStream getCSVLoad(List<UserFilterDto> userDto) {
        final CSVFormat format =
                CSVFormat.DEFAULT
                        .withQuoteMode(QuoteMode.MINIMAL)
                        .withHeader(
                                "Full name",
                                "Email",
                                "Registered Date",
                                "User type"
                        );

        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             CSVPrinter csvPrinter = new CSVPrinter(new PrintWriter(out), format);) {
            for (UserFilterDto user : userDto) {
                List<String> data =
                        Arrays.asList(
                                user.getFullName() + "",
                                user.getUEmail() + "",
                                user.getUserCreatedts() + "",
                                user.getUType());
                csvPrinter.printRecord(data);
            }
            csvPrinter.flush();
            return new ByteArrayInputStream(out.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException("fail to import data to CSV file: " + e.getMessage());
        }
    }

    public ResponseEntity<?> saveMandatoryFields(
            UserCandidateMandatoryFields payload, InternityUser internityUser) {
        try {
            Optional<User> userObj =
                    userRepository.findById(payload.getUId());
            if (userObj.isPresent()) {

                UserCandidateMandatoryFields userCandidateMandatoryFields = new UserCandidateMandatoryFields();

                UserCandidateMandatoryFields tempUserCandidateMandatoryFields = new UserCandidateMandatoryFields();

                Optional<UserCandidateMandatoryFields> userCandidateMandatoryFieldsObj =
                        userCandidateMandatoryFieldsRepository.findByuId(payload.getUId());
                if (userCandidateMandatoryFieldsObj.isPresent()) {
                    tempUserCandidateMandatoryFields = userCandidateMandatoryFieldsObj.get();
                    userCandidateMandatoryFields.setId(tempUserCandidateMandatoryFields.getId());
                }

                userCandidateMandatoryFields.setUId(payload.getUId());

                userCandidateMandatoryFields.setCurrentCtc(
                        payload.getCurrentCtc() != 0.0
                                ? payload.getCurrentCtc()
                                : tempUserCandidateMandatoryFields.getCurrentCtc());

                userCandidateMandatoryFields.setCurrentDesignation(
                        !StringUtils.isBlank(payload.getCurrentDesignation())
                                ? payload.getCurrentDesignation()
                                : tempUserCandidateMandatoryFields.getCurrentDesignation());

                userCandidateMandatoryFields.setCurrentOrg(
                        !StringUtils.isBlank(payload.getCurrentOrg())
                                ? payload.getCurrentOrg()
                                : tempUserCandidateMandatoryFields.getCurrentOrg());

                userCandidateMandatoryFields.setCurrentLoc(
                        !StringUtils.isBlank(payload.getCurrentLoc())
                                ? payload.getCurrentLoc()
                                : tempUserCandidateMandatoryFields.getCurrentLoc());

                userCandidateMandatoryFields.setExpectedCtc(
                        payload.getExpectedCtc() != 0.0
                                ? payload.getExpectedCtc()
                                : tempUserCandidateMandatoryFields.getExpectedCtc());

                userCandidateMandatoryFields.setActivelySearching(payload.isActivelySearching());

                userCandidateMandatoryFields.setYoe(
                        payload.getYoe() != 0.0
                                ? payload.getYoe()
                                : tempUserCandidateMandatoryFields.getYoe());

                userCandidateMandatoryFields.setPreferredLoc(
                        !StringUtils.isBlank(payload.getPreferredLoc())
                                ? payload.getPreferredLoc()
                                : tempUserCandidateMandatoryFields.getPreferredLoc());

                userCandidateMandatoryFields.setLastWorkingDay(
                        payload.getLastWorkingDay() != null
                                ? payload.getLastWorkingDay()
                                : tempUserCandidateMandatoryFields.getLastWorkingDay());

                userCandidateMandatoryFields.setPrimarySkills(
                        StringUtils.isBlank(payload.getPrimarySkills())
                                ? "" // Save an empty string if primarySkills is null or empty
                                : payload.getPrimarySkills() // Save the value from payload if it's not null or empty
                );

                userCandidateMandatoryFields.setNoticePeriodDays(
                        payload.getNoticePeriodDays() != -1
                                ? payload.getNoticePeriodDays()
                                : -1);

                userCandidateMandatoryFields.setResumeLink(
                        StringUtils.isNoneBlank(payload.getResumeLink())
                                ? payload.getResumeLink()
                                : StringUtils.EMPTY);

                userCandidateMandatoryFields.setServingNp(payload.isServingNp());

                UserCandidateMandatoryFields savedRecord = userCandidateMandatoryFieldsRepository
                        .saveAndFlush(userCandidateMandatoryFields);

                savedRecord.setResumeLink(payload.getResumeLink());

                syncOtherTables(userCandidateMandatoryFields);

                //save data in the history table
                saveMandatoryFieldsInHistoryTable(savedRecord);

                return new ResponseEntity<>(savedRecord, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(
                        commonUtils.message(
                                HttpStatus.INTERNAL_SERVER_ERROR, "User is not present"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Exception while saving mandatory fields for user {}", e);
        }
        return new ResponseEntity<>("An exception occurred while saving mandatory fields for user. Please contact support team", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private boolean syncOtherTables(UserCandidateMandatoryFields mandatoryFields) {
        try {
            Optional<UserPersonalDetail> userProfileObj = userProfileRepository.findByuId(mandatoryFields.getUId());
            if (userProfileObj.isPresent()) {
                if (StringUtils.isNoneBlank(mandatoryFields.getResumeLink())) {
                    UserPersonalDetail userPersonalDetail = userProfileObj.get();
                    userPersonalDetail.setResumeLink(mandatoryFields.getResumeLink());
                    userProfileRepository.save(userPersonalDetail);
                    return true;
                }
            }
        } catch (Exception e) {
            log.error("Exception while syncing other tables with mandatory fields values ::: {}", e);
        }
        return false;
    }

    private boolean saveMandatoryFieldsInHistoryTable(UserCandidateMandatoryFields savedRecord) {
        try {
            UserCandidateMandatoryFieldsHistory userCandidateMandatoryFieldsHistory = new UserCandidateMandatoryFieldsHistory();
            userCandidateMandatoryFieldsHistory.setUId(savedRecord.getUId());
            userCandidateMandatoryFieldsHistory.setCurrentCtc(savedRecord.getCurrentCtc());
            userCandidateMandatoryFieldsHistory.setActivelySearching(savedRecord.isActivelySearching());
            userCandidateMandatoryFieldsHistory.setCurrentDesignation(savedRecord.getCurrentDesignation());
            userCandidateMandatoryFieldsHistory.setCurrentLoc(savedRecord.getCurrentLoc());
            userCandidateMandatoryFieldsHistory.setUserUpdatedby(savedRecord.getUserUpdatedby());
            userCandidateMandatoryFieldsHistory.setUserCreatedby(savedRecord.getUserCreatedby());
            userCandidateMandatoryFieldsHistory.setUserUpdatedts(savedRecord.getUserUpdatedts());
            userCandidateMandatoryFieldsHistory.setUserUpdatedby(savedRecord.getUserUpdatedby());
            userCandidateMandatoryFieldsHistory.setCurrentOrg(savedRecord.getCurrentOrg());
            userCandidateMandatoryFieldsHistory.setExpectedCtc(savedRecord.getExpectedCtc());
            userCandidateMandatoryFieldsHistory.setYoe(savedRecord.getYoe());
            userCandidateMandatoryFieldsHistory.setPreferredLoc(savedRecord.getPreferredLoc());
            userCandidateMandatoryFieldsHistory.setNoticePeriodDays(savedRecord.getNoticePeriodDays());
            userCandidateMandatoryFieldsHistory.setLastWorkingDay(savedRecord.getLastWorkingDay());
            userCandidateMandatoryFieldsHistory.setServingNp(savedRecord.isServingNp());
            userCandidateMandatoryFieldsHistoryRepository.saveAndFlush(userCandidateMandatoryFieldsHistory);
            return true;
        } catch (Exception e) {
            log.error("Exception while saving the details in the history table");
            return false;
        }
    }

    public ResponseEntity<?> fetchMandatoryFields(String uId, InternityUser user) {
        try {
            Optional<UserCandidateMandatoryFields> userCandidateMandatoryFieldsObj = userCandidateMandatoryFieldsRepository
                    .findByuId(uId);
            if (userCandidateMandatoryFieldsObj.isPresent()) {
                UserCandidateMandatoryFields userCandidateMandatoryFields = userCandidateMandatoryFieldsObj.get();
                userCandidateMandatoryFields.setResumeLink(fetchResumeOfAnUser(userCandidateMandatoryFields.getUId()));
                return new ResponseEntity<>(userCandidateMandatoryFields, HttpStatus.OK);
            } else {
                UserCandidateMandatoryFields userCandidateMandatoryFields = new UserCandidateMandatoryFields();
                userCandidateMandatoryFields.setNoticePeriodDays(-1);
                return new ResponseEntity<>(userCandidateMandatoryFields, HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while fetching the mandatory fields for user {}", e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "An exception occurred while fetching the mandatory fields for user. Please contact support team"), HttpStatus.OK);
        }
    }

    private String fetchResumeOfAnUser(String uId) {
        try {
            Optional<UserPersonalDetail> userProfileObj = userProfileRepository.findByuId(uId);
            if (userProfileObj.isPresent()) {
                return userProfileObj.get().getResumeLink();
            }
        } catch (Exception e) {
            log.error("Exception while fetching the resume of an user ::: {}", e);
        }
        return StringUtils.EMPTY;
    }

    public Object parseResume(int limit, InternityUser user) {
        StringBuilder report = new StringBuilder();
        List<UserPersonalDetail> allUsers = userProfileRepository.findAll();
        List<UserPersonalDetail> usersWithResumes = new ArrayList<>();
        allUsers.forEach(u -> {
            if (u.getResumeLink() != null) {
                usersWithResumes.add(u);
            }
        });
        ResumeParsingReport parsingReport = new ResumeParsingReport();

        for (UserPersonalDetail registeredUser : usersWithResumes) {
            resumeLink = registeredUser.getResumeLink();
            try {
                if (registeredUser.getUId() != parsingReport.getDocumentOwnerId()) {
                    for (int i = 0; i < limit; i++) {
                        parseResumeAndSaveUserDetails(resumeLink, null, parsingReport, registeredUser);

                        report.append("Resume Parsed for" + " with id ").append(registeredUser.getUId());
                    }
                }
            } catch (Exception e) {
                log.error("Exception while parsing resume ::: {}", e);
                parsingReport.setParsed(false);
                parsingReport.setDocumentType("resume");
                parsingReport.setDocumentOwnerId(registeredUser.getUId());
                parsingReport.setEmail(registeredUser.getUId());
                report.append("[NOT PARSED] Resume did not parse for " + " with id ").append(registeredUser.getUId()).append(" due to ").append(e.getMessage());
                parsingReportRepository.save(parsingReport);
            }
        }

        return report.toString();
    }

    /**
     * Parse resume and save user details. If the user is not registered
     * then the profile will be created
     *
     * @param resumeLink
     * @param parsingReport
     * @param registeredUser
     * @return
     */
    private Response parseResumeAndSaveUserDetails(String resumeLink, String jobId,
                                                   ResumeParsingReport parsingReport,
                                                   UserPersonalDetail registeredUser) {
        log.info("parsing resume ::: {} ", resumeLink);
        try {
            JSONObject json = resumeParser.parsedResumeObj(resumeLink);
            log.info("json data from resume :::{} ", json.toString());
            if (StringUtils.isAnyBlank(json.toString())) {
                parsingReport.setParsed(false);
                parsingReport.setDocumentType("resume");
                parsingReport.setDocumentOwnerId(resumeLink);
                parsingReport.setEmail(null);
                parsingReportRepository.save(parsingReport);
                log.error("Exception while parsing resume getting empty data from resume");
                return responseUtill.internalServerErrorResponse("Exception while parsing resume getting empty data from resume");
            }
            log.info("Resume parsed successfully");
            List<UserDetailsInBulk> userDetailsInBulkList = new ArrayList<>();
            String email = json.has("email") && !json.isNull("email") ? json.getString("email") : null;
            if (StringUtils.isBlank(email)) {
                saveParsedReport(false, resumeLink, null);
                log.error("Email is not present in the resume");
                return responseUtill.internalServerErrorResponse("Email is not present in the resume");
            }

            UserDetailsInBulk userDetailsInBulk = resumeParser.getUserDetailsObjFromParsedResume(json, resumeLink, jobId);
            if (userDetailsInBulk == null) {
                saveParsedReport(false, resumeLink, email);
                log.error("Exception while getting user details object from parsed resume");
                return responseUtill.internalServerErrorResponse("Exception while getting user details object from parsed resume");
            }
            userDetailsInBulkList.add(userDetailsInBulk);
            Response response = iterateAndSaveUserDetails(userDetailsInBulkList);
            if (!response.getSuccess()) {
                saveParsedReport(false, resumeLink, email);
                return response;
            }
            List<String> uIdList = (List<String>) response.getResult();
            if (uIdList == null) {
                saveParsedReport(false, resumeLink, email);
                log.error("Exception while saving the basic details of the user from parsed resume");
                return responseUtill.internalServerErrorResponse("Exception while saving the basic details of the user from parsed resume");
            }
            saveParsedReport(true, uIdList.get(0), email);
            log.info("User details saved successfully ::: " + uIdList.get(0));
            return responseUtill.successResponse(uIdList.get(0));
        } catch (Exception e) {
            log.error("Exception while parsing resume and saving details of the user ::: {}", e.getMessage());
            return responseUtill.internalServerErrorResponse("Exception while parsing resume and saving details of the user");
        }
    }

    public void saveParsedReport(boolean success, String documentOwnerId, String email) {
        ResumeParsingReport parsingReport = new ResumeParsingReport();
        parsingReport.setParsed(success);
        parsingReport.setDocumentType("resume");
        parsingReport.setDocumentOwnerId(documentOwnerId);
        parsingReport.setEmail(email);
        parsingReportRepository.save(parsingReport);
    }

    private User saveUserBasicDetails(JSONObject json, String resumeLink) {
        try {
            String email = json.getString("email");

            User user = new User();
            user.setUsername(email);
            user.setEmail(email);
            user.setPassword("User@123");
            user.setActive(false);
            if (json.getString("mobile_number").equalsIgnoreCase("0")) {
                long unixTime = System.currentTimeMillis() / 1000L;
                log.info("generating random number ::: {}", unixTime);
                user.setUContact(unixTime + "");
            } else {
                user.setUContact(json.getString("mobile_number"));
            }
            user.setUType("NEWUSER");
            user.setFullName(json.getString("name"));
            user.setUGroup("NEWUSER");

            User insertedObj = userRepository.save(user);

            profileManagementService.save(insertedObj, resumeLink, null);

            return insertedObj;

        } catch (Exception e) {
            log.error("Exception while saving the basic details of the user from parsed resume ::: {}", e);
            return null;
        }
    }

    private void saveUserSkills(UserDetailsInBulk userDetailsInBulk, String uId) {
        String skills = userDetailsInBulk.getSkills();
        skills = skills.replaceAll("\\[", "").replaceAll("]", "");
        String[] skillsArray = skills.split(",");
        for (String skillName : skillsArray) {
            UserSkill userSkill = new UserSkill();
            userSkill.setUId(uId);
            userSkill.setSkillName(skillName);
            userSkillRepository.save(userSkill);
        }
    }

    private void saveEducationInformation(UserDetailsInBulk userDetailsInBulk, String uId) {
        EducationInformation education = new EducationInformation();
        //education.setDegree(json.isNull("degree")?"":json.get("degree")+"");
        //education.setInstituteName(userDetailsInBulk.getCollegeName());
        education.setUId(uId);
        educationInformationRepository.save(education);

    }

    private void saveUserWorkProfile(UserDetailsInBulk userDetailsInBulk, String uId) {
        UserWorkProfile workProfile = new UserWorkProfile();
        workProfile.setJobDesignation(userDetailsInBulk.getDesignation());
        //workProfile.setOrganisationName(json.get("company_names")+"");
        //workProfile.setOrganisationName(userDetailsInBulk.getDesignation());
        workProfile.setUId(uId);
        workProfileRepository.save(workProfile);
    }

    private void saveUserCandidateMandatoryFields(UserDetailsInBulk userDetailsInBulk, String uId) {

        Optional<UserCandidateMandatoryFields> fieldsObj = userCandidateMandatoryFieldsRepository.findByuId(uId);
        UserCandidateMandatoryFields mandatoryFields = null;

        mandatoryFields = fieldsObj.orElseGet(UserCandidateMandatoryFields::new);
        if (StringUtils.isBlank(mandatoryFields.getPrimarySkills()) || mandatoryFields.getPrimarySkills().equals("[]")) {
            mandatoryFields.setPrimarySkills(userDetailsInBulk.getSkills());
        }

        mandatoryFields.setUId(uId);

        //mandatoryFields.setCurrentDesignation(json.isNull("designation")?"":json.get("designation")+"");
        //mandatoryFields.setCurrentDesignation(userDetailsInBulk.getDesignation());
        //mandatoryFields.setYoe(Double.parseDouble(userDetailsInBulk.getYoe()));
        userCandidateMandatoryFieldsRepository.saveAndFlush(mandatoryFields);
    }

    public CandidateSearchResultDto searchCandidate(SearchCandidateCriteria searchCandidateCriteria, int offset, int limit, String order, String name) {
        try {
            String[] sort = order.split("\\.");
            Sort direction = Sort.by("desc".equalsIgnoreCase(sort[1]) ? Sort.Direction.DESC : Sort.Direction.ASC, sort[0]);

            List<CandidateFilterDto> candidateFilterDtoList = new ArrayList<>();
            Map<String, UserCandidateMandatoryFields> uIdAndMandatoryFieldsMap = new HashMap<>();

            Long countOfUsersWithMandatoryFields = userCandidateMandatoryFieldsRepository.count();

            Page<UserCandidateMandatoryFields> candidatePage = userCandidateMandatoryFieldsRepository.findAll(
                    new CandidateSpecification(searchCandidateCriteria, applicationRepository),
                    OffsetBasedPageRequest.of(offset, limit, direction));

            List<UserCandidateMandatoryFields> candidates = candidatePage.stream().collect(Collectors.toList());

            for (UserCandidateMandatoryFields candidate : candidates) {
                uIdAndMandatoryFieldsMap.put(candidate.getUId(), candidate);
            }

            int totalRecords = 0;

            if (!searchCandidateCriteria.getName().equalsIgnoreCase("all")
                    || !searchCandidateCriteria.getEmail().equalsIgnoreCase("all")) {
                SearchUserCriteria searchUserCriteria = SearchUserCriteria.builder()
                        .email(searchCandidateCriteria.getEmail())
                        .fullName(searchCandidateCriteria.getName())
                        .isActive(searchCandidateCriteria.getIsActive())
                        .build();

                Page<User> page =
                        userRepository.findAll(
                                new UserSpecification(searchUserCriteria),
                                OffsetBasedPageRequest.of(offset, 100, direction));

                List<UserFilterDto> users =
                        page.stream().map(user -> new UserFilterDto(user)).collect(Collectors.toList());
                Map<String, UserFilterDto> uIdAndEmailNameMap = new HashMap<>();

                totalRecords = users.size();

                for (UserFilterDto user : users) {
                    uIdAndEmailNameMap.put(user.getUId(), user);
                }

                List<String> listOfUid = new ArrayList<>();
                Map<String, UserPersonalDetail> uIdAndResumeMap = new HashMap<>();

                listOfUid.addAll(uIdAndEmailNameMap.keySet());
                List<UserPersonalDetail> userProfileList = userProfileRepository.findByuIdIn(listOfUid);

                for (UserPersonalDetail userProfile : userProfileList) {
                    uIdAndResumeMap.put(userProfile.getUId(), userProfile);
                }

                for (UserFilterDto user : users) {
                    CandidateFilterDto candidateFilterDto = new CandidateFilterDto();
                    UserCandidateMandatoryFields fields =
                            uIdAndMandatoryFieldsMap.get(user.getUId());
                    candidateFilterDto.setEmail(user.getUEmail());
                    candidateFilterDto.setName(user.getFullName());
                    UserPersonalDetail toGetResume = uIdAndResumeMap.get(user.getUId());
                    candidateFilterDto.setResumeLink(
                            toGetResume == null ? "NA" : toGetResume.getResumeLink()
                    );
                    candidateFilterDto.setContact(user.getUContact());
                    candidateFilterDto.setUId(user.getUId());
                    if (fields != null) {
                        candidateFilterDto.setCurrentLocation(fields.getCurrentLoc());
                        candidateFilterDto.setCurrentCtc(fields.getCurrentCtc());
                        candidateFilterDto.setCurrentOrg(fields.getCurrentOrg());
                        candidateFilterDto.setCurrentDesignation(fields.getCurrentDesignation());
                        candidateFilterDto.setExpectedCtc(fields.getExpectedCtc());
                        candidateFilterDto.setPreferredLocation(fields.getPreferredLoc());
                        candidateFilterDto.setSkills(fields.getPrimarySkills());
                        candidateFilterDto.setServingNp(fields.isServingNp());
                        candidateFilterDto.setYoe(fields.getYoe());
                        candidateFilterDto.setActivelySearching(fields.isActivelySearching());
                    }
                    candidateFilterDtoList.add(candidateFilterDto);
                }
            } else {

                totalRecords = Integer.parseInt(countOfUsersWithMandatoryFields + "");

                Map<String, User> uIdAndEmailNameMap = new HashMap<>();
                Map<String, UserPersonalDetail> uIdAndResumeMap = new HashMap<>();
                List<String> listOfUid = new ArrayList<>();
                listOfUid.addAll(uIdAndMandatoryFieldsMap.keySet());
                List<User> userListWithCandidate = userRepository.findByuIdIn(listOfUid);
                List<UserPersonalDetail> userProfileList = userProfileRepository.findByuIdIn(listOfUid);

                for (User user : userListWithCandidate) {
                    uIdAndEmailNameMap.put(user.getUId(), user);
                }

                for (UserPersonalDetail userProfile : userProfileList) {
                    uIdAndResumeMap.put(userProfile.getUId(), userProfile);
                }

                for (UserCandidateMandatoryFields fields : candidates) {
                    try {
                        CandidateFilterDto candidateFilterDto = new CandidateFilterDto();
                        log.info(fields.getUId() + "...being checked");
                        candidateFilterDto.setEmail(
                                uIdAndEmailNameMap.get(fields.getUId()).getFullName()
                        );
                        candidateFilterDto.setName(
                                uIdAndEmailNameMap.get(fields.getUId()).getFullName()
                        );
                        UserPersonalDetail toGetResume = uIdAndResumeMap.get(fields.getUId());
                        candidateFilterDto.setResumeLink(
                                toGetResume == null ? "NA" : toGetResume.getResumeLink()
                        );
                        candidateFilterDto.setContact(uIdAndEmailNameMap.get(fields.getUId()).getUContact());
                        candidateFilterDto.setUId(uIdAndEmailNameMap.get(fields.getUId()).getUId());
                        candidateFilterDto.setCurrentLocation(fields.getCurrentLoc());
                        candidateFilterDto.setCurrentCtc(fields.getCurrentCtc());
                        candidateFilterDto.setCurrentOrg(fields.getCurrentOrg());
                        candidateFilterDto.setCurrentDesignation(fields.getCurrentDesignation());
                        candidateFilterDto.setExpectedCtc(fields.getExpectedCtc());
                        candidateFilterDto.setPreferredLocation(fields.getPreferredLoc());
                        candidateFilterDto.setSkills(fields.getPrimarySkills());
                        candidateFilterDto.setServingNp(fields.isServingNp());
                        candidateFilterDto.setYoe(fields.getYoe());
                        candidateFilterDto.setActivelySearching(fields.isActivelySearching());
                        candidateFilterDtoList.add(candidateFilterDto);
                    } catch (Exception e) {
                        log.error("Exception while setting candidate with uid ::: {} ::: {}", fields.getUId(), e);
                        continue;
                    }
                }
            }


            return CandidateSearchResultDto.builder()
                    .Details(candidateFilterDtoList)
                    .totalRecordCount(totalRecords).build();

        } catch (Exception e) {
            log.error("Exception while searching for the candidate {}", e);
            return null;
        }
    }


    public Object syncMandatoryFields() {
        try {
            List<User> userList = userRepository.findAll();
            List<UserCandidateMandatoryFields> userCandidateMandatoryFields = userCandidateMandatoryFieldsRepository
                    .findAll();
            List<String> listOfUidInMandatoryfields = new ArrayList<>();
            for (UserCandidateMandatoryFields fields : userCandidateMandatoryFields) {
                listOfUidInMandatoryfields.add(fields.getUId());
            }

            for (User user : userList) {
                if (!listOfUidInMandatoryfields.contains(user.getUId())) {
                    if (!StringUtils.isBlank(user.getEmail())
                            && !StringUtils.isBlank(user.getFullName())
                            && user.isActive()) {
                        try {
                            UserCandidateMandatoryFields candidateMandatoryFields =
                                    new UserCandidateMandatoryFields();
                            candidateMandatoryFields.setUId(user.getUId());
                            log.info("Candidate mandatory fields for user {}", user.getEmail());
                            userCandidateMandatoryFieldsRepository.save(candidateMandatoryFields);
                        } catch (Exception e) {
                            log.error("Not able to save the candidate mandatory fields for {}", user.getEmail());
                        }
                    }
                }
            }
            return "Saved";
        } catch (Exception e) {
            log.error("Exception while syncing the mandatory fields {}", e);
        }
        return null;
    }

    public Object parseIndividualResume(String uId, InternityUser user) {
        try {
            {
                StringBuilder report = new StringBuilder();
                Optional<UserPersonalDetail> allUsers = userProfileRepository.findByuId(uId);
                List<User> usersWithResumes = new ArrayList<>();

                ResumeParsingReport parsingReport = new ResumeParsingReport();

                resumeLink = allUsers.get().getResumeLink();

                log.info(resumeLink + "...");

                try {
                    String response = extractResume(resumeLink);
                    if (!StringUtils.isBlank(response)) {
                        JSONObject json = new JSONObject(response);
                        return json.toString();
                    }
                } catch (Exception e1) {
                    log.error("Exception while parsing resume ::: {}", e1);
                }

                return report.toString();
            }
        } catch (Exception e) {
            log.error("Exception while parsing resume for an individual {}", e);
        }
        return null;
    }

    public String extractResume(String resumeLink) {
        RestTemplate restTemplate = new RestTemplate();

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            String payloadJson = "{\"resume_s3_url\": \"" + resumeLink + "\"}";
            HttpEntity<String> request = new HttpEntity<String>(payloadJson, headers);
            String response =
                    restTemplate.postForObject(
                            resumeParsingUrl,
                            request,
                            String.class);
            return response;
        } catch (Exception e) {
            log.error("Exception while extracting resume ::: {}", e);
        }
        return "";
    }

    /**
     * fetch role for an user
     *
     * @param uId
     * @param internityUser
     * @return
     */
    public Map<String, String> fetchRoleAccessForAUser(String uId, InternityUser internityUser) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                Map<String, String> resWithRole = new HashMap<>();
                resWithRole.put("role", commonUtils.getRoleEnum(userObj.get().getURole()).name());
                return resWithRole;
//				List<RoleManagement> roleManagementList = roleManagementRepository.findByRoleName(user.getURole());
//				Map<String, String> roleAccesses = new HashMap<>();
//				JSONObject roles = new JSONObject();
//				for(RoleManagement roleManagement : roleManagementList){
//					roles.put(roleManagement.getEntityName(), roleManagement.getAccessesList());
//				}
//				roleAccesses.put("roles", roles.toString());
//				roleAccesses.put("uId", uId);
//				return roleAccesses;
            } else {
                return commonUtils.messageWithStatus(HttpStatus.INTERNAL_SERVER_ERROR, "User is not present with the given id");
            }
        } catch (Exception e) {
            log.error("Exception while fetching the role and its accesses for the user with id ::: {} ::: {}", uId, e);
            return commonUtils.messageWithStatus(HttpStatus.INTERNAL_SERVER_ERROR, "Exception while fetching the role and its accesses for the user with id " + uId);
        }
    }

    public Object parseMultipleResumeAndCreateProfile(Map<String, List<String>> resumeLinkObj) {
        List<String> resumeLinkList = awsIntegration.fetchAllFilesInABucket("");
        for (String resumeLink : resumeLinkList) {
            log.info("parsing resume ::: " + resumeLink);
            Map<String, String> obj = new HashMap<>();
            obj.put("resumeLink", resumeLink);
            obj.put("jobId", "NA");

            Response response = (Response) parseResumeAndCreateProfile(obj).getBody();
            if (!response.getSuccess()) {
                log.info("resume parsed and profile created ::: " + response.getResult().toString());
            }
            log.info("===============================");
        }
        return commonUtils.message(HttpStatus.OK, "parsed successfully");
    }

    public ResponseEntity<?> parseResumeAndCreateProfile(Map<String, String> resumeLinkObj) {
        ResumeParsingReport parsingReport = new ResumeParsingReport();
        try {
            log.info("inside parsing resume");
            String resumeLink = resumeLinkObj.get("resumeLink");
            if (StringUtils.isBlank(resumeLink)) {
                log.error("Resume link cannot be empty");
                return new ResponseEntity<>(responseUtill.badRequestResponse("Resume link cannot be empty"), HttpStatus.BAD_REQUEST);
            }
            String jobId = resumeLinkObj.get("jobId");
            if (StringUtils.isBlank(jobId)) {
                log.error("Job id cannot be empty");
                return new ResponseEntity<>(responseUtill.badRequestResponse("Job id cannot be empty"), HttpStatus.BAD_REQUEST);
            }

            Response response = parseResumeAndSaveUserDetails(resumeLink, jobId, parsingReport, null);

            if (response.getSuccess()) {
                String uId = response.getResult().toString();
                log.info("resume parsed and profile created ::: " + uId);
                String jsonBody = "{\"message\":\"Resume parsed and profile created successfully\",\"uId\":\"" + uId + "\"}";
                log.info("parse resume and create profile success ::: {}", jsonBody);
                return new ResponseEntity<>(responseUtill.successResponse(jsonBody), HttpStatus.OK);
            }
            log.error("parse resume and create profile failed ::: {}", response.getError().getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);

        } catch (Exception e) {
            parsingReport.setParsed(false);
            parsingReport.setDocumentType("resume");
            parsingReport.setDocumentOwnerId(resumeLink);
            parsingReport.setEmail(null);
            parsingReportRepository.save(parsingReport);
            log.error("Exception while parsing resume and creating the profile ::: {}", e.getMessage());
            return new ResponseEntity<>(responseUtill.internalServerErrorResponse("Exception while parsing resume and creating the profile"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public List<String> readFile(MultipartFile file, String jobId) {
        if (file.getOriginalFilename().contains(".csv")) {
            return readFromCsv(file, jobId);
        } else if (file.getOriginalFilename().contains(".xls")) {
            return readFromExcel(file, jobId);
        }
        return null;
    }

    private List<String> readFromCsv(MultipartFile file, String colWithEmails) {
        try {
            Map<String, List<String>> result = new HashMap<>();
            List<String> listOfEmailId = new ArrayList<>();

            EmailValidator validator = EmailValidator.getInstance();
            Reader reader = new InputStreamReader(file.getInputStream());
            CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT);
            List<CSVRecord> list = parser.getRecords();
            SortedSet<String> sortedEmailSet = new TreeSet<>();

            for (CSVRecord record : list) {
                String[] arr = new String[record.size()];
                int i = 0;
                for (String email : record) {
                    if (validator.isValid(email)) {
                        listOfEmailId.add(email);
                    }
                }
            }
            parser.close();
            return null;
        } catch (Exception e) {
            log.error("Exception while reading from the csv file {}", e);
        }
        return Collections.EMPTY_LIST;
    }

    /**
     * Read excel file containing the details of the profile
     * and the resume
     *
     * @param file
     * @param jobId
     * @return
     */
    private List<String> readFromExcel(MultipartFile file, String jobId) {
        try {
            Workbook wb = null;
            List<UserDetailsInBulk> userDetailsInBulk = new ArrayList<>();
            DataFormatter fmt = new DataFormatter();
            Map<String, Integer> map = new HashMap<String, Integer>();
            Map<String, Integer> mapOfCustomAnswers = new HashMap<String, Integer>();

            if (file.getOriginalFilename().endsWith("xls")) {
                wb = new HSSFWorkbook(file.getInputStream());
            } else {
                wb = new XSSFWorkbook(file.getInputStream());
            }

            Sheet sheet = wb.getSheetAt(0);
            Row firstRow = sheet.getRow(0);
            short minColIx = firstRow.getFirstCellNum();
            short maxColIx = firstRow.getLastCellNum();

            for (short colIx = minColIx; colIx < maxColIx; colIx++) {
                Cell cell = firstRow.getCell(colIx);
                if (cell.getStringCellValue().startsWith("Custom")) {
                    mapOfCustomAnswers.put(cell.getStringCellValue(), cell.getColumnIndex());
                } else {
                    map.put(cell.getStringCellValue(), cell.getColumnIndex());
                }
            }

            if (sheet.getPhysicalNumberOfRows() != 0) {
                for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                    Row row = sheet.getRow(i);
                    if (row == null) {
                        continue;
                    }
                    UserDetailsInBulk userDetails = new UserDetailsInBulk();
                    userDetails.setJobId(jobId);

                    if (row.getCell(map.get("Name")) != null) {
                        try {
                            if (row.getCell(map.get("Name")).getCellType() == CellType.NUMERIC) {
                                userDetails.setName(row.getCell(map.get("Name")).getNumericCellValue() + "");
                            } else if (row.getCell(map.get("Name")).getCellType() == CellType.ERROR) {
                                userDetails.setName("NA");
                            } else {
                                userDetails.setName(row.getCell(map.get("Name")).getStringCellValue());
                            }
                        } catch (Exception e) {
                            log.error("Error while parsing name ::: {}", e);
                            userDetails.setName("NA");
                        }
                    }

                    if (row.getCell(map.get("Email")) != null) {
                        try {
                            userDetails.setEmail(
                                    row.getCell(map.get("Email")).getStringCellValue());
                        } catch (Exception e) {
                            log.error("Error while parsing name ::: {}", e);
                            continue;
                        }
                    }

                    if (row.getCell(map.get("Contact No")) != null) {
                        if (row.getCell(map.get("Contact No")).getCellType() == CellType.NUMERIC) {
                            userDetails.setContact(
                                    fmt.formatCellValue(row.getCell(map.get("Contact No"))) + "");
                        } else {
                            userDetails.setContact(
                                    row.getCell(map.get("Contact No")).getStringCellValue());
                        }
                    }

                    if (row.getCell(map.get("resumeLink")) == null) {
                        log.error("Resume is not present in the Field for email ::: {}", userDetails.getEmail());
                        //continue;
                    } else {
                        if (row.getCell(map.get("resumeLink")).getCellType() == CellType.NUMERIC) {
                            userDetails.setName(row.getCell(map.get("resumeLink")).getNumericCellValue() + "");
                        } else if (row.getCell(map.get("resumeLink")).getCellType() == CellType.ERROR) {
                            userDetails.setResumeLink("NA");
                        } else {
                            userDetails.setResumeLink(
                                    row.getCell(map.get("resumeLink")).getStringCellValue());
                        }
                    }

//                    if (row.getCell(map.get("Yoe")) != null) {
//                        if (row.getCell(map.get("Yoe")).getCellType() == CellType.NUMERIC) {
//                            userDetails.setYoe(
//                                    fmt.formatCellValue(row.getCell(map.get("Yoe"))) + "");
//                        } else {
//                            userDetails.setYoe(row.getCell(map.get("Yoe")).getStringCellValue());
//                        }
//					}

                    if (row.getCell(map.get("Skills")) != null) {
                        if (row.getCell(map.get("Skills")).getCellType() == CellType.NUMERIC) {
                            userDetails.setSkills(row.getCell(map.get("Skills")).getNumericCellValue() + "");
                        } else if (row.getCell(map.get("Skills")).getCellType() == CellType.ERROR) {
                            userDetails.setSkills("NA");
                        } else {
                            userDetails.setSkills(row.getCell(map.get("Skills")).getStringCellValue());
                        }
                    }

                    // parse resume if details are unavailable
//					if (row.getCell(map.get("Skills")) == null
//							|| row.getCell(map.get("Yoe"))  == null
//							|| row.getCell(map.get("Email")) == null ) {
//
//						JSONObject parsedObj = resumeParser.parsedResumeObj(resumeLink);
//
//						if(row.getCell(map.get("Skills")) == null){
//							userDetails.setSkills(parsedObj.get("skills")+"");
//						}
//
//						if(row.getCell(map.get("Yoe")) == null){
//							userDetails.setSkills(parsedObj.get("Yoe")+"");
//						}
//
//						if(row.getCell(map.get("Email")) == null){
//							userDetails.setSkills(parsedObj.get("Email")+"");
//						}
//					}

//                    JSONObject mapOfQuestionAndAnswer = new JSONObject();
//
//					//set custom question answers from excel sheet
//					setCustomQuestionAnswers(row, mapOfQuestionAndAnswer, mapOfCustomAnswers);
//
//                    userDetails.setCustomQuestionAnswerList(mapOfQuestionAndAnswer.toString());

                    userDetailsInBulk.add(userDetails);
                }
            }

            return (List<String>) iterateAndSaveUserDetails(userDetailsInBulk).getResult();
        } catch (Exception e) {
            log.error("exception {}", e);
        }
        return Collections.EMPTY_LIST;
    }

    private JSONObject setCustomQuestionAnswers(Row row, JSONObject mapOfQuestionAndAnswer,
                                                Map<String, Integer> mapOfCustomAnswers) {
        try {
            DataFormatter fmt = new DataFormatter();
            for (String key : mapOfCustomAnswers.keySet()) {
                if (row.getCell(mapOfCustomAnswers.get(key)) != null) {
                    if (row.getCell(mapOfCustomAnswers.get(key)).getCellType()
                            == CellType.NUMERIC) {
                        mapOfQuestionAndAnswer.put(
                                key,
                                fmt.formatCellValue(
                                        row.getCell(mapOfCustomAnswers.get(key)))
                                        + "");
                    } else {
                        mapOfQuestionAndAnswer.put(
                                key,
                                row.getCell(mapOfCustomAnswers.get(key))
                                        .getStringCellValue());
                    }
                }
            }
            return mapOfQuestionAndAnswer;
        } catch (Exception e) {
            log.error("Exception while setting custom answers from the excel sheet ::: {}", e);
        }
        return new JSONObject();
    }

    private Response iterateAndSaveUserDetails(List<UserDetailsInBulk> userDetailsInBulk) {
        try {

            List<String> completedUidList = new ArrayList<>();

            String uId = "";
            for (UserDetailsInBulk userDetails : userDetailsInBulk) {
                log.info("############START###########");
                if (userDetails.getEmail().equalsIgnoreCase("NA")) {
                    log.info("Skipping {} as email is NA", userDetails.getName());
                    continue;
                }
                log.info("Starting to save ::: {} with email ::: {}", userDetails.getName(), userDetails.getEmail());
                JSONObject json = new JSONObject();
                json.put("email", userDetails.getEmail());
                json.put("name", userDetails.getName());
                json.put("mobile_number", userDetails.getContact());
                //json.put("total_experience", userDetails.getYoe());
                json.put("skills", userDetails.getSkills());
                Optional<User> userObj = userRepository.findByEmail(userDetails.getEmail());
                if (userObj.isPresent()) {
                    uId = userObj.get().getUId();
                    saveUserCandidateMandatoryFields(userDetails, uId);
                    log.info("skipping to save in Db email ::: {}", userDetails.getEmail());
                } else {
                    try {
                        Optional<User> user = userRepository.findByuContact(userDetails.getContact());
                        if (user.isPresent()) {
                           return responseUtill.internalServerErrorResponse("User with contact number " + userDetails.getContact() + " already exists");
                        }
                        User savedUser = saveUserBasicDetails(json, userDetails.getResumeLink());
                        if (savedUser == null) {
                            return responseUtill.internalServerErrorResponse("Exception while saving the basic details of the user from parsed resume");
                        }
                        uId = savedUser.getUId();
                        saveUserCandidateMandatoryFields(userDetails, uId);
                    } catch (Exception e) {
                        log.error("Exception {}", e.getMessage());
                        continue;
                    }
                }
                userDetails.setUId(uId);
                saveUserSkills(userDetails, uId);
                //saveUserCandidateMandatoryFields(userDetails, uId);
                completedUidList.add(uId);

                //saveToJobApplicationScreeningAnswer(userDetails);
                log.info("############END###########");
            }

            if (completedUidList.isEmpty()) {
                log.error("Uid List is empty");
                return responseUtill.internalServerErrorResponse("Uid List is empty");
            }
            log.info("completedUidList ::: {}", completedUidList);
            return responseUtill.successResponse(completedUidList);
        } catch (Exception e) {
            log.error("Exception while iterating and saving the user details {}", e.getMessage());
            return responseUtill.internalServerErrorResponse("Exception while iterating and saving the user details");
        }
    }

    private void saveToJobApplicationScreeningAnswer(UserDetailsInBulk userDetails) {
        try {
            if (StringUtils.isBlank(userDetails.getCustomQuestionAnswerList())) {
                return;
            }
            log.info("JobApplicationScreeningAnswer data saved for ::: jobId {} ::: uId {}", userDetails.getJobId(), userDetails.getUId());
            JobApplicationScreeningAnswer answer;
            Optional<JobApplicationScreeningAnswer> obj = screeningAnswerRepository.findByuIdAndJobId(userDetails.getUId(), userDetails.getJobId());
            if (obj.isPresent()) {
                answer = obj.get();
            } else {
                answer = new JobApplicationScreeningAnswer();
            }
            answer.setJobId(userDetails.getJobId());
            answer.setAllCustomQueAnswer(userDetails.getCustomQuestionAnswerList());
            answer.setUId(userDetails.getUId());
            screeningAnswerRepository.save(answer);
        } catch (Exception e) {
            log.error("Exception while saving job application screening answers ::: {}", e);
        }
    }

    private String getCellValue(Cell cell) {
        try {
            return cell.getStringCellValue();
        } catch (Exception e) {
            log.error("Exception while fetching the cell value ::: {}", e);
            return "";
        }
    }

    public List<String> getEmailAndPhoneOfUsers(String type) {
        try {
            if (type.equalsIgnoreCase("all")) {
                List<User> users = userRepository.findAll();
                return users.stream()
                        .map(User::getEmail)
                        .collect(Collectors.toList());
            } else if (type.equalsIgnoreCase("jobs")) {
                List<Application> allApplications = applicationRepository.findAll();

                Set<String> uIds = allApplications.stream()
                        .map(Application::getUId)
                        .collect(Collectors.toSet());

                List<String> jobEmails = new ArrayList<>();
                List<User> userList = userRepository.findEmailByuIdIn(uIds);
                for (User user : userList) {
                    jobEmails.add(user.getEmail());
                }
                return jobEmails;
            } else if (type.equalsIgnoreCase("hackathons")) {
                List<DrillParticipant> allParticipants = drillParticipantRepository.findAll();
                return allParticipants.stream()
                        .map(DrillParticipant::getEmail)
                        .collect(Collectors.toList());
            }
            return Collections.emptyList();
        } catch (Exception e) {
            log.error("Error occurred while fetching emails by type: {}", e.getMessage());
            return null;
        }
    }

    public AuthResponseDto loginWithGoogle(GoogleAuthentication googleAuthenticationObj) {
        try {
            String authenticationToken = "";
            String[] chunks = googleAuthenticationObj.getCredential().split("\\.");
            Base64.Decoder decoder = Base64.getUrlDecoder();
            String payload = new String(decoder.decode(chunks[1]));

            JSONObject jsonObject = new JSONObject(payload);
            String email = jsonObject.getString("email");
            User user = new User();
            Collection<SimpleGrantedAuthority> oldAuthorities = (Collection<SimpleGrantedAuthority>) SecurityContextHolder.getContext().getAuthentication().getAuthorities();

            if (checkIfEmailAlreadyExists(email)) {
                User userFromDb = userRepository.findByEmail(email).get();
                user.setUId(userFromDb.getUId());
                user.setEmail(userFromDb.getEmail());
                user.setURole(userFromDb.getURole());
                user.setFullName(userFromDb.getFullName());

                Optional<UserPersonalDetail> personalDetailObj = userProfileRepository.findByuId(userFromDb.getUId());
                if (!personalDetailObj.isPresent()) {
                    profileManagementService.save(user, user.getResumeLink(), null);
                }
            } else {
                user.setFullName(getNameFromGoogleToken(jsonObject));
                user.setEmail(email);
                user.setUsername(email);
                user.setSource(AuthenticationPlatform.GOOGLE.name());
                user.setPassword("User@123");
                user.setActive(true);
                long unixTime = System.currentTimeMillis() / 1000L;
                log.info("generating random number ::: {}", unixTime);
                user.setUContact(unixTime + "");
                user.setUType("NEWUSER");
                user.setUGroup("NEWUSER");
                user.setURole(Roles.USER.name());

                User savedUser = userRepository.saveAndFlush(user);

                profileManagementService.save(savedUser, savedUser.getResumeLink(), null);

            }
            SimpleGrantedAuthority authority = new SimpleGrantedAuthority(user.getURole());
            List<SimpleGrantedAuthority> updatedAuthorities = new ArrayList<SimpleGrantedAuthority>();
            updatedAuthorities.add(authority);

            authenticationToken = generateAuthenticationToken(user, updatedAuthorities);

            AuthResponseDto responseObj = new AuthResponseDto();
            responseObj.setResponseCode(HttpStatus.OK.value());
            responseObj.setToken(authenticationToken);
            responseObj.setAuthoritiesInString(authorityListToSet(updatedAuthorities).toString());

            JSONObject userJson = new JSONObject();
            userJson.put("fullName", user.getFullName());
            userJson.put("uemail", user.getEmail());
            userJson.put("uid", user.getUId());
            responseObj.setUserDetails(userJson);
            return responseObj;
        } catch (Exception e) {
            log.error("Exception while registering or logging in the user with Google ::: {}", e);
        }
        return null;
    }

    private static Set<String> authorityListToSet(Collection<? extends GrantedAuthority> userAuthorities) {
        Set<String> set = new HashSet<>(userAuthorities.size());
        for (GrantedAuthority authority : userAuthorities) {
            if ((authority.getAuthority() + "").contains("ANONYMOUS")) {
                continue;
            }
            set.add("\"" + authority.getAuthority() + "\"");
        }
        return set;
    }

    private String getNameFromGoogleToken(JSONObject jsonObject) {
        try {
            return StringUtils.isBlank(jsonObject.getString("name"))
                    ? jsonObject.getString("given_name") + " " + jsonObject.getString("family_name")
                    : jsonObject.getString("name");
        } catch (Exception e) {
            log.error("Exception while fetching name from Google authentication token");
            return jsonObject.getString("given_name");
        }
    }

    private String generateAuthenticationToken(User user, List<SimpleGrantedAuthority> updatedAuthorities) {
        try {
            byte[] secretBytes = secretKey1.getBytes(StandardCharsets.UTF_8); // Convert secret to byte array

            String token = Jwts.builder().setSubject(user.getEmail())
                    .claim("authorities", updatedAuthorities).setIssuedAt(new Date())
                    .setExpiration(java.sql.Date.valueOf(LocalDate.now().plusDays(expirationNumberOfDays)))
                    .signWith(SignatureAlgorithm.HS512, secretBytes).compact();

            String jwt = tokenPrefix + " " + token;
            return jwt;
        } catch (Exception e) {
            log.error("Exception while generating authentication token ::: {}", e);
        }
        return null;
    }

    public ResponseEntity<?> fetchAllUsersOfACustomer(String customerId, InternityUser internityUser) {
        try {
            List<CustomerUser> customerUserList = customerUserRepository.findByCompanyId(customerId);
            if (customerUserList.size() > 0) {
                List<String> uIdList = customerUserList.stream().map(CustomerUser::getUId).collect(Collectors.toList());
                List<User> userList = userRepository.findByuIdIn(uIdList);
                List<User> finalUsersWithHiddenPassword = new ArrayList<>();
                for (User user : userList) {
                    user.setPassword(null);
                    finalUsersWithHiddenPassword.add(user);
                }
                return new ResponseEntity<>(finalUsersWithHiddenPassword, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(Collections.EMPTY_LIST, HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while fetching all users of a customer ::: {}", e);
        }
        return new ResponseEntity<>(Collections.EMPTY_LIST, HttpStatus.OK);
    }

    public ResponseEntity<?> inviteOrAssignUserToCustomer(String customerId, String email,
                                                          String designation, InternityUser internityUser) {
        try {
            Optional<User> userObj = userRepository.findByEmail(email);
            if (userObj.isPresent()) {
                User user = userObj.get();
                CustomerUser customerUser = new CustomerUser();
                customerUser.setUId(user.getUId());
                customerUser.setCompanyId(customerId);
                customerUser.setDesignation(designation);
                assignUserToCustomer(customerUser, internityUser);

                user.setURole(UserRoles.ADMIN.name());
                userRepository.save(user);
                return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "Admin role is assigned successfully")
                        , HttpStatus.OK);
            } else {
                Optional<Partner> partner = partnerRepository.findById(customerId);
                if (partner.isPresent()) {
                    sendInviteToUserForDrillAdmin(email, partner.get());
                    return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "User has been invited successfully")
                            , HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(commonUtils.message(HttpStatus.OK,
                            "Customer is not registered with us. Please connect with Admin support")
                            , HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        } catch (Exception e) {
            log.error("Exception while inviting user to become admin for customer with id ::: {}", customerId);
        }
        return new ResponseEntity<>(commonUtils.message(HttpStatus.OK,
                "Exception while inviting user to become admin for customer")
                , HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private void sendInviteToUserForDrillAdmin(String email, Partner customer) {
        try {
            EmailContent emailContent = new EmailContent();
            emailContent.setSubject("You've been invited to host the hackathon for " + customer.getPartnerName() + " | Where U Elevate");
            emailContent.setTemplateName("GenericMailForAllUsers");
            emailContent.setUserName("Dear user");
            emailContent.setMessage("<p>You have been invited to host the hackathon on Drill platform by Where U Elevate." +
                    "<br/>To host the hackathon, you need to register on the platform by visiting " +
                    "<a href=\"https://whereuelevate.com\">our platform by clicking here.</a><br/><br/>" +
                    "Once registered, you can be assigned with the relevant host privileges on Drill platform.</p>");
            messageUtils.sendMail(email, emailContent);
        } catch (Exception exception) {
            log.info(exception.getMessage());
        }
    }

    public ResponseEntity<?> removeUserFromCustomer(String uId, InternityUser internityUser) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                User user = userObj.get();
                user.setURole(UserRoles.USER.name());
                userRepository.save(user);

                customerUserRepository.deleteById(uId);
                return new ResponseEntity<>(commonUtils.message(HttpStatus.OK, "User removed successfully")
                        , HttpStatus.OK);
            } else {
                return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "User is not present")
                        , HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Exception while removing user from customer ::: {}", e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Exception while removing user from customer ::: " + e.getMessage())
                    , HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    public Response fetchUserAnalyticsByUId(String uId, InternityUser user) {
        try {
            Optional<User> userObj = userRepository.findById(uId);
            if (userObj.isPresent()) {
                List<Application> applicationListOfAnUser = applicationRepository.findByuId(uId);
                List<DrillParticipant> drillParticipantListOfAnUser = drillParticipantRepository.findByPlatformUId(uId);
                List<Wishlist> wishlistListOfJobForAnUser = wishlistRepository.findByuIdAndEntityName(uId, PlatformEntityCategory.JOB);
                List<Wishlist> wishlistListOfHackathonForAnUser = wishlistRepository.findByuIdAndEntityName(uId, PlatformEntityCategory.HACKATHON);
                Long pageViewJobCount = pageviewRepository.findCountByPageNameAndUId("job_page", uId);
                Long pageViewHackathonCount = pageviewRepository.findCountByPageNameAndUId("hackathon_page", uId);

                Map<String, String> dashboardAnalyticsOfAnUser = new HashMap<>();
                dashboardAnalyticsOfAnUser.put("uId", uId);
                dashboardAnalyticsOfAnUser.put("countAppliedJobs", applicationListOfAnUser.size() + "");
                dashboardAnalyticsOfAnUser.put("countAppliedHackathons", drillParticipantListOfAnUser.size() + "");
                dashboardAnalyticsOfAnUser.put("countWishlistJobs", wishlistListOfJobForAnUser.size() + "");
                dashboardAnalyticsOfAnUser.put("countWishlistHackathons", wishlistListOfHackathonForAnUser.size() + "");
                dashboardAnalyticsOfAnUser.put("countViewedJobs", pageViewJobCount + "");
                dashboardAnalyticsOfAnUser.put("countViewedHackathons", pageViewHackathonCount + "");
                return new Response(200, true, dashboardAnalyticsOfAnUser, null);
            } else {
                return new Response(500, false, null,
                        new ResponseError("500", "No record present for given user id"));
            }
        } catch (Exception e) {
            log.error("Exception while fetching the analytics of an user ::: {}", e);
            Map<String, String> dashboardAnalyticsOfAnUser = new HashMap<>();
            dashboardAnalyticsOfAnUser.put("uId", uId);
            dashboardAnalyticsOfAnUser.put("countAppliedJobs", 0 + "");
            dashboardAnalyticsOfAnUser.put("countAppliedHackathons", 0 + "");
            dashboardAnalyticsOfAnUser.put("countWishlistJobs", 0 + "");
            dashboardAnalyticsOfAnUser.put("countWishlistHackathons", 0 + "");
            return new Response(200, true, dashboardAnalyticsOfAnUser, null);
        }
    }

    public Response fetchSkillsByUId(String uId, String categoryToFetch, InternityUser internityUser) {
        try {
            if (!checkIfUserAlreadyExistsWithUid(uId)) {
                return new Response(500, false, null,
                        new ResponseError("500", "No record found for the given user id"));
            }

            if ("all".equals(categoryToFetch)) {
                List<UserSkill> userSkillList = userSkillRepository.findByuId(uId);
                List<String> userSkills = userSkillList.stream().map(e -> e.getSkillName()).collect(Collectors.toList());
                Optional<UserCandidateMandatoryFields> userCandidateMandatoryFieldsObj =
                        userCandidateMandatoryFieldsRepository.findByuId(uId);
                if (userCandidateMandatoryFieldsObj.isPresent()) {
                    if (StringUtils.isNoneBlank(userCandidateMandatoryFieldsObj.get().getPrimarySkills())) {
                        List<String> list = Stream.of(userCandidateMandatoryFieldsObj.get().getPrimarySkills()
                                .replaceAll("\\[", "").replaceAll("\\]", "")
                                .replaceAll("\\\"", "")
                                .split(",")).collect(Collectors.toList());

                        userSkills.addAll(list);
                    }
                }
                return new Response(200, true, userSkills, null);
            }
        } catch (Exception e) {
            log.error("Exception while fetching the opportunities of an user ::: {}", e);
        }
        List<String> userSkillsAll = new ArrayList<>();
        userSkillsAll.add("all");
        return new Response(200, true, userSkillsAll, null);
    }

    public Response fetchTrackHackathons(String uId, InternityUser user) {
        try {
            List<DrillParticipant> drillParticipantList = drillParticipantRepository.findByPlatformUId(uId);
            List<Object> result = new ArrayList<>();
            for (DrillParticipant drillParticipant : drillParticipantList) {
                Response response = drillService.fetchTheCompleteTrackOfHackathon(drillParticipant.getDrillId(),
                        drillParticipant.getParticipantId(), "NA", "NA", user);
                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.registerModule(new JavaTimeModule());

                result.add(response.getResult());
            }
            return new Response(200, true, result, null);
        } catch (Exception e) {
            log.error("Exception while fetch the tracking details of hackathons ::: {}", e);
        }
        return new Response(500, false, null, new ResponseError("500",
                "Failed to fetch the hackathon track"));
    }
}
