package com.wue.service;

import com.wue.constant.*;
import com.wue.domain.*;
import com.wue.domain.common.*;
import com.wue.domain.drill.Drill;
import com.wue.repository.*;
import com.wue.repository.common.*;
import com.wue.repository.drill.DrillRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.drill.SendCustomMailUtils;
import lombok.extern.log4j.Log4j2;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import springfox.documentation.spring.web.json.Json;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Log4j2
public class CommonService {
	
	@Autowired
	FeaturedRepository featuredRepository;
	
	@Autowired
	CaseStudyRepository caseStudyRepository;
	
	@Autowired
	PartnerRepository partnerRepository;

	@Autowired
	CommonRepository repository;
	
	@Autowired
	UserTypesMasterReposiotry utypeRepo;
	
	@Autowired
	UserRolesMasterRepository uroleRepo;

	@Autowired
	PageviewRepository pageviewRepository;

	@Autowired
	LocationMasterRepository locationMasterRepository;

	@Autowired
	IndustryMasterRepository industryMasterRepository;

	@Autowired
	DomainMasterRepository domainMasterRepository;

	@Autowired
	TechnologyMasterRepository technologyMasterRepository;

	@Autowired
	CommonUtils commonUtils;
	
	@Autowired
	JobsRepository jobsRepository;

	@Autowired
	CollegeMasterRepository collegeMasterRepository;

	@Autowired
	CompanyMasterRepository companyMasterRepository;

	@Autowired
	JobMasterRepository jobMasterRepository;
	
	@Autowired
	DrillRepository drillRepository;

	@Autowired
	OrganisationAndAcademicRepository organisationAndAcademicRepository;

	@Autowired
	ContactUsRepository contactUsRepository;

	@Autowired
	SendCustomMailUtils sendCustomMailUtils;

	@Value("${bulk.mail.url:https://mail.whereuelevate.com}")
	private String bulkMailUrl;

	@Value("${support.mail.id:techsupport@wuelev8.tech}")
	private String techSupportEmail;

	@Value("${care.emailid:care@wuelev8.tech}")
	String careEmailId;

	@Autowired
	TestimonialPostRepository testimonialPostRepository;

	public Json getTeamsPage(String title, InternityUser user) {
		Optional<Common> commonObj = repository.findByTitle(title);
		if(commonObj.isPresent()) {
			Common common = commonObj.get();
			return common.getContent();
		}
		return null;
	}

	public ResponseEntity<?> savePageView(PageView obj, InternityUser internityUser) {
		try {
			pageviewRepository.save(obj);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.OK
					, "Page view saved"), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while updating page view {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					, "Failed to update page view"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<?> getTimezones(InternityUser user) {
		try {
			return new ResponseEntity<>(commonUtils.getZoneAndOffSet3(),HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while fetching timezone ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					,"Exception while fetching timezones. Please contact admin or mail " +
							"to " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<?> getlocation(String countryCode, InternityUser user) {
		try {
			List<String> locationMasterList = locationMasterRepository.findByCountryCodeAndReturnUnique(countryCode);

			return new ResponseEntity<>(locationMasterList,HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while fetching location ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					,"Exception while fetching location. Please contact admin or mail " +
							"to " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<?> saveLocation(LocationMaster payload, InternityUser user) {
		try{
			return new ResponseEntity<>(locationMasterRepository.save(payload), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while saving location ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					,"Exception while saving location. Please contact admin or mail " +
							"to" + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
public ResponseEntity<List<String>> getIndustryOptions()
{
	try{
		List<IndustryMaster> industryMasterList=industryMasterRepository.findAll();
		if(industryMasterList!=null)
		{
			List<String> industryList = new ArrayList<>();
			for(IndustryMaster obj : industryMasterList){
				industryList.add(obj.getIndustry());
			}
			return new ResponseEntity<>(industryList,HttpStatus.OK);
		}
		else
			return new ResponseEntity<>(null,HttpStatus.OK);
	}
	catch(Exception e)
	{
		log.error("Exception while getting industry options ::: {}",e);
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
	public ResponseEntity<?> saveOrUpdateDomainOptions(DomainMaster domainMaster) {
		try {
		if(domainMaster.getId()!=null) {
			Optional<DomainMaster> record1 = domainMasterRepository.findById(domainMaster.getId());
			if (record1.isPresent()) {
				DomainMaster record = record1.get();
				if (domainMaster.getDomain() != null)
					record.setDomain(domainMaster.getDomain());
				if (domainMaster.getTags() != null)
					record.setTags(domainMaster.getTags());
				return new ResponseEntity<>(record, HttpStatus.OK);
			}
		}

		return new ResponseEntity<>(domainMasterRepository.save(domainMaster), HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception while saving domain options ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					, "Exception while saving domain optons. Please contact admin or mail " +
							"to" + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	public ResponseEntity<?> saveOrUpdateTechnologyOptions(TechnologyMaster technologyMaster) {
		try {
		if(technologyMaster.getId()!=null){
		Optional<TechnologyMaster> record1 = technologyMasterRepository.findById(technologyMaster.getId());
		if (record1.isPresent()) {
			TechnologyMaster record = record1.get();
			if (technologyMaster.getTechnology() != null)
				record.setTechnology(technologyMaster.getTechnology());
			if (technologyMaster.getTags() != null)
				record.setTags(technologyMaster.getTags());
			return new ResponseEntity<>(record, HttpStatus.OK);
			}
		}

		return new ResponseEntity<>(technologyMasterRepository.save(technologyMaster), HttpStatus.OK);

		} catch (Exception e) {
			log.error("Exception while saving technology options ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					, "Exception while saving technology optons. Please contact admin or mail " +
							"to" + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<?> getUserCommonMap(InternityUser user) {
		try{
			Map<String, Object> objectMap = new HashMap<>();
	        List<String> rolesList = uroleRepo.findListOfRoles();
	        List<String> typesList = utypeRepo.findListOfTypes();

	        objectMap.put("roles", rolesList);
	        objectMap.put("types", typesList);

	        return new ResponseEntity<>(objectMap,HttpStatus.OK);
	        }
		catch (Exception e){
			log.error("Exception while getting user roles and types ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					,"Exception while getting user roles and types. Please contact admin or mail " +
							"to " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
        
    }

	public ResponseEntity<?> saveUserRolesdetails(UserRolesMaster payload, InternityUser user) {
			try{
				return new ResponseEntity<>(uroleRepo.save(payload), HttpStatus.OK);
			}
			catch (Exception e){
				log.error("Exception while saving user role details {}", e);
				return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
						,"Exception while saving user role details. Please contact admin or mail " +
								"to " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	
	public ResponseEntity<?> saveUserTypesdetails(UserTypesMaster payload, InternityUser user) {
		try{
			return new ResponseEntity<>(utypeRepo.save(payload), HttpStatus.OK);
		}
		catch (Exception e){
			log.error("Exception while saving user type details ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					,"Exception while saving user type details. Please contact admin or mail " +
							"to " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<List<String>> getDomainOptions() {
		try {
			List<DomainMaster> domainMasterList = domainMasterRepository.findAll();
			if (domainMasterList != null) {

				List<String> domainList = new ArrayList<>();
				for(DomainMaster obj : domainMasterList){
					domainList.add(obj.getDomain());
				}

				return new ResponseEntity<>(domainList, HttpStatus.OK);
			}
			else{
				return new ResponseEntity<>(null,HttpStatus.OK);
			}
		}
		catch (Exception e)
		{
			log.error("Exception while getting domain options ::: {}",e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<List<String>> getCollegeOptions()
	{
		try{
			List<CollegeMaster> collegeMasterList = collegeMasterRepository.findAll();
			if(collegeMasterList!=null)
			{
				List<String> collegeList = new ArrayList<>();
				for(CollegeMaster obj : collegeMasterList){
					collegeList.add(obj.getCollege());
				}
				return new ResponseEntity<>(collegeList,HttpStatus.OK);
			}
			else
				return new ResponseEntity<>(null,HttpStatus.OK);
		}
		catch(Exception e) {
			log.error("Exception while getting college options ::: {}", e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<List<String>> getTechnologyOptions()
	{
		try{
			List<TechnologyMaster> technologyMasterList = technologyMasterRepository.findAll();
			if(technologyMasterList!=null)
			{
				List<String> technologyList = new ArrayList<>();
				for(TechnologyMaster obj : technologyMasterList){
					technologyList.add(obj.getTechnology());
				}
				return new ResponseEntity<>(technologyList,HttpStatus.OK);
			}
			else{
				return new ResponseEntity<>(null, HttpStatus.OK);
			}
		}
		catch(Exception e)
		{
			log.error("Exception while getting technology options ::: {}",e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	public ResponseEntity<List<String>> getCompanyOptions()
	{
		try{
			List<CompanyMaster> companyMasterList=companyMasterRepository.findAll();
			if(companyMasterList!=null)
			{
				List<String> companyList=new ArrayList<>();
				for(CompanyMaster obj : companyMasterList){
					companyList.add(obj.getCompany());
				}
				return new ResponseEntity<>(companyList,HttpStatus.OK);
			}
			else
				return new ResponseEntity<>(null,HttpStatus.OK);
		}
		catch(Exception e)
		{

			log.error("Exception while getting company options ::: {}",e);

			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	public ResponseEntity<?> saveOrUpdateIndustryOptions(List<IndustryMaster> industryMasters) {
	    try {
	        List<String> savedIndustries = new ArrayList<>();
	        
	        for (IndustryMaster industryMaster : industryMasters) {
	            if (industryMaster.getId() != null) {
	                Optional<IndustryMaster> record1 = industryMasterRepository.findById(industryMaster.getId());
	                if (record1.isPresent()) {
	                    IndustryMaster record = record1.get();
	                    if (industryMaster.getIndustry() != null)
	                        record.setIndustry(industryMaster.getIndustry());
	                    if (industryMaster.getTags() != null)
	                        record.setTags(industryMaster.getTags());
	                    savedIndustries.add(record.getIndustry());
	                    // Save the updated record
	                    industryMasterRepository.save(record);
	                }
	            } else {
	                // Save the new industryMaster
	                IndustryMaster savedIndustry = industryMasterRepository.save(industryMaster);
	                savedIndustries.add(savedIndustry.getIndustry());
	            }
	        }
	        
	        return new ResponseEntity<>(savedIndustries, HttpStatus.OK);
	    } catch (Exception e) {
	        log.error("Exception while saving industry options: {}", e);
	        String errorMessage = "Exception while saving industry options. Please contact admin or email " +
					techSupportEmail;
	        return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, errorMessage),
	                HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}



	public ResponseEntity<Map<String,List<String>>> getJobDesignationOptions()
	{
		try{
			List<JobMaster> jobMaster=jobMasterRepository.findAll();
			if(jobMaster!=null)
			{
				Map<String,List<String>> jobOptions=new HashMap<>();
				List<String> ans=new ArrayList<>();
				for(int i=0;i<jobMaster.size();i++)
				{String temp=jobMaster.get(i).toString();
					temp=temp.substring(temp.indexOf('(')+1,temp.length()-1);
					temp='{'+temp+'}';
					ans.add(temp);
				}
				jobOptions.put("job_designation",ans);
				return new ResponseEntity<>(jobOptions,HttpStatus.OK);
			}
			else
				return new ResponseEntity<>(null,HttpStatus.OK);
		}
		catch(Exception e)
		{
			log.error("Exception while getting job designation options ::: {}",e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	public ResponseEntity<?> saveOrUpdateCollegeOptions(CollegeMaster collegeMaster)
	{
		try{
			if(collegeMaster.getId()!=null){
				Optional<CollegeMaster> record1=collegeMasterRepository.findById(collegeMaster.getId());
				if(record1.isPresent())
				{
					CollegeMaster record=record1.get();
					if(collegeMaster.getCollege()!=null)
						record.setCollege(collegeMaster.getCollege());
					if(collegeMaster.getTags()!=null)
						record.setTags(collegeMaster.getTags());

					return new ResponseEntity<>(record,HttpStatus.OK);
				}
			}

			return new ResponseEntity<>(collegeMasterRepository.save(collegeMaster),HttpStatus.OK);

		}
		catch(Exception e)
		{

			log.error("Exception while saving college options ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					,"Exception while saving industry options. Please contact admin or mail " +
							"to " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<?> saveOrUpdateCompanyOptions(CompanyMaster companyMaster)
	{
		try{
			if(companyMaster.getId()!=null){
				Optional<CompanyMaster> record1=companyMasterRepository.findById(companyMaster.getId());
				if(record1.isPresent())
				{
					CompanyMaster record=record1.get();
					if(companyMaster.getCompany()!=null)
						record.setCompany(companyMaster.getCompany());
					if(companyMaster.getTags()!=null)
						record.setTags(companyMaster.getTags());
					return new ResponseEntity<>(record,HttpStatus.OK);
				}
			}

			return new ResponseEntity<>(companyMasterRepository.save(companyMaster),HttpStatus.OK);

		}
		catch(Exception e)
		{
			log.error("Exception while saving company options ::: {}", e);
			return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR
					,"Exception while saving company options. Please contact admin or mail " +
							"to " + techSupportEmail), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	public ResponseEntity<?> saveOrUpdateJobDesignationOptions(List<JobMaster> jobMasters) {
	    try {
	        List<JobMaster> savedJobDesignations = new ArrayList<>();

	        for (JobMaster jobMaster : jobMasters) {
	            JobMaster savedJob;

	            if (jobMaster.getId() != null) {
	                Optional<JobMaster> record1 = jobMasterRepository.findById(jobMaster.getId());
	                if (record1.isPresent()) {
	                    JobMaster record = record1.get();
	                    if (jobMaster.getJobdesignation() != null)
	                        record.setJobdesignation(jobMaster.getJobdesignation());
	                    if (jobMaster.getTags() != null)
	                        record.setTags(jobMaster.getTags());
	                    savedJobDesignations.add(record);
	                    // Save the updated record
	                    savedJob = jobMasterRepository.save(record);
	                }
	            } else {
	                // Save the new jobMaster
	                savedJob = jobMasterRepository.save(jobMaster);
	                savedJobDesignations.add(savedJob);
	            }
	        }

	        return new ResponseEntity<>(savedJobDesignations, HttpStatus.OK);
	    } catch (Exception e) {
	        log.error("Exception while saving job designation options: {}", e);
	        String errorMessage = "Exception while saving job designation options. Please contact admin or email " +
					techSupportEmail;
	        return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, errorMessage),
	                HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}


	public Featured saveFeaturedJobAndDrill(Featured featured,InternityUser user) {
	        try {
				Optional<Featured> featuredObj = featuredRepository.findByElementIdAndElementType(
						featured.getElementId(), featured.getElementType());
				if(featuredObj.isPresent()){
					featured.setId(featuredObj.get().getId());
				}
 	        	log.info("Saving featured job and drill");
	            featured.setElementType(featured.getElementType().toUpperCase());
	            return featuredRepository.save(featured);
	            
	        } catch (Exception e) {
	            log.error("Failed to save featured data ::: {}", e);
	            return null;
	        }
	    }

	public Object getFeaturedItems(String elementType, InternityUser user) {
	    List<Map<String, Object>> featuredItems = new ArrayList<>();
	    List<Map<String, Object>> drillList = new ArrayList<>();
	    List<Map<String, Object>> jobList = new ArrayList<>();
	    try {
	        List<Featured> jobs = new ArrayList<>();
	        List<Featured> drills = new ArrayList<>();

	        if (FeaturedElementType.JOB.toString().equalsIgnoreCase(elementType)) {
	            jobs = featuredRepository.findByElementTypeAndIsActiveOrderByPositionOrderDesc(FeaturedElementType.JOB.name(), true);
	        } else if (FeaturedElementType.DRILL.toString().equalsIgnoreCase(elementType)) {
	            drills = featuredRepository.findByElementTypeAndIsActiveOrderByPositionOrderDesc(FeaturedElementType.DRILL.name(), true);
	        } else {
	            jobs = featuredRepository.findByElementTypeAndIsActiveOrderByPositionOrderDesc(FeaturedElementType.JOB.name(), true);
	            drills = featuredRepository.findByElementTypeAndIsActiveOrderByPositionOrderDesc(FeaturedElementType.DRILL.name(), true);

			}

	        // Get all the element IDs (jobs and drills)
	        List<String> jobIds = jobs.stream().map(Featured::getElementId).collect(Collectors.toList());
	        List<String> drillIds = drills.stream().map(Featured::getElementId).collect(Collectors.toList());

	        // Remove inactive IDs from the lists
	        List<String> inactiveJobIds = jobsRepository.findInactiveElementIds(jobIds);
	        jobIds.removeAll(inactiveJobIds);

	        List<String> inactiveDrillIds = drillRepository.findInactiveElementIds(drillIds);
	        drillIds.removeAll(inactiveDrillIds);

	        // Map the remaining IDs to their corresponding objects
	        Map<String, Job> activeJobsMap = jobsRepository.findByJobIdInAndIsActive(jobIds, true)
	            .stream()
	            .collect(Collectors.toMap(Job::getJobId, Function.identity()));
	        log.info("Retrieved active jobs from the database and created a map of job objects with their respective IDs.");
	        Map<String, Drill> activeDrillsMap = drillRepository.findByDrillIdInAndIsActive(drillIds, true)
	                .stream().collect(Collectors.toMap(Drill::getDrillId, Function.identity()));
	        log.info("Retrieved active drills from the database and created a map of drill objects with their respective IDs.");

	        // Iterate over the Featured objects and add them to the featuredItems list
	        for (Featured job : jobs) {
	            String elementId = job.getElementId();
	            if (jobIds.contains(elementId)) {
	                Job activeJob = activeJobsMap.get(elementId);
	                Map<String, Object> item = new HashMap<>();
	                item.put("positionOrder", job.getPositionOrder());
	                item.put("details", activeJob);
	                jobList.add(item);
	            }
	        }

	        for (Featured drill : drills) {
	            String elementId = drill.getElementId();
	            if (drillIds.contains(elementId)) {
	                Drill activeDrill = activeDrillsMap.get(elementId);
	                Map<String, Object> item = new HashMap<>();
	                item.put("positionOrder", drill.getPositionOrder());
	                item.put("details", activeDrill);
	                drillList.add(item);
	            }
	        }
	        jobList.sort((a, b) -> ((Integer) b.get("positionOrder")).compareTo((Integer) a.get("positionOrder")));
	        drillList.sort((a, b) -> ((Integer) b.get("positionOrder")).compareTo((Integer) a.get("positionOrder")));
	        
	        Map<String, Object> resultMap = new HashMap<>();
	        resultMap.put("Job", jobList);
	        resultMap.put("Drill", drillList);

	        featuredItems.add(resultMap);
	      

	    } catch (Exception e) {
	        log.error("Exception while fetching the featured details ::: {}", e);
	        return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
	                "Exception while fetching the featured details"), HttpStatus.INTERNAL_SERVER_ERROR);
	    }

	    return featuredItems;
	}

	public OrganisationAndAcademicInstitute saveOrganisationAndAcademicInstitute(
			OrganisationAndAcademicInstitute organisationAndAcademicInstitute, InternityUser user) {
	    try {
	        if (organisationAndAcademicInstitute.getType().equalsIgnoreCase("AcademicInstitute")
					|| organisationAndAcademicInstitute.getType().equalsIgnoreCase("Organisation")) {
	  		  return organisationAndAcademicRepository.save(organisationAndAcademicInstitute);
	        }
	        	Partner latestPartner = partnerRepository.findFirstByOrderByCreatedTsDesc();
	        	Integer positionOrder = organisationAndAcademicRepository.getLastPositionOrderOfTypeOrganisation();
	            String partnerName = latestPartner.getPartnerName();

	            Optional<OrganisationAndAcademicInstitute> existingData = organisationAndAcademicRepository.findByName(partnerName);
	            if (existingData.isPresent()) {
	                throw new Exception("Data with partner name already exists in organisationAndAcademicRepository.");
	            }

	            // Set the partner details and save the data
	            organisationAndAcademicInstitute.setName(partnerName);
	            organisationAndAcademicInstitute.setType("Organisation");
	            organisationAndAcademicInstitute.setPositionOrder(positionOrder+1);
	            organisationAndAcademicInstitute.setImageUrl(latestPartner.getPartnerLogoPath());
	            // Set other properties of organisationAndAcademicInstitute as needed
	            
	            return organisationAndAcademicRepository.save(organisationAndAcademicInstitute);
	    } catch (Exception e) {
	        log.error("Failed to save organisation and academic institute data ::: {}", e);
	        return null;
	    }
	}


	
	public Object getOrganisationAndAcademicInstitute(String type,InternityUser user) {
	    List<Map<String, Object>> result = new ArrayList<>();
	    try {
	        List<OrganisationAndAcademicInstitute> organisation = new ArrayList<>();
	        List<OrganisationAndAcademicInstitute> academicInstitute = new ArrayList<>();

	        if (CommonConstants.ORGANISATION.equalsIgnoreCase(type)) {
	            organisation = organisationAndAcademicRepository.findByTypeAndIsActive(CommonConstants.ORGANISATION,true);
	        } else if (CommonConstants.ACADEMICINSTITUTE.equalsIgnoreCase(type)) {
	            academicInstitute = organisationAndAcademicRepository.findByTypeAndIsActive(CommonConstants.ACADEMICINSTITUTE,true);
	        } else {
	            organisation = organisationAndAcademicRepository.findByTypeAndIsActive(CommonConstants.ORGANISATION,true);
	            academicInstitute = organisationAndAcademicRepository.findByTypeAndIsActive(CommonConstants.ACADEMICINSTITUTE,true);
	        }

	        Map<String, Object> organisationMap = new HashMap<>();
	        List<Map<String, Object>> organisationList = new ArrayList<>();
	        organisation.sort(Comparator.comparingInt(OrganisationAndAcademicInstitute::getPositionOrder));
	        for (OrganisationAndAcademicInstitute organisationAndAcademicInstituteObj : organisation) {
	            organisationMap = new HashMap<>();
	            organisationMap.put("name", organisationAndAcademicInstituteObj.getName());
	            organisationMap.put("imageUrl", organisationAndAcademicInstituteObj.getImageUrl());
	            organisationMap.put("positionOrder", organisationAndAcademicInstituteObj.getPositionOrder());
	            organisationList.add(organisationMap);
	        }

	        Map<String, Object> academicInstituteMap = new HashMap<>();
	        List<Map<String, Object>> academicInstituteList = new ArrayList<>();
	        academicInstitute.sort(Comparator.comparingInt(OrganisationAndAcademicInstitute::getPositionOrder));
	        for (OrganisationAndAcademicInstitute organisationAndAcademicInstituteObj : academicInstitute) {
	            academicInstituteMap = new HashMap<>();
	            academicInstituteMap.put("name", organisationAndAcademicInstituteObj.getName());
	            academicInstituteMap.put("imageUrl", organisationAndAcademicInstituteObj.getImageUrl());
	            academicInstituteMap.put("positionOrder", organisationAndAcademicInstituteObj.getPositionOrder());
	            academicInstituteList.add(academicInstituteMap);
	        }
	        organisationList.sort((a, b) -> ((Integer) b.get("positionOrder")).compareTo((Integer) a.get("positionOrder")));
	        academicInstituteList.sort((a, b) -> ((Integer) b.get("positionOrder")).compareTo((Integer) a.get("positionOrder")));
	        log.info("Sorting the list of Organisation and AcademicInstitute according to their positionOrder");


	        Map<String, Object> resultMap = new HashMap<>();
	        resultMap.put("Organisation", organisationList);
	        resultMap.put("AcademicInstitute", academicInstituteList);

	        result.add(resultMap);

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return result;
	}

    public Map<String,?> fetchTestimonialAsPerCategoryAndService(String category, String service) {
		try{
			Set<String> setOfTestimonialCategory = new HashSet<>();
			Map<String, List<TestimonialPost>> result = new HashMap<>();
            if (!category.equals("NA") && service.equals("NA")) {
				List<TestimonialPost> testimonialPostList = testimonialPostRepository.findByTestimonialCategoryAndIsActiveOrderByPositionOrderDesc(category, true);
				result.put(category.toUpperCase(), testimonialPostList);
			}else if(category.equals("NA") && !service.equals("NA")){
				List<TestimonialPost> testimonialPostList = testimonialPostRepository.findByServiceAndIsActiveOrderByPositionOrderDesc(service, true);
				List<TestimonialPost> customerPost = new ArrayList<>();
				List<TestimonialPost> userPost = new ArrayList<>();
				for(TestimonialPost post : testimonialPostList){
					if(post.getTestimonialCategory().equalsIgnoreCase(TestimonialCategoryType.CUSTOMER.name())){
						customerPost.add(post);
					}else if(post.getTestimonialCategory().equalsIgnoreCase(TestimonialCategoryType.USER.name())){
						userPost.add(post);
					}
				}
				result.put(TestimonialCategoryType.CUSTOMER.name(), customerPost);
				result.put(TestimonialCategoryType.USER.name(), userPost);
			}else if(!category.equals("NA") && !service.equals("NA")){
				List<TestimonialPost> testimonialPostList = testimonialPostRepository.findByTestimonialCategoryAndServiceAndIsActiveOrderByPositionOrderDesc(category, service, true);
				result.put(category.toUpperCase(), testimonialPostList);
			}
			else {
				List<TestimonialPost> testimonialPostList = testimonialPostRepository.findAllByIsActiveOrderByPositionOrderDesc(true);
				List<TestimonialPost> customerPost = new ArrayList<>();
				List<TestimonialPost> userPost = new ArrayList<>();
				for(TestimonialPost post : testimonialPostList){
					if(post.getTestimonialCategory().equalsIgnoreCase(TestimonialCategoryType.CUSTOMER.name())){
						customerPost.add(post);
					}else if(post.getTestimonialCategory().equalsIgnoreCase(TestimonialCategoryType.USER.name())){
						userPost.add(post);
					}
				}
				result.put(TestimonialCategoryType.CUSTOMER.name(), customerPost);
				result.put(TestimonialCategoryType.USER.name(), userPost);
			}
			return result;
		}
		catch (Exception e){
			log.error("Exception while fetching the testimonial as per category ::: {}", e);
			return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Error while returning the list of testimonials");
		}
    }

	public Object saveCase(CaseStudy caseStudy, InternityUser user) {
		 try {
			  return caseStudyRepository.save(caseStudy);
	        } catch (Exception e) {
	            log.error("Failed to save case study data ::: {}", e);
	            return commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Error while saving the case study data");
	        }
	    }

	public List<CaseStudy> getCaseStudies(String custUrl, String type, String subType, boolean isFeatured) {
	    List<CaseStudy> caseStudies = new ArrayList<>();
	    try {
			if(!custUrl.equals("NA")){
				Optional<CaseStudy> caseStudy = caseStudyRepository.findByCustUrl(custUrl);
				if(caseStudy.isPresent()){
					return Arrays.asList(caseStudy.get());
				}
				else {
					return null;
				}
			}
	        if (type.equalsIgnoreCase("JOB")) {
	            // Fetch records based on type and isActive
	            caseStudies = caseStudyRepository.findByTypeAndIsActiveTrue(CaseStudyTypeEnum.JOB.name());
	            log.info("Fetched all case studies of type JOB where isActive is true");
	        } else if (type.equalsIgnoreCase("HACKATHON")) {
	            // Fetch records based on type and isActive
	            caseStudies = caseStudyRepository.findByTypeAndIsActiveTrue(CaseStudyTypeEnum.HACKATHON.name());
	            log.info("Fetched all case studies of type HACKATHON where isActive is true");
	        } else {
	            // Fetch all records where isActive is true
	            caseStudies = caseStudyRepository.findByIsActiveTrue();
	            log.info("Fetched all case studies where isActive is true");
	        }

	        if (isFeatured) {
	            // Filter records based on subType and isFeatured
	            if (subType.equalsIgnoreCase("NA")) {
	                caseStudies = caseStudies.stream()
	                        .filter(c -> c.isFeatured())
	                        .collect(Collectors.toList());
	                log.info("Filtered case studies where isFeatured is true");
	            } else {
	                caseStudies = caseStudies.stream()
	                        .filter(c -> c.getSubType().equalsIgnoreCase(subType))
	                        .filter(c -> c.isFeatured())
	                        .collect(Collectors.toList());
	                log.info("Filtered case studies by subType {} and isFeatured is true", subType);
	            }
	        } else {
	            // Filter records based on subType and isActive
	            if (subType.equalsIgnoreCase("NA")) {
	                caseStudies = caseStudies.stream()
	                        .filter(c -> !c.isFeatured())
	                        .collect(Collectors.toList());
	                log.info("Filtered case studies where isFeatured is false");
	            } else {
	                caseStudies = caseStudies.stream()
	                        .filter(c -> c.getSubType().equalsIgnoreCase(subType))
	                        .filter(c -> !c.isFeatured())
	                        .collect(Collectors.toList());
	                log.info("Filtered case studies by subType {} and isFeatured is false", subType);
	            }
	        }
	    } catch (Exception e) {
	        log.error("Error fetching case studies: {}", e);
	    }
	    return caseStudies;
	}

	public Map<String, Object> getCustomerCategoriesAndSubcategories() {
        Map<String, Object> response = new HashMap<>();

        try {
            List<Map<String, List<String>>> subcategories = new ArrayList<>();

            // Iterate over the categories
            for (CustomerCategory category : CustomerCategory.values()) {
                List<String> categorySubcategories = new ArrayList<>();

                // Iterate over the subcategories
                for (CustomerSubcategory subcategory : CustomerSubcategory.values()) {
                    if (subcategory.getCategory().equals(category.name())) {
                        categorySubcategories.add(subcategory.getDisplayName());
                    }
                }

                Map<String, List<String>> categorySubcategoryMap = new HashMap<>();
                categorySubcategoryMap.put(category.getDisplayName(), categorySubcategories);
                subcategories.add(categorySubcategoryMap);
            }

            List<String> categories = new ArrayList<>();
            for (CustomerCategory category : CustomerCategory.values()) {
                categories.add(category.getDisplayName());
            }

            response.put("category", categories);
            response.put("subCategory", subcategories);
        } catch (Exception e) {
            log.error("Error occurred while retrieving customer categories and subcategories", e);
            response.put("error", "An error occurred while retrieving customer categories and subcategories.");
        }

        log.info("Retrieved customer categories and subcategories successfully");

        return response;
    }

	public boolean updateFeaturedItems(String elementId, String elementType, InternityUser user) {
		try{
			Optional<Featured> featuredObj = featuredRepository.findByElementIdAndElementType(elementId,
					elementType);
			if(featuredObj.isPresent()){
				featuredRepository.deleteById(featuredObj.get().getId());
				return true;
			}
		}
		catch (Exception e){
			log.error("Exception while updating the featured items ::: {}", e);
		}
		return false;
	}
	public ResponseEntity<String> verifyWebhook(String verifyToken, String challenge) {
		RestTemplate restTemplate = new RestTemplate();
        String pythonApiUrl = "http://13.200.62.58:5000/webhook"; 

        String urlWithParams = pythonApiUrl+"?hub.mode=subscribe"+"&hub.challenge="+challenge+"&hub.verify_token="+verifyToken;

        ResponseEntity<String> response = restTemplate.getForEntity(urlWithParams, String.class);
        return response;
    }
	public String processUserMessage(String incomingMessage) {
		RestTemplate restTemplate = new RestTemplate();
        String pythonApiUrl = "http://13.200.62.58:5000/webhook";
        JSONObject messageData = new JSONObject(incomingMessage);
        String message = messageData.getString("message");
        String recipient = messageData.getString("recipient");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        String requestBody = "{\"message\": \"" + message + "\", \"recipient\": \"" + recipient + "\"}";

        HttpEntity<String> requestEntity = new HttpEntity<>(requestBody, headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(pythonApiUrl, HttpMethod.POST, requestEntity, String.class);

        return responseEntity.getBody();
    }


	public ContactUs addContactUsQuery(ContactUs payload) {
		try{
			ContactUs savedQuery = contactUsRepository.save(payload);
			if(payload.getPurposeToConnect().equalsIgnoreCase("HACKATHON_QUERY")){
				sendCustomMailUtils.sendMailForGenericUser("Dear Team", techSupportEmail,"New Hackathon query",
						"<b>Sender Name</b> : "+payload.getSenderFullName()+"<br/>"
								+ "<b>Sender Email</b> : "+payload.getEmail()+" <br/>"
								+ "<b>Sender Contact</b> : "+payload.getContact()+"<br/>"
								+ "<b>Sender Message</b> : "+payload.getMessage()+"<br/>");
			}else {
				sendCustomMailUtils.sendMailForGenericUser("Dear Team", careEmailId,"New query on the platform for "+ payload.getPurposeToConnect(),
						"<b>Sender Name</b> : "+payload.getSenderFullName()+"<br/>"
								+ "<b>Sender Email</b> : "+payload.getEmail()+" <br/>"
								+ "<b>Sender Contact</b> : "+payload.getContact()+"<br/>"
								+ "<b>Purpose to connect</b> : "+payload.getPurposeToConnect()+"<br/>"
								+ "<b>Sender Message</b> : "+payload.getMessage()+"<br/>");
			}
			return savedQuery;
		}
		catch (Exception e){
			log.error("Exception while saving query to connect with us ::: {}", e);
		}
		return new ContactUs();
	}

}
		        
		        	
		        
		        

