package com.wue.service;

import com.wue.constant.UserRoles;
import com.wue.domain.*;
import com.wue.domain.CandidateApplication.JobApplicationScreeningAnswer;
import com.wue.domain.drill.Drill;
import com.wue.domain.drill.DrillParticipant;
import com.wue.domain.drill.DrillTeams;
import com.wue.model.EmailContent;
import com.wue.repository.*;
import com.wue.repository.CandidateApplication.JobApplicationScreeningAnswerRepository;
import com.wue.repository.drill.DrillParticipantRepository;
import com.wue.repository.drill.DrillRepository;
import com.wue.repository.drill.DrillTeamsRepository;
import com.wue.util.InternityUser;
import com.wue.util.SendMessageUtils;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Log4j2
@Service
public class PlatformStatsService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	JobsRepository jobRepository;

	@Autowired
	PartnerRepository partnerRepository;

	@Autowired
	PlatformStatsRepository statsRepository;

	@Autowired
	JobViewRepository jobViewRepository;

	@Autowired
	PageviewRepository pageviewRepository;

	@Autowired
	SendMessageUtils sendMessageUtils;

	@Autowired
	DrillTeamsRepository drillTeamsRepository;

	@Autowired
	DrillRepository drillRepository;
	
	@Autowired
	ApplicationRepository applicationRepository;

	@Autowired
	UserCandidateMandatoryFieldsRepository userCandidateMandatoryFieldsRepository;

	@Value("${environment:prod}")
	String environment;
	@Value("${stats.receiver.email:sunil@wuelev8.tech}")
	String statsReceiverEmail;

	@Autowired
	DrillParticipantRepository drillParticipantRepository;

//    @Scheduled(cron = "0 0 * * * *")
//    public boolean updateDrillPhasesStatus() {
//        try {
//            List<Drill> listOfActiveDrill = drillRepository.findByIsActiveTrue();
//            for (Drill drill : listOfActiveDrill) {
//                List<DrillPhases> drillPhasesList =
//                        drillPhasesRepository.findByDrillIdOrderByPhaseStartDtAsc(
//                                drill.getDrillId());
//                for (int i = 0; i < drillPhasesList.size(); i++) {
//					DrillPhases drillPhases = drillPhasesList.get(i);
//                    if (drillPhases
//                            .getPhaseStatus()
//                            .equalsIgnoreCase(DrillPhaseStatus.RUNNING.name())) {
//						if(drillPhases.getPhaseStartDt()drillPhasesList.get(i+1).getPhaseEndDt())
//					}
//                }
//            }
//        } catch (Exception e) {
//            log.error("Exception while updating drill phase status for all Drills");
//            return false;
//        }
//        return true;
//    }

	public boolean saveStats(PlatformStats stats, InternityUser user) {
		Long numberOfUsersOnPlatform = stats.getNumberOfUsersOnPlatform()==null?userRepository.count():stats.getNumberOfUsersOnPlatform();
		Long numberOfJobs = stats.getNumberOfJobPosted()==null?jobRepository.count():stats.getNumberOfJobPosted();
		Long numberOfPartners = stats.getNumberOfPartners()==null?partnerRepository.count():stats.getNumberOfPartners();

		stats.setNumberOfUsersOnPlatform(numberOfUsersOnPlatform);
		stats.setNumberOfJobPosted(numberOfJobs);
		stats.setNumberOfPartners(numberOfPartners);

		statsRepository.save(stats);

		return true;

	}

	@Scheduled(cron="0 0 9 * * *")
	public boolean scheduledSaveStats() {
		PlatformStats stats = new PlatformStats();
		//Long numberOfUsersOnPlatform = stats.getNumberOfUsersOnPlatform()==null?userRepository.count():stats.getNumberOfUsersOnPlatform();
		Long numberOfJobs = stats.getNumberOfJobPosted()==null?jobRepository.count():stats.getNumberOfJobPosted();
		Long numberOfPartners = stats.getNumberOfPartners()==null?partnerRepository.count():stats.getNumberOfPartners();

		Map<String, String> statsMap = statsOnPlatform();

		stats.setNumberOfUsersOnPlatform(25000L);
		stats.setNumberOfJobPosted(numberOfJobs);
		stats.setNumberOfPartners(numberOfPartners);
        if (statsMap != null) {
            stats.setNumberOfJobPostedInOneDay(
                    Long.parseLong(statsMap.get("Job added in last 24 hours")));
            stats.setNumberOfUsersInOneDay(
                    Long.parseLong(statsMap.get("Users added in last 24 hours")));
            stats.setNumberOfJobViewsInOneDay(
                    Long.parseLong(statsMap.get("Job Views in last 24 hours")));
            stats.setNumberOfPlatformViewsInOneDay(
                    Long.parseLong(statsMap.get("Site Views in last 24 hours")));
            stats.setNumberOfDrillViewsInOneDay(
                    Long.parseLong(statsMap.get("Drill Views in last 24 hours")));
            stats.setNumberOfLandingViewsInOneDay(
                    Long.parseLong(statsMap.get("Landing page Views in last 24 hours")));
            stats.setNumberOfProfileViewsInOneDay(
                    Long.parseLong(statsMap.get("Profile Views in last 24 hours")));
            stats.setNumberOfActiveUsersInOneDay(
                    Long.parseLong(statsMap.get("Active users added in last 24 hours")));
            stats.setNumberOfInactiveUsersInOneDay(
                    Long.parseLong(statsMap.get("Inactive users added in last 24 hours")));
            stats.setNumberOfActiveUsersOnPlatform(
                    Long.parseLong(statsMap.get("Total Active Users")));
            stats.setNumberOfInactiveUsersOnPlatform(
                    Long.parseLong(statsMap.get("Total Inactive Users")));
		}
		stats.setJoiningsDone(50L);
		stats.setNumberOfHackathons(20);
		stats.setNumberOfSquadPrograms(9);
		statsRepository.save(stats);

		return true;
	}

	public PlatformStats fetchPlatformStats(String pageName, InternityUser user) {
		PlatformStats stats = statsRepository.findFirstByOrderByStatsIdDesc();
		return stats;
	}

	public List<PlatformStats> listOfPlatformStats(int numberOfDays, InternityUser user) {
		List<PlatformStats> stats = null;
		if(numberOfDays == 0) {
			stats = statsRepository.findFirst7ByOrderByRecordInsertedtsDesc();
		}else {
			stats = statsRepository.findStatsAsPerDates(numberOfDays);
		}
		return stats;
	}

	public List<PlatformStats> listOfPlatformStatsForADrill(int numberOfDays, String drillId, InternityUser user) {
		List<PlatformStats> stats = null;
		if(numberOfDays == 0) {
			stats = statsRepository.findFirst7ByOrderByRecordInsertedtsDesc();
		}else {
			stats = statsRepository.findStatsAsPerDates(numberOfDays);
		}
		return stats;
	}

	public Map<String, String> cumulativePlatformStats(InternityUser user) {
		Long numberOfJobs = jobRepository.count();
		Long numberOfActiveJobs = jobRepository.countActiveJobs();
		Long numberOfUsers = userRepository.count();
		Long numberofJobViews = jobViewRepository.count();
		Long numberOfSiteViews = pageviewRepository.count();

		Map<String, String> statsMap = new HashMap<>();
		statsMap.put("numberOfJobs", numberOfJobs+"");
		statsMap.put("numberOfActiveJobs", numberOfActiveJobs+"");
		statsMap.put("numberOfUsers", numberOfUsers+"");
		statsMap.put("numberofJobViews", numberofJobViews+"");
		statsMap.put("numberofSiteViews", numberOfSiteViews+"");

		return statsMap;
	}

    public Map<String, Object> getFileOrListofParticipants() {
		List<DrillParticipant> participantList = drillParticipantRepository.findAll();
		int countOfUserNotInDrill = 0;
		int countOfDrillParticipants = 0;

		Map<String, Object> resultMap = new HashMap<>();

		List<String> resultListOfListStr = new ArrayList<>();

		List<String> uidsFromDrill = new ArrayList<>();
		for(DrillParticipant drillParticipant : participantList){
			countOfDrillParticipants++;
			uidsFromDrill.add(drillParticipant.getPlatformUId());
		}

		List<User> userList = userRepository.findByuIdNotIn(uidsFromDrill);

		for(User user : userList){
			String strOfList = new String();
			strOfList = strOfList + user.getFullName() + ", ";
			strOfList = strOfList + user.getEmail() + ", ";
			strOfList = strOfList + user.getUContact() + ", ";
			strOfList = strOfList + user.getResumeLink() + ", ";
			strOfList = strOfList + user.getUserCreatedts() + ", ";
			strOfList = strOfList + user.isActive() +"\n";
			resultListOfListStr.add(strOfList);
			countOfUserNotInDrill++;
		}

		Long usersAddedToday = drillParticipantRepository.fetchCountOfUsersAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1));

		resultMap.put("Users registered but not in Drill",countOfUserNotInDrill);
		resultMap.put("Total Drill Participants",countOfDrillParticipants);
		//resultMap.put("Drill Participants in 24 hours",countOfDrillParticipants);
		resultMap.put("Users Info registered but not in Drill",resultListOfListStr);

		return resultMap;
    }

    public String fetchReportOfStats(String to) throws MessagingException {
		if (to.equals("NA")) {
			return sendEmailWithStats();
		} else {
			EmailContent emailContent = configureStatsMailContent();
			if(!environment.equals("")){
				sendMessageUtils
						.sendMail(to, emailContent);
			}
			return emailContent.getMessage();
		}
	}

	@Scheduled(cron="0 0 9 * * *")
	private String sendEmailWithStats() throws MessagingException {
		EmailContent emailContent = configureStatsMailContent();
		if(!environment.equals("")){
			sendMessageUtils
					.sendMail(statsReceiverEmail, emailContent);
		}
		return emailContent.getMessage();
	}

	private EmailContent configureStatsMailContent() {

		Map<String, String> statsMap = statsOnPlatform();

		if(statsMap == null){
			return null;
		}

		StringBuilder message = new StringBuilder();
		message.append("<table style=\"border-style:groove\"><th><td colspan=\"2\">Platform Stats</td></th>");

		for (Map.Entry<String, String> entry : statsMap.entrySet()) {
			message.append("<tr><td>"+entry.getKey() + "</td><td>&nbsp;&nbsp;" + entry.getValue() +"</td></tr>");
		}
		message.append("</table>");
		message.append("<br/>");

		Map<String, Object> drillInfo = getFileOrListofParticipants();
		message.append(
				"<table style=\"border-style:groove\"><th><td colspan=\"2\">Drill Stats</td></th>");
		for (Map.Entry<String, Object> entry : drillInfo.entrySet()) {
			if (!entry.getKey().equalsIgnoreCase("Users Info registered but not in Drill")) {
				message.append("<tr><td>" + entry.getKey() + "</td><td>&nbsp;&nbsp;" + entry.getValue() + "</td></tr>");
			}
		}

		message.append("</table>");

		EmailContent emailContent = new EmailContent();
		emailContent.setMessage(message.toString());
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
		emailContent.setSubject("Where U Elevate daily report " + formatter.format(LocalDate.now()) + " from "+environment+" environment");
		emailContent.setTemplateName("GenericMailForAllUsers");
		return emailContent;
	}

	private Map<String, String> statsOnPlatform() {
		try{
			Long numberOfJobs = jobRepository.count();
			Long numberOfActiveJobs = jobRepository.countActiveJobs();
			Long numberOfUsers = userRepository.count();
			Long numberOfActiveUsers = userRepository.fetchCountOfActiveUsers();
			Long numberOfInactiveUsers = userRepository.fetchCountOfInactiveUsers();
			Long numberofJobViews = jobViewRepository.count();
			Long numberOfSiteViews = pageviewRepository.count();

			Long numberOfJobsAddedInOneDay = jobRepository.fetchCountOfJobsAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1));
			Long numberofJobViewsAddedInOneDay = jobViewRepository.fetchCountOfJobViewsAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1));
			Long numberOfSiteViewsAddedInOneDay = pageviewRepository.fetchCountOfSiteViewsAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1));
			Long numberOfDrillViewsAddedInOneDay = pageviewRepository.fetchCountOfSpecificPageViewsAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1), Arrays.asList("hackathon_page"));
			Long numberOfLandingViewsAddedInOneDay = pageviewRepository.fetchCountOfSpecificPageViewsAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1), Arrays.asList("hackathon_page"));
			Long numberOfProfileViewsAddedInOneDay = pageviewRepository.fetchCountOfSpecificPageViewsAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1), Arrays.asList("hackathon_page"));

			Long usersAddedToday = userRepository.fetchCountOfUsersAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1));
			Long activeUsersAddedToday = userRepository.fetchCountOfActiveUsersAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1));
			Long inactiveUsersAddedToday = userRepository.fetchCountOfInactiveUsersAddedInBetweenDays(LocalDate.now(), LocalDate.now().minusDays(1));



			Map<String, String> statsMap = new HashMap<>();
			statsMap.put("Total Jobs on Platform", numberOfJobs+"");
			statsMap.put("Total Active jobs", numberOfActiveJobs+"");
			statsMap.put("Total Users", numberOfUsers+"");
			statsMap.put("Total Active Users", numberOfActiveUsers+"");
			statsMap.put("Total Inactive Users", numberOfInactiveUsers+"");
			statsMap.put("Total Job Views", numberofJobViews+"");
			statsMap.put("Total Website Views", numberOfSiteViews+"");
			statsMap.put("Users added in last 24 hours", usersAddedToday+"");
			statsMap.put("Active users added in last 24 hours", activeUsersAddedToday+"");
			statsMap.put("Inactive users added in last 24 hours", inactiveUsersAddedToday+"");
			statsMap.put("Job added in last 24 hours", numberOfJobsAddedInOneDay+"");
			statsMap.put("Job Views in last 24 hours", numberofJobViewsAddedInOneDay+"");
			statsMap.put("Site Views in last 24 hours", numberOfSiteViewsAddedInOneDay+"");
			statsMap.put("Drill Views in last 24 hours", numberOfDrillViewsAddedInOneDay+"");
			statsMap.put("Landing page Views in last 24 hours", numberOfLandingViewsAddedInOneDay+"");
			statsMap.put("Profile Views in last 24 hours", numberOfProfileViewsAddedInOneDay+"");
			return statsMap;
		}
		catch (Exception e){
			log.error("Exception while setting the map of stats {}", e);
		}
		return null;
	}

	public Object getOverallStatsOfDrillOfAPartner(int rangeToFetch, String partnerId, String uId, String entityId, String pageName, InternityUser user) {
		try{
			if(checkIfUserHasWUEAdminRole(uId)){
				Map<String, Object> overallStats = new HashMap<>();

				List<Drill> listOfDrill = drillRepository.findAll();
				List<String> listOfDrillId =
						listOfDrill.stream().map(e -> e.getDrillId()).collect(Collectors.toList());
				List<DrillParticipant> participantList =
						drillParticipantRepository.findListOfParticipantByDrillIn(listOfDrillId);
				int countOfParticipants = 0;
				int countOfProfessional = 0;
				int countOfStudent = 0;
				for (DrillParticipant drillParticipant : participantList) {
                    if (!StringUtils.isBlank(drillParticipant.getParticipantType())) {
                        if (drillParticipant.getParticipantType().equalsIgnoreCase("profesional")) {
                            countOfProfessional++;
                        } else if (drillParticipant
                                .getParticipantType()
                                .equalsIgnoreCase("student")) {
                            countOfStudent++;
                        }
                        countOfParticipants++;
					}
				}
				overallStats.put("partnerId", partnerId);
				overallStats.put("totalHackathons", listOfDrill.stream().count());
				overallStats.put(
							"totalImpressions",
							pageviewRepository.findCountByPageName("hackathon_page"));
				overallStats.put("totalParticipants", countOfParticipants);
				if(countOfParticipants==0){
					countOfParticipants = 1;
				}
				overallStats.put(
						"percentageOfParticipantType",
						"{\"student\":\""
								+ (countOfStudent * 100) / countOfParticipants
								+ "\""
								+ ",\"professional\":\""
								+ (countOfProfessional * 100) / countOfParticipants
								+ "\"}");
				return overallStats;
            } else {
                Map<String, Object> overallStats = new HashMap<>();

                List<Drill> listOfDrill = drillRepository.findByDrillPartnerId(partnerId);
                List<String> listOfDrillId =
                        listOfDrill.stream().map(e -> e.getDrillId()).collect(Collectors.toList());
                List<DrillParticipant> participantList =
                        drillParticipantRepository.findListOfParticipantByDrillIn(listOfDrillId);
                int countOfParticipants = 0;
                int countOfProfessional = 0;
                int countOfStudent = 0;
                for (DrillParticipant drillParticipant : participantList) {
                    if (drillParticipant.getParticipantType().equalsIgnoreCase("profesional")) {
                        countOfProfessional++;
                    } else if (drillParticipant.getParticipantType().equalsIgnoreCase("student")) {
                        countOfStudent++;
                    }
                    countOfParticipants++;
                }
                overallStats.put("partnerId", partnerId);
                overallStats.put("totalHackathons", listOfDrill.stream().count());
                overallStats.put(
                        "totalImpressions",
                        pageviewRepository.findCountByEntityIdIn(listOfDrillId));
                overallStats.put("totalParticipants", countOfParticipants);
				if(countOfParticipants==0){
					countOfParticipants = 1;
				}
                overallStats.put(
                        "percentageOfParticipantType",
                        "{\"student\":\""
                                + (countOfStudent * 100) / countOfParticipants
                                + "\""
                                + ",\"professional\":\""
                                + (countOfProfessional * 100) / countOfParticipants
                                + "\"}");
                return overallStats;
			}
		}
		catch (Exception e){
			log.error("Exception while getting the overall stats of Drill for a partner {}", e);
			return null;
		}
	}

	private boolean checkIfUserHasWUEAdminRole(String uId) {
		try{
			Optional<User> userObj = userRepository.findById(uId);
			if(userObj.isPresent()){
				User user = userObj.get();
				return (user.getURole().equalsIgnoreCase(UserRoles.SUPERADMIN.name())
						|| user.getURole().equalsIgnoreCase(UserRoles.WUEDRILLSUPERADMIN.name()));
			}
		}
		catch (Exception e){
			log.error("Exception while checking the role of the user for SUPERADMIN AND WUEDRILLSUPERADMIN {}", e);
		}
		return false;
	}

	public Object getOverallStatsOfDrill(String drillId) {
		try{
			List<DrillParticipant> participantList = drillParticipantRepository.findByDrillId(drillId);
			List<DrillTeams> drillTeamsList = drillTeamsRepository.findByDrillId(drillId);

			Map<String, List<Map<String, Object>>> result = new HashMap<>();

			Map<String, Object> overallParticipation = new HashMap<>();

			overallParticipation.put("name","totalRegistrations");
			overallParticipation.put("value",participantList.stream().count());

			Map<String, Object> overallTeams = new HashMap<>();

			overallTeams.put("name","totalTeams");
			overallTeams.put("value",drillTeamsList.stream().count());

			Map<String, Object> professional = new HashMap<>();

			professional.put("name","professional");
			professional.put("value",participantList.stream()
					.filter(p -> p.getParticipantType().equalsIgnoreCase("profesional")).count());

			//Students

			Map<String, Object> student = new HashMap<>();

			student.put("name","student");
			student.put("value", participantList.stream()
					.filter(p -> p.getParticipantType().equalsIgnoreCase("student")).count());

			List<Map<String, Object>> listOfStats = new ArrayList<>();
			listOfStats.add(professional);
			listOfStats.add(student);
			result.put("participantTypes", listOfStats);

			// Themes

			List<String> drillThemesValues = drillTeamsList.stream().map(t -> t.getSelectedTheme())
					.collect(Collectors.toList());
			Map<String, Long> themesCount = drillThemesValues.stream()
					.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
			//themes

			List<Map<String, Object>> themesList = new ArrayList<>();
			if(themesCount.isEmpty()){
				Map<String, Object> themes = new HashMap<>();
				themes.put("name","themes");
				themes.put("value", 0);
				themesList.add(themes);
            } else {
                for (String theme : themesCount.keySet()) {
                    Map<String, Object> themes = new HashMap<>();
                    themes.put("name", theme);
                    themes.put("value", themesCount.get(theme));
                    themesList.add(themes);
                }
			}

			result.put("themes", themesList);

			//teamSizes

			List<String> drillTeamSizesValues = drillTeamsList.stream().map(t -> t.getTeamCurrentSize()+"")
					.collect(Collectors.toList());
			Map<String, Long> teamSizeCount = drillTeamSizesValues.stream()
					.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
			List<Map<String, Object>> teamSizesList = new ArrayList<>();

			if(teamSizeCount.isEmpty()){
				Map<String, Object> teamSizes = new HashMap<>();
				teamSizes.put("name", "teams");
				teamSizes.put("value", 0);
				teamSizesList.add(teamSizes);
            } else {
                for (String teamSize : teamSizeCount.keySet()) {
                    Map<String, Object> teamSizes = new HashMap<>();
                    teamSizes.put("name", teamSize);
                    teamSizes.put("value", teamSizeCount.get(teamSize));
                    teamSizesList.add(teamSizes);
                }
			}
			result.put("teamSizes", teamSizesList);

			List<Map<String, Object>> overallParticipationList = new ArrayList<>();
			overallParticipationList.add(overallParticipation);
			result.put("overallParticipation", overallParticipationList);

			List<Map<String, Object>> overallTeamsList = new ArrayList<>();
			overallTeamsList.add(overallTeams);
			result.put("overallTeams", overallTeamsList);

			return result;

 		}
		catch (Exception e){
			log.error("Exception while getting the overall stats of Drill for a partner {}", e);
			return null;
		}
	}

	@Autowired
	JobApplicationScreeningAnswerRepository screeningAnswerRepository;

	public Object getOverallStatsOfApplication(String jobId,String partnerId) {
	    try {	
	    	Map<String, List<Map<String, Object>>> response = new HashMap<>();
	        List<Application> currentStatusList;
	        List<JobApplicationScreeningAnswer> applicationScreeningAnswers;
	        List<UserCandidateMandatoryFields> userCandidateMandatoryFieldsList = new ArrayList<>();

	        if (jobId != null && !jobId.equals("NA")) {
	            currentStatusList = applicationRepository.findByJobId(jobId);
	            applicationScreeningAnswers = screeningAnswerRepository.findByJobId(jobId);
	        } else if (partnerId != null && !partnerId.equals("NA")) {
	            List<Job> jobs = jobRepository.findByPartnerId(partnerId);
	            List<String> jobIds = jobs.stream()
	                    .map(Job::getJobId)
	                    .collect(Collectors.toList());
	            currentStatusList = applicationRepository.findByJobIdIn(jobIds);
	            applicationScreeningAnswers = screeningAnswerRepository.findByJobIdIn(jobIds);
	        } else {
	            currentStatusList = applicationRepository.findAll();
	            applicationScreeningAnswers = screeningAnswerRepository.findAll();
	        }
	        List<String> uIds = currentStatusList.stream()
	            .map(Application::getUId)
	            .collect(Collectors.toList());

	        userCandidateMandatoryFieldsList = userCandidateMandatoryFieldsRepository.findUserByuIdIn(uIds);

	        Map<String, Integer> statusCountMap = currentStatusList.stream()
	            .collect(Collectors.groupingBy(Application::getCurrentStatus, Collectors.summingInt(e -> 1)));
			Map<String, Integer> statusCountMapFinal = new HashMap<>();
			for(String key : statusCountMap.keySet()){
				if(key.startsWith("ROUND")
						|| key.startsWith("INTERVIEW")
						){
					if(statusCountMap.containsKey("INTERVIEWED")){
						statusCountMapFinal.put("INTERVIEWED",statusCountMapFinal.get("INTERVIEWED")+statusCountMap.get(key));
					}else {
						statusCountMapFinal.put("INTERVIEWED", statusCountMap.get(key));
					}
				}
				else {
					statusCountMapFinal.put(key, statusCountMap.get(key));
				}
			}
	        List<Map<String, Object>> currentStatusStats = statusCountMapFinal.entrySet().stream()
	            .map(entry -> {
	                Map<String, Object> statusStat = new HashMap<>();
	                statusStat.put("name", entry.getKey());
	                statusStat.put("value", entry.getValue());
	                return statusStat;
	            })
	            .collect(Collectors.toList());

	        response.put("currentStatus", currentStatusStats);
	        
	        Map<String, Integer> yoeCountMap = userCandidateMandatoryFieldsList.stream()
	            .map(UserCandidateMandatoryFields::getYoe)
	            .mapToDouble(Double::doubleValue)
	            .mapToObj(this::calculateYoeRange)
	            .collect(Collectors.groupingBy(Function.identity(), Collectors.summingInt(e -> 1)));

	        List<Map<String, Object>> yoeStats = yoeCountMap.entrySet().stream()
	            .map(entry -> {
	                Map<String, Object> yoeStat = new HashMap<>();
	                yoeStat.put("name", entry.getKey());
	                yoeStat.put("value", entry.getValue());
	                return yoeStat;
	            })
	            .collect(Collectors.toList());

	        response.put("yoe", yoeStats);
	        
	        Map<String, Integer> skillsCountMap = userCandidateMandatoryFieldsList.stream()
	            .map(UserCandidateMandatoryFields::getPrimarySkills)
	            .filter(Objects::nonNull)
	            .flatMap(skills -> Arrays.stream(skills.split(",")))
	            .map(String::trim)
	            .filter(skill -> !skill.isEmpty())
	            .collect(Collectors.groupingBy(Function.identity(), Collectors.summingInt(e -> 1)));

	        
	        List<Map<String, Object>> skillsStats = skillsCountMap.entrySet().stream()
	            .map(entry -> {
	                Map<String, Object> skillStat = new HashMap<>();
	                skillStat.put("name", entry.getKey());
	                skillStat.put("value", entry.getValue());
	                return skillStat;
	            })
	            .collect(Collectors.toList());

	        response.put("Skills", skillsStats);

	        return response;
	    } catch (Exception e) {
	        log.error("Exception while getting application stats: {}", e);
	        return null;
	    }
	}

	private String calculateYoeRange(double yearsOfExperience) {
		if (yearsOfExperience >= 0 && yearsOfExperience < 1) {
	        return "0-1 year";
	    } else if (yearsOfExperience >= 1 && yearsOfExperience < 2) {
	        return "1-2 years";
	    } else if (yearsOfExperience >= 2 && yearsOfExperience < 3) {
	        return "2-3 years";
	    } else if (yearsOfExperience >= 3 && yearsOfExperience < 4) {
	        return "3-4 years";
	    } else if (yearsOfExperience >= 4 && yearsOfExperience < 5) {
	        return "4-5 years";
	    } else if (yearsOfExperience >= 5 && yearsOfExperience < 6) {
	        return "5-6 years";
	    } else if (yearsOfExperience >= 6 && yearsOfExperience < 7) {
	        return "6-7 years";
	    } else if (yearsOfExperience >= 7 && yearsOfExperience < 8) {
	        return "7-8 years";
	    }
	    return "Other";
	}

	public Map<String, Long> fetchCountOfImpressions(String category, String partnerId, String entityId) {
		try{
			Map<String, Long> countOfImpressionMap = new HashMap<>();
			if(!"NA".equals(entityId)){
				Long countImpression = pageviewRepository.findCountByEntityId(entityId);
				countOfImpressionMap.put(entityId, countImpression);
			}else if(!"NA".equals(partnerId)){
				if(!category.equalsIgnoreCase("JOB")){
					List<Drill> drillList = drillRepository.findByDrillPartnerId(partnerId);
					for(Drill drill : drillList){
						countOfImpressionMap.put(drill.getDrillId(),
								pageviewRepository.findCountByEntityId(drill.getDrillId()));
					}
				}
			}
			return countOfImpressionMap;
		}
		catch (Exception e){
			log.error("Exception while fetching count of impressions ::: {}", e);
		}
		return Collections.EMPTY_MAP;
	}

}
