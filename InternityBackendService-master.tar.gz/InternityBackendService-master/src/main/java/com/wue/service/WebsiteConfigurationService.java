package com.wue.service;

import com.wue.domain.WueTeam;
import com.wue.repository.WueTeamsRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Log4j2
public class WebsiteConfigurationService {
    @Autowired
    CommonUtils utils;

    @Autowired
    WueTeamsRepository wueTeamsRepository;

    public ResponseEntity<String> save(WueTeam obj, InternityUser user) {
        try {
            wueTeamsRepository.save(obj);
            return new ResponseEntity<>("{\"msg\":\""+utils.message(HttpStatus.OK, "")+"\"}", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("{\"Error\":\""+utils.message(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage())+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<?> getMembersList( InternityUser user) {
        try {
            List<WueTeam> teamsList = wueTeamsRepository.findAll();
            return new ResponseEntity<>(teamsList, HttpStatus.OK);
        }
         catch (Exception e) {
            return new ResponseEntity<>("{\"Error\":\""+utils.message(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage())+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }
}
