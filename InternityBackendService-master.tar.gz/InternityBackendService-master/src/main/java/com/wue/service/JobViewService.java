package com.wue.service;

import com.wue.domain.JobView;
import com.wue.repository.JobViewRepository;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.text.DateFormatSymbols;
import java.util.*;

@Service
@Log4j2
public class JobViewService {
	@Autowired
	private CommonUtils commonUtils;

	@Autowired
	JobViewRepository jobViewRepository;

	public ResponseEntity<?> save(JobView jobView, InternityUser internityUser){
		try {
			fetchDateAndSetData(jobView);
			jobViewRepository.save(jobView);
			return new ResponseEntity<>(commonUtils
					.message(HttpStatus.OK, "Job View successfully saved")
					, HttpStatus.OK);
		}
		catch (Exception e){
			return new ResponseEntity<>(commonUtils
					.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save job view")
					, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void fetchDateAndSetData(JobView jobView) {
		Date date = jobView.getCreatedTs();
		String dayNames[] = new DateFormatSymbols().getWeekdays();
		String monthNames[] = new DateFormatSymbols().getMonths();
		jobView.setDayOfWeek(dayNames[date.getDay()]);
		jobView.setMonthOfYear(monthNames[date.getMonth()]);
		jobView.setYear(date.getYear());
	}

	public ResponseEntity<?> fetchViewsOnJob(String jobId, String uId, InternityUser internityUser) {
		Map<String, Object> response = new HashMap<>();
		if(!StringUtils.isEmpty(jobId)){
			List<JobView> listOfJobviewObj = jobViewRepository.findByuIdAndJobId(jobId, uId);
			response.put("count", listOfJobviewObj.size());
			response.put("data", listOfJobviewObj);
		}else {
			List<JobView> listOfJobviewObj = jobViewRepository.findByjobId(jobId);
			response.put("count", listOfJobviewObj.size());
			response.put("data", listOfJobviewObj);
		}
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
