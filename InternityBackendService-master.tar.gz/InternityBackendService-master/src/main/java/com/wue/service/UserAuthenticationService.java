package com.wue.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * This service will be used by spring security authentication provider. This class implements UserDetails service
 * which have method loadUserByUserName() that will be used for injecting user credentials for authentication.
 * @author Rishab
 */
@Service
public class UserAuthenticationService implements UserDetailsService {

    @Autowired
    HttpServletRequest request;

    @Autowired
    UserManagementService userManagementService;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            return userManagementService.getUserDetails(username);
        } catch (Exception e) {
            throw new UsernameNotFoundException("Invalid Username");
        }
    }
}