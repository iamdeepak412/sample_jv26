package com.wue.service.drill;

import com.wue.constant.drill.*;
import com.wue.domain.drill.*;
import com.wue.repository.UserRepository;
import com.wue.repository.drill.*;
import com.wue.util.CommonUtils;
import com.wue.util.SendMessageUtils;
import com.wue.util.drill.SendCustomMailUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;


@Service
@Log4j2
public class DrillPhaseService {

    @Autowired DrillRepository drillRepository;

    @Autowired DrillPhasesRepository drillPhasesRepository;

    @Autowired UserRepository userRepository;

    @Autowired SendMessageUtils messageUtils;

    @Autowired SendCustomMailUtils sendCustomMailUtils;

    @Value("${domain.url:http://api-dev.wuelev8.tech:8080}")
    String domainUrl;

    @Autowired CommonUtils commonUtils;

    @Value(
            "#{'${drill.skills:Java,reactJs,Python,NodeJs,Docker,DevOps,Kubernetes,Others}'.trim().split(',')}")
    private List<String> drillCommonSkills;

    @Value(
            "#{'${drill.affiliate.platforms:Facebook, LinkedIn, Where U Elevate, Twitter}'.trim().split(',')}")
    private String drillAffiliatePlatforms;

    public DrillStatus getCurrentDrillStatus(Drill drill){
        try{
            List<DrillPhases> drillPhasesList = drillPhasesRepository.findByDrillIdOrderByPhaseStartDtAsc(drill.getDrillId());

        }
        catch (Exception e){
            log.error("Exception while getting the current status of the Drill ::: {}", e);
        }
        return null;
    }
}
