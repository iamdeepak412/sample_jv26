package com.wue.repository.blog;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.blog.BlogCategory;

import java.util.List;

@EnableJpaRepositories
public interface BlogCategoryRepository extends JpaRepository <BlogCategory,String> {

    List<BlogCategory> findByNameLike(String categoryName);
}
