package com.wue.repository.ConfigureJob;

import com.wue.domain.ConfigureJob.JobScreeningQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface JobScreeningQuestionRepository extends JpaRepository<JobScreeningQuestion, String>  {

    List<JobScreeningQuestion> findByJobId(String jobId);

	JobScreeningQuestion findByQuestionId(String questionId);
}

