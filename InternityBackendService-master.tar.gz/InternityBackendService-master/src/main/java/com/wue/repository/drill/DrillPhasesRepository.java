package com.wue.repository.drill;

import com.wue.domain.drill.DrillPhases;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface DrillPhasesRepository extends JpaRepository<DrillPhases, String> {

    List<DrillPhases> findByDrillIdOrderByPhaseStartDtDesc(String drillId);
    List<DrillPhases> findByDrillIdOrderByPhaseStartDtAsc(String drillId);
    Optional<DrillPhases> findByDrillIdAndPhaseType(String drillId, String phaseType);
	List<DrillPhases> findByDrillIdOrderByPhaseEndDtDesc(String drillId);

    List<DrillPhases> findByDrillIdAndPhaseStatusOrderByPhaseStartDtDesc(String drillId, String name);

    List<DrillPhases> findByDrillIdAndPhaseStatusOrderByPhaseStartDtAsc(String drillId, String name);

    List<DrillPhases> findByDrillId(String drillId);

    Optional<DrillPhases> findByDrillIdAndPhaseId(String drillId, String phaseId);

    DrillPhases findByDrillIdAndPhasePosition(String drillId, int i);
}
