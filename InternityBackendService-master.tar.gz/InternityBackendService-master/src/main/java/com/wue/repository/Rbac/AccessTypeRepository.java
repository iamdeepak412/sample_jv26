package com.wue.repository.Rbac;

import com.wue.domain.Rbac.AccessType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface AccessTypeRepository extends JpaRepository<AccessType, Long>  {

    List<AccessType> findAllByIsActive(boolean b);
}

