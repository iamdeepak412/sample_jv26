package com.wue.repository.common;

import com.wue.domain.common.DomainMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DomainMasterRepository extends JpaRepository<DomainMaster,Long> {

}
