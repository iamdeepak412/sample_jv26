package com.wue.repository.drill;

import com.wue.domain.drill.DrillJudgingCriteria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillJudgingCriteriaRepository extends JpaRepository<DrillJudgingCriteria, String> {

    List<DrillJudgingCriteria> findByDrillId(String drillId);
    List<DrillJudgingCriteria> findByDrillIdAndPhaseId(String drillId, String phaseId);
}
