package com.wue.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wue.domain.Featured;

@Repository
public interface FeaturedRepository extends JpaRepository<Featured, Long> {

	List<Featured> findAllByIsActiveTrue();

	List<Featured> findByElementTypeAndIsActiveOrderByPositionOrderDesc(String featuredType, boolean isActive);

    Optional<Featured> findByElementIdAndElementType(String elementId, String elementType);
}
