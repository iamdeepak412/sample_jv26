package com.wue.repository.drill;

import com.wue.domain.drill.DrillOrganiserDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillOrganiserDetailsRepository extends JpaRepository<DrillOrganiserDetails, String> {

    List<DrillOrganiserDetails> findByDrillId(String drillId);
}
