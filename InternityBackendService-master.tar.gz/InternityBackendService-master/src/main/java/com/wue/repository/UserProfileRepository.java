package com.wue.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.UserPersonalDetail;

@EnableJpaRepositories
public interface UserProfileRepository extends JpaRepository<UserPersonalDetail, Long>  {

	Optional<UserPersonalDetail> findByuId(String uId);

    Optional<UserPersonalDetail> findByuIdAndResumeLinkIsNotNull(String uId);

    List<UserPersonalDetail> findByResumeLinkIsNotNull();

    List<UserPersonalDetail> findByuIdIn(List<String> filteredApplicationUIds);
}

