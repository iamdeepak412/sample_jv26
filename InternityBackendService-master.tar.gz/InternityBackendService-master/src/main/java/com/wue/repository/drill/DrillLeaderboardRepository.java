package com.wue.repository.drill;

import com.wue.domain.drill.DrillLeaderboard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillLeaderboardRepository extends JpaRepository<DrillLeaderboard, String>, JpaSpecificationExecutor<DrillLeaderboard> {

    DrillLeaderboard findByDrillIdAndPhaseIdAndTeamId(String drillId, String phaseId, String teamId);
    DrillLeaderboard findByDrillIdAndPhaseIdAndParticipantId(String drillId, String phaseId, String participantId);

    List<DrillLeaderboard> findAllByDrillIdAndPhaseId(String drillId, String phaseId);

    DrillLeaderboard findByDrillIdAndPhaseIdAndSubmissionId(String drillId, String phaseId, String submissionId);

    List<DrillLeaderboard> findAllByDrillId(String drillId);
}
