package com.wue.repository;

import com.wue.domain.UserCandidateMandatoryFields;
import com.wue.util.OffsetBasedPageRequest;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface UserCandidateMandatoryFieldsRepository
        extends JpaRepository<UserCandidateMandatoryFields, Long>,JpaSpecificationExecutor<UserCandidateMandatoryFields>    {

    Optional<UserCandidateMandatoryFields> findByuId(String uId);


    Optional<UserCandidateMandatoryFields> findTop1ByuIdOrderByUserCreatedtsDesc(String uId);

	Page<UserCandidateMandatoryFields> findByuIdIn(List<String> filteredApplicationUIds,
			Pageable userPageable);

	List<UserCandidateMandatoryFields> findUserByuIdIn(List<String> uIds);


	Page<UserCandidateMandatoryFields> findAllByuIdIn(ArrayList arrayList, OffsetBasedPageRequest of);
}
