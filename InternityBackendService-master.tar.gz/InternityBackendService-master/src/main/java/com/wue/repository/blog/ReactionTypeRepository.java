package com.wue.repository.blog;

import com.wue.domain.blog.ReactionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ReactionTypeRepository extends JpaRepository<ReactionType,String> {
    List<ReactionType> findByReactionTypeId(String reactionTypeId);
}
