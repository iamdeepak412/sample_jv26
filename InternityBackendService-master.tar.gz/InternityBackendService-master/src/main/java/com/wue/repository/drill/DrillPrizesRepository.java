package com.wue.repository.drill;

import com.wue.domain.drill.DrillPrizes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillPrizesRepository extends JpaRepository<DrillPrizes, String> {
    
    List<DrillPrizes> findByDrillId(String drillId);

    List<DrillPrizes> findByDrillIdOrderByPositionOrder(String drillId);
}
