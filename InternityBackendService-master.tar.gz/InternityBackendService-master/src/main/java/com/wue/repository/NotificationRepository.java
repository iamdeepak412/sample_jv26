package com.wue.repository;

import com.wue.domain.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface NotificationRepository extends JpaRepository<Notification, Long> {

   @Query("SELECT n from Notification n where n.receiverUid=?1 AND n.isRead=false")
   List<Notification> findByReceiverUidAndUnread(String receiverUid);

   List<Notification> findByReceiverUid(String receiverUid);

    List<Notification> findBynotificationType(String messageType);
}
