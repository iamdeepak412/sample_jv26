package com.wue.repository.drill;

import com.wue.domain.drill.DrillOverview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface DrillOverviewRepository extends JpaRepository<DrillOverview, String> {

}
