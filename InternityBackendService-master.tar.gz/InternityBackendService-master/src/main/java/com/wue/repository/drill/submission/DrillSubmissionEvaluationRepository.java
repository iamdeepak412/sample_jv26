package com.wue.repository.drill.submission;

import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.domain.drill.submission.DrillSubmissionEvaluation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface  DrillSubmissionEvaluationRepository extends JpaRepository<DrillSubmissionEvaluation, String> {
    List<DrillSubmissionEvaluation> findBydrillId(String drillId);

    Optional<DrillSubmissionEvaluation> findBySubmissionIdAndJudgeId(String submissionId, String judgeId);

    List<DrillSubmissionEvaluation> findBydrillIdAndPhaseId(String drillId, String phaseId);

    List<DrillSubmissionEvaluation> findBydrillIdAndPanelId(String drillId, String panelId);

    List<DrillSubmissionEvaluation> findBydrillIdAndPhaseIdAndPanelId(String drillId, String phaseId, String panelId);

    List<DrillSubmissionEvaluation> findBySubmissionId(String submissionId);


    DrillSubmissionEvaluation findByPhaseId(String phaseId);

    List<DrillSubmissionEvaluation> findAllByPhaseId(String phaseId);

    DrillSubmissionEvaluation findBySubmissionIdAndPhaseId(String submissionId, String phaseId);

    List<DrillSubmissionEvaluation> findDistinctSubmissionIdByDrillIdAndPhaseId(String drillId, String phaseId);

    List<DrillSubmissionEvaluation> findAllByDrillIdAndPhaseIdAndSubmissionId(String drillId, String phaseId, String submissionId);
}
