package com.wue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.UserWorkProfile;

@EnableJpaRepositories
public interface WorkProfileRepository extends JpaRepository<UserWorkProfile, Long>  {

	List<UserWorkProfile> findByuId(String uId);
	
	@Query("DELETE FROM UserWorkProfile p where p.expCount=:id AND p.uId=:uId")
	void deleteByIdAnduId(Long id, String uId);

}

