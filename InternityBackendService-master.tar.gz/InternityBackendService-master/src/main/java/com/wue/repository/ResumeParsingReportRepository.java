package com.wue.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.wue.domain.ResumeParsingReport;

public interface ResumeParsingReportRepository  extends JpaRepository<ResumeParsingReport, String> {

}