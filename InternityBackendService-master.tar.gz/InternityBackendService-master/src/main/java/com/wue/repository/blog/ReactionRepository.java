package com.wue.repository.blog;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.blog.Reaction;

@EnableJpaRepositories
public interface ReactionRepository extends JpaRepository<Reaction,String> {

	List<Reaction> findByuIdOrReactionIdOrPostId(String reactionId, String postId, String uId);
	Reaction findByReactionId(String reactionId);

	List<Reaction> findByPostId(String postId);

	List<Reaction> findByuId(String uId);

	Reaction findByuIdAndPostId(String uId, String postId);


}
