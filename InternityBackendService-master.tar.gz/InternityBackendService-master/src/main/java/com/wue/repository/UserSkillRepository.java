package com.wue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.UserSkill;

@EnableJpaRepositories
public interface UserSkillRepository extends JpaRepository<UserSkill, Long>  {

	List<UserSkill> findByuId(String uId);

	//@Query("DELETE FROM UserSkill p where p.userSkillId=:id AND p.uId=:uId")
	//Long deleteByUserSkillIdAndUId(@Param("user_skill_id") Long id, @Param("u_id") String uId);

}

