package com.wue.repository.certificategenerator;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wue.domain.certificategenerator.WebCheckin;

@Repository
public interface WebCheckinRepository extends JpaRepository< WebCheckin, String> {

	List<WebCheckin> findByEventId(String eventId);

	Optional<WebCheckin> findByParticipantId(String participantId);

}
