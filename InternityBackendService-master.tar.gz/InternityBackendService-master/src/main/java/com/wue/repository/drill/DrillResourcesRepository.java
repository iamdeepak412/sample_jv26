package com.wue.repository.drill;

import com.wue.domain.drill.DrillResources;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillResourcesRepository extends JpaRepository<DrillResources, String> {

    Optional<DrillResources> findByDrillId(String drillId);
}
