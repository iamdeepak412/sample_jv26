package com.wue.repository.drill.mails;

import com.wue.domain.drill.mails.DrillMailTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillMailTemplateRepository extends JpaRepository<DrillMailTemplate, String> {
    List<DrillMailTemplate> findByDrillId(String drillId);
}
