package com.wue.repository.CandidateApplication;

import com.wue.domain.CandidateApplication.JobApplicationScreeningAnswer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface JobApplicationScreeningAnswerRepository extends JpaRepository<JobApplicationScreeningAnswer, Long>  {

    Optional<JobApplicationScreeningAnswer> findByApplicationId(String applicationId);

    Page<JobApplicationScreeningAnswer> findByApplicationIdIn(List<Long> applicationIds, Pageable userPageable);

    List<JobApplicationScreeningAnswer> findByJobId(String jobId);

    Optional<JobApplicationScreeningAnswer> findByuIdAndJobId(String uId, String jobId);

	List<JobApplicationScreeningAnswer> findByJobIdIn(List<String> jobIds);
}

