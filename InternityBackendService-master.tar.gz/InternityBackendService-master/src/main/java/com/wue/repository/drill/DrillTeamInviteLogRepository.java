package com.wue.repository.drill;

import com.wue.domain.drill.DrillTeamInviteLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface DrillTeamInviteLogRepository extends JpaRepository<DrillTeamInviteLog, String> {
}
