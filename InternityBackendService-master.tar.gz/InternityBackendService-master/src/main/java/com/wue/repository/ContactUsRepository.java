package com.wue.repository;

import com.wue.domain.ContactUs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface ContactUsRepository extends JpaRepository<ContactUs, Long> {

    List<ContactUs> findAllByIsVisibleOrderByCreatedtsDesc(boolean isVisible);
}
