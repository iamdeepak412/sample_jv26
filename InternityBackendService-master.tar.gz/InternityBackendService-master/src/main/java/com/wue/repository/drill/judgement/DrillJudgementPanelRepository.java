package com.wue.repository.drill.judgement;

import com.wue.domain.drill.judgement.DrillJudgementPanel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillJudgementPanelRepository extends JpaRepository<DrillJudgementPanel, String> {
    List<DrillJudgementPanel> findByDrillId(String drillId);

    List<DrillJudgementPanel> findByDrillIdAndPhaseId(String drillId, String phaseId);
}
