package com.wue.repository.drill;

import com.wue.domain.drill.Drill;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface DrillRepository extends JpaRepository<Drill, String> {

    List<Drill> findByIsActiveTrue();

    Optional<Drill> findByDrillCustUrl(String custUrl);

    List<Drill> findByIsActiveTrueOrderByDrillStartDtAsc();

    List<Drill> findAllByOrderByDrillStartDtAsc();

	List<Drill> findByDrillPartnerIdAndDrillStartDtLessThan(String uId, LocalDateTime now);

	List<Drill> findByDrillPartnerIdAndIsActiveTrue(String uId);

    List<Drill> findByDrillPartnerIdAndDrillEndDtLessThan(String companyId, LocalDateTime now);

    List<Drill> findByDrillPartnerIdAndDrillEndDtGreaterThan(String companyId, LocalDateTime now);

    List<Drill> findByDrillEndDtLessThan(LocalDateTime now);

    List<Drill> findByDrillEndDtGreaterThan(LocalDateTime now);

	List<Drill> findByDrillId(String drillId);

	List<Drill> findByDrillPartnerId(String partnerId);

    List<Drill> findByIsActiveTrueOrderByCreatedTsAsc();

    List<Drill> findAllByOrderByCreatedTsAsc();

    List<Drill> findByDrillLatestStatusOrderByCreatedTsDesc(String name);

    List<Drill> findByDrillPartnerIdAndDrillLatestStatusOrderByCreatedTsDesc(String companyId, String name);


	@Query("SELECT d.drillId FROM Drill d WHERE d.drillId IN :drillIds AND d.isActive = false")
	 List<String> findInactiveElementIds(@Param("drillIds") List<String> drillIds);

	List<Drill> findByDrillIdInAndIsActive(List<String> drillIds, boolean b);

	Page<Drill> findAll(Specification<Drill> specification, Pageable pageable);


    int countByDrillName(String drillName);

    int countByDrillCustUrlStartingWith(String custUrl);

    Optional<Drill> findByDrillCustUrlStartingWith(String custUrl);
}
