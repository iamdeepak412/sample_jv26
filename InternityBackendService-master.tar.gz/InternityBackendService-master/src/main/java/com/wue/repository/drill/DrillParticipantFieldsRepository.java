package com.wue.repository.drill;

import com.wue.domain.drill.DrillParticipantFields;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DrillParticipantFieldsRepository extends JpaRepository<DrillParticipantFields, String> {
}
