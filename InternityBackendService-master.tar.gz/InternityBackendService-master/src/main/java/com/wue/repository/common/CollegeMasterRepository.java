package com.wue.repository.common;

import com.wue.domain.common.CollegeMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CollegeMasterRepository extends JpaRepository<CollegeMaster,Long> {

}