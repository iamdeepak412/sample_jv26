package com.wue.repository.drill.problemstatement;

import com.wue.domain.drill.problemstatement.DrillProblemstatement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillProblemStatementRepository extends JpaRepository<DrillProblemstatement, String> {

    Optional<DrillProblemstatement> findByDrillId(String drillId);
}
