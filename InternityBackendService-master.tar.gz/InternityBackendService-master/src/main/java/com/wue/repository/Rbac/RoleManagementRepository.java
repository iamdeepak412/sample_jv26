package com.wue.repository.Rbac;

import com.wue.domain.Rbac.RoleManagement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface RoleManagementRepository extends JpaRepository<RoleManagement, Long>  {

    List<RoleManagement> findAllByIsActive(boolean b);

    List<RoleManagement> findByRoleName(String roleName);
}

