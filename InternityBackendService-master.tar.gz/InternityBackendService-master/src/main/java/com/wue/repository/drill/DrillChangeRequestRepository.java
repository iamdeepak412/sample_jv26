package com.wue.repository.drill;

import com.wue.constant.drill.RequestStatus;
import com.wue.constant.drill.RequestType;
import com.wue.domain.drill.DrillChangeRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillChangeRequestRepository extends JpaRepository<DrillChangeRequest, String>, JpaSpecificationExecutor<DrillChangeRequest> {

    Optional<DrillChangeRequest> findByRequestedBy(String participantId);

    Optional<DrillChangeRequest> findByRequestedByAndRequestTypeAndEntityId(String participantId, RequestType newTeamMember,String teamId);

    Optional<DrillChangeRequest> findByRequestedByAndRequestTypeAndRequestStatus(String participantId, RequestType teamSize, RequestStatus pending);

    Optional<DrillChangeRequest> findByRequestedByAndRequestTypeAndEntityIdAndRequestStatus(String participantId, RequestType newTeamMember, String teamId, RequestStatus pending);
}
