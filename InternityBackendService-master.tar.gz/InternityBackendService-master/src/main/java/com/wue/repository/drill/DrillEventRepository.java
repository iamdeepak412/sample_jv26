package com.wue.repository.drill;

import com.wue.domain.drill.DrillEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillEventRepository extends JpaRepository<DrillEvent, Long> {
    List<DrillEvent> findByDrillId(String drillId);
}
