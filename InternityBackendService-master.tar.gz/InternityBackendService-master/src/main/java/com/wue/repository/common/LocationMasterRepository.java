package com.wue.repository.common;

import com.wue.domain.common.LocationMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LocationMasterRepository extends JpaRepository<LocationMaster, Long>{
	List<LocationMaster> findByCountryCode(String countryCode);

	@Query("SELECT distinct CONCAT(city, ',' , SPACE(1), state) from LocationMaster loc where loc.countryCode=?1")
	List<String> findByCountryCodeAndReturnUnique(String countryCode);
}
