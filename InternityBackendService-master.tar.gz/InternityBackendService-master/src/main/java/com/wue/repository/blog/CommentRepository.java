package com.wue.repository.blog;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.blog.Comment;

@EnableJpaRepositories
public interface CommentRepository extends JpaRepository<Comment,String> {

	List<Comment> findByuIdOrCommentIdOrBlogpostId(String commentId, String blogpostId, String uId);

	List<Comment> findByuIdOrBlogpostId(String uId, String blogpostId);

	List<Comment> findByuId(String uId);

	List<Comment> findByParentCommentId(String parentCommentId);

	List<Comment> findByCommentId(String commentId);

	List<Comment> findByBlogpostId(String blogpostId);

	List<Comment> findByuIdAndBlogpostId(String uId, String blogpostId);

	List<Comment> findByBlogpostIdAndParentCommentId(String blogpostId, String na);

	List<Comment> findByuIdAndBlogpostIdAndParentCommentId(String uId, String blogpostId, String parentCommentId);

	long countByParentCommentId(String commentId);


}
