package com.wue.repository.drill;

import com.wue.domain.drill.DrillNewFaq;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillNewFaqRepository extends JpaRepository<DrillNewFaq, String> {

    List<DrillNewFaq> findByDrillId(String drillId);
}
