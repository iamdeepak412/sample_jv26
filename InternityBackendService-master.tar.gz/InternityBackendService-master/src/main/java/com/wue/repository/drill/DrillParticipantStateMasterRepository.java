package com.wue.repository.drill;

import com.wue.domain.drill.DrillParticipantStateMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillParticipantStateMasterRepository extends JpaRepository<DrillParticipantStateMaster, String> {

    @Query("SELECT participantState from DrillParticipantStateMaster")
    List<String> findAllStates();
}
