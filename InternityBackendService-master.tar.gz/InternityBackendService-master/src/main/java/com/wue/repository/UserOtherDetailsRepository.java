package com.wue.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.UserOtherDetails;

@EnableJpaRepositories
public interface UserOtherDetailsRepository extends JpaRepository<UserOtherDetails, Long>  {

	Optional<UserOtherDetails> findByuId(String uId);
}

