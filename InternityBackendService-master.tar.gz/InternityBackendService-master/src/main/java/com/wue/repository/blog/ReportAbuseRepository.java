package com.wue.repository.blog;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.blog.ReportAbuse;

@EnableJpaRepositories
public interface ReportAbuseRepository extends JpaRepository<ReportAbuse,String>, JpaSpecificationExecutor<ReportAbuse> {

	List<ReportAbuse> findByReportIdOrPostId(String reportId, String postId);

}

