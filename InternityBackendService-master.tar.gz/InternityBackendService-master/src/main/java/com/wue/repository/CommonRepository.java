package com.wue.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wue.domain.Common;

@Repository
public interface CommonRepository extends JpaRepository<Common, Long>{
	Optional<Common> findByTitle(String title);
}
