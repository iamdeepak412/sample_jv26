package com.wue.repository;

import com.wue.domain.PageView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PageviewRepository extends JpaRepository<PageView, Long>{
    @Query("SELECT COUNT(*) FROM PageView pv where cast(pv.createdTs as LocalDate)>=?2" +
            " AND cast(pv.createdTs as LocalDate)<=?1")
    Long fetchCountOfSiteViewsAddedInBetweenDays(LocalDate now, LocalDate minusDays);

    @Query("SELECT COUNT(*) FROM PageView pv where cast(pv.createdTs as LocalDate)>=?2" +
            " AND cast(pv.createdTs as LocalDate)<=?1 AND page_name IN (?3)")
    Long fetchCountOfSpecificPageViewsAddedInBetweenDays(LocalDate now, LocalDate minusDays, List<String> hackathon_page);

	List<PageView> findByEntityId(String drillId);

    @Query("SELECT COUNT(*) FROM PageView pv where entity_id IN (?1)")
    Long findCountByEntityIdIn(List<String> listOfDrillId);

    @Query("SELECT COUNT(*) FROM PageView pv where page_name = ?1")
    Long findCountByPageName(String pageName);

    @Query("SELECT COUNT(*) FROM PageView pv where page_name = ?1 and u_id=?2")
    Long findCountByPageNameAndUId(String pageName, String uId);

    @Query("SELECT COUNT(*) FROM PageView pv where page_name = ?1 and entity_id=?2")
    Long findCountByPageNameAndEntityId(String pageName, String entityId);

    @Query("SELECT COUNT(*) FROM PageView pv where page_name = ?1 and entity_id IN (?2)")
    Long findCountByPageNameAndEntityIdIn(String pageName, List<String> entityId);

    @Query("SELECT COUNT(*) FROM PageView pv where entity_id = (?1)")
    Long findCountByEntityId(String entityId);

}
