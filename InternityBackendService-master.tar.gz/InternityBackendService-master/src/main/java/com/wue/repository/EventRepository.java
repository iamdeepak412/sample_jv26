package com.wue.repository;

import com.wue.domain.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface EventRepository extends JpaRepository<Event, Integer>  {
    List<Event> findByType(String type);
}
