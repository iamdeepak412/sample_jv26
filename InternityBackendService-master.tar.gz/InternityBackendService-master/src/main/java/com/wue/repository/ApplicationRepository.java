package com.wue.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.Application;

@EnableJpaRepositories
public interface ApplicationRepository extends JpaRepository<Application, Long>,JpaSpecificationExecutor<Application>{

	List<Application> findByJobId(String jobId);
	List<Application> findByuId(String uId);
    Optional<Application> findByuIdAndJobId(String uId, String jobId);

	@Query("Select jobId from Application where uId=?1")
	List<String> findJobListByuId(String uId);

    List<Application> findByuIdOrderByUpdatedtsDesc(String uId);
	List<Application> findByJobIdOrderByUpdatedtsDesc(String jobId);

    List<Application> findByuIdAndCurrentStatusOrderByUpdatedtsDesc(String uId, String applicationStatus);

	Collection<? extends Application> findByJobIdAndCurrentStatusOrderByUpdatedtsDesc(String jobId, String applicationStatus);
	List<Application> findByJobIdIn(List<String> jobIds);

	@Query("SELECT a FROM Application a WHERE a.jobId = :jobId AND a.uId = :uId")
	Application findByJobIdAndUId(String jobId, String uId);
}
