package com.wue.repository;

import com.wue.domain.JobView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.time.LocalDate;
import java.util.List;

@EnableJpaRepositories
public interface JobViewRepository extends JpaRepository<JobView, Long> {

    List<JobView> findByuIdAndJobId(String uId, String jobId);

    List<JobView> findByjobId(String jobId);

    @Query("SELECT COUNT(*) FROM JobView jv where cast(jv.createdTs as LocalDate)>=?2" +
            " AND cast(jv.createdTs as LocalDate)<=?1")
    Long fetchCountOfJobViewsAddedInBetweenDays(LocalDate now, LocalDate minusDays);
}
