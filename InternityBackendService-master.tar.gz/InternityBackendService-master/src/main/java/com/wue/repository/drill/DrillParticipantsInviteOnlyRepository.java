package com.wue.repository.drill;


import com.wue.domain.drill.DrillParticipantsInviteOnly;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Set;

@EnableJpaRepositories
public interface DrillParticipantsInviteOnlyRepository extends JpaRepository<DrillParticipantsInviteOnly, String>, JpaSpecificationExecutor<DrillParticipantsInviteOnly> {
    DrillParticipantsInviteOnly findByDrillIdAndParticipantEmail(String drillId, String email);

    List<DrillParticipantsInviteOnly> findAllByDrillIdAndParticipantEmailIn(String drillId, Set<String> participantEmails);
}
