package com.wue.repository.drill.participant;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.drill.participant.ConfigureParticipantFields;

@EnableJpaRepositories
public interface ConfigureParticipantFieldsRepository extends JpaRepository<ConfigureParticipantFields, Long> {

	List<ConfigureParticipantFields> findByDrillId(String drillId);

}
