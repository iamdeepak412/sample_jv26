package com.wue.repository;

import com.wue.domain.UserCandidateMandatoryFieldsHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface UserCandidateMandatoryFieldsHistoryRepository
        extends JpaRepository<UserCandidateMandatoryFieldsHistory, Long>,JpaSpecificationExecutor<UserCandidateMandatoryFieldsHistory>    {

    Optional<UserCandidateMandatoryFieldsHistory> findByuId(String uId);


    Optional<UserCandidateMandatoryFieldsHistory> findTop1ByuIdOrderByUserCreatedtsDesc(String uId);
}
