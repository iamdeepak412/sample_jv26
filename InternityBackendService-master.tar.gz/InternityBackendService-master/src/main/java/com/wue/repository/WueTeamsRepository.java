package com.wue.repository;
import com.wue.domain.WueTeam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface WueTeamsRepository extends JpaRepository<WueTeam, String>{

}
