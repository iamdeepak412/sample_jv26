package com.wue.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.CareerPath;

@EnableJpaRepositories
public interface CareerPathRepository extends JpaRepository<CareerPath, Long>  {

}

