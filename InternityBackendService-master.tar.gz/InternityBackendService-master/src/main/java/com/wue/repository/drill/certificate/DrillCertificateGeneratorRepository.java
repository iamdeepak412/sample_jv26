package com.wue.repository.drill.certificate;

import com.wue.constant.drill.certificate.DrillCertificateType;
import com.wue.domain.drill.certificate.DrillCertificateGenerator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface DrillCertificateGeneratorRepository extends JpaRepository<DrillCertificateGenerator,String> {

    DrillCertificateGenerator findByCertificateId(String certificateId);

    DrillCertificateGenerator findByEventIdAndParticipantPlatformUIdAndCertificateTypeAndEventPhaseId(String drillId, String participantPlatformUId, DrillCertificateType certificateType, String phaseId);
}
