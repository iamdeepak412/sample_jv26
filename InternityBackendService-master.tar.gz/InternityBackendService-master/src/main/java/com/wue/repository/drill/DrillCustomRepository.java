package com.wue.repository.drill;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.drill.DrillCustom;

@EnableJpaRepositories
public interface DrillCustomRepository extends JpaRepository<DrillCustom,String> {

	List<DrillCustom> findByDrillId(String drillId);
	
}
