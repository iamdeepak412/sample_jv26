package com.wue.repository.common;

import com.wue.domain.common.CompanyMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyMasterRepository extends JpaRepository<CompanyMaster,Long> {
}