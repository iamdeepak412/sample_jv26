package com.wue.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.wue.domain.TestimonialPost;

import java.util.List;

@EnableJpaRepositories
public interface TestimonialPostRepository extends JpaRepository<TestimonialPost, Long> {

    List<TestimonialPost> findByTestimonialCategory(String category);

    List<TestimonialPost> findByService(String service);

    List<TestimonialPost> findByTestimonialCategoryAndService(String category, String service);

    List<TestimonialPost> findByTestimonialCategoryAndIsActiveOrderByPositionOrderDesc(String category, boolean isActive);

    List<TestimonialPost> findByServiceAndIsActiveOrderByPositionOrderDesc(String service, boolean isActive);

    List<TestimonialPost> findByTestimonialCategoryAndServiceAndIsActiveOrderByPositionOrderDesc(String category, String service, boolean isActive);

    List<TestimonialPost> findAllByIsActiveOrderByPositionOrderDesc(boolean isActive);
}
