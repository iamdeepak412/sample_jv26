package com.wue.repository.Rbac;

import com.wue.domain.Rbac.PlatformEntityType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface PlatformEntityTypeRepository extends JpaRepository<PlatformEntityType, Long>  {

    List<PlatformEntityType> findAllByIsActive(boolean b);
}

