package com.wue.repository;

import com.wue.domain.Application;
import com.wue.domain.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Transactional
@EnableJpaRepositories
public interface JobsRepository extends JpaRepository<Job, String>, JpaSpecificationExecutor<Job> {
	  
	@Query("SELECT j FROM Job j WHERE j.jobTitle = ?1")
	List<Job> findByFilterQuery(String query);

	@Query("SELECT j.jobTitle FROM Job j where j.isActive=1")
	Set<String> findAllDistinctJobTitle();
	
	@Query("SELECT j.jobLocation FROM Job j where j.isActive=1")
	Set<String> findAllDistinctJobLocation();
	
	@Query("SELECT j.jobType FROM Job j where j.isActive=1")
	Set<String> findAllDistinctJobType();

	@Query("SELECT COUNT(jobId) FROM Job j where j.isActive=1")
    Long countActiveJobs();

	@Query("SELECT COUNT(*) FROM Job j where j.isActive=1 AND cast(j.updatedTs as LocalDate)>=?2" +
			" AND cast(j.updatedTs as LocalDate)<=?1")
    Long fetchCountOfJobsAddedInBetweenDays(LocalDate now, LocalDate minusDays);

    Optional<Job> findByCustUrl(String custUrl);
	
	 @Query("SELECT j.jobId FROM Job j WHERE j.jobId IN :elementIds AND j.isActive = false")
	 List<String> findInactiveElementIds(@Param("elementIds") List<String> elementIds);

	List<Job> findByJobIdInAndIsActive(List<String> elementIds, boolean b);

	List<Job> findByJobIdIn(List<String> elementIds);

	List<Job> findByPartnerId(String partnerId);

	List<Application> getApplicationsByJobId(String jobId);

    List<Job> findFirst3ByOrderByCreatedTsDesc();

    int countByJobTitle(String jobTitle);

	int countByCustUrlStartingWith(String custUrl);
}
