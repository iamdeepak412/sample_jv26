package com.wue.repository;

import com.wue.domain.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@EnableJpaRepositories
public interface UserRepository extends JpaRepository<User, String>,JpaSpecificationExecutor<User>    {

    @Query("SELECT u from User u where u.username=?1 and u.isActive=1")
    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String uEmail);
    Optional<User> findByuContact(String uEmail);
    
    @Query("SELECT u from User u where u.username=?1 and u.isActive=1")
    String findByUserName(String username);


    List<User> findByuIdNotIn(List<String> uidsFromDrill);


    @Query("SELECT COUNT(username) FROM User u where cast(u.userCreatedts as LocalDate)>=?2" +
            " AND cast(u.userCreatedts as LocalDate)<=?1")
    Long fetchCountOfUsersAddedInBetweenDays(LocalDate start_dt, LocalDate end_dt);

    @Query("SELECT COUNT(username) FROM User u where u.isActive=1 AND cast(u.userCreatedts as LocalDate)>=?2" +
            " AND cast(u.userCreatedts as LocalDate)<=?1")
    Long fetchCountOfActiveUsersAddedInBetweenDays(LocalDate start_dt, LocalDate end_dt);

    @Query("SELECT COUNT(username) FROM User u where u.isActive!=1 AND cast(u.userCreatedts as LocalDate)>=?2" +
            " AND cast(u.userCreatedts as LocalDate)<=?1")
    Long fetchCountOfInactiveUsersAddedInBetweenDays(LocalDate start_dt, LocalDate end_dt);

    @Query("SELECT COUNT(username) FROM User u where u.isActive=1")
    Long fetchCountOfActiveUsers();

    @Query("SELECT COUNT(username) FROM User u where u.isActive!=1")
    Long fetchCountOfInactiveUsers();

    Page<User> findByuIdIn(List<String> filteredApplicationUIds, Pageable userPageable);

	String findEmailByuId(String uId);

    List<User> findEmailByuIdIn(Set<String> uIds);

    List<User> findByuIdIn(List<String> uIdList);

    List<User> findAllByEmailIn(List<String> winnersList);

    @Query("SELECT u FROM User u WHERE u.uRole = :role")
    List<User> findByURole(String role);
}
