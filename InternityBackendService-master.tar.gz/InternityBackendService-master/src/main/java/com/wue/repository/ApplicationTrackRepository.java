package com.wue.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.ApplicationTrack;

@EnableJpaRepositories
public interface ApplicationTrackRepository extends JpaSpecificationExecutor<ApplicationTrack>, JpaRepository<ApplicationTrack, Long> {

	List<ApplicationTrack> findByApplicationId(Long applicationId);

	List<ApplicationTrack> findByApplicationIdOrderByUpdatedtsAsc(Long applicationId);
	List<ApplicationTrack> findByApplicationIdOrderByUpdatedtsDesc(Long applicationId);

    Optional<ApplicationTrack> findByApplicationIdAndStatus(Long applicationId, String status);

	List<ApplicationTrack> findTop1ByApplicationIdOrderByUpdatedtsDesc(Long applicationId);
}
