package com.wue.repository;

import com.wue.domain.CaseStudy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface CaseStudyRepository extends JpaRepository<CaseStudy, Long> {

	List<CaseStudy> findByTypeAndIsActiveTrue(String type);

	List<CaseStudy> findByIsActiveTrue();

    Optional<CaseStudy> findByCustUrl(String custUrl);
}
