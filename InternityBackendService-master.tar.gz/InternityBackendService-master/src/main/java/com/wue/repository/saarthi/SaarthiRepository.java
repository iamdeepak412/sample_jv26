package com.wue.repository.saarthi;

import com.wue.domain.saarthi.Saarthi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface SaarthiRepository extends JpaRepository<Saarthi, String>, JpaSpecificationExecutor<Saarthi> {

    Optional<Saarthi> findByEmailId(String emailId);

    Optional<Saarthi> findByContactNo(String contactNo);
}
