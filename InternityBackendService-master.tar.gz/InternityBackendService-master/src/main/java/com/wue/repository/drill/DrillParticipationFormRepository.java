package com.wue.repository.drill;

import com.wue.domain.drill.DrillParticipationForm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillParticipationFormRepository extends JpaRepository<DrillParticipationForm, String> {

    Optional<DrillParticipationForm> findByDrillId(String drillId);
}
