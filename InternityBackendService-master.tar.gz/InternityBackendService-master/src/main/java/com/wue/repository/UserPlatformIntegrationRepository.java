package com.wue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.wue.domain.UserPlatformIntegration;

@EnableJpaRepositories
public interface UserPlatformIntegrationRepository extends JpaRepository<UserPlatformIntegration, Long> {

	List<UserPlatformIntegration> findByuId(String uId);

}
