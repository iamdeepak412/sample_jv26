package com.wue.repository.blog;

import com.wue.domain.blog.CommentReaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface CommentReactionRepository extends JpaRepository<CommentReaction, String> {
    List<CommentReaction> findByPostId(String blogPostId);

    List<CommentReaction> findByuId(String uId);

    List<CommentReaction> findByCommentId(String commentId);

    List<CommentReaction> findAllByuIdAndCommentId(String uId, String commentId);

    List<CommentReaction> findByuIdAndPostId(String uId, String blogPostId);

    CommentReaction findByuIdAndCommentId(String uId, String commentId);
}


