package com.wue.repository.drill.submission;

import com.wue.domain.drill.submission.ConfigureSubmissionFields;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillConfigureSubmissionFieldsRepository extends JpaRepository<ConfigureSubmissionFields, String> {
    Optional<ConfigureSubmissionFields> findByDrillId(String drillId);

    Optional<ConfigureSubmissionFields> findByDrillIdAndPhaseId(String drillId, String phaseId);
}
