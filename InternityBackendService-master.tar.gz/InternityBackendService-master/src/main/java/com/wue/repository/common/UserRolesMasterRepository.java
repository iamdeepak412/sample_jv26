package com.wue.repository.common;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wue.domain.common.UserRolesMaster;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserRolesMasterRepository extends JpaRepository<UserRolesMaster, Long> {

    @Query("SELECT DISTINCT role from UserRolesMaster")
    List<String> findListOfRoles();
}
