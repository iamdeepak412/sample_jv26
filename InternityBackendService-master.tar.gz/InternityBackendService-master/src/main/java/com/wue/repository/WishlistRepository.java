package com.wue.repository;

import com.wue.constant.job.PlatformEntityCategory;
import com.wue.domain.Wishlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface WishlistRepository extends JpaRepository<Wishlist, Long>  {

	List<Wishlist> findByuId(String uId);

    List<Wishlist> findByuIdAndEntityName(String uId, PlatformEntityCategory entityName);

    List<Wishlist> findByEntityName(PlatformEntityCategory entityName);
}

