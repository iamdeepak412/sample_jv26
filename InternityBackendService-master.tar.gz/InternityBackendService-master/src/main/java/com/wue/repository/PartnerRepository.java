package com.wue.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.Partner;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface PartnerRepository extends JpaRepository<Partner, String> {

    Optional<Partner> findByPartnerName(String partnerName);

    List<Partner> findAllByOrderByCreatedTsDesc();

    List<Partner> findByIsActiveOrderByCreatedTsDesc(boolean active);

    Partner findFirstByOrderByCreatedTsDesc();
}
