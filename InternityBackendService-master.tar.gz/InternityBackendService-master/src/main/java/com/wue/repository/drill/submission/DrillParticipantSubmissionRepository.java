package com.wue.repository.drill.submission;

import com.wue.domain.drill.submission.DrillParticipantSubmission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface DrillParticipantSubmissionRepository extends JpaRepository<DrillParticipantSubmission, String>, JpaSpecificationExecutor<DrillParticipantSubmission> {
    List<DrillParticipantSubmission> findByDrillId(String drillId);

    Optional<DrillParticipantSubmission> findFirstByDrillIdAndTeamIdOrderByUpdatedTsDesc(String drillId, String teamId);

    List<DrillParticipantSubmission> findByDrillIdAndTheme(String drillId, String themeId);

    Optional<DrillParticipantSubmission> findFirstByDrillIdAndTeamIdAndThemeOrderByUpdatedTsDesc(String drillId, String teamId, String themeId);

    Optional<DrillParticipantSubmission> findFirstByDrillIdAndParticipantIdOrderByUpdatedTsDesc(String drillId, String participantId);
    @Query("SELECT DISTINCT e.teamId FROM DrillParticipantSubmission e WHERE e.teamId  IS NOT NULL")
	List<String> submissionfindBydrillId(String drillId);
    
    Optional<DrillParticipantSubmission> findTop1ByDrillIdAndTeamIdOrderByUpdatedTsDesc(String drillId, String teamId);

    List<DrillParticipantSubmission> findByDrillIdAndTeamId(String drillId, String teamId);

    @Query("SELECT DISTINCT e.teamId FROM DrillParticipantSubmission e WHERE e.drillId=?1 and e.panelId=?2")
    List<String> findBydrillIdAndPanelId(String drillId, String panelId);

    List<DrillParticipantSubmission> findByDrillIdAndParticipantIdOrderByUpdatedTsDesc(String drillId, String participantId);

    List<DrillParticipantSubmission> findBySubmissionIdIn(List<String> submissionIdList);

    List<DrillParticipantSubmission> findByDrillIdAndIsActiveSubmission(String drillId, boolean b);

    List<DrillParticipantSubmission> findByParticipantIdAndPhaseId(String participantId, String phaseId);

    List<DrillParticipantSubmission> findByDrillIdAndParticipantIdAndPhaseIdOrderByUpdatedTsDesc(String drillId, String participantId, String phaseId);

    List<DrillParticipantSubmission> findByDrillIdAndTeamIdAndPhaseId(String drillId, String teamId, String phaseId);

    Optional<DrillParticipantSubmission> findFirstByDrillIdAndParticipantIdAndIsActiveSubmissionOrderByCreatedTsDesc(
            String drillId, String participantId, boolean isActiveSubmission);

    Optional<DrillParticipantSubmission> findByDrillIdAndPhaseIdAndParticipantIdAndIsActiveSubmission(String drillId,
			String phaseId, String participantId, boolean isActiveSubmission);

    Optional<DrillParticipantSubmission> findTop1ByDrillIdAndTeamIdAndPhaseIdOrderByUpdatedTsDesc(String drillId, String teamId, String phaseId);

    DrillParticipantSubmission findTopByParticipantIdAndDrillIdAndIsActiveSubmissionOrderByUpdatedTsDesc(String participantId, String drillId, boolean b);


    List<DrillParticipantSubmission> findAllByPhaseId(String phaseId);

    List<DrillParticipantSubmission> findAllByPhaseIdAndIsActiveSubmission(String phaseId, boolean b);


    List<DrillParticipantSubmission> findDistinctTeamIdBySubmissionIdIn(List<String> submissionIds);

    List<DrillParticipantSubmission> findAllByDrillIdAndPhaseIdAndIsActiveSubmissionTrue(String drillId, String phaseId);

    DrillParticipantSubmission findByTeamIdAndPhaseIdAndIsActiveSubmission(String teamId, String phaseId, boolean b);

    DrillParticipantSubmission findByParticipantIdAndPhaseIdAndIsActiveSubmission(String participantId, String phaseId, boolean b);
}
