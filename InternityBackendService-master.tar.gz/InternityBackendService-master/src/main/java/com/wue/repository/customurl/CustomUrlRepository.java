package com.wue.repository.customurl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import com.wue.domain.customurl.CustomUrl;

@Repository
public interface CustomUrlRepository extends JpaRepository<CustomUrl, Long> {

	Optional<CustomUrl> findByShortUrl(String shortUrl);

	boolean existsByEntityId(String entityId);

	Optional<CustomUrl> findByOriginalUrl(String originalUrl);

	Optional<CustomUrl> findByEntityId(String entityId);
}
