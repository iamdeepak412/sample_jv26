package com.wue.repository.drill.participant;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.drill.participant.DefaultParticipantFields;

@EnableJpaRepositories
public interface DefaultParticipantFieldsRepository extends JpaRepository<DefaultParticipantFields, Long> {

}
