package com.wue.repository.drill.judgement;

import com.wue.domain.drill.judgement.DrillJudgePanelLookup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface DrillJudgePanelLookupRepository extends JpaRepository<DrillJudgePanelLookup, Long> {
    List<DrillJudgePanelLookup> findByPanelId(String panelId);

    Optional<DrillJudgePanelLookup> findByJudgeId(String judgeId);
}
