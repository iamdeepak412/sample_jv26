package com.wue.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wue.domain.BotMessages;

public interface BotMessagesRepository extends JpaRepository<BotMessages,Long> {

	List<BotMessages> findByRecordCreatedTsBetween(LocalDateTime startDt, LocalDateTime endDt);

	List<BotMessages> findByPlatformAndRecordCreatedTsBetween(String platform, LocalDateTime startDt,
			LocalDateTime endDt);

	List<BotMessages> findByPlatform(String platform);

    Optional<BotMessagesRepository> findByPlatformAndEntityId(String platform, String wue);
}
