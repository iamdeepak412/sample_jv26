package com.wue.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.EducationInformation;

@EnableJpaRepositories
public interface EducationInformationRepository extends JpaRepository<EducationInformation, Long> {

	List<EducationInformation> findByuId(String uId);

	@Query("SELECT distinct instituteName from EducationInformation")
	Set<String> findAllInstituteName();
	
	@Query("DELETE FROM EducationInformation p where p.eduInfoCount=:id AND p.uId=:uId")
	void deleteByIdAnduId(Long id, String uId);

}
