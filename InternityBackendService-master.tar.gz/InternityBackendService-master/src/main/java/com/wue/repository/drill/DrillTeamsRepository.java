package com.wue.repository.drill;

import com.wue.domain.drill.DrillTeams;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface DrillTeamsRepository extends JpaRepository<DrillTeams, String>, JpaSpecificationExecutor<DrillTeams> {

    Optional<DrillTeams> findByDrillIdAndTeamName(String drillId, String teamName);

    Optional<DrillTeams> findByTeamIdAndTeamLeadParticipantId(String teamId, String leadParticipantId);

    List<DrillTeams> findByDrillId(String drillId);

    List<DrillTeams> findByDrillIdAndTeamNameStartsWith(String drillId, String initialLetters);

    Optional<DrillTeams> findByDrillIdAndTeamId(String drillId, String teamId);

	Optional<DrillTeams> findByTeamNameIgnoreCaseAndDrillId(String teamName, String drillId);


    Optional<DrillTeams> findByDrillIdAndTeamInviteCode(String drillId, String code);
    

    Optional<DrillTeams> findByTeamIdAndTeamInviteCode(String teamId, String inviteCode);


    List<DrillTeams> findByTeamIdAndDrillId(String teamId, String drillId);

    Optional<DrillTeams> findByDrillIdAndTeamLeadParticipantId(String drillId, String participantId);
}
