package com.wue.repository.drill;

import com.wue.constant.drill.Stage;
import com.wue.domain.drill.TeamsParticipants;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface TeamsParticipantsRepository extends JpaRepository<TeamsParticipants, Long> , JpaSpecificationExecutor<TeamsParticipants> {

    Optional<TeamsParticipants> findByTeamIdAndParticipantId(String teamId, String participantId);

    List<TeamsParticipants> findByParticipantIdAndTeamIdInAndIsRequestAccepted
            (String participantId, List<String> teamIds, boolean isRequestAccepted);

    List<TeamsParticipants> findByTeamIdAndIsRequestAccepted
            (String teamId, boolean isRequestAccepted);

    List<TeamsParticipants> findByParticipantId(String participantId);

    Optional<TeamsParticipants> findByParticipantIdAndDrillIdAndIsRequestAccepted(String participantId, String drillId, boolean b);

    Optional<TeamsParticipants> findByParticipantIdAndIsRequestAccepted(String participantId, boolean b);

    List<TeamsParticipants> findByDrillIdAndIsRequestAccepted(String drillId, boolean b);

    List<TeamsParticipants> findByDrillIdAndTeamId(String drillId, String teamId);

    List<TeamsParticipants> findByTeamId(String teamId);

    List<TeamsParticipants> findByDrillIdAndParticipantIdAndIsRequestAccepted(String drillId, String participantId, boolean b);

    List<TeamsParticipants> findByDrillIdAndTeamIdAndIsRequestAccepted(String drillId, String teamId, boolean b);

    List<TeamsParticipants> findByDrillIdAndTeamIdAndStageAndIsRequestAccepted(String drillId, String teamId, Stage name, boolean b);

    List<TeamsParticipants> findByParticipantIdAndDrillId(String participantId, String drillId);


    List<TeamsParticipants> findAllByTeamIdIn(List<String> teamIds);

    TeamsParticipants findByDrillIdAndParticipantId(String drillId, String participantId);
}
