package com.wue.repository.common;

import com.wue.domain.common.JobMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobMasterRepository extends JpaRepository<JobMaster,Long> {
}