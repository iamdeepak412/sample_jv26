package com.wue.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wue.domain.SkillsLookup;

public interface SkillsLookupRepository extends JpaRepository<SkillsLookup, Long>{

	List<SkillsLookup> findBySkillNameStartsWith(String initialLetters);

    Optional<SkillsLookup> findBySkillName(String skillName);
}
