package com.wue.repository.blog;

import java.util.List;
import java.util.Optional;

import com.wue.domain.drill.DrillTeams;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.blog.BlogPost;

@EnableJpaRepositories
public interface BlogPostRepository extends JpaRepository<BlogPost,String>, JpaSpecificationExecutor<BlogPost> {

	List<BlogPost> findByuIdOrCategoryId(String uId, String categoryId);

	Optional<BlogPost> findByCustUrl(String custUrl);
	int countByCustUrlStartingWith(String custUrl);



}
