package com.wue.repository.drill;

import com.wue.domain.drill.DrillCollaborators;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface DrillCollaboratorsRepository extends JpaRepository<DrillCollaborators, String> {

    List<DrillCollaborators> findByDrillId(String drillId);

    List<DrillCollaborators> findByDrillIdOrderByPositionOrder(String drillId);

    List<DrillCollaborators> findByDrillIdAndCollaboratorTypeOrderByPositionOrder(String drillId, String type);

    Optional<DrillCollaborators> findByCollaboratorTypeAndCollaboratorIdAndKey(String type, String judgeId,
                                                                               String key);

    Optional<DrillCollaborators> findByDrillIdAndCollaboratorName(String drillId, String judgeName);
}
