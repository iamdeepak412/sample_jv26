package com.wue.repository.subscription;

import com.wue.domain.subscription.Subscription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface SubscriptionRepository extends JpaRepository<Subscription, String> {
    Optional<Subscription> findByuIdAndComponentAndComponentIdAndIsActiveTrue(String uId, String component, String componentId);
}
