package com.wue.repository.drill.certificate;

import com.wue.domain.drill.certificate.DrillCertificateGeneratorTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillCertificateGeneratorTemplateRepository extends JpaRepository<DrillCertificateGeneratorTemplate,String> {

    List<DrillCertificateGeneratorTemplate> findByEventId(String drillId);
}
