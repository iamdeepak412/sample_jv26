package com.wue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.wue.domain.PlatformStats;

@EnableJpaRepositories
public interface PlatformStatsRepository extends JpaRepository<PlatformStats, Long> {

	PlatformStats findFirstByOrderByStatsIdDesc();

	@Query(value = "SELECT * FROM platform_stats e where DATE(e.record_insertedts) > DATE_SUB(CURDATE(), INTERVAL ?1 DAY)", nativeQuery = true)
	List<PlatformStats> findStatsAsPerDates(int numberOfDays);

	List<PlatformStats> findFirst7ByOrderByRecordInsertedtsDesc();
}
