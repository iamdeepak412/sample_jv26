package com.wue.repository.drill.publish;

import com.wue.domain.drill.publish.DrillPublishRequests;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillPublishRequestsRepository extends JpaRepository<DrillPublishRequests, String> {

    Optional<DrillPublishRequests> findByDrillId(String drillId);
}
