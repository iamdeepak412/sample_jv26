package com.wue.repository.drill.judgement;

import com.wue.domain.drill.judgement.DrillAssignPanel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillAssignJudgePanelRepository extends JpaRepository<DrillAssignPanel, Long> {

    Optional<DrillAssignPanel> findByPanelId(String panelId);

    Optional<DrillAssignPanel> findByJudgeidListContaining(String judgeId);

}
