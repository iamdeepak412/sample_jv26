package com.wue.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.wue.domain.ApplicationTrack;
import com.wue.domain.OrganisationAndAcademicInstitute;

@EnableJpaRepositories
public interface OrganisationAndAcademicRepository extends JpaSpecificationExecutor<ApplicationTrack>, JpaRepository<OrganisationAndAcademicInstitute, Long> {

	List<OrganisationAndAcademicInstitute> findByTypeAndIsActive(String string, boolean isActive);
	
	 @Query(value = "SELECT MAX(oai.positionOrder) FROM OrganisationAndAcademicInstitute oai WHERE oai.type = 'organisation'")
	  Integer getLastPositionOrderOfTypeOrganisation();

	Optional<OrganisationAndAcademicInstitute> findByName(String partnerName);

}
