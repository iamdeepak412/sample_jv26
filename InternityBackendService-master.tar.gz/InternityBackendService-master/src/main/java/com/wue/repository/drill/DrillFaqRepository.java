package com.wue.repository.drill;

import com.wue.domain.drill.DrillFaq;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.Optional;

@EnableJpaRepositories
public interface DrillFaqRepository extends JpaRepository<DrillFaq, String> {

    Optional<DrillFaq> findByDrillId(String drillId);
}
