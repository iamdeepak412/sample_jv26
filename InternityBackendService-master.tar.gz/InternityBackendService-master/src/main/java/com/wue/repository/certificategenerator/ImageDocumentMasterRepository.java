package com.wue.repository.certificategenerator;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wue.domain.certificategenerator.ImageDocumentMaster;

@Repository
public interface ImageDocumentMasterRepository extends JpaRepository< ImageDocumentMaster, Long> {

	Optional<ImageDocumentMaster> findByEventId(String eventId);

}
