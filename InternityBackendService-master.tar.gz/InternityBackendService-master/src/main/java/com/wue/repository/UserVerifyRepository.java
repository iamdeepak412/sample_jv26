package com.wue.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wue.domain.UserVerify;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;

@EnableJpaRepositories
public interface UserVerifyRepository extends JpaRepository<UserVerify, Long>{

	Optional<UserVerify> findByUserEmailAndOtp(String string, String string2);

    @Transactional
    void deleteAllByUserEmailAndType(@Param("userEmail") String userEmail, @Param("type") String type);
}
