package com.wue.repository;

import com.wue.constant.UserProfileOtherDetailsType;
import com.wue.domain.UserProfileOtherDetailsv2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface UserProfileOtherDetailsRepository extends JpaRepository<UserProfileOtherDetailsv2, Long>  {

	List<UserProfileOtherDetailsv2> findByuIdAndOtherDetailsType(String uId, UserProfileOtherDetailsType otherDetailsType);
	List<UserProfileOtherDetailsv2> findByuId(String uId);

}

