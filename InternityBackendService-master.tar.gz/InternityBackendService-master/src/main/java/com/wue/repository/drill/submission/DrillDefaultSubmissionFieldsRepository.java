package com.wue.repository.drill.submission;

import com.wue.domain.drill.submission.DefaultSubmissionFields;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
public interface DrillDefaultSubmissionFieldsRepository extends JpaRepository<DefaultSubmissionFields, String> {
}
