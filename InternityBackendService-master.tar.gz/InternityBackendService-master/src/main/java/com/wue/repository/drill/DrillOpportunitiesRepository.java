package com.wue.repository.drill;

import com.wue.domain.drill.DrillOpportunities;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.util.List;

@EnableJpaRepositories
public interface DrillOpportunitiesRepository extends JpaRepository<DrillOpportunities, String> {

    List<DrillOpportunities> findByDrillId(String drillId);
}
