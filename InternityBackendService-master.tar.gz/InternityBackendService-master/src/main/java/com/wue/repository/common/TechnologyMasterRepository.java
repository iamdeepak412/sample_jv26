package com.wue.repository.common;

import com.wue.domain.common.TechnologyMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TechnologyMasterRepository extends JpaRepository<TechnologyMaster,Long> {
}
