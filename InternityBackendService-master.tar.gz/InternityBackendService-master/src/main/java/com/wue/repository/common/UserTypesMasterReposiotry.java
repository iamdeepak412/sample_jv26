package com.wue.repository.common;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wue.domain.common.UserTypesMaster;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface UserTypesMasterReposiotry extends JpaRepository<UserTypesMaster, Long> {

    @Query("SELECT DISTINCT type from UserTypesMaster")
    List<String> findListOfTypes();
}
