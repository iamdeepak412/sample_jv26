package com.wue.repository.drill;

import com.wue.domain.User;
import com.wue.domain.drill.DrillParticipant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@EnableJpaRepositories
public interface DrillParticipantRepository extends JpaRepository<DrillParticipant, String>,JpaSpecificationExecutor<DrillParticipant>{

    List<DrillParticipant> findByDrillId(String drillId);

    Optional<DrillParticipant> findByDrillIdAndPlatformUId(String drillId, String uId);

    Optional<DrillParticipant> findByDrillIdAndEmail(String drillId, String email);

    @Query("SELECT COUNT(participantId) FROM DrillParticipant u where cast(u.createdTs as LocalDate)>=?2" +
            " AND cast(u.createdTs as LocalDate)<=?1")
    Long fetchCountOfUsersAddedInBetweenDays(LocalDate now, LocalDate minusDays);

	List<DrillParticipant> findByDrillIdAndParticipantType(String eventId, String positionOrder);

    List<DrillParticipant> findByDrillIdAndParticipantState(String eventId, String positionOrder);
    @Query("Select COUNT(participant_type) from DrillParticipant where participant_type = 'professionals'")
	Long findByTypeProfessional();

    @Query("Select COUNT(participant_type) from DrillParticipant where participant_type = 'student'")
	Long findByTypeStudent();
    @Query("Select COUNT(participant_type) from DrillParticipant where participant_type = 'professionals'")
	Long findByParticipantIdTypeProfessional();

    @Query("SELECT dp FROM DrillParticipant dp where drill_id IN (?1)")
    List<DrillParticipant> findListOfParticipantByDrillIn(List<String> listOfDrillId);


    Optional<DrillParticipant> findByDrillIdAndParticipantId(String drillId, String participantId);

    @Query("SELECT dp FROM DrillParticipant dp " +
            "WHERE dp.drillId = :drillId " +
            "AND dp.participantId NOT IN (SELECT tp.participantId FROM TeamsParticipants tp WHERE tp.drillId = :drillId AND tp.isRequestAccepted = true)")
    List<DrillParticipant> findParticipantsNotInAnyTeamForDrill(@Param("drillId") String drillId);

    @Query("SELECT dp FROM DrillParticipant dp " +
            "WHERE dp.drillId = :drillId " +
            "AND dp.fullName = :fullName " +
            "AND dp.participantId NOT IN (SELECT tp.participantId FROM TeamsParticipants tp WHERE tp.drillId = :drillId AND tp.isRequestAccepted = true)")
    List<DrillParticipant> findParticipantsByNameAndDrillIdNotInAnyTeam(
            @Param("fullName") String fullName,
            @Param("drillId") String drillId
    );

    @Query("SELECT dp FROM DrillParticipant dp " +
            "WHERE dp.drillId = :drillId " +
            "AND dp.email = :email " +
            "AND dp.participantId NOT IN (SELECT tp.participantId FROM TeamsParticipants tp WHERE tp.drillId = :drillId AND tp.isRequestAccepted = true)")
    List<DrillParticipant> findParticipantsByEmailAndDrillIdNotInAnyTeam(
            @Param("email") String email,
            @Param("drillId") String drillId
    );

    List<DrillParticipant> findByPlatformUId(String uId);

    List<DrillParticipant> findAllByDrillId(String drillId);

    List<DrillParticipant> findAllByParticipantIdIn(List<String> participantIds);

    List<DrillParticipant> findAllByDrillIdAndPlatformUIdIn(String drillId, List<String> restrictedList);

}
