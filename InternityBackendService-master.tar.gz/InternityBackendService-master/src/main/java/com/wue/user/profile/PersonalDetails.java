package com.wue.user.profile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.domain.User;
import com.wue.domain.UserPersonalDetail;
import com.wue.repository.UserProfileRepository;
import com.wue.repository.UserRepository;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class PersonalDetails extends ProfileSection {

	@Autowired
	UserProfileRepository userProfileRepository;
	
	@Autowired
	UserRepository userRepository;
	
	public boolean update(Map<String, Object> requestPayload) {
		ObjectMapper obj = new ObjectMapper();
		try {
			UserPersonalDetail userPersonalDetail = obj.convertValue(requestPayload, UserPersonalDetail.class);
			userProfileRepository.save(userPersonalDetail);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception while saving the json {}", e);
		}

		return false;
	}

	public List<Map<String, Object>> fetch(String uId) {
		try {
		Optional<User> userObj = userRepository.findById(uId);
		List<Map<String, Object>> personalList = new ArrayList<>();
		if (userObj.isPresent()) {
			Optional<UserPersonalDetail> userProfileObj = userProfileRepository.findByuId(uId);
			if (userProfileObj.isPresent()) {
				ObjectMapper oMapper = new ObjectMapper();
				Map<String, Object> map = oMapper.convertValue(userProfileObj.get(), Map.class);
				personalList.add(map);
				return personalList;
			}
		}
		}
		catch(Exception e) {
			log.error("Exception while fetching profile {}", e);
		}
		return Collections.emptyList();
	}

	@Override
	public boolean delete(Long id, String uId) {
		try {
			userProfileRepository.deleteById(id);
			return true;
		} catch (Exception e) {
			log.error("Error while deleting user personal details for {} with error {}", id, e);
			return false;
		}
	}
}
