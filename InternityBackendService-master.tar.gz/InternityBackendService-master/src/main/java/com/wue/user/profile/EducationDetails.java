package com.wue.user.profile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.domain.EducationInformation;
import com.wue.repository.EducationInformationRepository;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class EducationDetails extends ProfileSection{

	@Autowired
	EducationInformationRepository educationRepository;
	
	public boolean update(Map<String, Object> requestPayload) {
		ObjectMapper obj = new ObjectMapper();
		try {
			
			EducationInformation eduProfile = obj.convertValue(requestPayload, EducationInformation.class);
			educationRepository.save(eduProfile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	
	@Override
	public List<Map<String, Object>> fetch(String uId) {
		List<EducationInformation> eduDetailsObj = educationRepository.findByuId(uId);
		if(!eduDetailsObj.isEmpty()) {
			ObjectMapper oMapper = new ObjectMapper();
			List<Map<String, Object>> map = oMapper.convertValue(eduDetailsObj, ArrayList.class);
			return map;
		}
		return Collections.emptyList();
	}

	@Override
	public boolean delete(Long id, String uId) {
		try {
			educationRepository.deleteById(id);
			return true;
		} catch (Exception e) {
			log.error("Error while deleting education details for {} with error {}", id, e);
			return false;
		}
	}

}
