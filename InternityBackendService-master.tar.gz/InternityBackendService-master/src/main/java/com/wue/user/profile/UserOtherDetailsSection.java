package com.wue.user.profile;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.domain.User;
import com.wue.domain.UserOtherDetails;
import com.wue.repository.UserOtherDetailsRepository;
import com.wue.repository.UserRepository;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class UserOtherDetailsSection extends ProfileSection {

	@Autowired
	UserOtherDetailsRepository userOtherDetailsRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Override
	public boolean update(Map<String, Object> requestPayload) {
		ObjectMapper obj = new ObjectMapper();
		try {
			String uId = requestPayload.get("uid").toString();
			Optional<User> user = userRepository.findById(uId);
			if(user.isPresent()) {
				requestPayload.put("uid", user.get());
				UserOtherDetails otherDetails = obj.convertValue(requestPayload, UserOtherDetails.class);
				userOtherDetailsRepository.save(otherDetails);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public List<Map<String, Object>> fetch(String uId) {
		Optional<UserOtherDetails> userOtherDetailsObj = userOtherDetailsRepository.findByuId(uId);
		List<Map<String, Object>> otherDetailsList = new ArrayList<>();

		if(userOtherDetailsObj.isPresent()) {
			ObjectMapper oMapper = new ObjectMapper();
			Map<String, Object> map = oMapper.convertValue(userOtherDetailsObj.get(), HashMap.class);
			otherDetailsList.add(map);
			return otherDetailsList;
		}
		return Collections.emptyList();
	}

	@Override
	public boolean delete(Long id, String uId) {
		try {
			userOtherDetailsRepository.deleteById(id);
			return true;
		} catch (Exception e) {
			log.error("Error while deleting other details for {} with error {}", id, e);
			return false;
		}
	}
}
