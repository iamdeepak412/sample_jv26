package com.wue.user.profile;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public abstract class ProfileSection{

	public abstract boolean update(Map<String, Object> sectionDetails);

	public abstract List<Map<String, Object>> fetch(String uId);

	public abstract boolean delete(Long id, String uId);

}
