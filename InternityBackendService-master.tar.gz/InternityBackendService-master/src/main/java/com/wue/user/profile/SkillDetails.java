package com.wue.user.profile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.domain.User;
import com.wue.domain.UserSkill;
import com.wue.repository.UserRepository;
import com.wue.repository.UserSkillRepository;

import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class SkillDetails extends ProfileSection {

	@Autowired
	UserSkillRepository userSkillRepository;
	
	@Autowired
	UserRepository userRepository;
	
	public boolean update(Map<String, Object> requestPayload) {
		ObjectMapper obj = new ObjectMapper();
		try {
			String uId = requestPayload.get("uid").toString();
			Optional<User> user = userRepository.findById(uId);
			if(user.isPresent()) {
				requestPayload.put("uid", user.get());
				UserSkill skill = obj.convertValue(requestPayload, UserSkill.class);
				userSkillRepository.save(skill);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<Map<String, Object>> fetch(String uId) {
		List<UserSkill> userProfileObj = userSkillRepository.findByuId(uId);
		if(!userProfileObj.isEmpty()) {
			ObjectMapper oMapper = new ObjectMapper();
			List<Map<String, Object>> map = oMapper.convertValue(userProfileObj, ArrayList.class);
			return map;
		}
		return Collections.emptyList();
	}

	@Override
	public boolean delete(Long id, String uId) {
		try {
			userSkillRepository.deleteById(id);
			return true;
		} catch (Exception e) {
			log.error("Error while deleting skill details for {} with error {}", id, e);
			return false;
		}
	}
}
