package com.wue.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonView;
import com.wue.domain.User;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Component
@Scope("prototype")
public class UserFilterDto {
	@JsonView(SearchProfiles.Basic.class)
	private String uId;
	
	@JsonView(SearchProfiles.Basic.class)
	private String username;
	
	@JsonView(SearchProfiles.Basic.class)
	private String fullName;
	
	@JsonView(SearchProfiles.Basic.class)
	private String uEmail;
	
	@JsonView(SearchProfiles.Basic.class)
	private String uContact;
	
	@JsonView(SearchProfiles.Basic.class)
	private String password;
	
	@JsonView(SearchProfiles.Basic.class)
	private String uGroup;
	
	@JsonView(SearchProfiles.Basic.class)
	private String uRole;
	
	@JsonView(SearchProfiles.Basic.class)
	private boolean isActive;
	
	@JsonView(SearchProfiles.Basic.class)
	private String uType;
	
	@JsonView(SearchProfiles.Basic.class)
	private boolean isConditionAccepted;
	
	@JsonView(SearchProfiles.Basic.class)
	private String resumeLink;
	
	@JsonView(SearchProfiles.Basic.class)
	private boolean mentor;
	
	@JsonView(SearchProfiles.Basic.class)
	private boolean jobfeed;
	
	@JsonView(SearchProfiles.Basic.class)
	private String userCreatedby;
	
	@JsonView(SearchProfiles.Basic.class)
	private String userUpdatedby;
	
	@JsonView(SearchProfiles.Basic.class)
	private Date userCreatedts;

	@JsonView(SearchProfiles.Basic.class)
	private Date userUpdatedts;

	public UserFilterDto(User user) {
		super();
		this.uId = user.getUId();
		this.username = user.getUsername();
		this.fullName = user.getFullName();
		this.uEmail = user.getEmail();
		this.uContact = user.getUContact();
		this.password = user.getPassword();
		this.uGroup = user.getUGroup();
		this.uRole = user.getURole();
		this.isActive = user.isActive();
		this.uType = user.getUType();
		this.isConditionAccepted = isConditionAccepted;
		this.resumeLink = user.getResumeLink();
		this.mentor = mentor;
		this.jobfeed = jobfeed;
		this.userCreatedby = user.getUserCreatedby();
		this.userUpdatedby = user.getUserUpdatedby();
		this.userCreatedts = user.getUserCreatedts();
		this.userUpdatedts = user.getUserUpdatedts();
	}
	

}
