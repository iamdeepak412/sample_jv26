package com.wue.dto.drill.submission.search;

import com.wue.domain.drill.DrillParticipant;
import com.wue.domain.drill.DrillTeams;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.repository.drill.DrillParticipantRepository;
import com.wue.repository.drill.DrillTeamsRepository;

import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DrillSubmissionSpecification implements Specification<DrillParticipantSubmission>
{
    /**
     * Serial UID
     */
    private static final long serialVersionUID = -1278985777970975122L;

    private transient DrillSubmissionSearchCriteria searchCriteria;

	private DrillTeamsRepository drillTeamsRepository;
	
	private DrillParticipantRepository drillParticipantRepository;

    public DrillSubmissionSpecification(DrillSubmissionSearchCriteria searchCriteria,DrillTeamsRepository drillTeamsRepository,DrillParticipantRepository drillParticipantRepository)
    {
        this.searchCriteria = searchCriteria;
        this.drillTeamsRepository = drillTeamsRepository;
        this.drillParticipantRepository = drillParticipantRepository;
    }

    @Override
    public Predicate toPredicate(Root<DrillParticipantSubmission> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder)
    {
        List<Predicate> predicates = new ArrayList<>();

        if(!"all".equalsIgnoreCase(searchCriteria.getDrillId()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("drillId"), searchCriteria.getDrillId()));
        }
        if(!"all".equalsIgnoreCase(searchCriteria.getTeamName()))
        {
        	String teamId = fetchTeamOrParticipantDetails(searchCriteria.getTeamName(),null,searchCriteria.getDrillId());
            predicates.add(criteriaBuilder.equal(root.<String>get("teamId"), teamId));
        }
        if(!"all".equalsIgnoreCase(searchCriteria.getParticipantEmail()))
        {
        	String participantId = fetchTeamOrParticipantDetails(null,searchCriteria.getParticipantEmail(),searchCriteria.getDrillId());
            predicates.add(criteriaBuilder.equal(root.<String>get("participantId"), participantId));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getPanelId()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("panelId"), searchCriteria.getPanelId()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getPhaseId()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("phaseId"), searchCriteria.getPhaseId()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getParticipantId()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("participantId"), searchCriteria.getParticipantId()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getTheme()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("theme"), searchCriteria.getTheme()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getTeamId()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("teamId"), searchCriteria.getTeamId()));
        }

        predicates.add(criteriaBuilder.equal(root.<Boolean>get("isActiveSubmission"), true));
        Predicate[] predicateArr = new Predicate[predicates.size()];

        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }
    private String fetchTeamOrParticipantDetails(String teamName, String participantEmail,String drillId) {
        if (teamName != null && !teamName.isEmpty()) {
            // Find the team by teamName, ignoring case
            Optional<DrillTeams> teamsObj = drillTeamsRepository.findByTeamNameIgnoreCaseAndDrillId(teamName,drillId);

            if (teamsObj.isPresent()) {
                return teamsObj.get().getTeamId();
            } else {
                return null;
            }
        } else if (participantEmail != null && !participantEmail.isEmpty()) {
            // Assuming you have a repository for participants, find the participant by email

            Optional<DrillParticipant> participantObj = drillParticipantRepository.findByDrillIdAndEmail(drillId,participantEmail);

            if (participantObj.isPresent()) {
                return participantObj.get().getParticipantId();
            } else {
                return null;
            }
        } else {
            return null; // Handle the case when both parameters are empty or null
        }
    }



}
