package com.wue.dto.drill.submission.search;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class DrillSubmissionSearchCriteria {
    private String drillId;
    private String teamId;
    private String theme;
    private String participantId;
    private String panelId;
    private String phaseId;
    private String teamName;
    private String participantEmail;
    private boolean isActiveSubmission=true;
}
