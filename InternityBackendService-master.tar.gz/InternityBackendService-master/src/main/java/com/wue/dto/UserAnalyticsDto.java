package com.wue.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class UserAnalyticsDto {
	private String uId;
	private int noOfJobsViews;
	private int noOfHackathonsViews;
	private int noOfJobsApplied;
	private int noOfHackathonsApplied;
}
