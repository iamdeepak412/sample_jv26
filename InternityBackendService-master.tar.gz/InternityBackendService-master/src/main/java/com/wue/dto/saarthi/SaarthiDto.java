package com.wue.dto.saarthi;

import com.wue.constant.saarthi.*;
import com.wue.domain.saarthi.Saarthi;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SaarthiDto {
    private String saarthiId;
    private String name;
    private String emailId;
    private String contactNo;
    private String gender;
    private String levelOfStudy;
    private String location;
    private String state;
    private String whyJoin;
    private String anythingElseText;
    private String referralCode;
    private GotToKnowPlatform gotToKnowPlatform;
    private String currCompanyName;
    private String currRole;
    private String primarySkills;
    private Integer totalExperience;
    private String yearOfStudy;
    private double passingYear;
    private Integer noOfSocietiesClubInstitute;
    private String partOfSolution;
    private String whoAreYou;
    private String communityName;
    private String organizationName;
    private String expectationsFromUs;
    private String profileLinks;
    private SaarthiRegistrationType registrationType;

    public SaarthiDto(Saarthi saarthi){
        this.saarthiId = saarthi.getSaarthiId();
        this.name = saarthi.getName();
        this.emailId = saarthi.getEmailId();
        this.contactNo = saarthi.getContactNo();
        this.communityName = saarthi.getCommunityName();
        this.anythingElseText = saarthi.getAnythingElseText();
        this.currCompanyName = saarthi.getCurrCompanyName();
        this.currRole = saarthi.getCurrRole();
        this.expectationsFromUs = saarthi.getExpectationsFromUs();
        this.gender = saarthi.getGender();
        this.gotToKnowPlatform = saarthi.getGotToKnowPlatform();
        this.levelOfStudy = saarthi.getLevelOfStudy();
        this.location = saarthi.getLocation();
        this.noOfSocietiesClubInstitute = saarthi.getNoOfSocietiesClubInstitute();
        this.organizationName = saarthi.getOrganizationName();
        this.partOfSolution = saarthi.getPartOfSolution();
        this.passingYear = saarthi.getPassingYear();
        this.primarySkills = saarthi.getPrimarySkills();
        this.profileLinks = saarthi.getProfileLinks();
        this.referralCode = saarthi.getReferralCode();
        this.registrationType = saarthi.getRegistrationType();
        this.state = saarthi.getState();
        this.totalExperience = saarthi.getTotalExperience();
        this.whoAreYou = saarthi.getWhoAreYou();
        this.whyJoin = saarthi.getWhyJoin();
        this.yearOfStudy = saarthi.getYearOfStudy();
    }
}
