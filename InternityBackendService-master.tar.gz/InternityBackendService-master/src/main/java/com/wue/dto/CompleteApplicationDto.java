package com.wue.dto;

import com.wue.domain.Job;
import com.wue.domain.User;
import com.wue.domain.UserCandidateMandatoryFields;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Date;

@Component
@Data
public class CompleteApplicationDto {
	private Long applicationId;
	private String userId;
	private String userFullName;
	private String jobId;
	private String partnerName;
	private String jobTitle;
	private String jobImg;
	private String resumeLink;
	private LocalDateTime appliedTs;
	private String currentStatus;
	private String subStatus;
	private LocalDateTime createdTs;
	private Date updatedTs;
	private String createdBy;
	private String updatedBy;
	private String skillsMatchedDetails;
	private UserCandidateMandatoryFields userCandidateMandatoryFields;
	private User allUserDetails;
	private String userProfileImgUrl;
	private Job jobObj;
}
