package com.wue.dto.search;

import com.wue.custom.specification.SearchReportAbuseCriteria;
import com.wue.domain.blog.ReportAbuse;
import com.wue.repository.blog.ReportAbuseRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;


@AllArgsConstructor
@NoArgsConstructor
public class ReportAbuseSpecification implements Specification<ReportAbuse> {

    private SearchReportAbuseCriteria searchCriteria;
    private ReportAbuseRepository reportAbuseRepository;

    @Override
    public Predicate toPredicate(Root<ReportAbuse> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {

        List<Predicate> predicates = new ArrayList<>();
        if (!"NA".equalsIgnoreCase(searchCriteria.getUId())) {
            predicates.add(criteriaBuilder.equal(root.get("uId"), searchCriteria.getUId()));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getPostId())) {
            if ("NA".equalsIgnoreCase(searchCriteria.getCommentId())) {
                predicates.add(criteriaBuilder.and(
                        criteriaBuilder.equal(root.get("postId"), searchCriteria.getPostId()),
                        criteriaBuilder.isNull(root.get("commentId"))
                ));
            }
            else if ("all".equalsIgnoreCase(searchCriteria.getCommentId())) {
                predicates.add(criteriaBuilder.and(
                        criteriaBuilder.equal(root.get("postId"), searchCriteria.getPostId()),
                        criteriaBuilder.isNotNull(root.get("commentId"))
                ));
            }
            else {
                predicates.add(criteriaBuilder.and(
                        criteriaBuilder.equal(root.get("postId"), searchCriteria.getPostId()),
                        criteriaBuilder.equal(root.get("commentId"), searchCriteria.getCommentId())
                ));
            }
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getReportId())) {
            predicates.add(criteriaBuilder.equal(root.get("reportId"), searchCriteria.getReportId()));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getCommentId()) && !"all".equalsIgnoreCase(searchCriteria.getCommentId())) {
            predicates.add(criteriaBuilder.equal(root.get("commentId"), searchCriteria.getCommentId()));
        }

        Predicate[] predicateArr = new Predicate[predicates.size()];
        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }
}


