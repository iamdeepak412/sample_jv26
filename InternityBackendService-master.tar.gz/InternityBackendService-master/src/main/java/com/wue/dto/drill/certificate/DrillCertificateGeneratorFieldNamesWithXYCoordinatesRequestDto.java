package com.wue.dto.drill.certificate;

import com.wue.constant.drill.certificate.DrillCertificateFieldType;
import com.wue.constant.drill.certificate.DrillCertificateFontFamily;
import com.wue.constant.drill.certificate.DrillCertificateFontStyles;
import com.wue.constant.drill.certificate.DrillCertificatePredefinedFields;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto {
    private DrillCertificatePredefinedFields field;
    private String customText;
    private int x;
    private int y;
    private int size;
    private DrillCertificateFontFamily fontFamily;
    private DrillCertificateFontStyles fontStyle;
    private String color;
}
