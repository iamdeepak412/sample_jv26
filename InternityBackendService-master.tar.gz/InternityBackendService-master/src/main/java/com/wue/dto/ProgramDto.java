package com.wue.dto;

public class ProgramDto {

}
