package com.wue.dto.search;

import com.wue.custom.specification.SearchJobCriteria;
import com.wue.domain.Job;
import org.springframework.data.jpa.domain.Specification;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;

public class JobSpecification implements Specification<Job>
{
    /**
     * Serial UID
     */
    private static final long serialVersionUID = -1278985777970975121L;

    private transient SearchJobCriteria searchCriteria;

    public JobSpecification(SearchJobCriteria searchCriteria)
    {
        this.searchCriteria = searchCriteria;
    }

    @Override
    public Predicate toPredicate(Root<Job> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder)
    {
        List<Predicate> predicates = new ArrayList<>();

        if(!"all".equalsIgnoreCase(searchCriteria.getJobTitle()))
        {
            String[] titles = searchCriteria.getJobTitle().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(titles.length);

            for(String title : titles) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("jobTitle"), "%"+title.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getJobType()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("jobType"), searchCriteria.getJobType()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getJobLocation()))
        {
            String[] locations = searchCriteria.getJobLocation().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(locations.length);

            for(String location : locations) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("jobLocation"), "%"+location.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }
        if(!"all".equalsIgnoreCase(searchCriteria.getPartnerId()))
        {
            String[] partners = searchCriteria.getPartnerId().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(partners.length);

            for(String partner : partners) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("partnerId"), "%"+partner.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getJobSkills()))
        {
            String[] skills = searchCriteria.getJobSkills().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(skills.length);

            for(String skill : skills) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("jobSkills"), "%"+skill.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }

        predicates.add(criteriaBuilder.ge(root.<Double>get("jobMinCtcRange"), searchCriteria.getJobMinCtc()));
        predicates.add(criteriaBuilder.le(root.<Double>get("jobMaxCtcRange"), searchCriteria.getJobMaxCtc()));
        predicates.add(criteriaBuilder.ge(root.<Integer>get("jobMinYoe"), searchCriteria.getJobMinYoe()));
        predicates.add(criteriaBuilder.le(root.<Integer>get("jobMaxYoe"), searchCriteria.getJobMaxYoe()));
        if(searchCriteria.getIsActive().equals("true")){
            predicates.add(criteriaBuilder.equal(root.<Boolean>get("isActive"), true));
        }else if(searchCriteria.getIsActive().equals("false")){
            predicates.add(criteriaBuilder.equal(root.<Boolean>get("isActive"), false));
        }
        if (!"all".equalsIgnoreCase(searchCriteria.getDrillId())) {
            predicates.add(criteriaBuilder.equal(criteriaBuilder.lower(root.get("drillId")),
                    searchCriteria.getDrillId().toLowerCase()));
        }

        Predicate[] predicateArr = new Predicate[predicates.size()];

        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }

}
