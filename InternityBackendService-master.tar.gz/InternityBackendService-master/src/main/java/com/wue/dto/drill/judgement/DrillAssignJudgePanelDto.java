package com.wue.dto.drill.judgement;


import com.wue.dto.drill.DrillJudgeDto;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
public class DrillAssignJudgePanelDto {
	private Long id;
	private String phaseId;
	private String phaseName;
	private String panelId;
	private String panelName;
	private List<DrillJudgeDto> judgesList;
}
