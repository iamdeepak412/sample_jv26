package com.wue.dto.search;

import com.wue.constant.saarthi.SaarthiRegistrationType;
import com.wue.custom.specification.SearchSaarthiCriteria;
import com.wue.domain.saarthi.Saarthi;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Log4j2
public class SaarthiSpecification implements Specification<Saarthi> {
    private SearchSaarthiCriteria searchCriteria;

    public SaarthiSpecification(SearchSaarthiCriteria searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    @Override
    public Predicate toPredicate(Root<Saarthi> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        if (!"all".equalsIgnoreCase(searchCriteria.getSaarthiId())) {
            predicates.add(criteriaBuilder.equal(
                    criteriaBuilder.lower(root.get("saarthiId")),
                    searchCriteria.getSaarthiId()));
        }
        if (!"all".equalsIgnoreCase(searchCriteria.getRegistrationType())) {
            SaarthiRegistrationType registrationType = SaarthiRegistrationType.valueOf(searchCriteria.getRegistrationType());
            predicates.add(criteriaBuilder.equal(
                    root.get("registrationType"),
                    registrationType));
        }
        if (!"all".equalsIgnoreCase(searchCriteria.getSaarthiWhoAreYouType())) {
            predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("whoAreYou")),
                    "%" + searchCriteria.getSaarthiWhoAreYouType() + "%"));
        }
        if (!"all".equalsIgnoreCase(searchCriteria.getSaarthiPartOfSolutionType())) {
            predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("partOfSolution")),
                    "%" + searchCriteria.getSaarthiPartOfSolutionType() + "%"));
        }

        Predicate[] predicateArr = new Predicate[predicates.size()];
        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }
}
