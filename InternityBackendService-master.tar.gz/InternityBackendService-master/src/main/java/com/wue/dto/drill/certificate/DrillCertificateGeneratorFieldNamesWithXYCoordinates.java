package com.wue.dto.drill.certificate;

import com.wue.constant.drill.certificate.DrillCertificateFontFamily;
import com.wue.constant.drill.certificate.DrillCertificateFontStyles;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DrillCertificateGeneratorFieldNamesWithXYCoordinates {

    private String text;
    private int x;
    private int y;
    private int size;
    private DrillCertificateFontFamily fontFamily;
    private DrillCertificateFontStyles fontStyle;
    private String color;
}
