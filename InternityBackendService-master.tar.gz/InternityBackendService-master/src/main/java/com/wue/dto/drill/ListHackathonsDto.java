package com.wue.dto.drill;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonView;
import com.wue.domain.drill.Drill;
import com.wue.dto.SearchProfiles;

public class ListHackathonsDto {
	
	@JsonView(SearchProfiles.Basic.class)
	private String drillId;

	@JsonView(SearchProfiles.Basic.class)
	private String drillName;

	@JsonView(SearchProfiles.Basic.class)
	private String drillTimezone;

	@JsonView(SearchProfiles.Basic.class)
	private LocalDateTime drillStartDt;

	@JsonView(SearchProfiles.Basic.class)
	private LocalDateTime drillEndDt;
	
	
	public ListHackathonsDto(Drill drill) {
		super();
		this.drillId = drill.getDrillId();
		this.drillName = drill.getDrillName();
		this.drillStartDt = drill.getDrillStartDt();
		this.drillEndDt = drill.getDrillEndDt();
	}


}
