package com.wue.dto.application;

import com.wue.constant.application.ApplicationInterviewRounds;
import com.wue.constant.application.ApplicationRejectedReasons;
import com.wue.constant.application.ApplicationStages;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ApplicationStageResponseDto {

    private String stage;
    private List<String> subStages;



    public static List<ApplicationStageResponseDto> generateStagesFromCurrentStage(ApplicationStages currentStage) {
        List<ApplicationStageResponseDto> stageDtos = new ArrayList<>();
        switch (currentStage) {
            case APPLIED:
                stageDtos.add(fromApplicationStage(ApplicationStages.SCREEN_SELECT));
                stageDtos.add(fromApplicationStage(ApplicationStages.REJECTED));
                stageDtos.add(fromApplicationStage(ApplicationStages.INTERVIEW));
                stageDtos.add(fromApplicationStage(ApplicationStages.OFFERED));
                stageDtos.add(fromApplicationStage(ApplicationStages.JOINED));
                break;
            case SCREEN_SELECT:
            case INTERVIEW:
                stageDtos.add(fromApplicationStage(ApplicationStages.INTERVIEW));
                stageDtos.add(fromApplicationStage(ApplicationStages.REJECTED));
                stageDtos.add(fromApplicationStage(ApplicationStages.OFFERED));
                stageDtos.add(fromApplicationStage(ApplicationStages.JOINED));
                break;
            case OFFERED:
                stageDtos.add(fromApplicationStage(ApplicationStages.JOINED));
                stageDtos.add(fromApplicationStage(ApplicationStages.REJECTED));
                break;
            case JOINED:
                stageDtos.add(fromApplicationStage(ApplicationStages.REJECTED));
                break;
            default:
                // Handle other cases if needed
                break;
        }
        return stageDtos;
    }

    public static ApplicationStageResponseDto fromApplicationStage(ApplicationStages stage) {

        ApplicationStageResponseDto dto = new ApplicationStageResponseDto();
        dto.setStage(stage.getStage());
        dto.setSubStages(generateSubStages(stage));
        return dto;
    }

    private static List<String> generateSubStages(ApplicationStages stage) {

        List<String> subStages = new ArrayList<>();

        switch (stage) {
            case INTERVIEW:
                // Add interview rounds
                for (ApplicationInterviewRounds round : ApplicationInterviewRounds.values()) {
                    subStages.add(round.getRound());
                }
                break;
            case REJECTED:
                // Add reject reasons
                for (ApplicationRejectedReasons reason : ApplicationRejectedReasons.values()) {
                    subStages.add(reason.getReason());
                }
                break;
            default:
                // For all other stages, return null
                return null;
        }
        return subStages;
    }
}