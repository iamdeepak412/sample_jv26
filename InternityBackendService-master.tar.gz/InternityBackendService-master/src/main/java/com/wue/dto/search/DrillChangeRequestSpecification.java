package com.wue.dto.search;

import com.wue.custom.specification.SearchDrillChangeRequestCriteria;
import com.wue.domain.drill.DrillChangeRequest;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Log4j2
public class DrillChangeRequestSpecification implements Specification<DrillChangeRequest> {
    private SearchDrillChangeRequestCriteria searchCriteria;
    public DrillChangeRequestSpecification(SearchDrillChangeRequestCriteria searchCriteria){
        this.searchCriteria = searchCriteria;

    }

    @Override
    public Predicate toPredicate(Root<DrillChangeRequest> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        if (!"all".equalsIgnoreCase(String.valueOf(searchCriteria.getRequestStatus()))) {
            predicates.add(criteriaBuilder.equal(
                    criteriaBuilder.lower(root.get("requestStatus")),
                    searchCriteria.getRequestStatus()));
        }

        if (!"all".equalsIgnoreCase(String.valueOf(searchCriteria.getEntityType()))) {
            predicates.add(criteriaBuilder.equal(
                    criteriaBuilder.lower(root.get("entityType")),
                    searchCriteria.getEntityType()));
        }
        if (!"all".equalsIgnoreCase(String.valueOf(searchCriteria.getRequestType()))) {
            predicates.add(criteriaBuilder.equal(
                    criteriaBuilder.lower(root.get("requestType")),
                    searchCriteria.getRequestType()));
        }
        if (!"all".equalsIgnoreCase((searchCriteria.getSourceId()))) {
            predicates.add(criteriaBuilder.equal(root.get("sourceId"), searchCriteria.getSourceId()));
        }
        if (!"all".equalsIgnoreCase((searchCriteria.getEntityId()))) {
            predicates.add(criteriaBuilder.equal(root.get("entityId"),searchCriteria.getEntityId()));
        }


        Predicate[] predicateArr = new Predicate[predicates.size()];
        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }
}
