package com.wue.dto.drill;


import com.wue.domain.drill.DrillTeams;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
public class DrillTeamsDto {
    private String teamId;
    private String teamName;
    private String teamImgUrl;
    private String selectedTheme;
    private int teamCurrentSize;
    private int declaredTeamSize;
    private String teamInviteCode;
    private boolean lookingForTeamMate;
    private String teamDescription;
    private List<DrillParticipantInfo> participantInfo;

    public DrillTeamsDto(DrillTeams drillTeams) {
        this.teamId = drillTeams.getTeamId();
        this.teamName = drillTeams.getTeamName();
        this.teamImgUrl = drillTeams.getTeamImgUrl();
        this.selectedTheme = drillTeams.getSelectedTheme();
        this.teamCurrentSize = drillTeams.getTeamCurrentSize();
        this.declaredTeamSize = drillTeams.getDeclaredTeamSize();
        this.teamInviteCode = drillTeams.getTeamInviteCode();
        this.lookingForTeamMate = drillTeams.isLookingForTeamMate();
        this.teamDescription = drillTeams.getTeamDescription();
    }
}
