package com.wue.dto;

import com.wue.domain.blog.BlogPost;
import com.wue.domain.drill.DrillTeams;
import com.wue.repository.UserCandidateMandatoryFieldsRepository;
import com.wue.repository.UserProfileRepository;
import com.wue.repository.blog.BlogCategoryRepository;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
public class BlogPostDto {
    private String blogpostId;
    private String uId;
    private String title;
    private String categoryId;
    private String custUrl;
    private String content;
    private String summary;
    private String coverImgUrl;
    private String tags;
    private int reactionCount;
    private int commentCount;
    private int minToRead;
    private boolean isActive;
    private boolean isFeatured;
    private String name;
    private Date blogPostDate;
    private String authorImgUrl;
    private String authorDesignation;
    private String categoryName;
    private long shareCount;
    private long reportAbuseCount;
    public BlogPostDto(BlogPost blogPost, UserCandidateMandatoryFieldsRepository userCandidateMandatoryFieldsRepository, UserProfileRepository userProfileRepository, BlogCategoryRepository blogCategoryRepository) {


        this.blogpostId = blogPost.getBlogpostId();
        this.categoryId = blogPost.getCategoryId();
        this.commentCount = blogPost.getCommentCount();
        this.content = blogPost.getContent();
        this.custUrl = blogPost.getCustUrl();
        this.coverImgUrl = blogPost.getCoverImgUrl();
        this.isActive = blogPost.isActive();
        this.isFeatured = blogPost.isFeatured();
        this.minToRead =  blogPost.getMinToRead();
        this.name = blogPost.getName();
        this.reactionCount = blogPost.getReactionCount();
        this.tags = blogPost.getTags();
        this.summary = blogPost.getSummary();
        this.title = blogPost.getTitle();
        this.uId = blogPost.getUId();
        this.blogPostDate = blogPost.getRecordCreatedTs();
        this.shareCount = blogPost.getShareCount();
        this.reportAbuseCount = blogPost.getReportAbuseCount();

        userCandidateMandatoryFieldsRepository.findByuId(blogPost.getUId()).ifPresent(userCandidateMandatoryFields -> this.authorDesignation = userCandidateMandatoryFields.getCurrentDesignation());
        userProfileRepository.findByuId(blogPost.getUId()).ifPresent(userProfile -> this.authorImgUrl = userProfile.getProfilePicLink());
        blogCategoryRepository.findById(blogPost.getCategoryId()).ifPresent(blogCategory -> this.categoryName = blogCategory.getName());
    }

}
