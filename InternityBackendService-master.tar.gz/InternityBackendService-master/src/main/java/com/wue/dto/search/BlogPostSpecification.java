package com.wue.dto.search;

import com.wue.custom.specification.SearchBlogPostCriteria;
import com.wue.domain.blog.BlogCategory;
import com.wue.domain.blog.BlogPost;
import com.wue.repository.blog.BlogCategoryRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
@Log4j2
public class BlogPostSpecification implements Specification<BlogPost> {

    private SearchBlogPostCriteria searchCriteria;
    private BlogCategoryRepository blogCategoryRepository;

    public BlogPostSpecification(SearchBlogPostCriteria searchCriteria, BlogCategoryRepository blogCategoryRepository) {
        this.searchCriteria = searchCriteria;
        this.blogCategoryRepository = blogCategoryRepository;
    }

    @Override
    public Predicate toPredicate(Root<BlogPost> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        if (!"NA".equalsIgnoreCase(searchCriteria.getUId())) {
            predicates.add(criteriaBuilder.equal(root.get("uId"), searchCriteria.getUId()));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getCategoryId())) {
            predicates.add(criteriaBuilder.equal(root.get("categoryId"), searchCriteria.getCategoryId()));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getName())) {
            predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("name")),
                    "%" + searchCriteria.getName() + "%"));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getTags())) {
            predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("tags")),
                    "%" + searchCriteria.getTags() + "%"));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getContent())) {
            predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("content")),
                    "%" + searchCriteria.getContent() + "%"));
        }

        if (!"NA".equalsIgnoreCase(searchCriteria.getCategoryName())) {
            List<BlogCategory> blogCategoryList = blogCategoryRepository.findByNameLike(searchCriteria.getCategoryName());
            if (!blogCategoryList.isEmpty()) {
                List<String> categoryIds = blogCategoryList.stream()
                        .map(BlogCategory::getCategoryId)
                        .collect(Collectors.toList());
                predicates.add(root.get("categoryId").in(categoryIds));
            }
        }

        if (!"NA".equalsIgnoreCase(searchCriteria.getBlogpostId())) {
            predicates.add(criteriaBuilder.equal(root.get("blogpostId"), searchCriteria.getBlogpostId()));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getCustUrl())) {
            predicates.add(criteriaBuilder.equal(root.get("custUrl"), searchCriteria.getCustUrl()));
        }
        if (!"NA".equalsIgnoreCase(searchCriteria.getTitle())) {
            predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("title")),
                    "%" + searchCriteria.getTitle() + "%"));
        }
        if (searchCriteria.isFeatured()){
            predicates.add(criteriaBuilder.equal(root.get("isFeatured"), true));
        }
        if (searchCriteria.isActive()){
            predicates.add(criteriaBuilder.equal(root.get("isActive"), true));
        }

        Predicate[] predicateArr = new Predicate[predicates.size()];

        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }
}
