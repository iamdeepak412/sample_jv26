package com.wue.dto.search;

import com.wue.custom.specification.SearchParticipantCriteria;
import com.wue.domain.drill.DrillParticipant;

import lombok.extern.log4j.Log4j2;

import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Log4j2
public class DrillParticipantSpecification implements Specification<DrillParticipant>
{
    /**
     * Serial UID
     */
    private static final long serialVersionUID = -1278985777970975121L;

    private transient SearchParticipantCriteria searchCriteria;

    public DrillParticipantSpecification(SearchParticipantCriteria searchCriteria)
    {
        this.searchCriteria = searchCriteria;
    }

    @Override
    public Predicate toPredicate(Root<DrillParticipant> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder)
    {
        List<Predicate> predicates = new ArrayList<>();

        if(!"all".equalsIgnoreCase(searchCriteria.getFullname()))
        {
            predicates.add(criteriaBuilder.like(root.<String>get("fullName"), "%"+searchCriteria.getFullname()+"%"));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getClgName()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("clgName"), searchCriteria.getClgName()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getDrillId()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("drillId"), searchCriteria.getDrillId()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getPreferredLoc()))
        {
            String[] locations = searchCriteria.getPreferredLoc().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(locations.length);

            for(String location : locations) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("preferredLoc"), "%"+location.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }
        if(!"all".equalsIgnoreCase(searchCriteria.getCurrentLoc()))
        {
            String[] locations = searchCriteria.getCurrentLoc().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(locations.length);

            for(String location : locations) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("currentLoc"), "%"+location.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getOrganisation()))
        {
            String[] organisations = searchCriteria.getOrganisation().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(organisations.length);

            for(String organisation : organisations) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("organisation"), "%"+organisation.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }
//        if(!"all".equalsIgnoreCase(searchCriteria.getCtc()))
//        {
//            String[] ctc = searchCriteria.getCtc().split(",");
//            List<Predicate> listOfPredicate = new ArrayList<>(ctc.length);
//
//            predicates.add(criteriaBuilder.equal(root.<String>get("ctc"), searchCriteria.getCtc()));
//
//            for(String Ctc : ctc) {
//                listOfPredicate.add(criteriaBuilder.like(root.<String>get("ctc"), "%"+Ctc.trim()+"%"));
//            }
//            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
//        }
//        if(!"all".equalsIgnoreCase(searchCriteria.getEctc()))
//        {
//            String[] ectc = searchCriteria.getEctc().split(",");
//            List<Predicate> listOfPredicate = new ArrayList<>(ectc.length);
//
//            for(String Ectc : ectc) {
//                listOfPredicate.add(criteriaBuilder.like(root.<String>get("ectc"), "%"+Ectc.trim()+"%"));
//            }
//            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
//        }
//
        if(!"all".equalsIgnoreCase(searchCriteria.getNoticePeriod()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("noticePeriod"), searchCriteria.getNoticePeriod()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getEmail()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("email"), searchCriteria.getEmail()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getParticipantState()))
        {
            predicates.add(criteriaBuilder.equal(root.<String>get("participantState"), searchCriteria.getParticipantState()));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getClgSpecialization()))
        {
            String[] specialization = searchCriteria.getClgSpecialization().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(specialization.length);

            for(String specializations : specialization) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("email"), "%"+specializations.trim()+"%"));
            }
            predicates.add(criteriaBuilder.or(listOfPredicate.toArray(new Predicate[0])));
        }
        if (!"all".equalsIgnoreCase(searchCriteria.getRegistrationStartDate())) {
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date startDate = dateFormat.parse(searchCriteria.getRegistrationStartDate());

                if (!"all".equalsIgnoreCase(searchCriteria.getRegistrationEndDate())) {
                    Date endDate = dateFormat.parse(searchCriteria.getRegistrationEndDate());
                    predicates.add(criteriaBuilder.between(root.get("createdTs"), startDate, endDate));
                } else {
                    // Handle the case where only start date is given, and end date is not
                    predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("createdTs"), startDate));
                }
            } catch (Exception e) {
                log.error("Error parsing dates: " + e.getMessage());
            }
        }

       //predicates.add(criteriaBuilder.ge(root.<Double>get("yearsOfExperience"), searchCriteria.getYearsOfExperience()));
       
       //predicates.add(criteriaBuilder.ge(root.<Double>get("clgPassingYear"), searchCriteria.getClgPassingYear()));
       
        //predicates.add(criteriaBuilder.equal(root.<Boolean>get("isServingNoticePeriod"), searchCriteria.isServingNoticePeriod()));

        Predicate[] predicateArr = new Predicate[predicates.size()];

        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }

}
