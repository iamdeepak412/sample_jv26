package com.wue.dto;

public enum ApplicationSource {
    PLATFORM,
    RESUME_PARSER
}
