package com.wue.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.sql.Date;

@Component
@Data
public class EventDto {
    private int eventId;
    private String type;
    private String mode;
    private String topic;
    private String agenda;
    private String owner;
    private String startDateTime;
    private String endDateTime;
    private String status;
    private String location;
    private String address;
    private String speaker;
    private String eventCreatedby;
    private String eventUpdatedby;
    private Date eventUpdatedts;
}
