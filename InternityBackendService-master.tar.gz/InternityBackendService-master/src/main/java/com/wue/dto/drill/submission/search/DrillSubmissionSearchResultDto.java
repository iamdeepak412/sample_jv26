package com.wue.dto.drill.submission.search;

import com.wue.dto.drill.submission.DrillParticipantSubmissionDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@Builder
public class DrillSubmissionSearchResultDto
{
    private long totalRecordCount;
    private List<DrillParticipantSubmissionDto> data;
}
