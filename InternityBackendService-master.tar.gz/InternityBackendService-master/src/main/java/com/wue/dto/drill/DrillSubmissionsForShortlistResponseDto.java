package com.wue.dto.drill;


import com.wue.domain.drill.DrillParticipant;
import com.wue.domain.drill.DrillPhases;
import com.wue.domain.drill.DrillTeams;
import com.wue.domain.drill.judgement.DrillJudgementPanel;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import lombok.*;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DrillSubmissionsForShortlistResponseDto {

    private DrillTeams drillTeamDetails;
    private DrillParticipantSubmission drillLatestSubmission;
    private List<DrillParticipant> teamAllParticipantsDetails;
    private String phaseAverageMarks;
    private DrillPhases phasesDetails;
    private String drillId;
    private DrillJudgementPanel panelDetails;
    private double criteriaTotalMarks;


}
