package com.wue.dto;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class UserProfileDto {
	
	private String uId;

    private String gender;

    private String currentCity;

    private String currentState;

    private String zipCode;
    
    private String currentAddress;

    private String maritalStatus;

    private String dateOfBirth;

    private String socialLink;

    private String otherDetails;

    private String coverLetter;

    private String resumeLink;

    private String languagesKnown;
    
    private String profileCreatedby;

    private LocalDateTime profileCreatedts;

    private String profileUpdatedby;

    private LocalDateTime profileUpdatedts;
}
