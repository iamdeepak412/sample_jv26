package com.wue.dto.drill.judgement;


import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class FinalEvaluationDto {
	private String submissionId;
	private String teamName;
	private String projectName;
	private String participantName;
	private String participantEmail;
	private String panelName;
	private String panelId;
	private String phaseName;
	private Float totalGivenMarks;
	private Float averageMarks;
	private String judgeNameAndMarksGiven;
}
