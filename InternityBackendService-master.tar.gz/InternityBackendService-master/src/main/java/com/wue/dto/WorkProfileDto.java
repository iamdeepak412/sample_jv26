package com.wue.dto;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class WorkProfileDto {
	
	private Long expCount;
	
	private String uId;
	
	private String organisationName;

	private String jobDesignation;
    
	private boolean isCurrentlyWorking;

	private LocalDateTime startDate;

	private LocalDateTime endDate;

	private String jobLocation;

	private String lastWorkingDay;

    private String createdby;

    private LocalDateTime createdts;

    private String updatedby;

    private LocalDateTime updatedts;
}
