package com.wue.dto.drill;

import com.wue.constant.drill.EntityType;
import com.wue.constant.drill.RequestStatus;
import com.wue.constant.drill.RequestType;
import com.wue.domain.drill.DrillChangeRequest;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DrillChangeRequestDto {

    private String requestId;
    private RequestType requestType;
    private String requestReason;
    private String requestData;
    private RequestStatus requestStatus;
    private String requestedBy;
    private String approvedBy;
    private String entityId;
    private EntityType entityType;
    private String sourceId;

    private DrillTeamsDto drillTeamsDto;

    public DrillChangeRequestDto(DrillChangeRequest drillChangeRequest) {
        this.requestId = drillChangeRequest.getRequestId();
        this.requestType = drillChangeRequest.getRequestType();
        this.requestReason = drillChangeRequest.getRequestReason();
        this.requestData = drillChangeRequest.getRequestData();
        this.requestStatus = drillChangeRequest.getRequestStatus();
        this.requestedBy = drillChangeRequest.getRequestedBy();
        this.approvedBy = drillChangeRequest.getApprovedBy();
        this.entityId = drillChangeRequest.getEntityId();
        this.entityType = drillChangeRequest.getEntityType();
        this.sourceId = drillChangeRequest.getSourceId();
    }
}
