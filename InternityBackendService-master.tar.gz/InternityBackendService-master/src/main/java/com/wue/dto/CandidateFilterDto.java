package com.wue.dto;

import com.fasterxml.jackson.annotation.JsonView;
import com.wue.domain.User;
import com.wue.domain.UserCandidateMandatoryFields;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Component
@Scope("prototype")
public class CandidateFilterDto {
	@JsonView(SearchProfiles.Basic.class)
	private String uId;

	@JsonView(SearchProfiles.Basic.class)
	private String name;

	@JsonView(SearchProfiles.Basic.class)
	private String email;

	@JsonView(SearchProfiles.Basic.class)
	private String contact;

	@JsonView(SearchProfiles.Basic.class)
	private String profileImg;

	@JsonView(SearchProfiles.Basic.class)
	private String resumeLink;

	@JsonView(SearchProfiles.Basic.class)
	private String skills;

	@JsonView(SearchProfiles.Basic.class)
	private String socialMediaLinks;

	@JsonView(SearchProfiles.Basic.class)
	private String currentDesignation;

	@JsonView(SearchProfiles.Basic.class)
	private String currentOrg;

	@JsonView(SearchProfiles.Basic.class)
	private double yoe;

	@JsonView(SearchProfiles.Basic.class)
	private double currentCtc;

	@JsonView(SearchProfiles.Basic.class)
	private double expectedCtc;

	@JsonView(SearchProfiles.Basic.class)
	private int noticePeriodDays;

	@JsonView(SearchProfiles.Basic.class)
	private LocalDateTime lastWorkingDay;

	@JsonView(SearchProfiles.Basic.class)
	private String currentLocation;

	@JsonView(SearchProfiles.Basic.class)
	private String preferredLocation;

	@JsonView(SearchProfiles.Basic.class)
	private boolean isServingNp;

	@JsonView(SearchProfiles.Basic.class)
	private boolean isActivelySearching;

	public CandidateFilterDto(User user, UserCandidateMandatoryFields userCandidateMandatoryFields) {
		this.uId = user.getUId();
		this.name = name;
		this.email = email;
		this.contact=contact;
		this.profileImg = profileImg;
		this.resumeLink = resumeLink;
		this.skills = skills;
		this.socialMediaLinks = socialMediaLinks;
		this.currentDesignation = currentDesignation;
		this.currentOrg = currentOrg;
		this.yoe = yoe;
		this.currentCtc = currentCtc;
		this.expectedCtc = expectedCtc;
		this.noticePeriodDays = noticePeriodDays;
		this.lastWorkingDay = lastWorkingDay;
		this.currentLocation = currentLocation;
		this.preferredLocation = preferredLocation;
		this.isServingNp = isServingNp;
		this.isActivelySearching = isActivelySearching;
	}
}
