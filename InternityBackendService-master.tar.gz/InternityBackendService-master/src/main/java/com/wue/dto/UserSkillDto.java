package com.wue.dto;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class UserSkillDto {
	
	private Long skillCount;
	
	private String uId;

    private long skillId;

    private String skillCategory;
    
    private long skillLevelId;
    
    private boolean isActive;

    private String createdby;

    private LocalDateTime createdts;

    private String updatedby;

    private LocalDateTime updatedts;
}
