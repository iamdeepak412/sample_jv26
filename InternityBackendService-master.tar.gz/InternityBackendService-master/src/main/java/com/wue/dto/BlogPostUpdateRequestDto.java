package com.wue.dto;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class BlogPostUpdateRequestDto {
    private Boolean isFeatured;
    private Boolean isActive;
}

