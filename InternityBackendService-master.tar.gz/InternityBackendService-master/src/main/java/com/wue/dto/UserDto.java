package com.wue.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class UserDto {
	private String uId;
	private String username;
	private String fullName;
	private String uEmail;
	private String uContact;
	private String password;
	private String uGroup;
	private String uRole;
	private String referralCode;
	private boolean isActive;
	private String uType;
	private boolean isConditionAccepted;
	private String resumeLink;
	private boolean mentor;
	private boolean jobfeed;
	private String returnUrl;
	private String userCreatedby;
	private String userUpdatedby;
	private String userCreatedts;
	private String userUpdatedts;
}
