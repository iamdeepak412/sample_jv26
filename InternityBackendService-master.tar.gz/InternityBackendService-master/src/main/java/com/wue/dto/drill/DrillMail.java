package com.wue.dto.drill;


import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
public class DrillMail {
	private List<String> listOfReceiver;
	private List<String> listofCc;
	private List<String> listOfBcc;
	private String userType;
	private String templateName;
	private String mailSubject;
	private String mailBody;
}
