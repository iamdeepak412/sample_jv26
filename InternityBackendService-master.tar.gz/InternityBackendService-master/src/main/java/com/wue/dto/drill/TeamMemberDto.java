package com.wue.dto.drill;

import com.wue.constant.drill.TeamInviteType;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class TeamMemberDto {

    private String participantImgUrl;
    private String participantValue;
    private String participantSkills;
    private TeamInviteType teamInviteType;
    private String inviteCode;
}
