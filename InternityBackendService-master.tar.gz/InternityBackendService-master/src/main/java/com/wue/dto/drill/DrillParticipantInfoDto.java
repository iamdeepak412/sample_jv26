package com.wue.dto.drill;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class DrillParticipantInfoDto {
    private String participantId;
    private String participantFullName;
    private String participantImgUrl;
    private String participantSkills;
    private String participantValue;

}
