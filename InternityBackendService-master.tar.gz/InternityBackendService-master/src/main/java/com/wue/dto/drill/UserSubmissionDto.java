package com.wue.dto.drill;

import org.springframework.stereotype.Component;

import com.wue.domain.drill.Drill;
import com.wue.domain.drill.DrillTeams;
import com.wue.domain.drill.submission.DrillParticipantSubmission;

import lombok.Data;

@Data
@Component
public class UserSubmissionDto {

    private DrillTeams teamDetails;
    private DrillParticipantSubmission projectDetails;
    private String participantId;
    private String drillId;
    private Drill drillDetails;

}