package com.wue.dto.drill;

import com.wue.constant.drill.DrillRequestType;
import com.wue.constant.job.DrillRequestStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DrillPublishRequestsDto {

    private String drillId;

    private DrillRequestType requestType;  //(PUBLISH/UNPUBLISH)

    private String requestByUId;

    private String remarks;
}
