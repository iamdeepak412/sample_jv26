package com.wue.dto;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class UpdatePassword {
	private String emailid;
	private String oldPassword;
	private String newPassword;
}
