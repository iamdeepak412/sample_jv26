package com.wue.dto.drill;

import com.wue.constant.drill.DrillWinnerType;
import com.wue.domain.drill.*;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class DrillLeaderboardResponseDto {

    private String leaderboardId;
    private String drillId;
    private String phaseId;
    private String position;
    private boolean isProjectShow;
    private DrillWinnerType winnerType;
    private String averageMarks;
    private DrillParticipantSubmission submissionInfoDetails;
    private DrillTeams teamInfoDetails;
    private List<DrillParticipant> participantInfoDetails;


}
