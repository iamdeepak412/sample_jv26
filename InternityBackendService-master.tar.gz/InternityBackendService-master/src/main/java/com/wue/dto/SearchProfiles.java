package com.wue.dto;
public class SearchProfiles
{
    public static class Basic {}
    public static class Detailed extends Basic {}

    public static Class<?> getProfileByName(String name)
    {
        if("Detailed".equalsIgnoreCase(name))
        {
            return SearchProfiles.Detailed.class;
        }
        else
        {
            return SearchProfiles.Basic.class;
        }
    }
}