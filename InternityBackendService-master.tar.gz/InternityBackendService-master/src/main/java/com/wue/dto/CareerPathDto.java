package com.wue.dto;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class CareerPathDto {
	
	private Long careerQueryCount;
	
	private String uId;
	
    private String listOfTargetOrganisation;
	
	private String listOfTargetSkill;

	private String targetPackage;

	private String targetCountry;

	private String targetJobNature;
    
	private String targetLocationIndia;

	private String targetCertification;

	private String otherTarget;

    private String createdby;

    private LocalDateTime createdts;

    private String updatedby;

    private LocalDateTime updatedts;
}
