package com.wue.dto.certificategenerator;


import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class CertificateGenerator {
	private String email;
	private String positionType;
	private String eventType;
	private String eventId;
	private String certificateUrl;
}
