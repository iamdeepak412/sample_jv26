package com.wue.dto.drill.judgement;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Data
public class DrillSubmissionJudgementEvaluationDto {
	private Long id;
	private String drillId;
	private String phaseId;
	private String phaseName;
	private String panelId;
	private String panelName;
	private String participantId;
	private String participantEmail;
	private String participantName;
	private String projectName;
	private String teamName;
	private String judgeMarks;
	private Float totalGivenMarks;
	private String submissionId;
	private String judgeId;
	private String judgeName;
	private Long submissionPosition;
	private String status;
	private String criteriaMarks;
	private String calculatedMarks;
	private String totalMarks;
	private String remarks;
	private Boolean isNominated=false;
	private Boolean isIgnored=false;
    private Date createdTs;
    private Date updatedTs;
	private String createdBy;
	private String updatedBy;
}
