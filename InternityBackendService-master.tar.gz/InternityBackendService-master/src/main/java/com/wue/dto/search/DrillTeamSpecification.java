package com.wue.dto.search;

import com.wue.custom.specification.SearchDrillTeamCriteria;
import com.wue.domain.drill.DrillTeams;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Log4j2
public class DrillTeamSpecification implements Specification<DrillTeams> {
    private SearchDrillTeamCriteria searchCriteria;

    public DrillTeamSpecification(SearchDrillTeamCriteria searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    @Override
    public Predicate toPredicate(Root<DrillTeams> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        if (!"all".equalsIgnoreCase(searchCriteria.getDrillId())) {
            predicates.add(criteriaBuilder.equal(
                    criteriaBuilder.lower(root.get("drillId")),
                    searchCriteria.getDrillId()));
        }

        if (!"all".equalsIgnoreCase(searchCriteria.getTeamId())) {
            predicates.add(criteriaBuilder.equal(
                    criteriaBuilder.lower(root.get("teamId")),
                    searchCriteria.getTeamId()));
        }

        if (!"all".equalsIgnoreCase(searchCriteria.getTeamName())) {
            predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("teamName")),
                    "%" + searchCriteria.getTeamName() + "%"));
        }


        // Add predicate for incompleteTeam
        if (searchCriteria.isIncompleteTeam()) {
            // Add additional predicates for teams that are not complete
            predicates.add(criteriaBuilder.lessThan(
                    root.get("teamCurrentSize"),
                    root.get("declaredTeamSize")
            ));
        }

        // Add predicate for looking for team
        if (searchCriteria.isLookingForTeamMate()){
            predicates.add(criteriaBuilder.isTrue(root.get("lookingForTeamMate")));
        }



        Predicate[] predicateArr = new Predicate[predicates.size()];
        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }
}
