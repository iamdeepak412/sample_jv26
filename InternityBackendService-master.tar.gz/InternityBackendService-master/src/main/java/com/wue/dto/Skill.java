package com.wue.dto;

import lombok.Data;

@Data
public class Skill {
    private String name;
    private String level;
}
