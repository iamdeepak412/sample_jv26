package com.wue.dto;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class UserOtherDetailsDto {
	
	private String uId;
	
    private String extraCurricular;

    private String certification;

    private String createdby;

    private LocalDateTime createdts;

    private String updatedby;

    private LocalDateTime updatedts;
}
