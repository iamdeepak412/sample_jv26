package com.wue.dto;

import java.util.Collection;

import org.json.JSONObject;
import org.springframework.security.core.GrantedAuthority;

/**
 * This is response object which contains authentication details after authentication.
 * 
 */
public class AuthResponseDto {

    private int status;
    private String token;
    private String userId;
    private JSONObject userDetails;
    private Collection<? extends GrantedAuthority> authorities;
    private Integer responseCode;
    private String authoritiesInString;

    //Constructors for initialization
    public AuthResponseDto() {
    }

	public AuthResponseDto(int status, String token, String userId, JSONObject userDetails,
			Collection<? extends GrantedAuthority> authorities, int responseCode, String authoritiesInString) {
		super();
		this.status = status;
		this.token = token;
		this.userId = userId;
		this.userDetails = userDetails;
		this.authorities = authorities;
		this.responseCode = responseCode;
		this.authoritiesInString = authoritiesInString;
	}

	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}

	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userDetails
	 */
	public JSONObject getUserDetails() {
		return userDetails;
	}

	/**
	 * @param userDetails the userDetails to set
	 */
	public void setUserDetails(JSONObject userDetails) {
		this.userDetails = userDetails;
	}

	/**
	 * @return the authorities
	 */
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	/**
	 * @param authorities the authorities to set
	 */
	public void setAuthorities(Collection<? extends GrantedAuthority> authorities) {
		this.authorities = authorities;
	}

	/**
	 * @return the responseCode
	 */
	public Integer getResponseCode() {
		return responseCode;
	}

	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(Integer responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * @return the authoritiesInString
	 */
	public String getAuthoritiesInString() {
		return authoritiesInString;
	}

	/**
	 * @param authoritiesInString the authoritiesInString to set
	 */
	public void setAuthoritiesInString(String authoritiesInString) {
		this.authoritiesInString = authoritiesInString;
	}

	@Override
	public String toString() {
		return "{\"status\":" + status + ", \"token\":\"" + token + "\", \"userId\":\"" + userId + "\", \"userDetails\":"
				+ userDetails + ", \"authorities\":" + authoritiesInString + ", \"responseCode\":" + responseCode + "}";
	}
    
}