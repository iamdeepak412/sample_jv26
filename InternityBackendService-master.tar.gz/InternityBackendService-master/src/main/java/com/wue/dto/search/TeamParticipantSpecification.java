package com.wue.dto.search;

import com.wue.custom.specification.SearchTeamParticipantCriteria;
import com.wue.domain.drill.TeamsParticipants;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Log4j2
public class TeamParticipantSpecification implements Specification<TeamsParticipants> {

    private SearchTeamParticipantCriteria searchCriteria;

    public TeamParticipantSpecification(SearchTeamParticipantCriteria searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    @Override
    public Predicate toPredicate(Root<TeamsParticipants> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        List<Predicate> predicates = new ArrayList<>();
        if (!"all".equalsIgnoreCase(searchCriteria.getDrillId())) {
            predicates.add(criteriaBuilder.equal(root.get("drillId"),
                    searchCriteria.getDrillId()));
        }

        if (!"all".equalsIgnoreCase(searchCriteria.getTeamId())) {
            predicates.add(criteriaBuilder.equal(root.get("teamId"), searchCriteria.getTeamId()));
        }

        if (!"all".equalsIgnoreCase(searchCriteria.getParticipantId())) {
            predicates.add(criteriaBuilder.equal(root.get("participantId"), searchCriteria.getParticipantId()));
        }

        if (!"all".equalsIgnoreCase(String.valueOf(searchCriteria.getStage()))) {
            predicates.add(criteriaBuilder.equal(root.get("stage"), searchCriteria.getStage()));

        }

        return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    }
}
