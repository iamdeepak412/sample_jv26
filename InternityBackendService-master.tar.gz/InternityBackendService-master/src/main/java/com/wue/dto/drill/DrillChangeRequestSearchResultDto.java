package com.wue.dto.drill;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@Builder
public class DrillChangeRequestSearchResultDto {
    private long totalRecordCount;

    private List<DrillChangeRequestDto> data;
}
