package com.wue.dto.search;

import com.wue.custom.specification.SearchUserCriteria;
import com.wue.domain.User;
import com.wue.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;


public class UserSpecification implements Specification<User>
{
	
	@Autowired
	UserRepository userRepo;
    /**
     * Serial UID
     */
    private static final long serialVersionUID = -1278985777970975121L;

    private transient SearchUserCriteria criteria;

    public UserSpecification(SearchUserCriteria searchCriteria)
    {
        this.criteria = searchCriteria;
    }

    @Override
    public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder){
    	{
            List<Predicate> predicates = new ArrayList<>();
        	SearchUserCriteria searchCriteria = null;
            if(!criteria.getEmail().equals("all")){
                predicates.add(criteriaBuilder.like(root.get("email"), "%"+criteria.getEmail()+"%"));
            }
            if(!criteria.getFullName().equals("all")){
                predicates.add(criteriaBuilder.like(root.get("fullName"), "%"+criteria.getFullName()+"%"));
            }
            if (!criteria.getIsActive().equals("NA")) {
                if (criteria.getIsActive().equalsIgnoreCase("True")) {
                    predicates.add(criteriaBuilder.equal(root.<Boolean>get("isActive"), true));
                } else {
                    predicates.add(criteriaBuilder.equal(root.<Boolean>get("isActive"), false));
                }
            }

            Predicate[] predicateArr = new Predicate[predicates.size()];

            return criteriaBuilder.and(predicates.toArray(predicateArr));
        }
    	
    }
}

