package com.wue.dto.assessprofile;


import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class UserDetailsInBulk {
	private String name;
	private String uId;
	private String jobId;
	private String email;
	private String contact;
	private String resumeLink;
	private String skills;
	private String yoe;
	private String collegeName;
	private String designation;
	private String customQuestionAnswerList;
}
