package com.wue.dto.drill.submission;

import com.fasterxml.jackson.annotation.JsonView;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.dto.SearchProfiles;
import lombok.*;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Component
@Scope("prototype")
public class DrillParticipantSubmissionDto {

    @JsonView(SearchProfiles.Basic.class)
    private String participantId;

    @JsonView(SearchProfiles.Basic.class)
    private String participantName;

    @JsonView(SearchProfiles.Basic.class)
    private String participantEmail;

    @JsonView(SearchProfiles.Basic.class)
    private String submissionId;

    @JsonView(SearchProfiles.Basic.class)
    private String drillId;

    @JsonView(SearchProfiles.Basic.class)
    private String teamId;

    @JsonView(SearchProfiles.Basic.class)
    private String theme;

    @JsonView(SearchProfiles.Basic.class)
    private String panelId;

    @JsonView(SearchProfiles.Basic.class)
    private String panelName;

    @JsonView(SearchProfiles.Basic.class)
    private String phaseId;

    @JsonView(SearchProfiles.Basic.class)
    private String phaseName;

    @JsonView(SearchProfiles.Basic.class)
    private String projectName;

    @JsonView(SearchProfiles.Basic.class)
    private String sourceCode;

    @JsonView(SearchProfiles.Basic.class)
    private String video;

    @JsonView(SearchProfiles.Basic.class)
    private String presentation;

    @JsonView(SearchProfiles.Basic.class)
    private String snapshots;

    @JsonView(SearchProfiles.Basic.class)
    private String otherSubmission;

    @JsonView(SearchProfiles.Basic.class)
    private String submissionDescription;

    @JsonView(SearchProfiles.Basic.class)
    private String teamName;

    @JsonView(SearchProfiles.Basic.class)
    private boolean isActiveSubmission;

    @JsonView(SearchProfiles.Basic.class)
    private Date createdTs;

    @JsonView(SearchProfiles.Basic.class)
    private Date updatedTs;

    @JsonView(SearchProfiles.Basic.class)
    private String createdBy;

    @JsonView(SearchProfiles.Basic.class)
    private String updatedBy;

    public DrillParticipantSubmissionDto(DrillParticipantSubmission submission){
        this.participantId = submission.getParticipantId();
        this.submissionId=submission.getSubmissionId();
        this.drillId = submission.getDrillId();
        this.teamId = submission.getTeamId();
        this.theme = submission.getTheme();
        this.phaseId = submission.getPhaseId();
        this.panelId = submission.getPanelId();
        this.projectName=submission.getProjectName();
        this.sourceCode=submission.getSourceCode();
        this.video=submission.getVideo();
        this.presentation=submission.getPresentation();
        this.snapshots=submission.getSnapshots();
        this.otherSubmission=submission.getOtherSubmission();
        this.submissionDescription=submission.getSubmissionDescription();
        this.isActiveSubmission=submission.isActiveSubmission();
        this.createdBy=submission.getCreatedBy();
        this.createdTs=submission.getCreatedTs();
        this.updatedBy=submission.getUpdatedBy();
        this.updatedTs=submission.getUpdatedTs();
    }
}
