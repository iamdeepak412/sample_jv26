package com.wue.dto.drill;

import java.util.Date;

import com.wue.constant.drill.PaymentStatus;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonView;
import com.wue.domain.drill.DrillParticipant;
import com.wue.dto.SearchProfiles;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Component
@Scope("prototype")
public class DrillParticipantDto {

	@JsonView(SearchProfiles.Basic.class)
	private String participantId;

	@JsonView(SearchProfiles.Basic.class)
	private String drillId;

	@JsonView(SearchProfiles.Basic.class)
	private String drillName;

	@JsonView(SearchProfiles.Basic.class)
	private String platformUId;

	@JsonView(SearchProfiles.Basic.class)
	private String participantType;

	@JsonView(SearchProfiles.Basic.class)
	private String participantState;

	@JsonView(SearchProfiles.Basic.class)
	private String email;

	@JsonView(SearchProfiles.Basic.class)
	private String fullName;

	@JsonView(SearchProfiles.Basic.class)
	private String contact;

	@JsonView(SearchProfiles.Basic.class)
	private String pancardId;

	@JsonView(SearchProfiles.Basic.class)
	private String teamName;

	@JsonView(SearchProfiles.Basic.class)
	private String theme;

	@JsonView(SearchProfiles.Basic.class)
	private String willingForJob;

	@JsonView(SearchProfiles.Basic.class)
	private String ctc;
	
	@JsonView(SearchProfiles.Basic.class)
	private String ectc;
	
	@JsonView(SearchProfiles.Basic.class)
	private String currentLoc;
	
	@JsonView(SearchProfiles.Basic.class)
	private String preferredLoc;
	
	@JsonView(SearchProfiles.Basic.class)
	private String clgName;
	
	@JsonView(SearchProfiles.Basic.class)
	private String clgSpecialization;
	
	@JsonView(SearchProfiles.Basic.class)
	private int clgPassingYear;
	
	@JsonView(SearchProfiles.Basic.class)
	private String jobTitle;
	
	@JsonView(SearchProfiles.Basic.class)
	private String organisation;
	
	@JsonView(SearchProfiles.Basic.class)
	private double yearsOfExperience;
	
	@JsonView(SearchProfiles.Basic.class)
	private boolean isServingNoticePeriod;
	
	@JsonView(SearchProfiles.Basic.class)
	private String noticePeriod;

	@JsonView(SearchProfiles.Basic.class)
	private Date updatedTs;

	@JsonView(SearchProfiles.Basic.class)
	private String resumeLink;

	@JsonView(SearchProfiles.Basic.class)
	private String skills;

	@JsonView(SearchProfiles.Basic.class)
	private String lastWorkingDay;

	@JsonView(SearchProfiles.Basic.class)
	private String candidateType;

	@JsonView(SearchProfiles.Basic.class)
	private String teamParticipationMessage;
	@JsonView(SearchProfiles.Basic.class)
	private PaymentStatus paymentStatus;

	@JsonView(SearchProfiles.Basic.class)
	private String affiliatePlatform;

	public DrillParticipantDto(DrillParticipant participants) {
		this.participantId = participants.getParticipantId();
		this.drillId = participants.getDrillId();
		this.platformUId = participants.getPlatformUId();
		this.participantType = participants.getParticipantType();
		this.participantState = participants.getParticipantState();
		this.email = participants.getEmail();
		this.ctc = participants.getCtc();
		this.ectc = participants.getEctc();
		this.currentLoc = participants.getCurrentLoc();
		this.preferredLoc = participants.getPreferredLoc();
		this.clgName = participants.getClgName();
		this.clgSpecialization = participants.getClgSpecialization();
		this.clgPassingYear = participants.getClgPassingYear();
		this.jobTitle = participants.getJobTitle();
		this.organisation = participants.getOrganisation();
		this.yearsOfExperience = participants.getYearsOfExperience();
		this.isServingNoticePeriod = participants.isServingNoticePeriod();
		this.noticePeriod = participants.getNoticePeriod();
		this.updatedTs = participants.getUpdatedTs();
		this.skills = participants.getSkills();
		this.resumeLink = participants.getResumeLink();
		this.lastWorkingDay = participants.getLastWorkingDay()+"";
		this.fullName = participants.getFullName();
		this.contact = participants.getContact();
		this.pancardId = participants.getPancardId();
		this.willingForJob = participants.isWillingForJob()+"";
		this.drillName = participants.getDrillName();
		this.teamName = participants.getTeamName();
		this.theme = participants.getTheme();
		this.candidateType = participants.getCandidateType();
		this.teamParticipationMessage = participants.getTeamParticipationMessage();
		this.paymentStatus = participants.getPaymentStatus();
		this.affiliatePlatform = participants.getAffiliatePlatform();
	}
	

	
}