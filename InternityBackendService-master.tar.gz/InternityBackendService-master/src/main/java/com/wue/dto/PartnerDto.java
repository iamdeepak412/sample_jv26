package com.wue.dto;

import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.Data;
@Component
@Data
public class PartnerDto {

    private String partnerId;
    private String partnerName;
    private String partnerDisplayName;
    private String partnerDescription;
    private String partnerSocialLinks;
    private String partnerType;
    private String partnerIndustry;
    private String partnerEstablishmentDate;
    private String partnerLogoPath;
    private String headquarter;
    private String location;
    private String gstin;
    private String pan;
    private String address;
    private String subCategory;
    private String representativeUid;
    private boolean isActive;
    private Date createdTs;
    private Date updatedTs;
    private String createdBy;
    private String updatedBy;


}

