package com.wue.dto.drill.submission;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class SubmissionField {
    private String fieldName;
    private String fieldDesc;
    private boolean isRequired;
}
