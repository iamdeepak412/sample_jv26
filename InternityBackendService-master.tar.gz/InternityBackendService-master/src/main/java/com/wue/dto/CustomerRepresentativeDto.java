package com.wue.dto;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class CustomerRepresentativeDto {
	 private String name;
	 private String contact;
	 private String email;
	 private String partnerId;

}
