package com.wue.dto;


import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;
@Component
@Data
public class ApplicationDto {
	private Long applicationId;
	private String uId;
	private String jobId;
	private LocalDateTime appliedTs;
	private String currentStatus;
	private String subStatus;
	private LocalDateTime createdTs;
	private LocalDateTime updatedTs;
	private String createdBy;
	private String updatedBy;
	private String skillsMatchedDetails;
	private String customQuestionAnswered;
}
