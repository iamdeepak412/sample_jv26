package com.wue.dto;

import java.util.Date;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class ApplicationTrackDto {

    private Long applicationTrackId;
    private String status;
    private String subStatus;
    private Long applicationId;
    private String feedback;
    private String updatedby;
    private Date updatedts;
}
