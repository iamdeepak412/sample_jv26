package com.wue.dto.drill;

import com.wue.domain.drill.DrillParticipant;
import com.wue.domain.drill.DrillTeams;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DrillLeaderboardByDrillResponseDto {

    private int position;
    private double totalAverageMarks;
    private DrillTeams teamDetails;
    private List<DrillParticipant> participantDetailsList;

}