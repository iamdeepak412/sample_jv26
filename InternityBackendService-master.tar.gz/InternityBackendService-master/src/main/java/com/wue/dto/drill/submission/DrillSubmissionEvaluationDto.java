package com.wue.dto.drill.submission;

import com.wue.domain.drill.submission.DrillSubmissionEvaluation;
import lombok.*;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Component
@Scope("prototype")
public class DrillSubmissionEvaluationDto {

	private Long id;

	private String drillId;

	private String submissionId;

	private String judgeId;

	private Long submissionPosition;

	private JSONArray criteriaMarks;

	private String totalMarks;

	private String remarks;

	private Boolean isNominated=false;

	private Boolean isIgnored=false;

    private Date createdTs;
	
    private Date updatedTs;
    
	private String createdBy;
	
	private String updatedBy;

	private String projectName;

	private String theme;

	private String teamName;

	private String teamId;

	private String panelName;

	private JSONObject resultantCriteriaMarks;

	public DrillSubmissionEvaluationDto(DrillSubmissionEvaluation drillSubmissionEvaluation) {
		this.id = drillSubmissionEvaluation.getId();
		this.drillId = drillSubmissionEvaluation.getDrillId();
		this.submissionId = drillSubmissionEvaluation.getSubmissionId();
		this.judgeId = drillSubmissionEvaluation.getJudgeId();
		this.submissionPosition = drillSubmissionEvaluation.getSubmissionPosition();
		this.criteriaMarks=new JSONArray(drillSubmissionEvaluation.getCriteriaMarks());
		this.totalMarks = drillSubmissionEvaluation.getTotalMarks();
		this.remarks = drillSubmissionEvaluation.getRemarks();
		this.isNominated = drillSubmissionEvaluation.getIsNominated();
		this.isIgnored = drillSubmissionEvaluation.getIsIgnored();
		this.createdTs = drillSubmissionEvaluation.getCreatedTs();
		this.updatedTs = drillSubmissionEvaluation.getUpdatedTs();
		this.createdBy = drillSubmissionEvaluation.getCreatedBy();
		this.updatedBy = drillSubmissionEvaluation.getUpdatedBy();
	}

	@Override
	public String toString() {
		return "{" +
				"\"drillId\":\"" + drillId + '\"' +
				", \"submissionId\":\"" + submissionId + '\"' +
				", \"judgeId\":\"" + judgeId + '\"' +
				", \"submissionPosition\":\"" + submissionPosition + '\"' +
				", \"totalMarks\":\"" + totalMarks + '\"' +
				", \"remarks\":\"" + remarks + '\"' +
				", \"isNominated\":\"" + isNominated + '\"' +
				", \"isIgnored\":\"" + isIgnored + '\"' +
				", \"createdTs\":\"" + createdTs + '\"' +
				", \"updatedTs\":\"" + updatedTs + '\"' +
				", \"createdBy\":\"" + createdBy + '\"' +
				", \"updatedBy\":\"" + updatedBy + '\"' +
				", \"projectName\":\"" + projectName + '\"' +
				", \"theme\":\"" + theme + '\"' +
				", \"teamName\":\"" + teamName + '\"' +
				", \"teamId\":\"" + teamId + '\"' +
				", \"panelName\":\"" + panelName + '\"' +
				", \"resultantCriteriaMarks\":\"" + resultantCriteriaMarks + '\"' +
				'}';
	}
}
