package com.wue.dto.search;

import com.wue.custom.specification.SearchCandidateCriteria;
import com.wue.domain.Application;
import com.wue.domain.UserCandidateMandatoryFields;
import com.wue.repository.ApplicationRepository;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

public class CandidateSpecification implements Specification<UserCandidateMandatoryFields>
{
    /**
     * Serial UID
     */
    private static final long serialVersionUID = -1278985777970975122L;

    private transient SearchCandidateCriteria searchCriteria;
    private transient ApplicationRepository applicationRepository;

    public CandidateSpecification(SearchCandidateCriteria searchCriteria, ApplicationRepository applicationRepository) {
        this.searchCriteria = searchCriteria;
        this.applicationRepository = applicationRepository;
    }

    @Override
    public Predicate toPredicate(Root<UserCandidateMandatoryFields> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder)
    {
        List<Predicate> predicates = new ArrayList<>();
        List<String> uids = fetchuIds(searchCriteria.getJobId());
        if (uids!= null && !uids.isEmpty()) {
            predicates.add(root.<String>get("uId").in(uids));
        }
        if(!"all".equalsIgnoreCase(searchCriteria.getCurrentDesignation()))
        {
            String[] titles = searchCriteria.getCurrentDesignation().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(titles.length);

            for(String title : titles) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("currentDesignation"), "%"+title.trim()+"%"));
            }
            predicates.add(criteriaBuilder.and(listOfPredicate.toArray(new Predicate[0])));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getCurrentOrg()))
        {
            String[] titles = searchCriteria.getCurrentOrg().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(titles.length);

            for(String title : titles) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("currentOrg"), "%"+title.trim()+"%"));
            }
            predicates.add(criteriaBuilder.and(listOfPredicate.toArray(new Predicate[0])));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getCurrentLocation()))
        {
            String[] locations = searchCriteria.getCurrentLocation().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(locations.length);

            for(String location : locations) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("currentLoc"), "%"+location.trim()+"%"));
            }
            predicates.add(criteriaBuilder.and(listOfPredicate.toArray(new Predicate[0])));
        }

        if(!"all".equalsIgnoreCase(searchCriteria.getPreferredLocation()))
        {
            String[] locations = searchCriteria.getPreferredLocation().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(locations.length);

            for(String location : locations) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("preferredLoc"), "%"+location.trim()+"%"));
            }
            predicates.add(criteriaBuilder.and(listOfPredicate.toArray(new Predicate[0])));
        }
        if(!"all".equalsIgnoreCase(searchCriteria.getSkills()))
        {
            String[] skills = searchCriteria.getSkills().split(",");
            List<Predicate> listOfPredicate = new ArrayList<>(skills.length);

            for(String skill : skills) {
                listOfPredicate.add(criteriaBuilder.like(root.<String>get("primarySkills"), "%"+skill.trim()+"%"));
            }
            predicates.add(criteriaBuilder.and(listOfPredicate.toArray(new Predicate[0])));
        }
        predicates.add(criteriaBuilder.ge(root.<Double>get("yoe"), searchCriteria.getMinYoe()));
        predicates.add(criteriaBuilder.le(root.<Double>get("yoe"), searchCriteria.getMaxYoe()));

        predicates.add(criteriaBuilder.ge(root.<Double>get("currentCtc"), searchCriteria.getMinCurrentCtc()));
        predicates.add(criteriaBuilder.le(root.<Double>get("currentCtc"), searchCriteria.getMaxCurrentCtc()));

        predicates.add(criteriaBuilder.ge(root.<Double>get("expectedCtc"), searchCriteria.getMinExpectedCtc()));
        predicates.add(criteriaBuilder.le(root.<Double>get("expectedCtc"), searchCriteria.getMaxExpectedCtc()));

        predicates.add(criteriaBuilder.ge(root.<Double>get("noticePeriodDays"), searchCriteria.getMinNoticePeriodDays()));
        predicates.add(criteriaBuilder.le(root.<Double>get("noticePeriodDays"), searchCriteria.getMaxNoticePeriodDays()));

//        predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.<LocalDateTime>get("lastWorkingDay"), searchCriteria.getMinLastWorkingDay()));
//        predicates.add(criteriaBuilder.lessThanOrEqualTo(root.<LocalDateTime>get("lastWorkingDay"), searchCriteria.getMaxLastWorkingDay()));

       // predicates.add(criteriaBuilder.equal(root.<Boolean>get("isServingNp"), searchCriteria.isServingNp()));

        Predicate[] predicateArr = new Predicate[predicates.size()];

        return criteriaBuilder.and(predicates.toArray(predicateArr));
    }
    
	public List<String> fetchuIds(String jobId) {
        // Fetch applications by jobId from the application repository
        List<Application> applications = applicationRepository.findByJobId(jobId);

        // Create a list to store the filtered candidate data
        List<String> listOfUids = new ArrayList<>();

        // Loop through the applications and populate candidateFilterDtoList
        for (Application application : applications) {
            String uId = application.getUId();
            listOfUids.add(uId);
        }
        return listOfUids;
	}

}
