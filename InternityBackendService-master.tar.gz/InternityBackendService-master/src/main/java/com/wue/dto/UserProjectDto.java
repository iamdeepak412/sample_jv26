package com.wue.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class UserProjectDto {
	
	private Long projectCount;
	
	private String uId;
	
    private long orgOrClgId;

    private String projectTitle;

    private String designation;
    
    private String client;
    
    private LocalDate startDate;

    private LocalDate endDate;
    
    private boolean isCurrentlyWorking;

    private String projectDescription;

    private String projectSite;

    private String teamSize;

    private String roleinProject;

	private String skillsUsed;

    private String createdby;

    private LocalDateTime createdts;

    private String updatedby;

    private LocalDateTime updatedts;
}
