package com.wue.dto.drill;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DrillTeamUpdateDto {
    private int teamSize;
    private String teamDescription;
    private boolean lookingForTeamMate;
    private String Reason;
}
