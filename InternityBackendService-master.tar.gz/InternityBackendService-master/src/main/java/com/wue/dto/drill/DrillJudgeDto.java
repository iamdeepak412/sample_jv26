package com.wue.dto.drill;


import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Data
public class DrillJudgeDto {
	private String judgeId;
	private String drillId;
	private String judgeName;
	private String judgeDesignation;
	private String judgeEmail;
	private String judgeContact;
	private String judgeTitle;
	private String judgeOrganisation;
	private String key;
	private String judgementLink;
	private String phaseId;
	private String phaseName;
	private String panelId;
	private String panelName;
	private Date createdTs;
	private Date updatedTs;
	private String createdBy;
	private String updatedBy;
}
