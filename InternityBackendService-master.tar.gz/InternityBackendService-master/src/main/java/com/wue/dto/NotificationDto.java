package com.wue.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Data
public class NotificationDto {
	private Long notificationId;
	private String senderUid;
	private String receiverUid;
	private boolean isRead;
	private String oneLiner;
	private String message;
	private String notificationType;
	private Date createdTs;
	private Date updatedTs;
	private String createdBy;
	private String updatedBy;
}
