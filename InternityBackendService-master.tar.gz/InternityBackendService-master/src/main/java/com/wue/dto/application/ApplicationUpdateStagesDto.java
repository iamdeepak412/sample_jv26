package com.wue.dto.application;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationUpdateStagesDto {

    private String newStatus;
    private String newSubStatus;
    private String feedback;
    private String otherText;

}