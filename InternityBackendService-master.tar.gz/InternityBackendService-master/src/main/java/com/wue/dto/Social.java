package com.wue.dto;

import lombok.Data;

@Data
public class Social {
    private String platform;
    private String link;
}
