package com.wue.dto.drill;


import com.wue.constant.drill.Stage;
import com.wue.domain.drill.DrillParticipant;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class DrillParticipantInfo {
	private String participantId;
	private String participantFullName;
	private String participantImgUrl;
	private String participantSkills;
	private String participantValue;
	private boolean isLead;
	private Stage stage;

	private DrillParticipant drillParticipant;
}
