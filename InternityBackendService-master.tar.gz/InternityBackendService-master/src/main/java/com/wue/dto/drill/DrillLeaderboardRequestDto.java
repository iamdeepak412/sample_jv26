package com.wue.dto.drill;

import com.wue.constant.drill.DrillWinnerType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@Builder
public class DrillLeaderboardRequestDto {

    private String position;
    private boolean isProjectShow;
    private String phaseId;
    private DrillWinnerType winnerType;
}
