package com.wue.dto;

import java.util.Date;


import com.fasterxml.jackson.annotation.JsonView;
import com.wue.domain.Job;
import com.wue.domain.drill.Drill;
import com.wue.repository.drill.DrillRepository;
import lombok.*;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Component
@Scope("prototype")
public class JobDto {

	@JsonView(SearchProfiles.Basic.class)
	private String jobId;

	@JsonView(SearchProfiles.Basic.class)
	private String jobRequisitionId;

	@JsonView(SearchProfiles.Basic.class)
	private String partnerId;

	@JsonView(SearchProfiles.Basic.class)
	private String jobType;

	@JsonView(SearchProfiles.Basic.class)
	private String jobTitle;

	@JsonView(SearchProfiles.Basic.class)
	private String jobLocation;

	@JsonView(SearchProfiles.Basic.class)
	private String jobIndustryCategory;

	@JsonView(SearchProfiles.Basic.class)
	private String jobSkills;

	@JsonView(SearchProfiles.Basic.class)
	private String jobMusthave;

	@JsonView(SearchProfiles.Basic.class)
	private String jobDomain;

	@JsonView(SearchProfiles.Basic.class)
	private Double jobMinCtcRange;

	@JsonView(SearchProfiles.Basic.class)
	private Double jobMaxCtcRange;

	@JsonView(SearchProfiles.Basic.class)
	private String jobCtcCurrency;

	@JsonView(SearchProfiles.Basic.class)
	private Boolean jobEsopAcceptance;

	@JsonView(SearchProfiles.Basic.class)
	private Double jobMinYoe;

	@JsonView(SearchProfiles.Basic.class)
	private Double jobMaxYoe;

	@JsonView(SearchProfiles.Basic.class)
	private String partnerName;

	@JsonView(SearchProfiles.Detailed.class)
	private String jobDescription;

	@JsonView(SearchProfiles.Basic.class)
	private Integer jobNumberOfVacancies;

	@JsonView(SearchProfiles.Basic.class)
	private String jobNoticePeriodAcceptable;

	@JsonView(SearchProfiles.Basic.class)
	private String jobScreeningQuestions;

	@JsonView(SearchProfiles.Basic.class)
	private String otherTags;

	@JsonView(SearchProfiles.Basic.class)
	private String jobPriority;

	@JsonView(SearchProfiles.Basic.class)
	private Boolean isActive;

	@JsonView(SearchProfiles.Basic.class)
	private Boolean isCompanyNameHidden;

	@JsonView(SearchProfiles.Basic.class)
	private String jobPostedBy;

	@JsonView(SearchProfiles.Basic.class)
	private String jobImageLink;

	@JsonView(SearchProfiles.Basic.class)
	private String jdLink;

	@JsonView(SearchProfiles.Basic.class)
	private String jobRounds;

	@JsonView(SearchProfiles.Basic.class)
	private Long jobApplicantCount;

	@JsonView(SearchProfiles.Basic.class)
	private boolean isSalaryHidden;

	@JsonView(SearchProfiles.Basic.class)
	private String custUrl;

	@JsonView(SearchProfiles.Basic.class)
	private String jobYoeTextForZero;

	@JsonView(SearchProfiles.Basic.class)
	private Date createdTs;

	@JsonView(SearchProfiles.Basic.class)
	private Date updatedTs;

	@JsonView(SearchProfiles.Basic.class)
	private String createdBy;

	@JsonView(SearchProfiles.Basic.class)
	private String updatedBy;

	@JsonView(SearchProfiles.Basic.class)
	private boolean isFeatured=false;

	@JsonView(SearchProfiles.Basic.class)
	private String duration;

	@JsonView(SearchProfiles.Basic.class)
	private boolean pastInternshipExperience;

	@JsonView(SearchProfiles.Basic.class)
	private String jobCtcCategory;

	@JsonView(SearchProfiles.Basic.class)
	private Drill drill;

	public JobDto(Job job, DrillRepository drillRepository) {
		this.jobId = job.getJobId();
		this.jobRequisitionId=job.getJobRequisitionId();
		this.partnerId = job.getPartnerId();
		this.jobType = job.getJobType();
		this.jobTitle = job.getJobTitle();
		this.jobLocation = job.getJobLocation();
		this.jobIndustryCategory = job.getJobIndustryCategory();
		this.jobSkills = job.getJobSkills();
		this.jobMusthave = job.getJobMusthave();
		this.jobDomain = job.getJobDomain();
		this.jobMinCtcRange = job.getJobMinCtcRange();
		this.jobMaxCtcRange = job.getJobMaxCtcRange();
		this.jobCtcCurrency = job.getJobCtcCurrency();
		this.jobEsopAcceptance = job.getJobEsopAcceptance();
		this.jobMinYoe = job.getJobMinYoe();
		this.jobMaxYoe = job.getJobMaxYoe();
		this.jobDescription = job.getJobDescription();
		this.jobNumberOfVacancies = job.getJobNumberOfVacancies();
		this.jobNoticePeriodAcceptable = job.getJobNoticePeriodAcceptable();
		this.jobScreeningQuestions = job.getJobScreeningQuestions();
		this.otherTags = job.getOtherTags();
		this.jobPriority = job.getJobPriority();
		this.isActive = job.getIsActive();
		this.isCompanyNameHidden = job.getIsCompanyNameHidden();
		this.jobPostedBy = job.getJobPostedBy();
		this.jobImageLink = job.getJobImageLink();
		this.jdLink = job.getJdLink();
		this.jobRounds = job.getJobRounds();
		this.createdTs = job.getCreatedTs();
		this.updatedTs = job.getUpdatedTs();
		this.createdBy = job.getCreatedBy();
		this.updatedBy = job.getUpdatedBy();
		this.partnerName = job.getPartnerName();
		this.jobApplicantCount = job.getJobApplicantCount();
		this.isSalaryHidden = job.getIsSalaryHidden();
		this.custUrl = job.getCustUrl();
		this.jobYoeTextForZero = job.getJobYoeTextForZero();
		this.duration = job.getDuration();
		this.pastInternshipExperience = job.isPastInternshipExperience();
		this.jobCtcCategory=job.getJobCtcCategory();
		if (job.getDrillId() != null) {
            this.drill = drillRepository.findById(job.getDrillId()).orElse(null);
		}
	}
}
