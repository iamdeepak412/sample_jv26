package com.wue.dto.drill;

import com.wue.constant.drill.ParticipatedDrillStatus;
import com.wue.domain.drill.Drill;
import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class ParticipatedDrillStatusDto {
    private Drill drillDetails;
    private ParticipatedDrillStatus status;
}
