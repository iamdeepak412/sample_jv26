package com.wue.dto;

public class TheCpSquadDto {

}
