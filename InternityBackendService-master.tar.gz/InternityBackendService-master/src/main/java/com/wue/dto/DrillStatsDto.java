package com.wue.dto;

import lombok.Data;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.Date;

@Component
@Data
public class DrillStatsDto {

	private String drillId;

	private Long numberOfDrillParticipantsInDays;

	private Long numberOfImpressionsInDays;

	private Long totalNumberOfDrillParticipants;


	@Column(name = "numb_users_in_one_day")
	private Long numberOfUsersInOneDay;

	@Column(name = "numb_jobs_in_one_day")
	private Long numberOfJobPostedInOneDay;

	@Column(name = "numb_platform_views_in_one_day")
	private Long numberOfPlatformViewsInOneDay;

	@Column(name = "numb_job_views_in_one_day")
	private Long numberOfJobViewsInOneDay;

	@Column(name = "user_updatedby", length = 100)
    private String userUpdatedby;

    @Column(name = "record_insertedts")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date recordInsertedts;
	
    @Column(name = "numb_squad")
	private int numberOfSquadPrograms;

    @Column(name = "numb_hackathons")
	private int numberOfHackathons;

	@Transient
	private int numberOfProfessionalsUsers;

	@Transient
	private int numberOfFreshersUsers;

	@Transient
	private int numberOfFresherHired;
	
	@Transient
	private int numberOfInternsHired;
	
	@Transient
	private int numberOfmeetups;
	
	@Transient
	private int numberOfColleges;
	
	@Transient
	private int numberOfFresherDrives;
	
	@Transient
	private int numberOfStudentsInSquad;
	
}
