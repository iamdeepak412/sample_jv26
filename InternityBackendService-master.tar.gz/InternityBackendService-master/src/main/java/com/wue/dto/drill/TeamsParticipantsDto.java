package com.wue.dto.drill;

import com.wue.constant.drill.Stage;
import com.wue.domain.drill.TeamsParticipants;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TeamsParticipantsDto {

    private String drillId;
    private String teamId;
    private String participantId;
    private boolean isRequestAccepted;
    private String participantValue;
    private Stage stage;


    public TeamsParticipantsDto(TeamsParticipants teamsParticipants) {
        this.drillId = teamsParticipants.getDrillId();
        this.teamId = teamsParticipants.getTeamId();
        this.participantId = teamsParticipants.getParticipantId();
        this.isRequestAccepted = teamsParticipants.isRequestAccepted();
        this.stage = teamsParticipants.getStage();
    }
}
