package com.wue.dto.drill;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Date;

@Component
@Getter
@Setter
@ToString
public class DrillPhasesDto {

	private String phaseId;
	private String drillId;
	private String phaseName;
	private String phaseType;
	private String phaseDesc;
	private String phaseTimezone;
	private LocalDateTime phaseStartDt;
	private LocalDateTime phaseEndDt;
	private boolean isDateConfirmed;
	private String startMonth;
	private String endMonth;
	private LocalDateTime phaseSubmissionEndDt;
	private String phaseMode;
	private String phaseLoc;
	private String phaseStatus;
	private boolean isHidden;
	private boolean isSubmissionAllowed;
	private boolean isSolutionSubmittedByParticipant;

	private Date createdTs;

	private Date updatedTs;

	private String createdBy;

	private String updatedBy;

}
