package com.wue.dto;

import com.wue.domain.blog.CommentReaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BlogPostCommentResponseDto {

    private String commentId;
    private String blogpostId;
    private String uId;
    private String content;
    private String parentCommentId;
    private Date recordCreatedTs;
    private Date recordUpdatedTs;
    private String commenterName;
    private String commenterImageUrl;
    private long commentReactionCount;
    private long reportAbuseCount;
    private CommentReaction commentReaction;
    private long childCommentsCount;
}

