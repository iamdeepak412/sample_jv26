package com.wue.dto.assessprofile;


import com.wue.domain.UserCandidateMandatoryFields;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Data
public class FinalAssessedProfileDetails {
	private Long applicationId;
	private String jobId;
	private String uId;
	private String name;
	private String email;
	private String contact;
	private String resumeLink;
	private String status;
	private String subStatus;
	private Date lastUpdated;
	private String expectedSkills;
	private String actualSkills;
	private Double skillScore;
	private String expectedYoe;
	private Double actualYoe;
	private Double yoeScore;
	private Double isDecidingQuestionScore;
	private String customQuestionMap;
	private UserCandidateMandatoryFields userCandidateMandatoryFields;
}
