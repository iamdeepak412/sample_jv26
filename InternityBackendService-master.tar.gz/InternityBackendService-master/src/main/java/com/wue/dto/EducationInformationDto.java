package com.wue.dto;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class EducationInformationDto {
	
	private Long eduInfoCount;
	
	private String uId;
	
    private String instituteName;

    private String degree;
    
    private boolean isPursuing;
    
    private String studyField;
    
    private String cgpaPercentage;
    
    private LocalDateTime startDate;

    private LocalDateTime endDate;

    private String jobLocation;

    private String createdby;

    private LocalDateTime createdts;

    private String updatedby;

    private LocalDateTime updatedts;
}
