package com.wue.factory;

import com.wue.user.profile.*;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

@Service
public class UserProfileFactory implements ApplicationContextAware{
	
	private static ApplicationContext context;

	public static ProfileSection getProfileSection(String section) {

		switch (section) {
			case "personal":
				return UserProfileFactory.context.getBean(PersonalDetails.class);
			case "education":
				return UserProfileFactory.context.getBean(EducationDetails.class);
			case "work":
				return UserProfileFactory.context.getBean(WorkDetails.class);
			case "skill":
				return UserProfileFactory.context.getBean(SkillDetails.class);
			case "other":
				return UserProfileFactory.context.getBean(UserOtherDetailsSection.class);
			case "project":
				return UserProfileFactory.context.getBean(UserProjectDetails.class);
			default:
				break;
		}
		return null;
	}

	public static <T> T getBean(Class<T> beanClass) {
        return context.getBean(beanClass);
    }
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		UserProfileFactory.context = applicationContext;
	}
}
