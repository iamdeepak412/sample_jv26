package com.wue.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.wue.constant.SearchProfile;
import com.wue.custom.specification.SearchBlogPostCriteria;
import com.wue.custom.specification.SearchDrillTeamCriteria;
import com.wue.custom.specification.SearchReportAbuseCriteria;
import com.wue.domain.blog.*;
import com.wue.dto.response.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wue.dto.BlogPostUpdateRequestDto;
import com.wue.service.BlogService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;

import lombok.extern.log4j.Log4j2;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/")
@Log4j2
public class BlogController {

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    BlogService blogService;

    @PostMapping("api/v1/blogs")
    public Response saveBlogPost(@RequestBody BlogPost payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.saveBlogPost(payload, user);
    }

    @GetMapping("api/v1/blogs/search")
    public Response getAllBlogPosts(
            @RequestParam(defaultValue = "NA", required = false) String uId,
            @RequestParam(defaultValue = "NA", required = false) String categoryId,
            @RequestParam(defaultValue = "NA", required = false) String name,
            @RequestParam(defaultValue = "NA", required = false) String tags,
            @RequestParam(defaultValue = "NA", required = false) String content,
            @RequestParam(defaultValue = "NA", required = false) String categoryName,
            @RequestParam(defaultValue = "NA", required = false) String blogpostId,
            @RequestParam(defaultValue = "NA", required = false) String custUrl,
            @RequestParam(defaultValue = "0", required = false) int offset,
            @RequestParam(defaultValue = "10", required = false) int limit,
            @RequestParam(defaultValue = "recordUpdatedTs.desc", required = false) String order,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
            @RequestParam(defaultValue = "NA", required = false) String title,
            @RequestParam(defaultValue = "false", required = false) boolean isActive,
            @RequestParam(defaultValue = "false", required = false) boolean isFeatured,
            HttpServletRequest request
    ) {
        InternityUser user = commonUtils.setUser(request);
        SearchBlogPostCriteria searchCriteria = SearchBlogPostCriteria.builder()
                .uId(uId)
                .categoryId(categoryId)
                .name(name)
                .categoryName(categoryName)
                .tags(tags)
                .content(content)
                .blogpostId(blogpostId)
                .custUrl(custUrl)
                .title(title)
                .isActive(isActive)
                .isFeatured(isFeatured)
                .build();
        return blogService.getBlogPosts(searchCriteria, offset, limit, order, profile, user);

    }

    @PutMapping("api/v1/blogs/{blogPostId}")
    public Response updateBlogPost(
            @PathVariable String blogPostId,
            @RequestBody BlogPost payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.updateBlogPost(blogPostId, payload, user);
    }

    @PutMapping("api/v1/blogs/{blogpostId}/{status}")
    public Response updateBlogPostStatus(@PathVariable String blogpostId,
                                         @PathVariable String status,
                                         @RequestParam String uId,
                                         @RequestBody BlogPostUpdateRequestDto updateRequest,
                                         HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.updateBlogPostStatus(blogpostId, status, uId, updateRequest, user);
    }

    @PostMapping("api/v1/blogs/categories")
    public Response saveBlogCategory(@RequestBody BlogCategory payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.saveBlogCategory(payload, user);
    }

    @GetMapping("api/v1/blogs/categories")
    public Response getBlogCategories(@RequestParam(defaultValue = "NA", required = false) String categoryId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.getBlogCategories(categoryId, user);
    }

    @PutMapping("api/v1/blogs/categories/{categoryId}")
    public Response updateBlogCategory(@PathVariable String categoryId, @RequestBody BlogCategory payload,
                                       HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.updateBlogCategory(categoryId, payload, user);
    }

    @PostMapping("api/v1/blogs/comments")
    public Response saveComment(@RequestBody Comment payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.saveComment(payload, user);
    }

    @GetMapping("api/v1/blogs/comments")
    public Response getComments(@RequestParam(defaultValue = "NA", required = false) String commentId,
                                @RequestParam(defaultValue = "NA", required = false) String blogpostId,
                                @RequestParam(defaultValue = "NA", required = false) String uId,
                                @RequestParam(defaultValue = "NA", required = false) String parentCommentId,
                                HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.getComments(commentId, blogpostId, uId, user, parentCommentId);
    }

    @PutMapping("api/v1/blogs/comments/{commentId}")
    public Response updateComment(@PathVariable String commentId, @RequestBody Comment payload,
                                  HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.updateComment(commentId, payload, user);
    }

    @PostMapping("api/v1/blogs/reactions")
    public Response saveReaction(@RequestBody Reaction payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.saveReaction(payload, user);
    }

    @GetMapping("api/v1/blogs/reactions")
    public Response getReactions(@RequestParam(defaultValue = "NA", required = false) String reactionId,
                                 @RequestParam(defaultValue = "NA", required = false) String postId,
                                 @RequestParam(defaultValue = "NA", required = false) String uId,
                                 HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.getReactions(reactionId, postId, uId, user);
    }

    @PutMapping("api/v1/blogs/reactions/{reactionId}")
    public Response updateReaction(@PathVariable String reactionId, @RequestBody Reaction payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.updateReaction(reactionId, payload, user);
    }

    @GetMapping("api/v1/blogs/reportabuse")
    public Response getReportAbuseEntries(@RequestParam(defaultValue = "NA", required = false) String reportId,
                                          @RequestParam(defaultValue = "NA", required = false) String postId,
                                          HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.getReportAbuseEntries(reportId, postId, user);
    }

    @PostMapping("api/v1/blogs/reportabuse")
    public Response saveReportAbuse(@RequestBody ReportAbuse payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.saveReportAbuse(payload, user);
    }

    @GetMapping("api/v1/blogs/reactiontypes")
    public Response getAllReactionTypes(@RequestParam(defaultValue = "NA", required = false) String reactionTypeId,
                                        HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.getAllReactionTypes(reactionTypeId, user);
    }

    @PostMapping("api/v1/blogs/reactiontypes")
    public Response saveReactionTypes(@RequestBody ReactionType payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.saveReactionType(payload, user);
    }

    @PostMapping("api/v1/blogs/sharecount/{blogPostId}")
    public Response addBlogPostShareCount(@PathVariable String blogPostId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.addBlogPostShareCount(blogPostId, user);
    }

    @GetMapping("api/v1/blogs/sharecount/{blogPostId}")
    public Response getBlogPostShareCount(@PathVariable String blogPostId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.getBlogPostShareCount(blogPostId, user);
    }

    @PostMapping("api/v1/blogs/comment/reactions")
    public Response saveCommentReaction(@RequestBody CommentReaction payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.saveCommentReaction(payload, user);
    }

    @PutMapping("api/v1/blogs/comment/reactions/{commentReactionId}")
    public Response updateCommentReaction(@PathVariable String commentReactionId, @RequestBody CommentReaction payload, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.updateCommentReaction(commentReactionId, payload, user);
    }

    @GetMapping("api/v1/blogs/comment/reactions")
    public Response getCommentReactions(@RequestParam(defaultValue = "NA", required = false) String commentReactionId,
                                        @RequestParam(defaultValue = "NA", required = false) String commentId,
                                        @RequestParam(defaultValue = "NA", required = false) String uId,
                                        @RequestParam(defaultValue = "NA", required = false) String blogPostId,
                                        HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return blogService.getCommentReactions(commentReactionId, commentId, uId, blogPostId, user);
    }

    @GetMapping("api/v1/blogs/reportabuse/search")
    public Response searchReportAbuseSearch(
            @RequestParam(defaultValue = "NA") String reportId,
            @RequestParam(defaultValue = "NA") String postId,
            @RequestParam(defaultValue = "NA") String uId,
            @RequestParam(defaultValue = "NA") String commentId,
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10") int limit,
            @RequestParam(defaultValue = "recordCreatedTs.desc") String order,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
            HttpServletRequest request
    ) {
        InternityUser user = commonUtils.setUser(request);
        SearchReportAbuseCriteria searchCriteria = new SearchReportAbuseCriteria(reportId, postId, uId, commentId);

        return blogService.getReportAbuseEntriesSearch(searchCriteria, offset, limit, order, user, profile);
    }

}
