package com.wue.controller.drill;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wue.constant.SearchProfile;
import com.wue.domain.drill.submission.ConfigureSubmissionFields;
import com.wue.domain.drill.submission.DefaultSubmissionFields;
import com.wue.domain.drill.submission.DrillParticipantSubmission;
import com.wue.domain.drill.submission.DrillSubmissionEvaluation;
import com.wue.dto.drill.UserSubmissionResultDto;
import com.wue.dto.drill.judgement.FinalEvaluationDto;
import com.wue.dto.drill.submission.search.DrillSubmissionSearchCriteria;
import com.wue.dto.drill.submission.search.DrillSubmissionSearchResultDto;
import com.wue.repository.drill.DrillRepository;
import com.wue.service.drill.DrillService;
import com.wue.service.drill.DrillSubmissionService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
@Log4j2
@RequestMapping("/")
public class DrillSubmissionController {

	@Autowired
	DrillRepository drillRepository;

	@Autowired
	DrillService drillService;

	@Autowired
	DrillSubmissionService drillSubmissionService;

	@Autowired
	CommonUtils commonUtils;

	@PostMapping("api/v1/drills/{drillId}/submissions")
	public ResponseEntity<?> addOrUpdate(@RequestBody DrillParticipantSubmission payload,
										 @PathVariable String drillId,
										 HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		payload.setDrillId(drillId);
		Object responseObj = drillSubmissionService.saveDrillSubmission(payload, user);
		if(responseObj instanceof DrillParticipantSubmission){
			return new ResponseEntity<>(responseObj, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(responseObj, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("api/v1/drills/{drillId}/submissions/idea")
	public ResponseEntity<?> addOrUpdateIdeaSubmission(@RequestBody DrillParticipantSubmission payload,
													   @PathVariable String drillId,
													   HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		payload.setDrillId(drillId);
		Object responseObj = drillSubmissionService.saveDrillIdeaSubmission(payload, user);
		if(responseObj instanceof DrillParticipantSubmission){
			return new ResponseEntity<>(responseObj, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(responseObj, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("api/v1/drills/{drillId}/submissions")
	public DrillSubmissionSearchResultDto getDrillSubmissions(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "all", required = false) String teamId,
			@RequestParam(defaultValue = "all", required = false) String theme,
			@RequestParam(defaultValue = "all", required = false) String participantId,
			@RequestParam(defaultValue = "all", required = false) String panelId,
			@RequestParam(defaultValue = "all", required = false) String phaseId,
			@RequestParam(defaultValue = "all", required = false) String participantEmail,
			@RequestParam(defaultValue = "all", required = false) String teamName,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
			@RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		DrillSubmissionSearchCriteria searchCriteria = DrillSubmissionSearchCriteria.builder()
				.drillId(drillId)
				.teamId(teamId)
				.theme(theme)
				.participantId(participantId)
				.phaseId(phaseId)
				.panelId(panelId)
				.participantEmail(participantEmail)
				.teamName(teamName)
				.build();
		return drillSubmissionService.searchDrillSubmissions(
				searchCriteria, offset, limit, order, profile.name());

	}

	@GetMapping("api/v1/drills/{drillId}/submissions/download")
	public ResponseEntity<InputStreamResource> downloadDrillSubmissions(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "all", required = false) String teamId,
			@RequestParam(defaultValue = "all", required = false) String theme,
			@RequestParam(defaultValue = "all", required = false) String participantId,
			@RequestParam(defaultValue = "all", required = false) String panelId,
			@RequestParam(defaultValue = "all", required = false) String phaseId,
			@RequestParam(defaultValue = "all", required = false) String participantEmail,
			@RequestParam(defaultValue = "all", required = false) String teamName,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "1000000", required = false) int limit,
			@RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
			@RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
			HttpServletRequest request, HttpServletResponse response){
		InternityUser user = commonUtils.setUser(request);
		DrillSubmissionSearchCriteria searchCriteria = DrillSubmissionSearchCriteria.builder()
				.drillId(drillId)
				.teamId(teamId)
				.theme(theme)
				.participantId(participantId)
				.phaseId(phaseId)
				.panelId(panelId)
				.participantEmail(participantEmail)
				.teamName(teamName)
				.build();
		String filename = "allSubmissions"+drillId+".csv";
		DrillSubmissionSearchResultDto resultDto = drillSubmissionService.searchDrillSubmissions(
				searchCriteria, offset, limit, order, profile.name());
		InputStreamResource file = new InputStreamResource(drillSubmissionService.getSubmissionCSVLoad(resultDto.getData()));

		response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename);
		return ResponseEntity.ok()
				.contentType(MediaType.parseMediaType("application/csv"))
				.body(file);

	}

	//Configure Submission fields
	@PostMapping("api/v1/drills/{drillId}/submissionFields/configure")
	public ResponseEntity<?> addorUpdateSubmissionFields(@RequestBody ConfigureSubmissionFields payload,
														 HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService.saveOrUpdateSubmissionFields(payload, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/submissionFields")
	public ResponseEntity<?> fetchDrillSubmissionFields(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.fetchDrillSubmissionFields(drillId, phaseId, user), HttpStatus.OK);
	}

	//Configure DEFAULT Submission fields
	@PostMapping("api/v1/drills/submissionFields/default")
	public ResponseEntity<?> addorUpdateDefaultSubmissionFields(@RequestBody DefaultSubmissionFields payload,
																HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService.saveOrUpdateDefaultSubmissionFields(payload, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/submissionFields/default")
	public ResponseEntity<?> fetchDefaultSubmissionFields(
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.fetchDefaultSubmissionFields(user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/judges/{judgeId}/teamSubmissions")
	public ResponseEntity<?> fetchDrillTeamSubmission(
			@PathVariable String drillId,
			@PathVariable String judgeId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.fetchDrillTeamSubmission(drillId, judgeId, phaseId, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/submissions/individualSubmission")
	public ResponseEntity<?> fetchIndividualSubmission(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String submissionId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String teamId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.fetchIndividualSubmission(drillId, phaseId,  teamId, submissionId, user), HttpStatus.OK);
	}

	@PostMapping("api/v1/drills/{drillId}/submissions/{submissionId}/judges/{judgeId}/evaluation")
	public ResponseEntity<?> saveDrillSubmissionEvaluation(@RequestBody DrillSubmissionEvaluation payload,
														   HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService.saveDrillSubmissionEvaluation(payload, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/submissions/individualSubmission/previous")
	public ResponseEntity<?> fetchDrillEvaluation(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String teamId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String submissionId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.fetchPreviousDrillEvaluation(drillId, phaseId, teamId, submissionId, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/submissions/evaluations")
	public ResponseEntity<?> fetchDrillEvaluation(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String submissionId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.fetchDrillEvaluation(drillId, submissionId, judgeId, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/submissions/evaluations/all")
	public ResponseEntity<?> fetchDrillEvaluation1(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String submissionId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.fetchDrillAllEvaluation(drillId, submissionId, judgeId, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/submissions/evaluations/search")
	public ResponseEntity<?> searchDrillEvaluation(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String panelId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.searchEvaluationv2(drillId, phaseId, panelId, judgeId, user), HttpStatus.OK);
	}
	@GetMapping("api/v1/drills/{drillId}/submissions/evaluations/export")
	public ResponseEntity<byte[]> exportDrillEvaluation(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String panelId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		responseHeaders.setContentDisposition(
				ContentDisposition.builder("inline").filename("Evaluation Data.xlsx").build());

		return new ResponseEntity<>(
				drillSubmissionService.exportEvaluationv2(drillId, phaseId, panelId, judgeId, user),
				responseHeaders,
				HttpStatus.OK);
	}

	@GetMapping(value = "api/v1/drills/{drillId}/submissions/evaluations/search/download")
	public ResponseEntity<InputStreamResource> downloadFinalEvaluation(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String panelId,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			InternityUser user = commonUtils.setUser(request);

			ObjectMapper objectMapper = new ObjectMapper();

			List<FinalEvaluationDto> finalEvaluationDtoList = objectMapper
					.convertValue(drillSubmissionService.downloadSearchEvaluationv2(drillId, phaseId, panelId, judgeId, user), List.class);

			String filename = "finalEvaluationDtoList.csv";

			InputStreamResource file = new InputStreamResource(drillSubmissionService.getCSVLoadOfFinalResult(finalEvaluationDtoList));

			response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename);
			return ResponseEntity.ok()
					.contentType(MediaType.parseMediaType("application/csv"))
					.body(file);

		}
		catch(Exception e) {
			log.error("Exception while exporting the complete evaluation ::: {}", e);
			return null;
		}
	}

	@GetMapping("api/v1/drills/{drillId}/submissions/evaluations/extended")
	public ResponseEntity<?> searchExtendedDrillEvaluation(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String panelId,
			@RequestParam(defaultValue = "NA", required = false) String teamName,
			@RequestParam(defaultValue = "ASC", required = false) String sortOrder,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.searchEvaluationv3(drillId, phaseId, panelId, judgeId,teamName,sortOrder,user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/submissions/evaluations/extended/export")
	public ResponseEntity<byte[]> exportExtentedDrillEvaluation(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String panelId,
			@RequestParam(defaultValue = "NA", required = false) String teamName,
			@RequestParam(defaultValue = "ASC", required = false) String sortOrder,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);

		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		responseHeaders.setContentDisposition(
				ContentDisposition.builder("inline").filename("Extended Evaluation Data.xlsx").build());

		return new ResponseEntity<>(
				drillSubmissionService.exportEvaluationv3(drillId, phaseId, panelId, judgeId,teamName,sortOrder, user),
				responseHeaders,
				HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{judgeId}/judgement/{drillId}/key/{key}")
	public ResponseEntity<?> drillJudgeUrl(
			@PathVariable String drillId,
			@PathVariable String judgeId,
			@PathVariable String key,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService
				.drillJudgeUrlWithKey(drillId,judgeId,key, user), HttpStatus.OK);
	}



	//ToDo
	@GetMapping("api/v1/drills/{drillId}/leaderboard")
	public ResponseEntity<?> drillLeaderboard(
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "Basic", required = false) String profile,
			HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			Object leaderboardData = drillSubmissionService.getDrillLeaderBoard(drillId, phaseId, profile, user);

			if (leaderboardData instanceof List<?>) {
				// Check if the returned data is a list (indicating success)
				return new ResponseEntity<>(leaderboardData, HttpStatus.OK);
			} else {
				// Handle custom error message returned by the service
				Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch drill leaderboard");
				return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Error while fetching drill leaderboard: " + e.getMessage(), e);
			Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Error while fetching drill leaderboard: " + e.getMessage());
			return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/api/v1/drills/user/{uId}/submissions")
	public ResponseEntity<?> allSubmissionByAnUser(
			@PathVariable(required = false) String uId,
			HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			UserSubmissionResultDto userSubmissions = drillSubmissionService.allSubmissionByAnUser(uId, user);
			return new ResponseEntity<>(userSubmissions, HttpStatus.OK);
		} catch (Exception e) {
			// Log the exception for debugging
			log.error("Exception while fetching all submission by an user: " + e.getMessage(), e);
			return new ResponseEntity<>(Collections.emptyList(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("api/v1/drills/{phaseId}/shortlist/submissions")
	public ResponseEntity<?> getDrillSubmissionShortlist(@PathVariable String phaseId,
														 @RequestParam(required = false) String marksThreshold,
														 @RequestParam(required = false) Map<String,String> submissionResultMap,
														 HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return drillSubmissionService.getDrillSubmissionShortlist(phaseId,marksThreshold,submissionResultMap, user);

	}

	@GetMapping("api/v1/drills/{drillId}/phase/{phaseId}/submissions")
	public ResponseEntity<?> getDrillActiveSubmissionOfPhase(@PathVariable String drillId,@PathVariable String phaseId,
															 HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return drillSubmissionService.getDrillActiveSubmissionOfPhase(drillId,phaseId, user);
	}
}
