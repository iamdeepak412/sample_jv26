package com.wue.controller.drill;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wue.constant.drill.certificate.DrillCertificateEventType;
import com.wue.constant.drill.certificate.DrillCertificateTo;
import com.wue.constant.drill.certificate.DrillCertificateType;
import com.wue.dto.drill.certificate.DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto;
import com.wue.repository.drill.DrillRepository;
import com.wue.service.drill.DrillCertificateService;
import com.wue.service.drill.DrillService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

@Log4j2
@RestController
@RequestMapping("/")

public class DrillCertificateGeneratorController {

    @Autowired
    DrillRepository drillRepository;

    @Autowired
    DrillService drillService;

    @Autowired
    CommonUtils commonUtils;
    @Autowired
    private DrillCertificateService certificateService;

    @PostMapping("/api/v1/drill/{drillId}/generate/certificates")
    public ResponseEntity<?> generateCertificates(
            @PathVariable String drillId,
            @RequestParam(name ="uId") String uId,
            @RequestParam("templateId") String templateId,
            @RequestParam("certificateType") DrillCertificateType certificateType,
            @RequestParam(name ="certificateTo", required = false) DrillCertificateTo certificateTo,
            @RequestParam(name = "restrictedList", required = false) List<String> restrictedList,
            @RequestParam(name = "extraParticipantsList", required = false) List<String> extraParticipantsList,
            @RequestParam(name = "winnersList", required = false) List<String> winnersList,
            @RequestParam(name = "otherList", required = false) List<String> otherList,
            @RequestParam(name="phaseId",required = false) String phaseId,
            @RequestParam(name ="eventType")DrillCertificateEventType eventType,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return certificateService.generateCertificates(drillId,uId,templateId, certificateType, certificateTo,
                                                       restrictedList, extraParticipantsList,winnersList,
                                                       otherList,phaseId,eventType,user);

    }

    @GetMapping("/api/v1/drill/download/certificates/{id}")
    public ResponseEntity<?> downloadCertificate(@PathVariable String id, HttpServletRequest request) throws IOException {

        InternityUser user = commonUtils.setUser(request);
        return certificateService.downloadCertificate(id,user);

    }

    @GetMapping("/api/v1/drill/preview/certificates/{id}")

    public ResponseEntity<?> previewCertificate(@PathVariable String id, HttpServletRequest request) throws IOException {

        InternityUser user = commonUtils.setUser(request);
        return certificateService.previewCertificate(id,user);

    }

    @GetMapping("/api/v1/drill/preview/demo/certificates")
    public ResponseEntity<?> previewDemoCertificate(
            @RequestPart(name = "image", required = false) MultipartFile imageFile,
            @RequestPart(name = "imageUrl", required = false) String imageUrl,
            @RequestPart("data") List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data,
            HttpServletRequest request) throws IOException {

        InternityUser user = commonUtils.setUser(request);
        return certificateService.previewDemoCertificate(imageFile, data, imageUrl,null,user);
    }

    @PostMapping("/api/v1/drill/{drillId}/template/certificates")
    public ResponseEntity<?> saveCertificateTemplate(@PathVariable String drillId,
                                                     @RequestPart(name ="uId") String uId,
                                                     @RequestPart("templateName") String templateName,
                                                     @RequestPart(name = "image", required = false) MultipartFile imageFile,
                                                     @RequestPart(name = "imageUrl", required = false) String imageUrl,
                                                     @RequestPart("data") List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> data,
                                                     HttpServletRequest request) {

        InternityUser user = commonUtils.setUser(request);
        return certificateService.saveCertificateTemplate(drillId, data, imageFile, imageUrl, uId, templateName,user);
    }
    @GetMapping("/api/v1/drill/template/preview/certificates/{id}")
    public ResponseEntity<?> getCertificateTemplatePreview(@PathVariable String id,HttpServletRequest request) throws JsonProcessingException {
        InternityUser user = commonUtils.setUser(request);
        return certificateService.getCertificateTemplatePreview(id,user);
    }
    @GetMapping("/api/v1/drill/{drillId}/template/certificates")
    public ResponseEntity<?> getCertificateTemplate(@RequestParam(name = "id", required = false) String id, @PathVariable String drillId,HttpServletRequest request)  {
       InternityUser user = commonUtils.setUser(request);
        return certificateService.getCertificateTemplate(id, drillId,user);
    }
    @PutMapping("/api/v1/drill/template/certificates/{id}")
    public ResponseEntity<?> updateCertificateTemplate(@PathVariable String id, @RequestBody List<DrillCertificateGeneratorFieldNamesWithXYCoordinatesRequestDto> template,
                                                       HttpServletRequest request) throws JsonProcessingException {
       InternityUser user = commonUtils.setUser(request);
        return certificateService.updateCertificateTemplate(id, template,user);
    }
    @DeleteMapping("/api/v1/drill/template/certificates/{id}")
    public ResponseEntity<?> deleteCertificateTemplate(@PathVariable String id,HttpServletRequest request)  {
       InternityUser user = commonUtils.setUser(request);
        return certificateService.deleteCertificateTemplate(id,user);
    }


}
