package com.wue.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wue.dto.application.ApplicationUpdateStagesDto;
import com.wue.dto.assessprofile.FinalAssessedProfileDetails;
import com.wue.dto.response.Response;
import com.wue.dto.search.ApplicationSearchResultDto;
import com.wue.service.BulkApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.wue.domain.Application;
import com.wue.domain.ApplicationTrack;
import com.wue.dto.ApplicationDto;
import com.wue.dto.CompleteApplicationDto;
import com.wue.service.ApplicationService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;

@CrossOrigin("*")
@RestController
@RequestMapping("/")
public class ApplicationController {

	@Autowired
	CommonUtils commonUtils;

	@Autowired
	ApplicationService applicationService;

	@Autowired
	BulkApplicationService bulkApplicationService;

	@PostMapping(value = "/api/v1/jobs/application")
	public ResponseEntity<?> addorUpdateApplication(@RequestBody ApplicationDto applicationDto,
			HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			return applicationService.addApplication(applicationDto, user);
		}
		catch (Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/api/v1/jobs/application")
	public ResponseEntity<List<Application>> fetchApplications(
			@RequestParam(defaultValue = "NA", required = false) String jobId,
			@RequestParam(defaultValue = "NA", required = false) String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService.fetchAllApplications(jobId, uId, "NA", user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/application/statusenum")
	public ResponseEntity<List<Map<String, String>>> fetchApplicationsStatusEnum(
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService.fetchApplicationEnum(user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/application/substatuses")
	public ResponseEntity<List<Map<String, String>>> fetchApplicationSubStatuses(
			@RequestParam(defaultValue = "NA", required = false) String subStatusType,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService
				.fetchApplicationSubstatusEnum(subStatusType,user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/completeapplication/search")
	public ResponseEntity<List<CompleteApplicationDto>> fetchCompleteApplications(
			@RequestParam(defaultValue = "NA", required = false) String uId,
			@RequestParam(defaultValue = "NA", required = false) String jobId,
			@RequestParam(defaultValue = "NA", required = false) String applicationStatus,
			@RequestParam(defaultValue = "NA", required = false) int minYoe,
			@RequestParam(defaultValue = "NA", required = false) int maxYoe,
			@RequestParam(defaultValue = "NA", required = false) int minExpectedCtc,
			@RequestParam(defaultValue = "NA", required = false) int maxExpectedCtc,
			@RequestParam(defaultValue = "NA", required = false) LocalDateTime minLwd,
			@RequestParam(defaultValue = "NA", required = false) LocalDateTime maxLwd,
			@RequestParam(defaultValue = "NA", required = false) boolean isServingNoticePeriod,
			@RequestParam(defaultValue = "NA", required = false) String currentLoc,
			@RequestParam(defaultValue = "NA", required = false) String noticePeriodDays,
			@RequestParam(defaultValue = "NA", required = false) int limit,
			@RequestParam(defaultValue = "NA", required = false) int offset,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService
				.searchListOfCompleteApplication( uId,  jobId,  applicationStatus,
		 minYoe,  maxYoe,  minExpectedCtc,  maxExpectedCtc,  minLwd,  maxLwd,
		 isServingNoticePeriod,  currentLoc,  noticePeriodDays,  limit,  offset,  user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/completeapplication")
	public ResponseEntity<List<CompleteApplicationDto>> searchCompleteApplications(
			@RequestParam(defaultValue = "NA", required = false) String uId,
			@RequestParam(defaultValue = "NA", required = false) String jobId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService
				.fetchListOfCompleteApplication(uId, jobId, user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/application/stats")
	public ResponseEntity<Map<String, Object>> getApplicationStats(@RequestParam String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService.fetchApplicationStats(uId, user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/application/filter")
	public ResponseEntity<List<ApplicationTrack>> fetchApplicationById(@RequestParam String filter,
			HttpServletRequest request) {
		if (filter.isEmpty()) {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
		//InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService.applicationFilter(filter), HttpStatus.OK);
	}

	@PutMapping(value = "/api/v1/jobs/application/{applicationId}")
	public ResponseEntity<String> updateApplicationStatus(@PathVariable Long applicationId,
														  @RequestBody Map<String, String> payload,
														  HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return applicationService.updateApplicationStatus(applicationId, payload, user);
	}

	@PutMapping(value = "/api/v1/jobs/application/bulk")
	public ResponseEntity<Map<String, String>> updateBulkApplicationStatus(
														  @RequestBody Map<String, String> payload,
														  HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return applicationService.updateApplicationStatusInBulk(payload, user);
	}

	@GetMapping(value = "/api/v1/jobs/application/{applicationId}")
	public ResponseEntity<?> getAllApplications(
			@PathVariable Long applicationId,
			@RequestParam(required = false) String jobId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService.fetchCompleteListApplicationTrack(applicationId, jobId, user),
				HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/application/track/{applicationId}")
	public ResponseEntity<?> getAllApplicationsTrack(
			@PathVariable Long applicationId,
			@RequestParam(required = false) String jobId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(applicationService.fetchCompleteListApplicationTrackv2(applicationId, jobId, user),
				HttpStatus.OK);
	}

	@GetMapping("api/v1/jobs/application/filterapplication")
	public ApplicationSearchResultDto filterApplications(
	        @RequestParam(defaultValue = "All", required = false) String skills,
	        @RequestParam( required = false,defaultValue = "0.0") Double minCTC,
	        @RequestParam( required = false,defaultValue = "0.0") Double maxCTC,
	        @RequestParam( required = false,defaultValue = "0.0") Double minYOE,
	        @RequestParam( required = false,defaultValue = "0.0") Double maxYOE,
	        @RequestParam(required = false,defaultValue = "0") Integer noticePeriod,
	        @RequestParam(defaultValue = "All", required = false) String preferredLocation,
	        @RequestParam(defaultValue = "All", required = false) String currentLocation,
	        @RequestParam(defaultValue = "All", required = false) String currentOrganization,
	        @RequestParam(defaultValue = "All", required = false) String currentStatus,
	        @RequestParam(defaultValue = "All", required = false) String subStatus,
	        @RequestParam(required = false) String appliedTimestamp,
	        @RequestParam(required = false) String lastWorkingDay,
	        @RequestParam(required = false, defaultValue = "10") int limit,
	        @RequestParam(required = false, defaultValue = "0") int offset,
	        @RequestParam(required = false, defaultValue = "DESC") String order,
	        @RequestParam(defaultValue = "All", required = false) String jobId,
	        HttpServletRequest request) {

	    InternityUser user = commonUtils.setUser(request);
	    return applicationService.filterApplications(
	            skills, minCTC, maxCTC, minYOE, maxYOE, noticePeriod, preferredLocation, currentLocation,
	            currentOrganization, currentStatus, subStatus, appliedTimestamp,
	            lastWorkingDay, limit, offset, order,jobId,user);
	}
	
	@GetMapping("api/v1/jobs/application/download")
	public ResponseEntity<?> downloadFilterApplications(
	        @RequestParam(defaultValue = "All", required = false) String skills,
	        @RequestParam( required = false,defaultValue = "0.0") Double minCTC,
	        @RequestParam( required = false,defaultValue = "0.0") Double maxCTC,
	        @RequestParam( required = false,defaultValue = "0.0") Double minYOE,
	        @RequestParam( required = false,defaultValue = "0.0") Double maxYOE,
	        @RequestParam(required = false,defaultValue = "0") Integer noticePeriod,
	        @RequestParam(defaultValue = "All", required = false) String preferredLocation,
	        @RequestParam(defaultValue = "All", required = false) String currentLocation,
	        @RequestParam(defaultValue = "All", required = false) String currentOrganization,
	        @RequestParam(defaultValue = "All", required = false) String currentStatus,
	        @RequestParam(defaultValue = "All", required = false) String subStatus,
	        @RequestParam(required = false) String appliedTimestamp,
	        @RequestParam(required = false) String lastWorkingDay,
	        @RequestParam(required = false, defaultValue = "10") int limit,
	        @RequestParam(required = false, defaultValue = "0") int offset,
	        @RequestParam(required = false, defaultValue = "ASC") String order,
	        @RequestParam(defaultValue = "All", required = false) String jobId,
	        HttpServletRequest request, HttpServletResponse response) {

	    InternityUser user = commonUtils.setUser(request);
	    List<FinalAssessedProfileDetails> completeApplicationDtos = applicationService.downloadFilterApplications(
	            skills, minCTC, maxCTC, minYOE, maxYOE, noticePeriod, preferredLocation, currentLocation,
	            currentOrganization, currentStatus, subStatus, appliedTimestamp,
	            lastWorkingDay, limit, offset, order,jobId,user);
		String filename = "filteredApplications.csv";

		InputStreamResource file = new InputStreamResource(applicationService.getCSVLoad(completeApplicationDtos));
		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/csv"))
				.body(file);
	}

	@PostMapping(value = "/api/v1/jobs/applications/bulk")
	public ResponseEntity<?> addorUpdateApplication(
			@RequestParam String zipFileKey,
			@RequestParam String jobId,HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			return new ResponseEntity<>(bulkApplicationService.runExtractorAndApplyOnJob(zipFileKey, jobId), HttpStatus.OK);
		}
		catch (Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@GetMapping(value = "/api/v1/jobs/application/{applicationId}/stages")
	public Response getApplicationStages(
			@PathVariable Long applicationId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return applicationService.getApplicationStages(applicationId, user);
	}

	@PutMapping(value = "/api/v1/jobs/application/{applicationId}/stages")
	public Response updateApplicationStages(
			@PathVariable Long applicationId,
			@RequestBody ApplicationUpdateStagesDto payload,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return applicationService.updateApplicationStages(applicationId, payload, user);
	}

	@GetMapping(value = "/api/v1/jobs/application/bulk/stages/{stage}")
	public Response getBulkApplicationStages(
			HttpServletRequest request, @PathVariable String stage) {
		InternityUser user = commonUtils.setUser(request);
		return applicationService.getBulkApplicationStages(stage, user);
	}

	@PutMapping("/api/v1/jobs/application/bulk/stages")
	public Response updateBulkApplicationStages(
			@RequestParam String applicationIds,
			@RequestBody ApplicationUpdateStagesDto payload,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return applicationService.updateApplicationStagesInBulk(applicationIds,payload, user);
	}


}
