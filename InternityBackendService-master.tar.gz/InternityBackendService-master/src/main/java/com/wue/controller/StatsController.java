package com.wue.controller;

import com.wue.domain.PlatformStats;
import com.wue.service.PlatformStatsService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/")
public class StatsController {
	
	@Autowired
	CommonUtils commonUtils;
	
	@Autowired
	PlatformStatsService service;
	
	@PostMapping("api/v1/stats/landingpage")
	public ResponseEntity<Boolean> savePlatformStats(@RequestBody PlatformStats stats, HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(service.saveStats(stats, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/stats/landingpage")
	public ResponseEntity<PlatformStats> fetchPlatformStats(@RequestParam(required = false) String pageName, HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(service.fetchPlatformStats(pageName, user), HttpStatus.OK);
	}


	@GetMapping("api/v1/stats")
	public ResponseEntity<List<PlatformStats>> listOfPlatformStatsInARange(
			@RequestParam(defaultValue = "0", required = false) int rangeToFetch,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(service.listOfPlatformStats(rangeToFetch, user), HttpStatus.OK);
	}

	@PostMapping("api/v1/stats")
	public ResponseEntity<?> samePlatformStats(
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(service.scheduledSaveStats(), HttpStatus.OK);
	}

	@GetMapping("api/v1/stats/drills/partners/{partnerId}/overall")
	public ResponseEntity<?> listOfPlatformStatsForADrill(
			@RequestParam(defaultValue = "0", required = false) int rangeToFetch,
			@RequestParam(defaultValue = "0", required = false) String uId,
			@RequestParam(defaultValue = "NA", required = false) String entityId,
			@RequestParam(defaultValue = "NA", required = false) String pageName,
			@PathVariable String partnerId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(service.getOverallStatsOfDrillOfAPartner(rangeToFetch, partnerId, uId, entityId, pageName, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/stats/cumulative")
	public ResponseEntity<Map<String, String>> listOfPlatformStats(
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(service.cumulativePlatformStats(user), HttpStatus.OK);
	}

	@GetMapping("api/v1/stats/drills/participants")
	public ResponseEntity<?> getListofParticipants(
			HttpServletRequest request) throws IOException {
		Map<String, Object> result = service.getFileOrListofParticipants();

		return new ResponseEntity<>(result, HttpStatus.OK);

	}

	@GetMapping("api/v1/stats/drills/report")
	public ResponseEntity<?> fetchReportOfStats(
			@RequestParam(defaultValue = "NA", required = false) String to,
			HttpServletRequest request) throws IOException, MessagingException {
		String result = service.fetchReportOfStats(to);

		return new ResponseEntity<>(result, HttpStatus.OK);

	}

	@GetMapping("api/v1/stats/impressions")
	public ResponseEntity<?> fetchImpressionsForAFeature(
			@RequestParam(defaultValue = "NA", required = false) String category,
			@RequestParam(defaultValue = "NA", required = false) String entityId,
			@RequestParam(defaultValue = "NA", required = false) String partnerId,
			HttpServletRequest request) throws IOException, MessagingException {
		Map<String, Long> result = service.fetchCountOfImpressions(category, partnerId, entityId);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@GetMapping("api/v1/stats/drills")
	public ResponseEntity<?> fetchReportOfDrill(
			@RequestParam String drillId,
			HttpServletRequest request) throws IOException, MessagingException {

		return new ResponseEntity<>(service.getOverallStatsOfDrill(drillId), HttpStatus.OK);

	}

	@GetMapping("api/v1/stats/applications")
	public ResponseEntity<?> fetchReportOfApplications(
			@RequestParam(defaultValue = "NA", required = false) String jobId,
			@RequestParam(defaultValue = "NA", required = false) String partnerId,
			HttpServletRequest request) throws IOException, MessagingException {

		return new ResponseEntity<>(service.getOverallStatsOfApplication(jobId,partnerId), HttpStatus.OK);

	}

}
