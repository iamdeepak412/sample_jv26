package com.wue.controller;

import com.wue.domain.Partner;
import com.wue.dto.CustomerRepresentativeDto;
import com.wue.dto.PartnerDto;
import com.wue.dto.response.Response;
import com.wue.service.PartnerService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/")
public class PartnerController {

	@Autowired
	PartnerService partnerService;

	 @Autowired
	 CommonUtils commonUtils;
	
	@PostMapping(value = "/api/v1/partners")
	public ResponseEntity<?> save(@RequestBody PartnerDto partnerDto, HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(partnerService.saveOrUpdate(partnerDto, user), HttpStatus.CREATED);
	}
	
	@PostMapping(value = "/api/v1/partners/representative")
	public ResponseEntity<?> saveRepresentativeDetails(@RequestBody CustomerRepresentativeDto customerRepresentativeDto, HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(partnerService.saveOrUpdateRepresentativeDetails(customerRepresentativeDto, user), HttpStatus.CREATED);
	}
	
	
	@PutMapping(value = "/api/v1/partners/{partnerId}")
	public ResponseEntity<?> update(@RequestBody PartnerDto partnerDto,
									@PathVariable String partnerId, HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(partnerService.updatePartner(partnerId,partnerDto, user), HttpStatus.OK);
	}

	@PatchMapping(value = "/api/v1/partners/{partnerId}/{action}")
	public ResponseEntity<?> activatePartner(@PathVariable String partnerId,
											 @PathVariable boolean action,
											 HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(partnerService.activatePartner(partnerId, action, user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/partners")
	public ResponseEntity<List<Partner>> fetch(
			@RequestParam(required = false) String partnerId,
			@RequestParam(required = false, defaultValue = "true") boolean active,
			@RequestParam(required = false, defaultValue = "basic") String mode,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(partnerService.fetch(partnerId, active, user), HttpStatus.OK);
	}
	@PostMapping(value = "/api/v1/partners/saveimagepositionOrder")
	public ResponseEntity<?> ImagePosition(
			@RequestParam(defaultValue = "NA", required = true) String imageUrl,
			@RequestParam(defaultValue = "NA", required = true) String positionOrder,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(partnerService.saveImagePositionOrder(imageUrl,positionOrder, user), HttpStatus.OK);
	}
	@GetMapping(value = "/api/v1/partners/getimageposition")
	public ResponseEntity<?> getImagePosition(
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(partnerService.fetchImagePosition(user), HttpStatus.OK);
	}
	@GetMapping("/api/v1/partners/representative")
	public Response getRepresentativeDetails(@RequestParam(defaultValue = "NA",required = false) String partnerId,
											 HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return partnerService.getRepresentativeDetails(partnerId,user);
	}
}
