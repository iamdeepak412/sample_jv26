package com.wue.controller;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.wue.constant.SearchProfile;
import com.wue.custom.specification.SearchJobCriteria;
import com.wue.domain.JobView;
import com.wue.domain.drill.DrillParticipant;
import com.wue.dto.SearchResultDto;
import com.wue.dto.response.Response;
import com.wue.service.JobViewService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wue.domain.Job;
import com.wue.service.JobsService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;

@CrossOrigin("*")
@RestController
@RequestMapping("/")
@Log4j2
public class JobsController {

	@Autowired
	CommonUtils commonUtils;

	@Autowired
	JobsService jobsService;

	@Autowired
	JobViewService jobViewService;

	@PostMapping(value = "/api/v1/jobs")
	public ResponseEntity<Job> createJob(@RequestBody Job jobDto, HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService.createJob(jobDto, user), HttpStatus.CREATED);
	}

	@GetMapping(value = "/api/v1/jobs/{jobId}")
	public ResponseEntity<Job> getJobDetails(@PathVariable String jobId, HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService.getJobDetails(jobId, user), HttpStatus.OK);
	}

	@PatchMapping(value = "/api/v1/jobs/{jobId}")
	public ResponseEntity<String> updateJobActiveStatus(@PathVariable String jobId, HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService.updateJobStatus(jobId, user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/search")
	@ApiOperation(value = "Search jobs", code = 200, response = SearchResultDto.class)
	public SearchResultDto search(
			@RequestParam(defaultValue = "all", required = false) String jobType,
			@RequestParam(defaultValue = "all", required = false) String jobTitle,
			@RequestParam(defaultValue = "all", required = false) String jobLocation,
			@RequestParam(defaultValue = "all", required = false) String jobSkills,
			@RequestParam(defaultValue = "all", required = false) String partnerId,
			@RequestParam(defaultValue = "0.0", required = false) double jobMinCtc,
			@RequestParam(defaultValue = "200.0", required = false) double jobMaxCtc,
			@RequestParam(defaultValue = "0", required = false) int jobMinYoe,
			@RequestParam(defaultValue = "40", required = false) int jobMaxYoe,
			@RequestParam(defaultValue = "NA", required = false) String isActive,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "createdTs.desc", required = false) String order,
			@RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
			@RequestParam(defaultValue = "all", required = false) String drillId,
			HttpServletRequest request) {
		try {
			SearchJobCriteria searchCriteria = SearchJobCriteria.builder().jobTitle(jobTitle)
						.jobType(jobType)
						.jobLocation(jobLocation)
						.jobSkills(jobSkills)
						.partnerId(partnerId)
						.jobMinCtc(jobMinCtc)
						.jobMaxCtc(jobMaxCtc)
						.jobMinYoe(jobMinYoe)
						.jobMaxYoe(jobMaxYoe)
						.isActive(isActive)
					    .drillId(drillId).build();

			return jobsService.searchJobs(searchCriteria, offset, limit, order, profile.name());
		}
		catch(Exception e) {
			return null;
		}
	}
	
	@GetMapping(value = "/api/v1/alljobs")
	public ResponseEntity<List<Job>> searchAllJobs(
			@RequestParam(required = false) String query,
			@RequestParam(required = false) String uId,
			HttpServletRequest request) {
		try {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService.listOfFilteredJobs(query, uId, user), HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
		}
	}

	@PutMapping(value = "/api/v1/jobs/{jobId}")
	public Response editJob(@PathVariable String jobId, @RequestBody Job payload,
							HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return jobsService.editJob(jobId, payload, user);
	}
	
	@PutMapping(value = "/api/v1/jobs/{jobId}/activate/{action}")
	public ResponseEntity<Boolean> activateJob(@PathVariable String jobId, @PathVariable boolean action,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService.editJobStatus(jobId, action, user), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/jobs/heading")
	public ResponseEntity<Map<String, Object>> getAllHeadings(HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			return new ResponseEntity<>(jobsService.getAllHeaders(user), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.OK);
		}
	}

	@PostMapping(value = "/api/v1/jobs/views/")
	public ResponseEntity<?> createJob(@RequestBody JobView jobView, HttpServletRequest request) {
		InternityUser internityUser = commonUtils.setUser(request);
		jobView.setDeviceInfo(request.getHeader("User-Agent"));
		return jobViewService.save(jobView, internityUser);
	}

	@GetMapping(value = "/api/v1/jobs/{jobId}/views")
	public ResponseEntity<?> getJobDetails(
			@PathVariable String jobId,
			@RequestParam(required = false) String uId,
			HttpServletRequest request) {
		InternityUser internityUser = commonUtils.setUser(request);
		return jobViewService.fetchViewsOnJob(jobId, uId, internityUser);
	}

	@GetMapping(value = "/api/v1/jobs/{jobId}/applications")
	public ResponseEntity<?> checkIfJobAppliedAlreadyOrNot(
			@PathVariable String jobId,
			@RequestParam String uId,
			HttpServletRequest request) {
		InternityUser internityUser = commonUtils.setUser(request);
		return jobsService.checkIfUserHasApplied(jobId, uId, internityUser);
	}

	@GetMapping(value = "/api/v1/jobs/referralcode")
	public ResponseEntity<?> getReferralCode(
			@RequestParam(required = false,defaultValue = "NA") String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService.fetchReferralCode(uId, user), HttpStatus.OK);
	}

	@PostMapping(value = "/api/v1/jobs/mails")
	public ResponseEntity<?> sendMailForReferAndInvite(
			@RequestParam(required = false, defaultValue = "NA") String type,
			@RequestParam(required = false, defaultValue = "NA") String recruiterUId,
			@RequestParam(required = false, defaultValue = "NA") String jobId,
			@RequestParam(required = false, defaultValue = "NA") String emailIdList,
			@RequestParam(required = false, defaultValue = "NA") String mailSubject,
			@RequestParam(required = false, defaultValue = "NA") String mailBody,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService
				.sendMailForRerralAndInvite(type, recruiterUId, jobId, emailIdList, mailSubject, mailBody, user),
				HttpStatus.OK);
	}
	@GetMapping(value = "/api/v1/jobs/resumescreening")
	public ResponseEntity<?> getSkillsPercentage(
	        @RequestParam(required = false, defaultValue = "NA") String uId,
	        @RequestParam(required = false, defaultValue = "NA") String jobId,
	        @RequestParam(required = false, defaultValue = "NA") String skills,
	        HttpServletRequest request) {
	    try {
	        InternityUser user = commonUtils.setUser(request);
	        Object result = jobsService.resumeScreeningAsPerJobDescription(uId, jobId,skills, user);
	        return ResponseEntity.ok(result);
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred while screening resumes as per job description: " + e.getMessage());
	    }
	}

	@GetMapping("/api/v1/jobs/customurl/{custUrl}")
	public ResponseEntity<?> fetchJobidFromCustUrl(
			@PathVariable String custUrl,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>("{\"jobId\":\""+jobsService.fetchJobidFromCusturl(custUrl)+"\"}", HttpStatus.OK);
	}

	@PostMapping("/api/v1/jobs/addcusturl")
	public ResponseEntity<?> addCustUrl(
			HttpServletRequest request) throws GeneralSecurityException, IOException {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(jobsService.postCustUrlForAllPreviousJobs(), HttpStatus.OK);
	}
	 @PostMapping("/api/v1/jobs/feeds/opentoall")
	    public ResponseEntity<String> sendEmailToAll(@RequestParam(required = false, defaultValue = "NA") String emailIdList,
	    		HttpServletRequest request) {
	        try {
	        	InternityUser user = commonUtils.setUser(request);
	        	jobsService.sendMailOpenToAll(emailIdList,user);
	            return ResponseEntity.ok("Emails sent successfully.");
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                    .body("Error sending emails: " + e.getMessage());
	        }
	    }
	 
	 @PostMapping("/api/v1/jobs/feeds/sendinvitemail")
	    public ResponseEntity<?> sendEmailToInvite(@RequestParam(required = false, defaultValue = "NA") String emailIdList,
	    		@RequestParam(required = false, defaultValue = "NA") String uId,
		        @RequestParam(required = false, defaultValue = "NA") String jobId,
		        HttpServletRequest request
	                                                ) {
	        try {
	        	InternityUser user = commonUtils.setUser(request);
	        	Map<String, String> result = jobsService.sendMailForInvite(uId,jobId,emailIdList,user);
	            return new ResponseEntity(result, HttpStatus.OK);
	        } catch (Exception e) {
	            return new ResponseEntity(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while " +
						"sending the email"), HttpStatus.INTERNAL_SERVER_ERROR);
			}
	    }
		
	 @DeleteMapping("/api/v1/jobs/screeningquestions/{questionId}")
	    public ResponseEntity<?> deleteScreeningQuestion(@PathVariable String questionId) {
	        return new ResponseEntity<>(jobsService.deleteScreeningQuestionById(questionId),HttpStatus.OK);
	       
	    }
	 
	 @PostMapping("/api/v1/jobs/jobdescription")
	 public ResponseEntity<?> processPDFFile(@RequestParam(required = true, defaultValue = "NA") String jobDescriptionLink) {
	     try {
	         ResponseEntity<?> response = jobsService.processPDF(jobDescriptionLink);
	         return new ResponseEntity<>(response,HttpStatus.OK);
	     } catch (Exception e) {
	    	 return new ResponseEntity(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while " +
						"processing the file"), HttpStatus.INTERNAL_SERVER_ERROR);
	     }
	 }

	@PostMapping("/api/v1/job/drill/{drillId}")
	public Response createDrillBasedJob(@PathVariable String drillId,
										@RequestBody Job job,
										HttpServletRequest request) {
		return jobsService.createDrillBasedJob(drillId, job, commonUtils.setUser(request));
	}

	@PutMapping("/api/v1/job/{jobId}/drill")
	public Response updateDrillBasedJob(@PathVariable String jobId,
										@RequestBody Job job,
										HttpServletRequest request) {
		return jobsService.updateDrillBasedJob(jobId, job, commonUtils.setUser(request));
	}

	@PostMapping("/api/v1/job/{jobId}/drill/{drillId}/apply")
	public Response applyDrillBasedJob(@PathVariable String jobId,
									   @PathVariable String drillId,
									   @RequestBody DrillParticipant participant,
									   HttpServletRequest request) {
		return jobsService.applyDrillBasedJob(jobId, drillId, participant, commonUtils.setUser(request));
	}
	    
}
