package com.wue.controller.drill;


import com.wue.dto.drill.DrillLeaderboardRequestDto;
import com.wue.dto.response.Response;

import com.wue.service.drill.DrillLeaderboardService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Log4j2
@RestController
@RequestMapping("/")
public class DrillLeaderboardController {

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    DrillLeaderboardService drillLeaderboardService;


    @PostMapping("api/v1/drills/{drillId}/leaderboards")
    public Response createLeaderboard(
            @PathVariable String drillId,
            @RequestParam(required = false) String teamId,
            @RequestParam(required = false) String participantId,
            @RequestBody DrillLeaderboardRequestDto payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillLeaderboardService.createLeaderboard(drillId, teamId,participantId,payload,user);
    }

    @PutMapping("api/v1/drills/leaderboards/{leaderboardId}")
    public Response updateLeaderboardDetails(
            @PathVariable String leaderboardId,
            @RequestBody DrillLeaderboardRequestDto payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillLeaderboardService.updateLeaderboardDetails(leaderboardId,payload,user);
    }


    @PutMapping("api/v1/drills/positions/leaderboards")
    public Response updateLeaderboardPositions(
            @RequestParam Map<String,String> leaderboardIdsAndPositions,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillLeaderboardService.updateLeaderboardPositions(leaderboardIdsAndPositions,user);
    }
    @GetMapping("api/v1/drills/{drillId}/phases/{phaseId}/leaderboards")
    public Response getAllLeaderboardDetails(
            @PathVariable String drillId,
            @PathVariable String phaseId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillLeaderboardService.getAllLeaderboardDetails(user,drillId,phaseId);
    }
    @GetMapping("api/v1/drills/leaderboards/{leaderboardId}")
    public Response getLeaderboardDetailsById(@PathVariable String leaderboardId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillLeaderboardService.getLeaderboardDetailsById(leaderboardId,user);
    }

   @GetMapping ("api/v1/drill/{drillId}/leaderboards")
    public Response getLeaderboardByDrill(@PathVariable String drillId, HttpServletRequest request) {
       InternityUser user = commonUtils.setUser(request);
       return drillLeaderboardService.getLeaderboardByDrill(drillId,user);
    }



}
