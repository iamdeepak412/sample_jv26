package com.wue.controller.drill;

import com.wue.constant.SearchProfile;
import com.wue.constant.drill.MemberType;
import com.wue.constant.drill.RequestType;
import com.wue.constant.drill.Stage;
import com.wue.custom.specification.SearchDrillTeamCriteria;
import com.wue.custom.specification.SearchTeamParticipantCriteria;
import com.wue.domain.drill.DrillTeams;
import com.wue.dto.drill.DrillTeamUpdateDto;
import com.wue.dto.drill.DrillTeamsDto;
import com.wue.dto.drill.TeamMemberDto;
import com.wue.dto.drill.TeamMemberInviteDto;
import com.wue.dto.response.Response;
import com.wue.service.drill.DrillTeamService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Log4j2
@RestController
@RequestMapping("/")
public class DrillTeamController {
    @Autowired
    CommonUtils commonUtils;

    @Autowired
    DrillTeamService drillTeamService;

    @GetMapping("/api/v1/drills/{drillId}/drillteams/name")
    public Response generateTeamName(
            @PathVariable String drillId,
            @RequestParam(defaultValue = "NA", required = false) String teamName,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.generateTeamName(drillId, teamName, user);
    }

    @PostMapping("api/v1/drills/{drillId}/drillteams/participants/{participantId}/teams")
    public Response addNewTeam(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @RequestBody DrillTeams payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.saveNewDrillTeam(drillId, participantId, payload, user);
    }

    @PostMapping("/api/v1/drills/{drillId}/drillteams/{teamId}/participants/{teamLeadParticipantId}/invites")
    public Response sendEmailToInviteForTeam(
            @PathVariable String drillId,
            @PathVariable String teamId,
            @PathVariable String teamLeadParticipantId,
            @RequestBody TeamMemberInviteDto payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.sendMailForTeamInvite(drillId, teamId, teamLeadParticipantId, payload, user);
    }

    @PostMapping("api/v1/drills/{drillId}/drillteams/participants/{participantId}/invitecode")
    public Response addTeamMemberByInviteCode(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @RequestBody TeamMemberDto payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.addTeamMemberToDrillTeamsByInviteCode(drillId, participantId, payload, user);
    }

    @PostMapping("api/v1/drills/{drillId}/drillteams/{teamId}/participants/{participantId}/searched")
    public Response addNewTeamMemberBySearched(
            @PathVariable String drillId,
            @PathVariable String teamId,
            @PathVariable String participantId,
            @RequestBody TeamMemberDto payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.addNewTeamMemberToDrillTeamsBySearched(drillId, teamId, participantId, payload, user);
    }


    @PostMapping("api/v1/drills/{drillId}/drillteams/{teamId}/participants/{participantId}/requests")
    public Response acceptTeamMemberForDrillTeam(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @PathVariable String teamId,
            @RequestParam String leadParticipantId,
            @RequestParam Stage stage,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.acceptOrRejectTeamMember(drillId, teamId, participantId, leadParticipantId, stage, user);
    }

    @PutMapping("api/v1/drills/{drillId}/drillteams/{teamId}/participants/{participantId}/teamdetails")
    public Response updateTeamDetailsForTeamLeadOrMember(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @PathVariable String teamId,
            @RequestParam RequestType requestType,
            @RequestParam String teamImgUrl,
            @RequestParam String teamName,
            @RequestParam String teamLeadId,
            @RequestParam List<String> participantIdList,
            @RequestBody DrillTeamUpdateDto payload,
            HttpServletRequest request
    ) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.processTeamDetailsUpdateRequest(drillId, teamId, participantId, teamName,
                teamLeadId, participantIdList, teamImgUrl, requestType, payload, user);
    }

    @PostMapping("api/v1/drills/{drillId}/drillteams/{teamId}/participants/{participantId}/status")
    public Response updateTeamStatus(@PathVariable String drillId,
                                     @PathVariable String participantId,
                                     @PathVariable String teamId,
                                     @RequestParam boolean isActive,
                                     @RequestBody String reason,
                                     HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.processTeamStatusUpdateRequest(drillId, teamId, participantId, isActive, reason, user);
    }

    @GetMapping("/api/v1/drills/{drillId}/drillteams/search")
    public Response findDrillTeams(
            @PathVariable String drillId,
            @RequestParam(defaultValue = "all", required = false) String teamId,
            @RequestParam(defaultValue = "all", required = false) String teamName,
            @RequestParam(defaultValue = "false", required = false) boolean isLookingForTeamMate,
            @RequestParam(defaultValue = "false", required = false) boolean isIncompleteTeam,
            @RequestParam(defaultValue = "0", required = false) int offset,
            @RequestParam(defaultValue = "10", required = false) int limit,
            @RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        SearchDrillTeamCriteria searchCriteria = SearchDrillTeamCriteria.builder()
                .drillId(drillId)
                .teamId(teamId)
                .teamName(teamName)
                .isIncompleteTeam(isIncompleteTeam)
                .isLookingForTeamMate(isLookingForTeamMate)
                .build();
        return drillTeamService.searchDrillTeams(searchCriteria, offset, limit, order, profile.name(), user);
    }


    @PutMapping("api/v1/drills/{drillId}/drillteams/participants/{participantId}/membertype")
    public Response updateMemberTypeInDrillParticipant(@PathVariable String drillId, @PathVariable String participantId,
                                                       @RequestParam MemberType memberType, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.updateMemberType(drillId, participantId, memberType, user);
    }


    @PostMapping("/api/v1/drills/{drillId}/drillteams/{teamId}/participants/{teamLeadParticipantId}/send-invitation")
    public Response sendInvitationToParticipant(
            @PathVariable String drillId,
            @PathVariable String teamId,
            @PathVariable String teamLeadParticipantId,
            @RequestParam String invitedParticipantId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.sendInvitationToParticipant(drillId, teamId, teamLeadParticipantId, invitedParticipantId, user);
    }

    @GetMapping("/api/v1/drills/{drillId}/participants/not-in-team")
    public Response getAllParticipantsNotInAnyTeam(
            @PathVariable String drillId,
            @RequestParam(defaultValue = "all", required = false) String name,
            @RequestParam(defaultValue = "all", required = false) String email,
            HttpServletRequest request
    ) {
        InternityUser requestingUser = commonUtils.setUser(request);
        return drillTeamService.getAllParticipantsNotInAnyTeam(drillId, name, email, requestingUser);
    }

    @GetMapping("/api/v1/drills/{drillId}/drillteams/participants/{participantId}/participantdetails")
    public Response getParticipantDetailsAndJoinedTeams(@PathVariable String drillId,
                                                        @PathVariable String participantId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillTeamService.getParticipantDetailsAndJoinedTeams(drillId, participantId, user);

    }


    @GetMapping("/api/v1/drills/{drillId}/drillteams/participants/searchteamrequest")
    public Response retrieveTeamsForParticipantRequest(@PathVariable String drillId,
                                                       @RequestParam(defaultValue = "all", required = false) String participantId,
                                                       @RequestParam(defaultValue = "all", required = false) String teamId,
                                                       @RequestParam(defaultValue = "all", required = false) Stage stage,
                                                       @RequestParam(defaultValue = "0", required = false) int offset,
                                                       @RequestParam(defaultValue = "10", required = false) int limit,
                                                       @RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
                                                       @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
                                                       HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        SearchTeamParticipantCriteria searchCriteria = SearchTeamParticipantCriteria.builder()
                .drillId(drillId)
                .teamId(teamId)
                .participantId(participantId)
                .stage(stage)
                .build();
        return drillTeamService.retrieveTeamsForParticipantRequest(searchCriteria, offset, limit, order, profile.name(), user);
    }

    @GetMapping("/api/v1/drills/{drillId}/drillteams/participants/searchteamrequest/download")
    public ResponseEntity<InputStreamResource> downloadRetrieveTeamsForParticipantRequestResult(@PathVariable String drillId,
                                                                                                @RequestParam(defaultValue = "all", required = false) String participantId,
                                                                                                @RequestParam(defaultValue = "all", required = false) String teamId,
                                                                                                @RequestParam(defaultValue = "all", required = false) Stage stage,
                                                                                                @RequestParam(defaultValue = "0", required = false) int offset,
                                                                                                @RequestParam(defaultValue = "10", required = false) int limit,
                                                                                                @RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
                                                                                                @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
                                                                                                HttpServletRequest request, HttpServletResponse response) {
        InternityUser user = commonUtils.setUser(request);
        SearchTeamParticipantCriteria searchCriteria = SearchTeamParticipantCriteria.builder()
                .drillId(drillId)
                .teamId(teamId)
                .participantId(participantId)
                .stage(stage)
                .build();
        List<DrillTeamsDto> drillTeamsDtos = drillTeamService.downloadSearchParticipantRequest(searchCriteria, offset, limit, order, profile.name(), user);
        String filename = "participantsRequest.csv";

        InputStreamResource file = new InputStreamResource(drillTeamService.getCSVLoad(drillTeamsDtos,drillId));

        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/csv"))
                .body(file);
    }


}
