package com.wue.controller.RoleManagement;

import com.wue.domain.Rbac.AccessType;
import com.wue.domain.Rbac.PlatformEntityType;
import com.wue.domain.Rbac.RoleManagement;
import com.wue.repository.Rbac.AccessTypeRepository;
import com.wue.repository.Rbac.PlatformEntityTypeRepository;
import com.wue.repository.Rbac.RoleManagementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/")
public class RoleManagementController {

	@Autowired
	AccessTypeRepository accessTypeRepository;

	@Autowired
	PlatformEntityTypeRepository platformEntityTypeRepository;

	@Autowired
	RoleManagementRepository roleManagementRepository;

	@PostMapping("api/v1/roles/accesses")
	public ResponseEntity<AccessType> addOrUpdateAccesses(@RequestBody AccessType payload, HttpServletRequest request){
		return new ResponseEntity<>(accessTypeRepository.save(payload), HttpStatus.OK);
	}

	@GetMapping("api/v1/roles/accesses")
	public ResponseEntity<List<AccessType>> fetchAccesses(HttpServletRequest request){
		return new ResponseEntity<>(accessTypeRepository.findAllByIsActive(true), HttpStatus.OK);
	}

	@DeleteMapping("api/v1/roles/accesses")
	public ResponseEntity<String> updateAccessVisibility(@RequestParam Long id,
												   @RequestParam boolean activate, HttpServletRequest request){
		try {
			Optional<AccessType> accessTypeObj = accessTypeRepository.findById(id);
			if(accessTypeObj.isPresent()){
				AccessType accessType = accessTypeObj.get();
				accessType.setActive(activate);
				accessTypeRepository.save(accessType);
			}
			return new ResponseEntity<>("Access updated Successfully", HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Access update operations failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("api/v1/roles/entities")
	public ResponseEntity<PlatformEntityType> addOrUpdateEntity(@RequestBody PlatformEntityType payload,
																HttpServletRequest request){
        payload.setEntityName((payload.getService()+"_"+payload.getEntityName()).toUpperCase());
		return new ResponseEntity<>(platformEntityTypeRepository.save(payload), HttpStatus.OK);
	}

	@GetMapping("api/v1/roles/entities")
	public ResponseEntity<List<PlatformEntityType>> fetchEntity(HttpServletRequest request){
		return new ResponseEntity<>(platformEntityTypeRepository.findAllByIsActive(true), HttpStatus.OK);
	}

	@DeleteMapping("api/v1/roles/entities")
	public ResponseEntity<String> updateEntityVisibility(@RequestParam Long id,
												   @RequestParam boolean activate, HttpServletRequest request){
		try {
			Optional<PlatformEntityType> entityTypeObj = platformEntityTypeRepository.findById(id);
			if(entityTypeObj.isPresent()){
				PlatformEntityType entityType = entityTypeObj.get();
				entityType.setActive(activate);
				platformEntityTypeRepository.save(entityType);
			}
			return new ResponseEntity<>("Entity updated Successfully", HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Entity update operations failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PostMapping("api/v1/roles")
	public ResponseEntity<RoleManagement> addOrUpdateRole(@RequestBody RoleManagement payload, HttpServletRequest request){
		return new ResponseEntity<>(roleManagementRepository.save(payload), HttpStatus.OK);
	}

	@GetMapping("api/v1/roles")
	public ResponseEntity<List<RoleManagement>> fetchRole(HttpServletRequest request){
		return new ResponseEntity<>(roleManagementRepository.findAllByIsActive(true), HttpStatus.OK);
	}

	@DeleteMapping("api/v1/roles")
	public ResponseEntity<String> updateRoleVisibility(@RequestParam Long id,
												   @RequestParam boolean activate, HttpServletRequest request){
		try {
			Optional<RoleManagement> roleObj = roleManagementRepository.findById(id);
			if(roleObj.isPresent()){
				RoleManagement roleType = roleObj.get();
				roleType.setActive(activate);
				roleManagementRepository.save(roleType);
			}
			return new ResponseEntity<>("Role updated Successfully", HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Role update operations failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
