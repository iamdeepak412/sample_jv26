package com.wue.controller;

import com.wue.domain.Squad;
import com.wue.service.SquadService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin("*")
@RestController
@RequestMapping("/")
public class SquadController {

	@Autowired
	CommonUtils commonUtils;

	@Autowired
	SquadService service;

	@PostMapping(value = "/api/v1/squad")
	public ResponseEntity<?> squadRegistration(@RequestBody Squad squad,
			HttpServletRequest request) {
		InternityUser internityUser = commonUtils.setUser(request);
		return service.saveOrUpdate(squad, internityUser);
	}

	@GetMapping(value = "/api/v1/squad")
	public ResponseEntity<?> fetchApplications(
			@RequestParam(defaultValue = "NA", required = false) String query,
			@RequestParam(defaultValue = "NA", required = false) String squadId,
			HttpServletRequest request) {
		InternityUser internityUser = commonUtils.setUser(request);
		return service.fetchSquadList(query, squadId, internityUser);
	}

}
