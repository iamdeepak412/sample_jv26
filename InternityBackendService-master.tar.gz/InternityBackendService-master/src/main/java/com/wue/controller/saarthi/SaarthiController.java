package com.wue.controller.saarthi;

import com.wue.constant.SearchProfile;
import com.wue.custom.specification.SearchSaarthiCriteria;
import com.wue.domain.saarthi.Saarthi;
import com.wue.dto.response.Response;
import com.wue.service.saarthi.SaarthiService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
@CrossOrigin("*")
@RestController
@RequestMapping("/")
@Log4j2
public class SaarthiController {

    @Autowired
    CommonUtils commonUtils;
    @Autowired
    SaarthiService saarthiService;

    @PostMapping("api/v1/saarthi")
    public Response addSaarthi(@RequestBody Saarthi payload,
                               HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return saarthiService.addSaarthi(payload,user);
    }

    @GetMapping("api/v1/saarthi/search")
    public Response getAllSaarthi(
            @RequestParam(defaultValue = "all",required = false) String saarthiId,
            @RequestParam(defaultValue = "all",required = false) String registrationType,
            @RequestParam(defaultValue = "all",required = false) String saarthiWhoAreYouType,
            @RequestParam(defaultValue = "all",required = false) String saarthiPartOfSolutionType,
            @RequestParam(defaultValue = "0", required = false) int offset,
            @RequestParam(defaultValue = "10", required = false) int limit,
            @RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        SearchSaarthiCriteria saarthiCriteria = SearchSaarthiCriteria.builder()
                .saarthiId(saarthiId)
                .registrationType(registrationType)
                .saarthiPartOfSolutionType(saarthiPartOfSolutionType)
                .saarthiWhoAreYouType(saarthiWhoAreYouType).build();
        return saarthiService.getAllSaarthi(saarthiCriteria,limit,offset,order,profile,user);
    }
    @PutMapping("api/v1/saarthi/{saarthiId}")
    public Response updateSaarthi(@PathVariable String saarthiId,@RequestBody Saarthi payload,
                                  HttpServletRequest request ){
        InternityUser user = commonUtils.setUser(request);
        return saarthiService.updateSaarthiDetails(saarthiId,payload,user);
    }

}



