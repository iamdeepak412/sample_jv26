package com.wue.controller;

import com.wue.domain.Wishlist;
import com.wue.dto.response.Response;
import com.wue.service.WishlistService;
import com.wue.util.CommonUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/")
@Log4j2
public class WishlistController {

	@Autowired
	CommonUtils commonUtils;
	
	@Autowired
	WishlistService wishlistService;

	@PostMapping(value = "api/v1/wishlists/users/{uId}")
	public Response saveWishlist(
			@PathVariable(name = "uId") String uId,
			@RequestBody Wishlist wishlist,
			HttpServletRequest request) {

		return wishlistService.saveWishlist(uId, wishlist);

	}

	@GetMapping(value = "api/v1/wishlists")
	public Response fetchWishlistPerUser(
			@RequestParam(defaultValue = "all", required = false) String uId,
			@RequestParam(defaultValue = "0.0", required = false) Long wishlistId,
			@RequestParam(defaultValue = "all", required = false) String entityName,
			HttpServletRequest request) {

		return wishlistService.fetchWishlistForAnUser(uId, wishlistId, entityName);

	}

}
