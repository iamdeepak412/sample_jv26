package com.wue.controller.drill;

import com.wue.constant.SearchProfile;
import com.wue.constant.drill.EntityType;
import com.wue.constant.drill.RequestStatus;
import com.wue.constant.drill.RequestType;
import com.wue.custom.specification.SearchDrillChangeRequestCriteria;
import com.wue.dto.response.Response;
import com.wue.service.drill.DrillChangeRequestService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@Log4j2
@RestController
@RequestMapping("/")
public class DrillChangeRequestController {

    @Autowired
    DrillChangeRequestService drillChangeRequestService;

    @Autowired
    CommonUtils commonUtils;

    @PutMapping("/api/v1/requests/{requestId}/users/{uId}")
    public Response updateRequestDetails(@PathVariable String requestId, @PathVariable String uId,
                                         @RequestParam RequestStatus status,
                                         HttpServletRequest request){
        InternityUser user = commonUtils.setUser(request);
        return drillChangeRequestService.updateRequestDetails(requestId,uId,status,user);
    }

    @GetMapping("/api/v1/requests/search")
    public Response fetchAllRequests(
            @RequestParam(defaultValue = "ALL", required = false) RequestType requestType,
            @RequestParam(defaultValue = "ALL", required = false) RequestStatus status,
            @RequestParam(defaultValue = "ALL", required = false) EntityType entityType,
            @RequestParam(defaultValue = "ALL",required = false)String entityId,
            @RequestParam(defaultValue = "All",required = false)String sourceId,
            @RequestParam(defaultValue = "0", required = false) int offset,
            @RequestParam(defaultValue = "10", required = false) int limit,
            @RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
            HttpServletRequest request
    ){
        InternityUser user = commonUtils.setUser(request);
        SearchDrillChangeRequestCriteria searchCriteria = SearchDrillChangeRequestCriteria.builder()
                .requestStatus(status)
                .requestType(requestType)
                .entityType(entityType)
                .entityId(entityId)
                .sourceId(sourceId)
                .build();
        return drillChangeRequestService.searchAllDrillChangeRequest(searchCriteria,offset,limit,order,profile.name(),user);
    }

}
