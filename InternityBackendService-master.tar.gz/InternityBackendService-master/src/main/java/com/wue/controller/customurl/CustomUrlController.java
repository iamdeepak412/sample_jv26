package com.wue.controller.customurl;

import com.wue.constant.customurl.CustomUrlEntityType;
import com.wue.constant.job.ElementType;
import com.wue.dto.response.Response;
import com.wue.repository.customurl.CustomUrlRepository;
import com.wue.service.customurl.CustomUrlService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Log4j2
@RestController
@RequestMapping("/")
public class CustomUrlController {
	

	@Autowired
	CustomUrlRepository custUrlRepository;

	@Autowired
	CustomUrlService custUrlService;

	@Autowired
	CommonUtils commonUtils;

    @PostMapping("/api/v1/customurls")
    public ResponseEntity<?> shortenUrl(
            @RequestParam String originalUrl,
            @RequestParam(required = false) String entityId,
            @RequestParam String customUrlFromUser,
            @RequestParam(required = false) CustomUrlEntityType entityType,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(
                custUrlService.shortenUrl(
                        originalUrl, customUrlFromUser, entityId, entityType, user),
                HttpStatus.OK);
    }

    @GetMapping("/api/v1/customurls")
    public ResponseEntity<?> redirectUrl(
			@RequestParam(defaultValue = "NA", required = false) String shortUrl,
			@RequestParam(defaultValue = "NA", required = false) String entityId,
			HttpServletRequest request)
            throws IOException {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(
                custUrlService.getLongUrl(shortUrl, entityId, user), HttpStatus.OK);
    }

    @GetMapping("/api/v1/customurls/valid/{elementType}")
    public Response customUrlValidate( @PathVariable ElementType elementType,
                                       @RequestParam String customUrl,
                                       HttpServletRequest request){
        InternityUser user = commonUtils.setUser(request);
        return custUrlService.checkCustomUrlValidity(customUrl,elementType,user);
    }
}
