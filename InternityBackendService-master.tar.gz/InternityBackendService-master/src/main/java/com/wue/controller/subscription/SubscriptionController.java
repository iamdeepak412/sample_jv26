package com.wue.controller.subscription;

import com.wue.domain.subscription.Subscription;
import com.wue.repository.subscription.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/")
public class SubscriptionController {

	@Autowired
	SubscriptionRepository subscriptionRepository;

	@PostMapping("api/v1/subscriptions")
	public ResponseEntity<Subscription> addOrUpdate(@RequestBody Subscription payload, HttpServletRequest request){
		return new ResponseEntity<>(subscriptionRepository.save(payload), HttpStatus.OK);
	}

	@GetMapping("api/v1/subscriptions")
	public ResponseEntity<List<Subscription>> fetchTestimonials(HttpServletRequest request){
		return new ResponseEntity<>(subscriptionRepository.findAll(), HttpStatus.OK);
	}

	@PutMapping("api/v1/subscriptions/{subscriptionId}/{action}")
	public ResponseEntity<?> update(
			@PathVariable String subscriptionId,
			@PathVariable boolean action,
			HttpServletRequest request){
		Optional<Subscription> subscriptionObj = subscriptionRepository.findById(subscriptionId);
		if(subscriptionObj.isPresent()){
			Subscription subscription = subscriptionObj.get();
			subscription.setActive(action);
			subscriptionRepository.save(subscription);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@DeleteMapping("api/v1/subscriptions/{subscriptionId}")
	public ResponseEntity<String> deleteSubscription(@PathVariable String subscriptionId, HttpServletRequest request){
		try {
			Optional<Subscription> subscriptionObj = subscriptionRepository.findById(subscriptionId);
			if(subscriptionObj.isPresent()){
				subscriptionRepository.deleteById(subscriptionId);
			}
			return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Delete operations failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
