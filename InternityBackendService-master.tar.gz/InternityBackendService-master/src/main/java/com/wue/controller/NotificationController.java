package com.wue.controller;

import com.wue.domain.BotMessages;
import com.wue.domain.Notification;
import com.wue.model.EmailContent;
import com.wue.service.NotificationService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/")
public class NotificationController {
    @Autowired
    NotificationService service;

    @Autowired
    CommonUtils utils;

    @PostMapping("api/v1/notification")
    public ResponseEntity<String> addOrUpdate(@RequestBody Notification payload, HttpServletRequest request){
        InternityUser user = utils.setUser(request);
        return service.save(payload, user);
    }

    @GetMapping("api/v1/notification/{receiverUid}")
    public ResponseEntity<?> getNotificationList(
            @PathVariable String receiverUid, HttpServletRequest request){
        InternityUser user = utils.setUser(request);
        return service.getNotificationList(receiverUid, user);
    }
    @GetMapping("api/v1/notification/")
    public ResponseEntity<?> getNotificationWithFilter(
            @RequestParam(required = false) String messageType, HttpServletRequest request){
        InternityUser user = utils.setUser(request);
        return service.getNotificationWithFilter(messageType, user);
    }
    @PutMapping("api/v1/notification/{action}")
    public ResponseEntity<?> getNotificationList(
            @PathVariable String action,
            @RequestBody Notification notification, HttpServletRequest request){
        InternityUser user = utils.setUser(request);
        return service.updateNotificationBody(action, notification, user);
    }
    @PostMapping("api/v1/notification/botmessages")
    public ResponseEntity<String> saveBotMessages(@RequestBody BotMessages payload,HttpServletRequest request){
        InternityUser user = utils.setUser(request);
        return service.saveBotMessages(payload, user);
    }
    @GetMapping("api/v1/notification/botmessages")
    public ResponseEntity<Map<String, List<Map<String, String>>>> fetchBotMessages(
            @RequestParam(defaultValue = "NA", required = false) String startDate,
            @RequestParam(defaultValue = "NA", required = false) String endDate,
            @RequestParam(defaultValue = "NA", required = false) String platform,HttpServletRequest request){	    
        try {
        	InternityUser user = utils.setUser(request);
            Map<String, List<Map<String, String>>> botMessagesMap = service.fetchSavedBotMessages(startDate, endDate, platform,user);
            return ResponseEntity.ok(botMessagesMap);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    @PostMapping("api/v1/notification/{platform}")
    public ResponseEntity<?> sendMessageFromBot(@RequestBody Map<String, Object> request, @PathVariable String platform) {
        return service.sendNotificationMessage(request, platform);
    }

    @PostMapping("api/v1/notifications/mails")
    public ResponseEntity<?> callBulkMailApi(
            @RequestParam(required = false, defaultValue="NA") String type,
            @RequestParam(required = false, defaultValue="NA") String partnerId,
            @RequestBody EmailContent emailContent,
            HttpServletRequest request) {
        InternityUser user = utils.setUser(request);
        return service.sendBulkMailToAll(partnerId, type,emailContent,user);
    }
}
