package com.wue.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wue.domain.UserPlatformIntegration;
import com.wue.repository.UserPlatformIntegrationRepository;

@RestController
@RequestMapping("/")
public class UserPlatformIntegrationController {

	@Autowired
	UserPlatformIntegrationRepository integrationRepository;
	
	@PostMapping("api/v1/platformintegration")
	public ResponseEntity<UserPlatformIntegration> addOrUpdate(@RequestBody UserPlatformIntegration platformInfo, HttpServletRequest request){
		return new ResponseEntity<>(integrationRepository.save(platformInfo), HttpStatus.OK);
	}
	
	@GetMapping("api/v1/platformintegration")
	public ResponseEntity<List<UserPlatformIntegration>> fetchDetails(@RequestParam(name = "uId") String uId , HttpServletRequest request){
		return new ResponseEntity<>(integrationRepository.findByuId(uId), HttpStatus.OK);
	}
	
}
