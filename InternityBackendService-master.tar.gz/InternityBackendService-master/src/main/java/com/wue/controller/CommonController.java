package com.wue.controller;

import com.wue.domain.CaseStudy;
import com.wue.domain.Featured;
import com.wue.domain.OrganisationAndAcademicInstitute;
import com.wue.domain.PageView;
import com.wue.domain.common.*;
import com.wue.service.CommonService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.SendMessageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.spring.web.json.Json;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RequestMapping("/")
@RestController
public class CommonController {
	
	@Autowired
	CommonService service;
	
	@Autowired
	CommonUtils utils;
	
	@Autowired
	SendMessageUtils messageUtils;

	@Autowired
	CommonUtils commonUtils;

	@GetMapping("/api/v1/")
	public Map<String,String> ping(){
		return utils.message(HttpStatus.OK,"server is up");
	}

	@GetMapping("/api/v1/common/{title}")
	public Json teamsPage(@PathVariable String title, HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return service.getTeamsPage(title, user);
	}

	@PostMapping("/api/v1/common/pages")
	public ResponseEntity<?> savePageView(@RequestBody PageView pageViewObj, HttpServletRequest request){
		InternityUser internityUser = utils.setUser(request);
		pageViewObj.setDeviceInfo(request.getHeader("User-Agent"));
		pageViewObj.setClientIpaddress(request.getRemoteAddr());
		return service.savePageView(pageViewObj, internityUser);
	}

	@GetMapping("/api/v1/common/timezones")
	public ResponseEntity<?> getTimeZones(HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return service.getTimezones(user);
	}

	@GetMapping("/api/v1/common/location")
	public ResponseEntity<?> getListOfLocation(
			@RequestParam(defaultValue = "IN", required = false) String countryCode,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return service.getlocation(countryCode, user);
	}

	@PostMapping("/api/v1/common/location")
	public ResponseEntity<?> saveListOfLocation(
			@RequestBody LocationMaster payload,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return service.saveLocation(payload, user);
	}

	@GetMapping("/api/v1/common/industry")
	public ResponseEntity<?> getIndustryOption()
	{
		return service.getIndustryOptions();
	}

	@GetMapping("/api/v1/common/domain")
	public ResponseEntity<?> getDomainOption()
	{
		return service.getDomainOptions();
	}

	@GetMapping("/api/v1/common/technology")
	public ResponseEntity<?> getTechnologyOption()
	{
		return service.getTechnologyOptions();
	}

	@PostMapping("/api/v1/common/industry")
	public ResponseEntity<?> saveOrUpdateIndustryOption(@RequestBody List<IndustryMaster> industryMaster)
	{
		return service.saveOrUpdateIndustryOptions(industryMaster);
	}

	@PostMapping("/api/v1/common/domain")
	public ResponseEntity<?> saveOrUpdateDomainOption(@RequestBody DomainMaster domainMaster)
	{
		return service.saveOrUpdateDomainOptions(domainMaster);
	}

	@PostMapping("/api/v1/common/technology")
	public ResponseEntity<?> saveOrUpdateTechnologyOption(@RequestBody TechnologyMaster technologyMaster)
	{
		return service.saveOrUpdateTechnologyOptions(technologyMaster);
	}

	@GetMapping("/api/v1/users/common")
	public ResponseEntity<?> getListOfDetails(
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return service.getUserCommonMap(user);
	}

	@PostMapping("/api/v1/users/roles")
	public ResponseEntity<?> saveListOfRolesMaster(
			@RequestBody UserRolesMaster payload,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return service.saveUserRolesdetails(payload, user);
	}
	
	@PostMapping("/api/v1/users/types")
	public ResponseEntity<?> saveListOfTypesMaster(
			@RequestBody UserTypesMaster payload,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return service.saveUserTypesdetails(payload, user);
	}

	@GetMapping("/api/v1/common/college")
	public ResponseEntity<?> getCollegeOption()
	{
		return service.getCollegeOptions();
	}

	@GetMapping("/api/v1/common/company")
	public ResponseEntity<?> getCompanyOption()
	{
		return service.getCompanyOptions();
	}

	@GetMapping("/api/v1/common/jobdesignation")
	public ResponseEntity<Map<String, List<String>>> getJobDesignationOption()
	{
		return service.getJobDesignationOptions();
	}

	@PostMapping("/api/v1/common/college")
	public ResponseEntity<?> saveOrUpdateCollegeOption(@RequestBody CollegeMaster collegeMaster)
	{
		return service.saveOrUpdateCollegeOptions(collegeMaster);
	}

	@PostMapping("/api/v1/common/company")
	public ResponseEntity<?> saveOrUpdateCompanyOption(@RequestBody CompanyMaster companyMaster)
	{
		return service.saveOrUpdateCompanyOptions(companyMaster);
	}

	@PostMapping("/api/v1/common/jobdesignation")
	public ResponseEntity<?> saveOrUpdateJobDesignationOption(@RequestBody List<JobMaster> jobMaster)
	{
		return service.saveOrUpdateJobDesignationOptions(jobMaster);
	}
	   
    @PostMapping("api/v1/common/featuredelements")
    public ResponseEntity<Featured> saveFeaturedDetails(@RequestBody Featured featured,
    		                                                         HttpServletRequest request) {
    	InternityUser user = utils.setUser(request);
        Featured savedFeaturedTable = service.saveFeaturedJobAndDrill(featured,user);
        return new ResponseEntity<>(savedFeaturedTable, HttpStatus.OK);
    }
    
    @GetMapping("api/v1/common/featuredelements")
    public ResponseEntity<?> getFeaturedJobsAndDrills(@RequestParam(defaultValue = "NA", required = false)String elementType,
    		                                                                                               HttpServletRequest request) {
    	InternityUser user = utils.setUser(request);
        return new ResponseEntity<>(service.getFeaturedItems(elementType,user), HttpStatus.OK);
    }

	@DeleteMapping("api/v1/common/featuredelements")
	public ResponseEntity<?> deleteFeaturedJobsAndDrills
			(@RequestParam String elementId,
			 @RequestParam String elementType,
			 HttpServletRequest request) {
		InternityUser user = utils.setUser(request);
		boolean isDeleted = service.updateFeaturedItems(elementId, elementType,user);
		if(isDeleted){
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		else {
			return new ResponseEntity<>(commonUtils
					.message(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to update featured elements"), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    @PostMapping("api/v1/common/organisationandacademic")
    public ResponseEntity<OrganisationAndAcademicInstitute> saveOrganisationAndAcademicInstitute(@RequestBody OrganisationAndAcademicInstitute organisationAndAcademicInstitute,
    		                                                                                                  HttpServletRequest request) {
    	InternityUser user = utils.setUser(request);
    	OrganisationAndAcademicInstitute savedorganisationAndAcademic = service.saveOrganisationAndAcademicInstitute(organisationAndAcademicInstitute,user);
        return new ResponseEntity<>(savedorganisationAndAcademic, HttpStatus.OK);
    }
    
    @GetMapping("api/v1/common/organisationandacademic")
    public ResponseEntity<?> getOrganisationAndAcademicInstitute(@RequestParam(defaultValue = "NA", required = false)String type,
    		                                                                                                         HttpServletRequest request) {
    	InternityUser user = utils.setUser(request);
        return new ResponseEntity<>(service.getOrganisationAndAcademicInstitute(type,user), HttpStatus.OK);
    }
    
    @PostMapping("api/v1/common/casestudy")
    public ResponseEntity<Object> saveCaseStudy(@RequestBody CaseStudy caseStudy,
    		                                                    HttpServletRequest request) {
    	InternityUser user = utils.setUser(request);
    	Object savedCaseStudy = service.saveCase(caseStudy,user);
        return new ResponseEntity<Object>(savedCaseStudy, HttpStatus.OK);
    }

    @GetMapping("api/v1/common/casestudy")
    public ResponseEntity<?> getCaseStudies(
			@RequestParam(required = false, defaultValue="NA") String custUrl,
			@RequestParam(required = false, defaultValue="NA") String type,
            @RequestParam(required = false, defaultValue="NA") String subType,
            @RequestParam(defaultValue = "true") boolean isFeatured) {
    	List<CaseStudy> caseStudies = service.getCaseStudies(custUrl, type, subType, isFeatured);
		if(custUrl.equals("NA") && caseStudies==null){
			return new ResponseEntity<>(commonUtils
					.message(HttpStatus.INTERNAL_SERVER_ERROR, "No case study found for this id."), HttpStatus.INTERNAL_SERVER_ERROR);
		}
    	return new ResponseEntity<>(caseStudies, HttpStatus.OK);
}
    @GetMapping("/api/v1/common/whatsappbot")
    public ResponseEntity<String> verifyWebhook(@RequestParam("hub.verify_token") String verifyToken,
                                                @RequestParam("hub.challenge") String challenge){
    	                                        
            return service.verifyWebhook(verifyToken, challenge);
    }
    @PostMapping("/api/v1/common/whatsappbot")
    public ResponseEntity<String> processUserMessage(@RequestBody String incomingMessage) {
        String responseMessage = service.processUserMessage(incomingMessage);
        return ResponseEntity.ok(responseMessage);
    }

	@GetMapping("api/v1/common/categoriesandsubcategories")
	public ResponseEntity<?> getCategoriesandsubcategories(HttpServletRequest request) {
		InternityUser user = utils.setUser(request);
		return new ResponseEntity<>(service.getCustomerCategoriesAndSubcategories(), HttpStatus.OK);
	}    
}
