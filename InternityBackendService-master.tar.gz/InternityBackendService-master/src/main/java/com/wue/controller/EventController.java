package com.wue.controller;

import com.wue.domain.Event;
import com.wue.dto.EventDto;
import com.wue.service.EventService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/")
public class EventController {

    @Autowired
    EventService eventService;

    @Autowired
    CommonUtils commonUtils;

    @PostMapping(value = "api/v1/events")
    public ResponseEntity<Integer> addorUpdateEvent(@RequestBody EventDto eventDto, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(eventService.addEvent(eventDto, user), HttpStatus.CREATED);
    }

    @PutMapping(value = "api/v1/events")
    public ResponseEntity<String> updateEvent(@RequestBody List<EventDto> eventDtoList, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(eventService.addOrUpdateEvent(eventDtoList, user), HttpStatus.OK);
    }

    @DeleteMapping(value = "api/v1/events")
    public ResponseEntity<String> deleteEvent(@RequestBody List<EventDto> eventDtoList, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(eventService.deleteEvent(eventDtoList, user), HttpStatus.OK);
    }

    @GetMapping(value = "api/v1/events")
    public ResponseEntity<List<Event>> fetchEvent(@RequestParam(defaultValue = "-1") int eventId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<List<Event>>(eventService.fetchAllEvent(eventId, user), HttpStatus.OK);
    }

}
