package com.wue.controller;

import com.wue.constant.CommonConstants;
import com.wue.constant.SearchProfile;
import com.wue.custom.specification.SearchCandidateCriteria;
import com.wue.custom.specification.SearchUserCriteria;
import com.wue.domain.CustomerUser;
import com.wue.domain.LoginAttempt;
import com.wue.domain.User;
import com.wue.domain.UserCandidateMandatoryFields;
import com.wue.dto.*;
import com.wue.dto.response.Response;
import com.wue.model.GoogleAuthentication;
import com.wue.service.UserManagementService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/")
@Log4j2
public class UserManagementController {

	@Autowired
	CommonUtils commonUtils;
	
	@Autowired
	UserManagementService userManagementService;

	@RequestMapping("api/v1/health")
	public String health() {
	    return "{\"status\": \"UP\"}";
	}
	
	@PostMapping(value = "api/v1/users/register")
	public ResponseEntity<String> register(@RequestBody UserDto userObj, HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			return userManagementService.registerOrUpdate(userObj, user);
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\"Please fill in correct details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "api/v1/users/add")
	public ResponseEntity<String> addNewUserFromAdmin(@RequestBody UserDto userObj, HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			return userManagementService.addUserFromAdmin(userObj, user);
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\"Please fill in correct details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "api/v1/users/login")
	public ResponseEntity<?> login(@RequestBody AuthenticationDto userObj, HttpServletRequest request) {
		try {
			log.info("inside authentication.@@");
			InternityUser user = commonUtils.setUser(request);
			User loggedInUser = userManagementService.loginUser(userObj.getUsername(), userObj.getPassword(), user);
			LoginAttempt loginAttempt = userManagementService.setLoginAttemptObj(loggedInUser, request);
			if (loggedInUser != null) {
				loginAttempt.setAttemptStatus(CommonConstants.SUCCESS);
				userManagementService.saveLoginAttempt(loginAttempt, user);
				return new ResponseEntity<>(loggedInUser, HttpStatus.OK);
			} else {
				loginAttempt.setAttemptStatus(CommonConstants.FAILED);
				userManagementService.saveLoginAttempt(loginAttempt, user);
				return new ResponseEntity<>("{\"Error\":\"User is not present. Please register.\"}",
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getLocalizedMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    @PostMapping(value = "api/v1/users/login/google")
    public void loginWithGoogle(
			@RequestBody GoogleAuthentication googleAuthenticationObj,
			HttpServletResponse response) throws IOException {
		AuthResponseDto responseObj = userManagementService.loginWithGoogle(googleAuthenticationObj);
		if(responseObj!=null){
			response.setStatus(HttpStatus.OK.value());
			response.getWriter().write(responseObj.toString());
			response.flushBuffer();
		}else {
			response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			response.getWriter().write(responseObj.toString());
			response.flushBuffer();
		}
	}

	@PostMapping(value = "api/v1/users/forgotpassword")
	public ResponseEntity<?> forgotPassword(
			@RequestParam String emailid,
			@RequestParam(defaultValue = "", required = false) String returnUrl,
			HttpServletRequest request) {
		try {
			log.info("forgot password");
			InternityUser user = commonUtils.setUser(request);
			Map<String, String> response = userManagementService.forgotPassword(emailid, returnUrl, user);
			if(response.containsKey(CommonConstants.ERROR)){
				return new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		catch(Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "api/v1/users/resendverification")
	public ResponseEntity<?> resendVerificationEmail(
			@RequestParam String emailid,
			@RequestParam(defaultValue = "", required = false) String returnUrl,
			HttpServletRequest request) {
		try {
			log.info("Resend Verification Email");
			InternityUser user = commonUtils.setUser(request);
			return new ResponseEntity<>(userManagementService.resendVerification(emailid, returnUrl, user), HttpStatus.OK);
		}
		catch(Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Description("API called when user forgot password without login")
	@PostMapping(value = "api/v1/users/updatepassword")
	public ResponseEntity<?> forgotPassword(
			@RequestBody UpdatePassword body,
			HttpServletRequest request) {
		try {
			log.info("update forgot password");
			InternityUser user = commonUtils.setUser(request);
			Map<String, String> result = userManagementService.updateForgotPassword(body, user);
			if (result != null && !result.containsKey("Error")) {
				return new ResponseEntity<>(result, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(result, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"msg\":\""+e.getMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Description("When loggedin, API called when user forgot password")
	@PutMapping(value = "api/v1/users/{uId}/updatepassword")
	public ResponseEntity<?> changePassword(
			@RequestBody UpdatePassword body,
			@PathVariable String uId,
			HttpServletRequest request) {
		try {
			log.info("update forgot password");
			InternityUser user = commonUtils.setUser(request);
			return userManagementService.changePasswordAfterLogin(uId, body);
		}
		catch(Exception e){
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "api/v1/users")
	public List<User> getUsers(
			@RequestParam(required = false, defaultValue = "NA") String query,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return userManagementService.getUsers(query, user);
	}

	@GetMapping(value = "api/v1/users/{userId}")
	public User getSingleUser(
			@PathVariable(name = "userId") String uid,
			HttpServletRequest request) {
		return userManagementService.getSingleUser(uid);
	}

	@GetMapping(value = "api/v1/users/pii/{type}")
	public List<String> getEmailAndPhoneOfUsers(
			@PathVariable String type,
			HttpServletRequest request) {
		return userManagementService.getEmailAndPhoneOfUsers(type);
	}

	@GetMapping(value = "api/v1/users/{uId}/accesses/component")
	public ResponseEntity<?> isUserHasAccessToDrill(
			@PathVariable(name = "uId") String uId,
			@RequestParam String component,
			@RequestParam String componentId,
			HttpServletRequest request) {
		return userManagementService.userHasAccessToDrill(uId, component, componentId) ;
	}

	@PostMapping(value = "api/v1/users/verify/{encodedstring}")
	public ResponseEntity<String> login(
			@PathVariable(name = "encodedstring") String encodedString, 
			HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			return userManagementService.verifyUser(encodedString, user);
		}
		catch(Exception e){
			log.error("Exception while verifying the user ::: {}", e);
			return new ResponseEntity<>("We Apologies for inconvinience caused. " +
					"Please try again in sometime", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "api/v1/users/{email}/loginattempt")
	public ResponseEntity<?> getLoginAttempt(@PathVariable String email, HttpServletRequest request) {
		try {
			InternityUser internityUser = commonUtils.setUser(request);
			return userManagementService.getListOfLoginAttempt(email, internityUser);
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getLocalizedMessage()+"\"}",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/api/v1/users/search")
	@ApiOperation(value = "Search Users", code = 200, response = UserSearchResultDto.class)
	public UserSearchResultDto searchUser(
			@RequestParam(defaultValue = "NA", required = false) String isActive,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "userUpdatedts.desc", required = false) String order,
			@RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
			@RequestParam(defaultValue = "all", required = false) String email,
			@RequestParam(defaultValue = "all", required = false) String fullName,
			HttpServletRequest request) {
		try {
			SearchUserCriteria searchCriteria = SearchUserCriteria.builder()
					.isActive(isActive)
					.email(email)
					.fullName(fullName)
					.build();
			return userManagementService.searchUser(searchCriteria, offset, limit, order, profile.name());
		}
		catch(Exception e) {
			return null;
		}
	}

	@GetMapping(value = "/api/v1/users/search/download")
	public ResponseEntity<InputStreamResource> downloadUserList(
			@RequestParam(defaultValue = "NA", required = false) String isActive,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "userUpdatedts.desc", required = false) String order,
			@RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
			@RequestParam(defaultValue = "all", required = false) String email,
			HttpServletRequest request, HttpServletResponse response) {
		try {
			SearchUserCriteria searchCriteria = SearchUserCriteria.builder()
					.isActive(isActive)
					.email(email)
					.build();
			UserSearchResultDto userSearchResultDto = userManagementService.searchUser(searchCriteria, offset, limit, order, profile.name());

			String filename = "allUsers.csv";

			InputStreamResource file = new InputStreamResource(userManagementService.getCSVLoad(userSearchResultDto.getDetails()));

			response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename);
			return ResponseEntity.ok()
					.contentType(MediaType.parseMediaType("application/csv"))
					.body(file);
		}
		catch(Exception e) {
			return null;
		}
	}

	@PostMapping(value = "api/v1/users/{uId}/customer")
	public ResponseEntity<?> assignUserToCustomer(
			@PathVariable String uId,
			@RequestBody CustomerUser payload
			, HttpServletRequest request) {
		try {
			InternityUser internityUser = commonUtils.setUser(request);
			payload.setUId(uId);
			return userManagementService.assignUserToCustomer(payload, internityUser);

		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getLocalizedMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(value = "api/v1/users/customers/{customerId}")
	public ResponseEntity<?> inviteOrAssignUserToCustomer(
			@PathVariable String customerId,
			@RequestParam String email,
			@RequestParam(defaultValue = "NA", required = false) String designation,
			HttpServletRequest request) {
		try {
			InternityUser internityUser = commonUtils.setUser(request);
			return userManagementService.inviteOrAssignUserToCustomer(customerId, email, designation, internityUser);

		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getLocalizedMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "api/v1/users/{uId}/customer")
	public ResponseEntity<?> fetchCustomerOfUser(
			@PathVariable String uId,
			HttpServletRequest request) {
		try {
			InternityUser internityUser = commonUtils.setUser(request);
			return userManagementService.fetchCustomerOfUser(uId, internityUser);
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getLocalizedMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "api/v1/users/customers/{customerId}")
	public ResponseEntity<?> fetchAllUsersOfACustomer(
			@PathVariable String customerId,
			HttpServletRequest request) {
		try {
			InternityUser internityUser = commonUtils.setUser(request);
			return userManagementService.fetchAllUsersOfACustomer(customerId, internityUser);
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getLocalizedMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping(value = "api/v1/users/{uId}/customers")
	public ResponseEntity<?> removeUserFromCustomer(
			@PathVariable String uId,
			HttpServletRequest request) {
		try {
			InternityUser internityUser = commonUtils.setUser(request);
			return userManagementService.removeUserFromCustomer(uId, internityUser);
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\""+e.getLocalizedMessage()+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	//@PreAuthorize("hasRole('ADMIN') or hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
	@PutMapping(value = "api/v1/users/{userId}/{target}")
	public ResponseEntity<?> getSingleUser(
			@PathVariable(name = "userId") String uid,
			@PathVariable(name = "target") String target,
			@RequestBody User user,
			HttpServletRequest request) {
		return userManagementService.updateSingleTargetOfUser(uid, target, user);
	}

	@PatchMapping(value = "api/v1/users/{userId}/{action}")
	public ResponseEntity<?> activateSingleUser(
			@PathVariable(name = "userId") String uid,
			@PathVariable(name = "action") boolean action,
			HttpServletRequest request) {
		InternityUser internityUser = commonUtils.setUser(request);
		return userManagementService.activateSingleUser(uid, action, internityUser);
	}

	@Deprecated
	@PostMapping(value = "api/v1/users/bulk/import")
	public ResponseEntity<?> bulkImportMails(
			@RequestBody String bulkEmails,
			@RequestParam int startingContactNumber,
			@RequestParam(defaultValue = "NA") String token,
			HttpServletRequest request) {
		//just1email#insert!!*
    	if (token.equals("just1email#insert!!*")) {
      		return userManagementService.bulkImportMails(bulkEmails, startingContactNumber);
		}else {
			return new ResponseEntity<>("Wrong token value", HttpStatus.OK);
		}
	}

	@PostMapping(value = "api/v1/users/{uId}/mandatoryfields")
	public ResponseEntity<?> saveMandatoryFields(
			@PathVariable String uId,
			@RequestBody UserCandidateMandatoryFields payload,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		payload.setUId(uId);
		return userManagementService.saveMandatoryFields(payload, user);
	}

	@GetMapping(value = "api/v1/users/{uId}/mandatoryfields")
	public ResponseEntity<?> fetchMandatoryFields(
			@PathVariable String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return userManagementService.fetchMandatoryFields(uId, user);
	}

	@PostMapping("api/v1/users/internalDbresumes/parse")
	public ResponseEntity<?> parseResume(
			@RequestParam(defaultValue = "10", required = false) int limit,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(userManagementService.parseResume(limit,user), HttpStatus.OK);
	}

	@GetMapping("api/v1/user/{uId}/resumes/parse")
	public ResponseEntity<?> parseIndividualResume(
			@PathVariable String uId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(userManagementService.parseIndividualResume(uId,user), HttpStatus.OK);
	}

	@Deprecated
	@PostMapping("api/v1/user/sync/allmandatoryFields")
	public ResponseEntity<?> syncmandatoryfields(
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(userManagementService.syncMandatoryFields(), HttpStatus.OK);
	}

	@GetMapping(value = "/api/v1/users/candidates/search")
	@ApiOperation(value = "Search all Candidates", code = 200, response = UserSearchResultDto.class)
	public CandidateSearchResultDto searchUser(
			@RequestParam(name="jobId", defaultValue = "all", required = false) String jobId,
			@RequestParam(defaultValue = "all", required = false) String currentDesignation,
			@RequestParam(defaultValue = "all", required = false) String currentOrg,
			@RequestParam(defaultValue = "0.0", required = false) double minYoe,
			@RequestParam(defaultValue = "40.0", required = false) double maxYoe,
			@RequestParam(defaultValue = "0.0", required = false) double minCurrentCtc,
			@RequestParam(defaultValue = "200.0", required = false) double maxCurrentCtc,
			@RequestParam(defaultValue = "0.0", required = false) double minExpectedCtc,
			@RequestParam(defaultValue = "200.0", required = false) double maxExpectedCtc,
			@RequestParam(defaultValue = "0", required = false) int minNoticePeriodDays,
			@RequestParam(defaultValue = "365", required = false) int maxNoticePeriodDays,
			@RequestParam(defaultValue = "all", required = false) String minLastWorkingDay,
			@RequestParam(defaultValue = "all", required = false) String maxLastWorkingDay,
			@RequestParam(defaultValue = "all", required = false) String currentLocation,
			@RequestParam(defaultValue = "all", required = false) String preferredLocation,
			@RequestParam(defaultValue = "false", required = false) boolean isServingNp,
			@RequestParam(defaultValue = "all", required = false) String skills,
			@RequestParam(defaultValue = "all", required = false) String email,
			@RequestParam(defaultValue = "all", required = false) String name,
			@RequestParam(defaultValue = "true", required = false) String isActive,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "userUpdatedts.desc", required = false) String order,
			@RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
			HttpServletRequest request) {
		try {
//			LocalDateTime minLwd = null;
//			LocalDateTime maxLwd = null;
//			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
//
//			if(!minLastWorkingDay.equals("all")){
//				minLwd = LocalDateTime.parse(minLastWorkingDay, formatter);
//			}
//			if(!maxLastWorkingDay.equals("all")){
//				maxLwd = LocalDateTime.parse(maxLastWorkingDay, formatter);
//			}

			SearchCandidateCriteria searchCandidateCriteria = SearchCandidateCriteria.builder()
					.currentDesignation(currentDesignation)
					.currentOrg(currentOrg)
					.isServingNp(isServingNp)
					.currentLocation(currentLocation)
					.preferredLocation(preferredLocation)
					.minYoe(minYoe)
					.maxYoe(maxYoe)
					.minCurrentCtc(minCurrentCtc)
					.maxCurrentCtc(maxCurrentCtc)
					.minExpectedCtc(minExpectedCtc)
					.maxExpectedCtc(maxExpectedCtc)
//					.minLastWorkingDay(minLwd)
//					.maxLastWorkingDay(maxLwd)
					.minNoticePeriodDays(minNoticePeriodDays)
					.maxNoticePeriodDays(maxNoticePeriodDays)
					.name(name)
					.email(email)
					.isActive(isActive)
					.jobId(jobId)
					.skills(skills)
					.build();
			return userManagementService.searchCandidate(searchCandidateCriteria, offset,
					limit, order, profile.name());
		}
		catch(Exception e) {
			log.error("Exception while searching candidates {}", e);
			return null;
		}
	}

	@GetMapping(value = "api/v1/users/{uId}/roles")
	public ResponseEntity<?> getRoleAccessesForAUser(
			@PathVariable(name = "uId") String uId,
			HttpServletRequest request) {
		InternityUser internityUser = commonUtils.setUser(request);
		return new ResponseEntity<>(userManagementService.fetchRoleAccessForAUser(uId, internityUser), HttpStatus.OK);
	}

	@PostMapping("api/v1/users/resumes/createprofile")
	public ResponseEntity<?> parseResumeAndCreateProfile(
			@RequestBody Map<String, String> resumeLink,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return userManagementService.parseResumeAndCreateProfile(resumeLink);
	}

	@PostMapping("api/v1/users/multipleResumes/createprofile")
	public ResponseEntity<?> parseMultipleResumeAndCreateProfile(
			@RequestBody Map<String, List<String>> resumeLink,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(userManagementService.parseMultipleResumeAndCreateProfile(resumeLink), HttpStatus.OK);
	}

	@PostMapping(value = "api/v1/users/readFromFile", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE }	)
	public ResponseEntity<?> readFromFile(
			@RequestParam(name = "file") MultipartFile file,
			@RequestParam(name="jobId", defaultValue = "NA", required = false) String jobId,
			HttpServletRequest request) {
		try {
			List<String> str = userManagementService.readFile(file, jobId);
			StringBuilder stringBuilder = new StringBuilder();

			for(String res : str){
				stringBuilder.append(res+",");
			}
			return new ResponseEntity("{\"result\":\""+stringBuilder.toString().substring(0,stringBuilder.length()-1)+"\"}", HttpStatus.OK);
		}
		catch(Exception e){
			return new ResponseEntity<>("{\"Error\":\"Please fill in correct details.\"}",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(value = "/api/v1/users/{uId}/analytics")
	@ApiOperation(value = "Fetch analytics of an user", code = 200, response = UserAnalyticsDto.class)
	public Response fetchUserAnalyticsByUId(
			@PathVariable(name="uId") String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return userManagementService.fetchUserAnalyticsByUId(uId,user);
	}

	@GetMapping(value = "/api/v1/users/{uId}/skills")
	@ApiOperation(value = "Fetch opportunities of an user", code = 200, response = UserAnalyticsDto.class)
	public Response fetchOpportunitiesByUId(
			@PathVariable(name="uId") String uId,
			@RequestParam(defaultValue = "all", required = false) String categoryToFetch,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return userManagementService.fetchSkillsByUId(uId, categoryToFetch, user);
	}

	@GetMapping(value = "/api/v1/users/{uId}/hackathons/track")
	@ApiOperation(value = "Fetch hackathons tracking of an user")
	public Response fetchHackathonsOfAnUser(
			@PathVariable(name="uId") String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return userManagementService.fetchTrackHackathons(uId, user);
	}
//	@GetMapping(value = "/api/v1/users/candidates/searchbyjobid")
//	@ApiOperation(value = "Search Candidates By JobId", code = 200, response = UserSearchResultDto.class)
//	public CandidateSearchResultDto searchUserByJobId(@RequestParam(name="jobId", defaultValue = "NA", required = false) String jobId,
//			HttpServletRequest request) {
//		InternityUser user = commonUtils.setUser(request);
//		return userManagementService.fetchUsersByJobId(jobId,user);
//		
//	}
}
