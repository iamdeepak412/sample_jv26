package com.wue.controller;

import java.util.Map;

import com.wue.service.UploadService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;



@RestController
public class UploadController {
    @Autowired
    UploadService uploadService;
    @PostMapping("/uploadFile")
    public ResponseEntity<?> uploadFile(@RequestParam(defaultValue = "NA", required = false) String drillId,
                                        @RequestParam(defaultValue = "NA", required = false) String teamId,
                                        @RequestParam(defaultValue = "NA", required = false) String participantId,
                                        @RequestParam(defaultValue = "NA", required = false) String theme,
                                        @RequestParam(defaultValue = "NA", required = false) String solutionType,
                                        @RequestParam("file") MultipartFile multipartFile) {

        Map<String, String> submissionResponse = uploadService.uploadFileService(drillId, teamId, participantId, theme, solutionType, multipartFile);
        if (submissionResponse.containsKey("Failed to upload file.")) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

        } else {

            return new ResponseEntity<>(submissionResponse, HttpStatus.CREATED);
        }

    }

}


