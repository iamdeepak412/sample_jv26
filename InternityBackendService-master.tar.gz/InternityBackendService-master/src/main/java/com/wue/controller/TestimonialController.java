package com.wue.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.wue.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wue.domain.TestimonialPost;
import com.wue.repository.TestimonialPostRepository;

@RestController
@RequestMapping("/")
public class TestimonialController {

	@Autowired
	TestimonialPostRepository testimonialPostRepository;

	@Autowired
	CommonService commonService;

	@PostMapping("api/v1/testimonial")
	public ResponseEntity<TestimonialPost> addOrUpdate(@RequestBody TestimonialPost testimonialPost,
													   HttpServletRequest request){
		return new ResponseEntity<>(testimonialPostRepository.save(testimonialPost), HttpStatus.OK);
	}
	
	@GetMapping("api/v1/testimonial")
	public ResponseEntity<List<TestimonialPost>> fetchTestimonials(HttpServletRequest request){
		return new ResponseEntity<>(testimonialPostRepository.findAll(), HttpStatus.OK);
	}

	@GetMapping("api/v1/testimonialwithcategory")
	public ResponseEntity<Map<String,List<TestimonialPost>>> fetchTestimonials(
			@RequestParam(defaultValue = "NA", required = false) String category,
			@RequestParam(defaultValue = "NA", required = false) String service,
			HttpServletRequest request){
		return new ResponseEntity(commonService.fetchTestimonialAsPerCategoryAndService(category, service), HttpStatus.OK);
	}
	
	@DeleteMapping("api/v1/testimonial")
	public ResponseEntity<String> delete(@RequestParam Long id, HttpServletRequest request){
		try {
			testimonialPostRepository.deleteById(id);
			return new ResponseEntity<>("Deleted Successfully", HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Delete operations failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
