package com.wue.controller;

import com.wue.domain.WueTeam;
import com.wue.service.WebsiteConfigurationService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/")
public class WebsiteConfigurationController {
    @Autowired
    WebsiteConfigurationService service;

    @Autowired
    CommonUtils utils;

    @PostMapping("api/v1/WUETeamMember")
    public ResponseEntity<String> addOrUpdate(@RequestBody WueTeam payload, HttpServletRequest request){
        InternityUser user = utils.setUser(request);
        return service.save(payload, user);
    }
    @GetMapping("api/v1/WUETeamMember")
    public ResponseEntity<?> getTeamMembersList(HttpServletRequest request){
        InternityUser user = utils.setUser(request);
        return service.getMembersList(user);
    }
}
