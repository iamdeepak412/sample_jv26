package com.wue.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wue.domain.SkillsLookup;
import com.wue.repository.SkillsLookupRepository;
import com.wue.service.ProfileManagementService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/")
@Log4j2
public class SkillsLookupController {

	@Autowired
	SkillsLookupRepository skillsLookupRepository;

	@Autowired
	ProfileManagementService service;

	@PostMapping("api/v1/skills/")
	public ResponseEntity<String> addOrUpdate(@RequestBody SkillsLookup skillsLookup) {
		try {
			skillsLookupRepository.save(skillsLookup);
			return new ResponseEntity<>("Skill saved/updated successfully", HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while adding/updating skill {}", e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("api/v1/skills/")
	public ResponseEntity<String> deleteSkill(@RequestParam List<Long> skillLookupId) {
		try {
			for (Long id : skillLookupId) {
				skillsLookupRepository.deleteById(id);
			}
			return new ResponseEntity<>("Deleted successfully", HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while deleting skill {}", e);
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("api/v1/skills/")
	public ResponseEntity<List<String>> fetchSkills(@RequestParam(defaultValue = "", required = false) String initialLetters) {
		try {
			return new ResponseEntity<>(service.fetchAutocompleteSkillList(initialLetters), HttpStatus.OK);
		} catch (Exception e) {
			log.error("Exception while adding/updating skill {}", e);
			return new ResponseEntity<>(Collections.emptyList(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
