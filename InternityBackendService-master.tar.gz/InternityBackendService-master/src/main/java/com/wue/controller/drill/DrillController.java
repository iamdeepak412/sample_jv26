package com.wue.controller.drill;

import com.wue.constant.SearchProfile;
import com.wue.constant.drill.DrillParticipantType;
import com.wue.constant.drill.DrillSectionEnum;
import com.wue.constant.drill.ParticipantState;
import com.wue.constant.drill.PaymentStatus;
import com.wue.custom.specification.SearchParticipantCriteria;
import com.wue.domain.drill.*;
import com.wue.domain.drill.participant.ConfigureParticipantFields;
import com.wue.domain.drill.participant.DefaultParticipantFields;
import com.wue.dto.drill.*;
import com.wue.dto.response.Response;
import com.wue.repository.drill.DrillParticipantRepository;
import com.wue.repository.drill.DrillRepository;
import com.wue.service.drill.DrillService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import io.swagger.annotations.ApiOperation;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.*;

@Log4j2
@RestController
@RequestMapping("/")
public class DrillController {

    @Autowired
    DrillRepository drillRepository;

    @Autowired
    DrillService drillService;

    @Autowired
    CommonUtils commonUtils;

    @Autowired
    DrillParticipantRepository drillParticipantRepository;

    //@PreAuthorize("hasRole('ADMIN') or hasRole('ORGANISER') or hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @PostMapping("api/v1/drills")
    public ResponseEntity<?> addOrUpdate(@RequestBody Drill payload,
                                         HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.saveDrill(payload, user), HttpStatus.OK);
    }

    //API while reordering and saving a list of items at once

    //@PreAuthorize("hasRole('ADMIN') or hasRole('ORGANISER') or hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @PostMapping("api/v1/drills/{section}")
    public ResponseEntity<?> saveSection(
            @PathVariable DrillSectionEnum section,
            @RequestBody Map<String, Object> payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.saveDrillSection(section, payload, user);
    }

    //@PreAuthorize("hasRole('ADMIN') or hasRole('ORGANISER') or hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @PutMapping("api/v1/drills/{section}")
    public ResponseEntity<?> saveSectionWithListOfItems(
            @PathVariable DrillSectionEnum section,
            @RequestBody List<Map<String, Object>> payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.updateListOfDrillSection(section, payload, user), HttpStatus.OK);
    }

    //@PreAuthorize("hasRole('ADMIN') or hasRole('ORGANISER') or hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @PutMapping("api/v1/drills/{drillId}/publish/{action}")
    public ResponseEntity<?> showOrHideDrill(@PathVariable String drillId,
                                             @PathVariable boolean action,
                                             HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.showOrHideDrill(drillId, action, user), HttpStatus.OK);
    }

    //@PreAuthorize("hasRole('ADMIN') or hasRole('ORGANISER') or hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @PutMapping("api/v1/drills/{drillId}/sections/actions")
    public ResponseEntity<?> showOrHideADrillSection(@PathVariable String drillId,
                                                     @RequestBody Map<DrillSectionEnum, Boolean> sectionMap,
                                                     HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.showOrHideListOfDrillSection(drillId, sectionMap, user), HttpStatus.OK);
    }

    @GetMapping("api/v1/drills/{drillId}/sections")
    public ResponseEntity<?> getDrillSectionWithStatus(@PathVariable String drillId,
                                                       HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.getDrillSectionWithStatus(drillId, user), HttpStatus.OK);
    }

    @GetMapping("api/v1/drills")
    public ResponseEntity<List<Drill>> searchDrills(
            @RequestParam(defaultValue = "NA", required = false) String drillId,
            @RequestParam(required = false) String runningStatus,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) boolean active,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.fetchDrills(drillId, runningStatus, type, active, user), HttpStatus.OK);
    }

    @GetMapping("api/v1/drills/search")
    public ResponseEntity<?> searchDrills(
            @RequestParam(defaultValue = "all", required = false) String drillId,
            @RequestParam(defaultValue = "all", required = false) String type,
            @RequestParam(defaultValue = "all", required = false) String status,
            @RequestParam(defaultValue = "all", required = false) String mode,
            @RequestParam(defaultValue = "all", required = false) String eligibility,
            @RequestParam(defaultValue = "all", required = false) String invitationType,
            @RequestParam(defaultValue = "all", required = false) String purpose,
            @RequestParam(defaultValue = "all", required = false) String isActive,
            @RequestParam(defaultValue = "all", required = false) String partnerId,
            @RequestParam(required = false, defaultValue = "1000") int limit,
            @RequestParam(required = false, defaultValue = "0") int offset,
            @RequestParam(required = false, defaultValue = "DESC") String order,
            HttpServletRequest request) {

        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.fetchDrills(drillId, type, status, mode, eligibility,
                invitationType, purpose, isActive, partnerId, limit, offset, order, user), HttpStatus.OK);
    }

    @GetMapping("api/v1/drills/phases")
    public ResponseEntity<List<DrillPhases>> fetchPhasesForDrill(
            @RequestParam(defaultValue = "NA", required = false) String drillId,
            @RequestParam(defaultValue = "NA", required = false) String phaseStatus,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.validateAndUpdateDrillPhases(drillId, phaseStatus), HttpStatus.OK);
    }

    @GetMapping("api/v1/drills/phases/participants/{participantId}")
    public ResponseEntity<?> fetchTheLatestPhaseForTheParticipant(
            @RequestParam(defaultValue = "NA", required = false) String drillId,
            @RequestParam(defaultValue = "NA", required = false) String participantId,
            HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            DrillPhases drillPhases = drillService.fetchTheLatestPhaseForTheParticipant(drillId, participantId);
            return new ResponseEntity<>(drillPhases, HttpStatus.OK);
        } catch (Exception e) {
            log.error(e);
            return new ResponseEntity<>(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Error while fetching the latest phase information from the hackathon for the participant")
                    , HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("api/v1/drills/{drillId}/phases")
    public ResponseEntity<Map<String, String>> addOrUpdatePhasesForADrill(
            @PathVariable String drillId,
            @RequestParam String uId,
            @RequestBody DrillPhases payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        Map<String, String> msgWithStatus = drillService.saveDrillPhase(drillId, uId, payload, user);
        if (msgWithStatus.get("status").equals(HttpStatus.INTERNAL_SERVER_ERROR.value() + "")) {
            return new ResponseEntity(msgWithStatus, HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return new ResponseEntity(msgWithStatus, HttpStatus.OK);
        }
    }

    @GetMapping("api/v1/drills/{drillId}/{section}")
    public ResponseEntity<?> searchDrillsSection(
            @PathVariable String drillId,
            @RequestParam(required = false) String participantId,
            @RequestParam(required = false) String phaseId,
            @PathVariable DrillSectionEnum section,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.fetchDrillSection(drillId, section, participantId, user, phaseId), HttpStatus.OK);
    }

    @GetMapping("api/v1/drills/{drillId}/sections/problemstatement/manage")
    public ResponseEntity<?> fetchProblemStatementForManage(
            @PathVariable String drillId,
            @RequestParam String uId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.manageProblemStatement(drillId, uId, user), HttpStatus.OK);
    }

    @GetMapping("/api/v1/drills/{drillId}/common/participate")
    public ResponseEntity<?> getDrillSpecificCommonValues(
            @PathVariable String drillId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.getDrillSpecificCommonValues(drillId, user), HttpStatus.OK);
    }

    @GetMapping("/api/v1/drills/common")
    public ResponseEntity<?> getDrillCommonValues(
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.getDrillCommonValues(user), HttpStatus.OK);
    }

    @PostMapping("api/v1/drills/{drillId}/participate")
    public ResponseEntity<?> addOrUpdateParticipant(@RequestBody DrillParticipant payload,
                                                    @PathVariable String drillId,
                                                    HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.saveDrillParticipant(payload, user), HttpStatus.OK);
    }

    @PostMapping("api/v1/drills/{drillId}/sendwelcomemail")
    public ResponseEntity<?> addOrUpdateParticipant(@PathVariable String drillId,
                                                    HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        Optional<Drill> drillObj = drillRepository.findById(drillId);
        Optional<DrillParticipant> drillParticipant = drillParticipantRepository.findById("edc4b844-8e02-4a91-ac66-1e1c634f8d21");
        drillService.sendWelcomeDrillEmail(drillObj.get(), drillParticipant.get());
        return new ResponseEntity("Mail sent", HttpStatus.OK);
    }

    //@PreAuthorize("hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @PutMapping("api/v1/drills/{drillId}/participants/{participantId}/state/{participantState}")
    public ResponseEntity<?> addOrUpdateParticipant(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @PathVariable ParticipantState participantState,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.updateStateOfAParticipant(drillId, participantId, participantState, user), HttpStatus.OK);
    }

    //@PreAuthorize("hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @PutMapping("api/v1/drills/{drillId}/participants/state")
    public ResponseEntity<?> updateParticipantStateInBulk(
            @PathVariable String drillId,
            @RequestBody String listOfParticipantEmail,
            @RequestParam ParticipantState participantState,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.updateStateOfAParticipantInBulk(drillId, listOfParticipantEmail, participantState, user), HttpStatus.OK);
    }

    //@PreAuthorize("hasRole('ADMIN') or hasRole('ORGANISER') or hasRole('WUEADMIN') or hasRole('WUESUPERADMIN')")
    @GetMapping("api/v1/drills/participants")
    public ResponseEntity<?> fetchParticipantsWithFilter(
            @RequestParam(defaultValue = "NA", required = false) String participantId,
            @RequestParam(defaultValue = "NA", required = false) String drillId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.fetchParticipants(drillId, participantId, user), HttpStatus.OK);
    }

    @PostMapping("api/v1/drills/{drillId}/participate/{participantId}/teams")
    public ResponseEntity<?> addNewTeam(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @RequestBody DrillTeams payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService
                .saveNewDrillTeam(drillId, participantId, payload, user), HttpStatus.OK);
    }

    @PostMapping("api/v1/drills/{drillId}/participate/{participantId}/teams/{teamId}")
    public ResponseEntity<?> addNewteamMember(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @PathVariable String teamId,
            @RequestBody TeamsParticipants payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.addDrillTeamMember(drillId, teamId,
                participantId, payload.getParticipantValue(), false, user), HttpStatus.OK);
    }

    @GetMapping("api/v1/drills/{drillId}/participate/{participantId}/teams/{teamId}/accept")
    public ResponseEntity<?> acceptTeamMember(
            @PathVariable String drillId,
            @PathVariable String participantId,
            @PathVariable String teamId,
            @RequestParam String leadParticipantId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        Map<String, String> response = drillService
                .acceptTeamMember(drillId, teamId, participantId, leadParticipantId, user);
        if (response.get("msg").startsWith("Failed")) {
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @GetMapping("/api/v1/drills/{drillId}/teams")
    public ResponseEntity<?> searchDrillTeamsWithInitialLetters(
            @PathVariable String drillId,
            @RequestParam(required = false) String initialLetters,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.searchDrillTeamsWithInitialLetters(drillId, initialLetters, user), HttpStatus.OK);
    }

    @GetMapping("/api/v1/drills/{drillId}/teams/{teamId}")
    public ResponseEntity<?> getDrillTeams(
            @PathVariable String drillId,
            @PathVariable String teamId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.getDrillTeams(drillId, teamId, user), HttpStatus.OK);
    }

    @GetMapping("/api/v1/drills/{drillId}/teams/name")
    public ResponseEntity<Boolean> checkNameAvailability(
            @PathVariable String drillId,
            @RequestParam String teamName,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.isTeamnameAvailable(drillId, teamName, user), HttpStatus.OK);
    }

    @GetMapping("/api/v1/drills/{drillId}/users/{uId}")
    public ResponseEntity<?> fetchUserAllInfo(
            @PathVariable String drillId,
            @PathVariable String uId,
            @RequestParam(defaultValue = "NA", required = false) String action,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.fetchUserObjOrIfUserRegistered(drillId, uId, action, user), HttpStatus.OK);
    }

    @GetMapping("/api/v1/drills/{drillId}/users")
    public ResponseEntity<?> fetchAllParticipantsOfADrill(
            @PathVariable String drillId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.fetchAllDrillParticipants(drillId, user), HttpStatus.OK);
    }

//	@GetMapping("/api/v1/drills/{drillId}/participant")
//	public ResponseEntity<?> fetchAllParticipants(
//			HttpServletRequest request) throws GeneralSecurityException, IOException {
//		InternityUser user = commonUtils.setUser(request);
//		return new ResponseEntity<>(sheetsQuickstart.getSheetResponse(), HttpStatus.OK);
//	}


    @GetMapping("/api/v1/drills/{custUrl}")
    public ResponseEntity<?> fetchDrillid(
            @PathVariable String custUrl,
            HttpServletRequest request) throws GeneralSecurityException, IOException {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>("{\"drillId\":\"" + drillService.fetchDrillidFromCusturl(custUrl) + "\"}", HttpStatus.OK);
    }

    @GetMapping(value = "/api/v1/drills/participant/search")
    @ApiOperation(value = "Search Users", code = 200, response = ParticipantSearchResultDto.class)
    public ParticipantSearchResultDto searchParticipant(
            @RequestParam(defaultValue = "all", required = false) String email,
            @RequestParam(defaultValue = "all", required = false) String drillId,
            //@RequestParam(defaultValue = "all", required = false) String ctc,
            //@RequestParam(defaultValue = "all", required = false) String ectc,
            @RequestParam(defaultValue = "all", required = false) String currentLoc,
            @RequestParam(defaultValue = "all", required = false) String preferredLoc,
            @RequestParam(defaultValue = "all", required = false) String clgName,
            @RequestParam(defaultValue = "all", required = false) String clgSpecialization,
            //@RequestParam(defaultValue = "0", required = false) int clgPassingYear,
            @RequestParam(defaultValue = "all", required = false) String fullname,
            @RequestParam(defaultValue = "all", required = false) String organisation,
            //@RequestParam(defaultValue = "0.0", required = false) double yearsOfExperience,
            //@RequestParam(defaultValue = "true", required = false) boolean isServingNoticePeriod,
            @RequestParam(defaultValue = "all", required = false) String noticePeriod,
            @RequestParam(defaultValue = "all", required = false) String participantState,
            @RequestParam(defaultValue = "all", required = false) String registrationStartDate,
            @RequestParam(defaultValue = "all", required = false) String registrationEndDate,
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10", required = false) int limit,
            @RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,

            HttpServletRequest request) {
        try {
            SearchParticipantCriteria searchCriteria = SearchParticipantCriteria.builder()
                    .email(email)
                    .drillId(drillId)
                    .participantState(participantState)
                    //.ctc(ctc)
                    //.ectc(ectc)
                    .currentLoc(currentLoc)
                    .preferredLoc(preferredLoc)
                    .clgName(clgName)
                    .clgSpecialization(clgSpecialization)
                    //.clgPassingYear(clgPassingYear)
                    .fullname(fullname)
                    .organisation(organisation)
                    //.yearsOfExperience(yearsOfExperience)
                    //.isServingNoticePeriod(isServingNoticePeriod)
                    .noticePeriod(noticePeriod)
                    .registrationEndDate(registrationEndDate)
                    .registrationStartDate(registrationStartDate)
                    .build();
            return drillService.searchParticipants(searchCriteria, offset, limit, order, profile.name());
        } catch (Exception e) {
            return null;
        }
    }

    @GetMapping(value = "/api/v1/drills/participant/search/download")
    @ApiOperation(value = "Search Users", code = 200, response = ParticipantSearchResultDto.class)
    public ResponseEntity<InputStreamResource> downloadSearchDrillParticipantResult(
            @RequestParam(defaultValue = "all", required = false) String email,
            @RequestParam(defaultValue = "all", required = false) String drillId,
            //@RequestParam(defaultValue = "all", required = false) String ctc,
            //@RequestParam(defaultValue = "all", required = false) String ectc,
            @RequestParam(defaultValue = "all", required = false) String currentLoc,
            @RequestParam(defaultValue = "all", required = false) String preferredLoc,
            @RequestParam(defaultValue = "all", required = false) String clgName,
            @RequestParam(defaultValue = "all", required = false) String clgSpecialization,
            //@RequestParam(defaultValue = "0", required = false) int clgPassingYear,
            @RequestParam(defaultValue = "all", required = false) String fullname,
            @RequestParam(defaultValue = "all", required = false) String organisation,
            @RequestParam(defaultValue = "all", required = false) String participantState,
            //@RequestParam(defaultValue = "0.0", required = false) double yearsOfExperience,
            //@RequestParam(defaultValue = "true", required = false) boolean isServingNoticePeriod,
            @RequestParam(defaultValue = "all", required = false) String noticePeriod,
            @RequestParam(defaultValue = "all", required = false) String registrationStartDate,
            @RequestParam(defaultValue = "all", required = false) String registrationEndDate,
            @RequestParam(defaultValue = "0") int offset,
            @RequestParam(defaultValue = "10", required = false) int limit,
            @RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
            HttpServletRequest request, HttpServletResponse response) {
        SearchParticipantCriteria searchCriteria = SearchParticipantCriteria.builder()
                .email(email)
                .drillId(drillId)
                .participantState(participantState)
                //.ctc(ctc)
                //.ectc(ectc)
                .currentLoc(currentLoc)
                .preferredLoc(preferredLoc)
                .clgName(clgName)
                .clgSpecialization(clgSpecialization)
                //.clgPassingYear(clgPassingYear)
                .fullname(fullname)
                .organisation(organisation)
                //.yearsOfExperience(yearsOfExperience)
                //.isServingNoticePeriod(isServingNoticePeriod)
                .noticePeriod(noticePeriod)
                .registrationEndDate(registrationEndDate)
                .registrationStartDate(registrationStartDate)
                .build();
        List<DrillParticipantDto> participantDtos = drillService.downloadSearchParticipants(searchCriteria, offset, limit, order, profile.name());
        System.out.println(participantDtos);
        String filename = "drillparticipants.csv";

        InputStreamResource file = new InputStreamResource(drillService.getCSVLoad(participantDtos, drillId), drillId);


        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/csv"))
                .body(file);
    }

    @GetMapping(value = "api/v1/drills/commons")
    public ResponseEntity<Map<String, List<String>>> getHackathonOptions() {
        try {
            return new ResponseEntity<>(drillService.getHackathonOption(), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/api/v1/drills/listDrill")
    public ResponseEntity<?> listAllDrill(
            @RequestParam(required = true) String uId,
            @RequestParam(defaultValue = "BASIC", required = false) SearchProfile profile,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return new ResponseEntity<>(drillService.listActiveandPreviousDrills(uId, user, profile.name()), HttpStatus.OK);
    }

    @DeleteMapping("api/v1/drills/{drillId}/{section}/{sectionId}")
    public ResponseEntity<Boolean> deleteDrillSection(@PathVariable String drillId,
                                                      @PathVariable String sectionId,
                                                      @PathVariable DrillSectionEnum section) {
        try {
            return new ResponseEntity<>(drillService.deleteSection(drillId, section, sectionId), HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(false, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/api/v1/drills/feeds/sendinvitemail")
    public ResponseEntity<?> sendEmailToInviteForDrill(@RequestParam(required = false, defaultValue = "NA") String emailIdList,
                                                       @RequestParam(required = false, defaultValue = "NA") String uId,
                                                       @RequestParam(required = false, defaultValue = "NA") String drillId,
                                                       HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            Map<String, String> result = drillService.sendMailForDrillInvite(uId, drillId, emailIdList, user);
            return new ResponseEntity(result, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "An error occurred while " +
                    "sending the email"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping("/api/v1/drills/{drillId}/requests/publish")
    public ResponseEntity<?> sendPublishOrUnpublishRequestToAdmin(@PathVariable String drillId, @RequestBody DrillPublishRequestsDto payload,
                                                                  HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.sendPublishOrUnpublishRequestToAdmin(drillId, payload, user);

    }

    @PostMapping("/api/v1/drills/{drillId}/requests/publish/{status}")

    public ResponseEntity<?> acceptOrRejectRequestForPublishOrUnpublishDrill(@PathVariable String drillId,
                                                                             @PathVariable boolean status,
                                                                             @RequestParam String uId,
                                                                             HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);

        return drillService.acceptOrRejectRequestForPublishOrUnpublishDrill(drillId, status, uId, user);

    }

    @GetMapping("/api/v1/drills/{drillId}/requests/currentstate/publish")
    public ResponseEntity<?> getCurrentStateOfDrillRequest(@PathVariable String drillId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.getCurrentStateOfDrillRequest(drillId, user);
    }


    @GetMapping("/api/v1/drills/{drillId}/requests/publish")
    public ResponseEntity<Boolean> fetchPublishRequestOfADrill(
            @PathVariable String drillId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.fetchPublishRequest(drillId, user);
    }

    @GetMapping("/api/v1/drills/{drillId}/requests/publish/validate")
    public ResponseEntity<?> validateDrillBeforePublish(
            @PathVariable String drillId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.validateDrill(drillId, user);
    }

    @PostMapping("api/v1/drills/{drillId}/participantFields/configure")
    public ResponseEntity<?> addorUpdateParticipantFields(@RequestBody List<ConfigureParticipantFields> payload,
                                                          HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            List<ConfigureParticipantFields> result = drillService.saveOrUpdateParticipantFields(payload, user);

            if (result != null) {
                return new ResponseEntity<>(result, HttpStatus.OK);
            } else {
                Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save or update participant fields");
                return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Error while saving or updating participant fields: " + e.getMessage(), e);
            Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save or update participant fields");
            return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("api/v1/drills/{drillId}/participantFields")
    public ResponseEntity<?> fetchDrillParticipantFields(@PathVariable String drillId, HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            List<ConfigureParticipantFields> fields = drillService.fetchDrillParticipantFields(drillId, user);

            if (fields != null) {
                return new ResponseEntity<>(fields, HttpStatus.OK);
            } else {
                Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch drill participant fields");
                return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Error while fetching drill participant fields: " + e.getMessage(), e);
            Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch drill participant fields");
            return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("api/v1/drills/participantFields/default")
    public ResponseEntity<?> addorUpdateDefaultParticipantFields(@RequestBody DefaultParticipantFields payload,
                                                                 HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            DefaultParticipantFields result = drillService.saveOrUpdateDefaultParticipantFields(payload, user);

            if (result != null) {
                return new ResponseEntity<>(result, HttpStatus.OK);
            } else {
                Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save or update default participant fields");
                return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Error while saving or updating default participant fields: " + e.getMessage(), e);
            Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save or update default participant fields");
            return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("api/v1/drills/participantFields/default")
    public ResponseEntity<?> fetchDefaultParticipantFields(HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            List<DefaultParticipantFields> fields = drillService.fetchDefaultParticipantFields(user);

            if (fields.isEmpty()) {
                Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch the default participant fields");
                return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
            }

            return new ResponseEntity<>(fields, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while fetching default participant fields: " + e.getMessage(), e);
            Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to fetch the default participant fields");
            return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping(value = "api/v1/drills/{drillId}/phases/{phaseId}/importParticipants", consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<?> readFromFile(
            @RequestParam(name = "file") MultipartFile file,
            @PathVariable String drillId,
            @PathVariable String phaseId,
            HttpServletRequest request) {
        try {
            Map<String, String> fieldMapping = new HashMap<>();
            fieldMapping.put("fullName", "fullName");
            fieldMapping.put("email", "email");
            fieldMapping.put("contact", "contact");
            //fieldMapping.put("clgName","Course Pursuing");
            //fieldMapping.put("clgPassingSemester","Course Stream");
            fieldMapping.put("clgSpecialization", "clgSpecialization");
            fieldMapping.put("clgPassingSemester", "clgPassingSemester");
            fieldMapping.put("clgPassingYear", "clgPassingYear");
            fieldMapping.put("clgName", "clgName");
            fieldMapping.put("teamName", "Team Name");
            fieldMapping.put("candidateType", "candidateType");
            fieldMapping.put("projectName", "Team Name");
            fieldMapping.put("participantValue", "participantValue");
            fieldMapping.put("theme", "Theme");
            fieldMapping.put("projectDescription", "projectDescription");

            List<String> str = drillService.readFromExcel(file, drillId, phaseId, fieldMapping);
            StringBuilder stringBuilder = new StringBuilder();

            for (String res : str) {
                stringBuilder.append(res + ",");
            }
            return new ResponseEntity("{\"result\":\"" + stringBuilder.toString().substring(0, stringBuilder.length() - 1) + "\"}", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("{\"Error\":\"Please fill in correct details.\"}",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("api/v1/drills/{drillId}/addJudges")
    public ResponseEntity<?> importJudges(@PathVariable String drillId,
                                          @RequestBody String payload, HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            Map<String, String> result = drillService.importJudges(payload, drillId, user);

            if (result != null) {
                return new ResponseEntity<>(result, HttpStatus.OK);
            } else {
                Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save or update default participant fields");
                return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (Exception e) {
            log.error("Error while importing judges: " + e.getMessage(), e);
            Map<String, String> errorMessage = commonUtils.message(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to save or update default participant fields");
            return new ResponseEntity<>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/api/v1/drills/{drillId}/drill")
    public ResponseEntity<?> deleteDrill(
            @PathVariable String drillId,
            @RequestParam String uId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.deleteDrill(drillId, uId, user);
    }

    @GetMapping(value = "/api/v1/drills/user/{uId}/status")
    public ResponseEntity<?> listAllParticipatedHackathon(
            @PathVariable(required = false) String uId,
            HttpServletRequest request) {
        try {
            InternityUser user = commonUtils.setUser(request);
            List<ParticipatedDrillStatusDto> participatedHackathons = drillService.listAllParticipatedHackathon(uId, user);
            return new ResponseEntity<>(participatedHackathons, HttpStatus.OK);
        } catch (Exception e) {
            // Log the exception for debugging
            log.error("Exception while fetching all participated hackathons: " + e.getMessage(), e);
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @GetMapping(value = "/api/v1/drills/{drillId}/participants/")
    public Response fetchTheCompleteTrackOfHackathon(
            @PathVariable(required = false) String drillId,
            @RequestParam(defaultValue = "NA", required = false) String participantId,
            @RequestParam(defaultValue = "NA", required = false) String uId,
            @RequestParam(defaultValue = "NA", required = false) String phaseId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        Response participatedHackathons = drillService
                .fetchTheCompleteTrackOfHackathon(drillId, participantId, uId, phaseId, user);
        return participatedHackathons;
    }

    @PostMapping(value = "/api/v1/drills/{drillId}/participants/invite")
    public Response inviteParticipantsForInviteOnlyDrill(
            @PathVariable String drillId,
            @RequestBody DrillParticipantsInviteOnlyRequestDto payload,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.inviteParticipantsForInviteOnlyDrill(drillId, payload, user);
    }

    @GetMapping(value = "/api/v1/drills/participants/{participantId}")
    public Response getDrillParticipant(@PathVariable String participantId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.getDrillParticipantByParticipantId(participantId, user);
    }

    @GetMapping("/api/v1/drill/{drillId}/participant/fields")
    public Response getParticipantFields(
            @PathVariable String drillId,
            HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.getParticipantFields(drillId, user);
    }

    @PutMapping("/api/v1/drill/{drillId}/participant/fields")
    public Response saveParticipantFields(
            @PathVariable String drillId,
            @RequestBody Map<String, Boolean> participantFieldMap,
            HttpServletRequest request) {

        InternityUser user = commonUtils.setUser(request);
        return drillService.saveParticipantFields(drillId, participantFieldMap, user);
    }

    @PostMapping("/api/v1/drill/{drillId}/paymentconfigurations")
    public Response saveDrillPaid(@PathVariable String drillId,
                                  @RequestBody Map<DrillParticipantType,Long> participantTypeAmountMap,
                                  HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.saveDrillPaidDetails(drillId, participantTypeAmountMap, user);
    }

    @GetMapping("/api/v1/drill/{drillId}/paymentconfigurations")
    public Response getPaidDrillDetails(@PathVariable String drillId, HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.getPaidDrillDetails(drillId, user);
    }

    @PutMapping("/api/v1/drill/participants/{participantId}/paid/paymentstatus")
    public Response updateParticipantPaymentStatus(@PathVariable String participantId,
                                                   @RequestParam PaymentStatus paymentStatus,
                                                   HttpServletRequest request){
        InternityUser user = commonUtils.setUser(request);
        return drillService.updateParticipantPaymentStatusDetails(participantId,paymentStatus,user);
    }

    @PostMapping("/api/v1/drills/{drillId}/participants/{participantId}/paymentstaus/{paymentStatus}/mail")
    public Response sendMailForParticipantPayments(@PathVariable String drillId,
                                                   @PathVariable String participantId,
                                                   @PathVariable PaymentStatus paymentStatus,
                                                   @RequestParam String transactionId,
                                                   @RequestParam Double transactionAmount,
                                                   @RequestParam String date,
                                                   HttpServletRequest request) {
        InternityUser user = commonUtils.setUser(request);
        return drillService.sendMailForParticipantPaymentReceived(drillId,participantId,paymentStatus,transactionId,transactionAmount,date,user);

    }

}
