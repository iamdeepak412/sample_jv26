package com.wue.controller.drill;

import com.wue.domain.drill.mails.DrillMailTemplate;
import com.wue.dto.drill.DrillMail;
import com.wue.model.EmailContent;
import com.wue.repository.drill.DrillRepository;
import com.wue.service.drill.DrillService;
import com.wue.service.drill.DrillSubmissionService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import com.wue.util.SendMessageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/")
public class DrillMailController {

	@Autowired
	DrillRepository drillRepository;

	@Autowired
	DrillService drillService;

	@Autowired
	DrillSubmissionService drillSubmissionService;

	@Autowired
	CommonUtils commonUtils;

	@Autowired
	SendMessageUtils sendMessageUtils;

	@GetMapping("api/v1/drills/mails/participantTypes")
	public ResponseEntity<?> getParticipantTypes(HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService.fetchParticipantTypes(user), HttpStatus.OK);
	}

	@PostMapping("api/v1/drills/{drillId}/mails/templates")
	public ResponseEntity<?> addOrUpdateMailTemplates(@RequestBody DrillMailTemplate payload,
			@PathVariable String drillId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService.addOrUpdateMailTemplates(payload, drillId, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/mails/templates")
	public ResponseEntity<?> getMailTemplates(@PathVariable String drillId,
											  @RequestParam(defaultValue = "NA", required = false) String templateId,
											  HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillSubmissionService.fetchMailTemplates(drillId, templateId, user), HttpStatus.OK);
	}

	@PostMapping("/api/v1/drills/{drillId}/mails")
	public ResponseEntity<?> sendMailToDifferentUsers(
			@PathVariable String drillId,
			@RequestBody DrillMail drillMail,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillService.sendMailToDifferentUsers(drillId, drillMail, user), HttpStatus.OK);
	}

	@PostMapping("/api/v1/drills/{drillId}/mailsWithAttachment")
	public ResponseEntity<?> sendMailWithAttachments(
			@RequestParam String drillId,
			@ModelAttribute EmailContent emailContent,
			@RequestParam ("file") MultipartFile FileToAttach,
			HttpServletRequest request) throws MessagingException {
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(sendMessageUtils.sendMailWithAttachment(drillId, emailContent,user,FileToAttach), HttpStatus.OK);
	}

}
