package com.wue.controller.drill;

import com.wue.domain.drill.judgement.DrillAssignPanel;
import com.wue.domain.drill.judgement.DrillJudgementPanel;
import com.wue.repository.drill.DrillRepository;
import com.wue.service.drill.DrillJudgementService;
import com.wue.service.drill.DrillService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/")
public class DrillJudgementController {

	@Autowired
	DrillRepository drillRepository;

	@Autowired
	DrillService drillService;

	@Autowired
	DrillJudgementService drillJudgementService;

	@Autowired
	CommonUtils commonUtils;

	@GetMapping("api/v1/drills/{drillId}/panels")
	public ResponseEntity<?> fetchJudgementPanels(
			@RequestParam(defaultValue = "NA", required = false) String panelId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@PathVariable String drillId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillJudgementService.fetchPanelList(drillId, phaseId, panelId, user), HttpStatus.OK);
	}

	@GetMapping("api/v1/drills/{drillId}/judges/{judgeId}")
	public ResponseEntity<?> fetchJudge(
			@PathVariable String drillId,
			@PathVariable String judgeId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillJudgementService.fetchJudgeDetails(drillId, judgeId, user), HttpStatus.OK);
	}

	@PostMapping("api/v1/drills/{drillId}/panels")
	public ResponseEntity<?> addOrUpdateJudgementPanel(
			@RequestBody DrillJudgementPanel payload,
			@PathVariable String drillId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		payload.setDrillId(drillId);
		return new ResponseEntity<>(drillJudgementService.addOrUpdatePanel(payload, user), HttpStatus.OK);
	}

	@DeleteMapping("api/v1/drills/{drillId}/panels/{panelId}")
	public ResponseEntity<?> deletePanel(
			@PathVariable String panelId,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillJudgementService.deletePanel(panelId, user), HttpStatus.OK);
	}


	@GetMapping("api/v1/drills/{drillId}/panels/{panelId}/assignjudges")
	public ResponseEntity<?> fetchJudgesFromPanel(
			@PathVariable String panelId,
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillJudgementService.fetchAssignedJudgesList(drillId, phaseId, panelId, user), HttpStatus.OK);
	}

  @PostMapping("api/v1/drills/{drillId}/panels/{panelId}/assign/{type}")
  public ResponseEntity<?> assignJudgesToPanel(
      @RequestBody DrillAssignPanel payload,
      @PathVariable String drillId,
	  @PathVariable String panelId,
	  @PathVariable String type,
	  @RequestParam(defaultValue = "NA", required = false) String phaseId,
	  HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
        if (type.equalsIgnoreCase("judge")) {
            return drillJudgementService.assignPanelv3(
                    payload, drillId, phaseId, panelId, type, user);
		}else if (type.equalsIgnoreCase("submission")){
			return drillJudgementService.assignSubmissionv3(
					payload, drillId, phaseId, panelId, type, user);
		}
		return null;
	}
	@PostMapping("api/v1/drills/{drillId}/judges/mail")
	public ResponseEntity<?> sendInviteLinkToJudges(
			@RequestParam(defaultValue = "NA", required = false) String panelId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "NA", required = false) String judgeId,
			@PathVariable String drillId,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		return new ResponseEntity<>(drillJudgementService.sendMailInviteLinkToJudges(drillId, phaseId, panelId, judgeId, offset,limit,order, user), HttpStatus.OK);
	}

//	@PostMapping("api/v1/drills/{drillId}/mails")
//	public ResponseEntity<?> sendMail(
//			@RequestParam(required = false) String mailTemplate,
//			@RequestParam(required = false) String receiverUniqueId,
//			@RequestParam(required = false) Map<String, String> msgDetails,
//			HttpServletRequest request
//			){
//		InternityUser user = commonUtils.setUser(request);
//		return drillJudgementService.sendInviteLinkToJudge(mailTemplate, receiverUniqueId, msgDetails);
//	}

  @GetMapping("api/v1/drills/{drillId}/panels/{panelId}/assignjudges/download")
	public ResponseEntity<?> downloadJudgesFromPanel(
			@PathVariable String panelId,
			@PathVariable String drillId,
			@RequestParam(defaultValue = "NA", required = false) String phaseId,
			@RequestParam(defaultValue = "0") int offset,
			@RequestParam(defaultValue = "10", required = false) int limit,
			@RequestParam(defaultValue = "updatedTs.desc", required = false) String order,
			HttpServletRequest request){
		InternityUser user = commonUtils.setUser(request);
		HttpHeaders responseHeaders = new HttpHeaders();
	    responseHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	    responseHeaders.setContentDisposition(
	            ContentDisposition.builder("inline").filename("List of Panels with the Judges.xlsx").build());
		return new ResponseEntity<>(drillJudgementService.downloadAssignedJudgesList(drillId, phaseId, panelId,offset,limit,order, user),responseHeaders, HttpStatus.OK);
	}
}
