package com.wue.controller.certificate;

import com.wue.dto.certificategenerator.CertificateGenerator;
import com.wue.service.certificategenerator.CertificateGeneratorService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.http.*;


import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("/")
@RestController
public class CertificateGeneratorController {

	@Autowired
	CertificateGeneratorService certificateGeneratorService;
	
	@Autowired
	CommonUtils utils;

	@PostMapping("/api/v1/certificates")
	public ResponseEntity<?> saveCertificateUrl(@RequestBody CertificateGenerator payload, HttpServletRequest request){
		InternityUser internityUser = utils.setUser(request);
		return certificateGeneratorService.saveCertificateUrl(payload, internityUser);
	}

	@PostMapping("api/v1/certificates/generate")
	public ResponseEntity<?> generateCertificate(
			@RequestParam String eventId,
			@RequestParam String eventType,
			@RequestParam(defaultValue = "NA", required = false) String positionOrder,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return new ResponseEntity<>(certificateGeneratorService.saveCertificateToDB(eventId,eventType,positionOrder,user), HttpStatus.OK);
	}

	@GetMapping("api/v1/certificates/participants")
	public ResponseEntity<?> fetchCertificateUrlForParticipant(
			@RequestParam(defaultValue = "NA", required = false) String participantId,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return new ResponseEntity<>(certificateGeneratorService.fetchCertificateUrl(participantId, user), HttpStatus.OK);
	}

	@PostMapping("api/v1/drills/{drillId}/certificates/sendmail")
	public ResponseEntity<?> sendMail(
			@RequestParam String eventId,
			@RequestParam String eventType,
			@RequestParam(defaultValue = "NA", required = false) String positionType,
			@RequestParam(defaultValue = "NA", required = false) String email,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return new ResponseEntity<>(certificateGeneratorService
				.sendMailToParticipants(eventId,eventType,positionType,email,user), HttpStatus.OK);
	}
	
	@PostMapping("api/v1/certificates/saveImageUrl")
	public ResponseEntity<?> saveImageUrlToDB(
			@RequestParam String eventId,
			@RequestParam String eventType,
			@RequestParam("file") MultipartFile multipartFile,
			@RequestParam(value="json", required=true)String imageTitleAxis,
			@RequestParam(defaultValue = "NA", required = false) String positionType,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return new ResponseEntity<>(certificateGeneratorService.saveImageUrlToDB(eventId,eventType,positionType,multipartFile,imageTitleAxis, user), HttpStatus.OK);
	}
	
//	@PostMapping("api/v1/certificates/generateBoardingPass")
//	public ResponseEntity<?> generateBoardingPass(
//			@RequestParam String eventId,
//			@RequestParam String participantId,
//			HttpServletRequest request){
//		InternityUser user = utils.setUser(request);
//		return new ResponseEntity<>(certificateGeneratorService.generateBoardingPass(eventId,participantId, user), HttpStatus.OK);
//	}
	@PostMapping("api/v1/certificates/upload")
	public ResponseEntity<?> uploadFileToS3(
			@RequestParam String eventId,
			@RequestParam String eventType,
			@RequestParam("file") MultipartFile multipartFile,
//			@RequestParam String imageTitleAxis,
			@RequestParam(defaultValue = "NA", required = false) String positionType,
			HttpServletRequest request){
		InternityUser user = utils.setUser(request);
		return new ResponseEntity<>(certificateGeneratorService.uploadFileToS3(eventId,eventType,positionType,multipartFile, user), HttpStatus.OK);
	}
	@PostMapping("api/v1/certificates/generatecertificate")
    public Map<String, byte[]> generateCertificateImage(@RequestParam String imageUrl, 
    		                                          @RequestBody List<String> details) throws IOException {
        byte[] certificateImage = certificateGeneratorService.generateCertificate(imageUrl,details);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_JPEG);
        headers.setContentLength(certificateImage.length);
        Map<String, byte[]> image = new HashMap<>();
        image.put("image", certificateImage);
        return image;
    }
}
