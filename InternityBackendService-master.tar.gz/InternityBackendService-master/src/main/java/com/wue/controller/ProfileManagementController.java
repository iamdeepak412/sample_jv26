package com.wue.controller;

import com.wue.constant.ProfileSectionEnum;
import com.wue.constant.UserProfileOtherDetailsType;
import com.wue.domain.*;
import com.wue.repository.*;
import com.wue.service.ProfileManagementService;
import com.wue.util.CommonUtils;
import com.wue.util.InternityUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@Log4j2
@RequestMapping("/")
public class ProfileManagementController {

	@Autowired
	CommonUtils commonUtils;

	@Autowired
	ProfileManagementService profileManagementService;

	@Autowired
	UserProfileRepository personalDetailsRepository;

	@Autowired
	EducationInformationRepository eduInformationRepository;

	@Autowired
	UserProjectRepository userProjectRepository;

	@Autowired
	UserSkillRepository userSkillRepository;

	@Autowired
	WorkProfileRepository workProfileRepository;

	@Deprecated
	@PutMapping(value = "api/v1/users/profile/{section}")
	public ResponseEntity<String> addProfile(@PathVariable String section,
											 @RequestBody Map<String, Object> requestPayload, HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			if (profileManagementService.update(requestPayload, section, user)) {
				return new ResponseEntity<>("{\"msg\":\"User profile section created successfully!\"}", HttpStatus.CREATED);
			}
		} catch (Exception e) {
			log.error("Exception while saving the profile details{}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@DeleteMapping(value = "api/v1/users/profile/{section}")
	public ResponseEntity<String> deleteProfileSection(@PathVariable String section,
													   @RequestParam Long id, HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			if (profileManagementService.delete(id, section, user)) {
				return new ResponseEntity<>("{\"msg\":\"User profile section deleted successfully!\"}", HttpStatus.CREATED);
			}
		} catch (Exception e) {
			log.error("Exception while saving the profile details{}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value = "api/v1/users/profile/personal")
	public ResponseEntity<String> addPersonalDetails(@RequestBody UserPersonalDetail requestPayload,
													 HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			String uId = user.getUId();

			/*TO DO
				change requestPayload.getUId() to uId fetched from request header
			 */
			Optional<UserPersonalDetail> record = personalDetailsRepository.findByuId(requestPayload.getUId());
			if (record.isPresent()) {
				log.info("record is already present for uid {}", record.get());
				requestPayload.setPersonalDetailsCount(record.get().getPersonalDetailsCount());
			}
			log.info("record {}", requestPayload);
			personalDetailsRepository.save(requestPayload);
			log.info("Personal details saved successfully");
			return new ResponseEntity<>("{\"msg\":\"Personal Details Saved\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while saving the personal {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct personal details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value = "api/v1/users/profile/education")
	public ResponseEntity<String> addEducationDetails(@RequestBody EducationInformation requestPayload,
													  HttpServletRequest request) {
		try {
			eduInformationRepository.save(requestPayload);
			log.info("Education details saved successfully");
			return new ResponseEntity<>("{\"msg\":\"Education Details Saved\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while saving the education details {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct education details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value = "api/v1/users/profile/project")
	public ResponseEntity<String> addProjectDetails(@RequestBody UserProject requestPayload,
													HttpServletRequest request) {
		try {
			userProjectRepository.save(requestPayload);
			log.info("Project details saved successfully");
			return new ResponseEntity<>("{\"msg\":\"Project Details Saved\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while saving the project {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct project details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value = "api/v1/users/profile/work")
	public ResponseEntity<String> addWorkProfile(@RequestBody UserWorkProfile requestPayload, HttpServletRequest request) {
		try {
			workProfileRepository.save(requestPayload);
			log.info("Work profile saved successfully");
			return new ResponseEntity<>("{\"msg\":\"Work Profile Saved\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while saving the work profile {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct work profile details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value = "api/v1/users/profile/skill")
	public ResponseEntity<String> addUserSkills(@RequestBody UserSkill requestPayload, HttpServletRequest request) {
		try {
			profileManagementService.saveSkill(requestPayload);
			log.info("User skills saved successfully");
			return new ResponseEntity<>("{\"msg\":\"User Skills Saved\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while saving the skill {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct skill details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PostMapping(value = "api/v1/users/profile/other/{section}")
	public ResponseEntity<String> addUserOtherDetails(@RequestBody UserProfileOtherDetailsv2 requestPayload,
													  HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			profileManagementService.saveOtherDetailsv2(requestPayload, user);

			log.info("User other details saved successfully");
			return new ResponseEntity<>("{\"msg\":\"User Other details saved successfully\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while saving the other details {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct other details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value = "api/v1/users/profile/other/{section}")
	public ResponseEntity<String> updateUserOtherDetails(@RequestBody UserProfileOtherDetailsv2 requestPayload,
													  HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			profileManagementService.updateOtherDetailsv2(requestPayload, user);

			log.info("User other details updated successfully");
			return new ResponseEntity<>("{\"msg\":\"User Other details Updated\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while updating the other details {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct other details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@DeleteMapping(value = "api/v1/users/profile/other/{section}/{sectionId}")
	public ResponseEntity<String> addUserOtherDetails(@PathVariable("sectionId") Long sectionId,
													  HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			profileManagementService.deleteOtherDetailsv2(sectionId, user);

			log.info("User other details deleted successfully");
			return new ResponseEntity<>("{\"msg\":\"User Other details deleted successfully\"}", HttpStatus.CREATED);
		} catch (Exception e) {
			log.error("Exception while deleting the other details {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct other details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@GetMapping(value = "api/v1/users/profile/other/{section}")
	public ResponseEntity<?> fetchUserOtherDetails(@PathVariable("section") UserProfileOtherDetailsType section,
												   @RequestParam("uId") String uId, HttpServletRequest request) {
		try {
			InternityUser user = commonUtils.setUser(request);
			return profileManagementService.fetchOtherDetailsv2(section, uId, user);
		} catch (Exception e) {
			log.error("Exception while fetching the other details {}", e);
		}
		return new ResponseEntity<>("{\"msg\":\"Please fill in correct skill details.\"}", HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@GetMapping(value = "api/v1/users/profile/{section}")
	public ResponseEntity<?> fetchProfileSection(@PathVariable String section, @RequestParam("uId") String uId,
												 HttpServletRequest request) throws Exception {
		try {
			List<?> profileSection = profileManagementService.fetchSection(section, uId);
			if (null != profileSection) {
				if (section.equalsIgnoreCase(ProfileSectionEnum.PERSONAL.name())
						|| section.equalsIgnoreCase(ProfileSectionEnum.OTHER.name())) {
					return new ResponseEntity<>(profileSection.get(0), HttpStatus.OK);
				}
				return new ResponseEntity<>(profileSection, HttpStatus.OK);
			} else {
				throw new Exception("No Details found for this user");
			}
		} catch (Exception e) {
			log.error("Error in fetching profile section {}", e.getMessage());
			return new ResponseEntity<>("Failed to fetch profile section for user {}", HttpStatus.INTERNAL_SERVER_ERROR);
			//throw e;
		}
	}

	@GetMapping(value = "api/v1/users/profile/common/{section}")
	public ResponseEntity<?> fetchCommonFieldsPerSection(
			@PathVariable String section,
			@RequestParam(name = "uId", required = false) String uId,
			HttpServletRequest request) throws Exception {
		try {
			Map<String, Object> profileSection = profileManagementService.fetchCommonFields(section, uId);
			if (null != profileSection) {
				return new ResponseEntity<>(profileSection, HttpStatus.OK);
			} else {
				throw new Exception("No Details found");
			}
		} catch (Exception e) {
			log.error("Error in fetching profile section {}", section);
			throw e;
		}
	}

	@GetMapping(value = "api/v1/users/profile/completion/{uId}")
	public ResponseEntity<?> fetchCommonFieldsPerSection(
			@PathVariable String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return profileManagementService.findCompletePercentage(uId, user);
	}

	@GetMapping(value = "api/v1/users/profile/resume")
	public ResponseEntity<?> isResumeUploadedByUser(
			@RequestParam String uId,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return profileManagementService.findByUidAndResumeLinkIsNull(uId, user);
	}

	@PutMapping(value = "api/v1/users/profile/{uId}/upload")
	public ResponseEntity<?> uploadResume(
			@PathVariable String uId,
			@RequestBody UserUploadLink userUploadLink,
			HttpServletRequest request) {
		InternityUser user = commonUtils.setUser(request);
		return profileManagementService.saveUploadLink(uId, userUploadLink,user);
	}

}
