package com.wue.controller;

import com.wue.domain.ContactUs;
import com.wue.repository.ContactUsRepository;
import com.wue.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/")
public class ContactUsController {

	@Autowired
	ContactUsRepository contactUsRepository;

	@Autowired
	CommonService commonService;

	@PostMapping("api/v1/contactus")
	public ResponseEntity<ContactUs> addOrUpdate(@RequestBody ContactUs payload, HttpServletRequest request){
		return new ResponseEntity<>(commonService.addContactUsQuery(payload), HttpStatus.OK);
	}
	
	@GetMapping("api/v1/contactus")
	public ResponseEntity<List<ContactUs>> fetchTestimonials(HttpServletRequest request){
		return new ResponseEntity<>(contactUsRepository.findAllByIsVisibleOrderByCreatedtsDesc(true), HttpStatus.OK);
	}
	
	@DeleteMapping("api/v1/contactus/{action}")
	public ResponseEntity<String> updateVisibility(@RequestParam Long id,
												   @PathVariable boolean action, HttpServletRequest request){
		try {
			Optional<ContactUs> contactUsObj = contactUsRepository.findById(id);
			if(contactUsObj.isPresent()){
				ContactUs contactUs = contactUsObj.get();
				contactUs.setVisible(false);
				contactUsRepository.save(contactUs);
			}
			return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<>("Delete operations failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
