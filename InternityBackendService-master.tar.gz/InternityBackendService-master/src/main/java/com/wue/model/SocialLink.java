package com.wue.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@Table(name = "social_link")
public class SocialLink implements Serializable {
    private static final long serialVersionUID = 7153465824760053247L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    @Column(name = "platform")
    private String platform;

    @Column(name = "link")
    private String link;

    @Column(name = "profile_id")
    private Integer profileId;

}
