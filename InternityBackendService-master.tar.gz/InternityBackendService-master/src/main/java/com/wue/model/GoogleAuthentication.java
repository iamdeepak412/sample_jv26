package com.wue.model;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class GoogleAuthentication {
    private String credential;
}
