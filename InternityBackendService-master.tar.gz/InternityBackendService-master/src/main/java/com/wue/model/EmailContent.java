package com.wue.model;

import java.util.Map;

public class EmailContent {

    private String subject;
    private String heading;
    private String message;
    private String link;
    private String templateName;
    private String otp;
    private String userName;
    private String mobile;
    private String cc;
    private String bcc;
	private String jobId;
	private String resumeLink ;
	private String to;
    private String unsubscribeLink;
    private Map<String, String> customerDetails;

    public EmailContent() {
    }

    public EmailContent(String subject, String heading, String message, String link, String templateName, String otp,String to,String unsubscribeLink, Map<String, String> customerDetails) {
        this.subject = subject;
        this.heading = heading;
        this.message = message;
        this.link = link;
        this.templateName = templateName;
        this.otp = otp;
        this.to = to;
        this.unsubscribeLink = unsubscribeLink;
        this.customerDetails = customerDetails;
    }

    public EmailContent(String subject, String heading, String message, String link, String templateName, String otp, String cc, String bcc,String to,String unsubscribeLink, Map<String, String> customerDetails) {
        this.subject = subject;
        this.heading = heading;
        this.message = message;
        this.link = link;
        this.templateName = templateName;
        this.otp = otp;
        this.cc = cc;
        this.bcc = bcc;
        this.to = to;
        this.unsubscribeLink = unsubscribeLink;
        this.customerDetails = customerDetails;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCc() {
        return cc;
    }

    public void setCc(String cc) {
        this.cc = cc;
    }

    public String getBcc() {
        return bcc;
    }

    public void setBcc(String bcc) {
        this.bcc = bcc;
    }
    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

	public void setJobId(String jobId) {
		this.jobId = jobId;
		// TODO Auto-generated method stub
		
	}

	public void setResumeLink(String resumeLink) {
		this.resumeLink = resumeLink;
		// TODO Auto-generated method stub
		
	}
	
	public String getUnsubscribeLink() {
        return unsubscribeLink;
    }

    public void setUnsubscribeLink(String unsubscribeLink) {
        this.unsubscribeLink = unsubscribeLink;
    }

    public Map<String, String> getCustomerDetails() {
        return customerDetails;
    }

    public void setCustomerDetails(Map<String, String> customerDetails) {
        this.customerDetails = customerDetails;
    }
}

