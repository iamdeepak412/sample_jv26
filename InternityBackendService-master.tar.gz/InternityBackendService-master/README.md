# InternityBackendService

## How to run the service

> in application.properties, add the MySQL configuration information as per your system

Either directly run the project in your IDE or run
> mvn spring-boot:run
> mvn clean install

